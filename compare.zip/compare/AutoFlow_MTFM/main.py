
import os
import sys
import json
import time
import argparse
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional

import numpy as np
import torch
from torch.utils.data import DataLoader, SubsetRandomSampler

PROJECT_ROOT = Path(__file__).parent.absolute()
sys.path.insert(0, str(PROJECT_ROOT))

try:
    from config import (
        DEEPSEEK_API_KEY, DEEPSEEK_BASE_URL, DEEPSEEK_MODEL,
        DATA_PATH, EMBEDDING_PATH, CHECKPOINT_PATH, LOG_PATH,
        TRAIN_EPOCHS, BATCH_SIZE, USE_ROBERTA,
        AUTO_EPOCHS, WORKFLOW_METHOD
    )
    print("[Config] ✓ 已加载 config.py 配置文件")
except ImportError:
    print("[Config] ✗ 未找到 config.py，使用默认配置")
    DEEPSEEK_API_KEY = None
    DEEPSEEK_BASE_URL = "https://api.deepseek.com/v1"
    DEEPSEEK_MODEL = "deepseek-chat"
    DATA_PATH = "./data"
    EMBEDDING_PATH = "./embedding"
    CHECKPOINT_PATH = "./checkpoints"
    LOG_PATH = "./logs"
    TRAIN_EPOCHS = 100
    BATCH_SIZE = 128
    USE_ROBERTA = False
    AUTO_EPOCHS = 30
    WORKFLOW_METHOD = "simple"

from autoflow import AutoFlowGenerator, Flow, make_execute_func
from mtfm import MTFM, MTFMRoBERTa, MTFMConfig, MTFMTrainer
from tools import TextDataset, MashupDataset, get_indices, create_data_loaders


class AutoFlowMTFMSystem:
    
    def __init__(self,
                 data_path: str = None,
                 embedding_path: str = None,
                 model_path: str = None,
                 use_roberta: bool = None,
                 deepseek_api_key: str = None,
                 auto_model_name: str = None):
        print("=" * 60)
        print("AutoFlow + MTFM 整合系统 - 完整版")
        print("=" * 60)
        
        self.data_path = Path(data_path or DATA_PATH)
        self.embedding_path = Path(embedding_path or EMBEDDING_PATH)
        self.use_roberta = use_roberta if use_roberta is not None else USE_ROBERTA
        api_key = deepseek_api_key or DEEPSEEK_API_KEY
        model_name = auto_model_name or DEEPSEEK_MODEL
        
        print("\n[1] 加载ProgrammableWeb数据集...")
        self.dataset = TextDataset(
            str(self.data_path),
            str(self.embedding_path),
            use_roberta=self.use_roberta
        )
        
        print(f"\n[2] 初始化MTFM模型 (use_roberta={self.use_roberta})...")
        self.mtfm_config = MTFMConfig(self.dataset)
        
        if self.use_roberta:
            self.mtfm_model = MTFMRoBERTa(self.mtfm_config)
        else:
            self.mtfm_model = MTFM(self.mtfm_config)
        
        self.mtfm_model.to(self.mtfm_config.device)
        
        self.model_path = Path(model_path) if model_path else PROJECT_ROOT / "checkpoints" / "mtfm_best.pth"
        if self.model_path.exists():
            self.mtfm_model.load_state_dict(
                torch.load(self.model_path, map_location=self.mtfm_config.device)
            )
            self.mtfm_trained = True
            print(f"  ✓ 加载MTFM模型: {self.model_path}")
        else:
            self.mtfm_trained = False
            print(f"  ⚠ MTFM模型未训练，请先运行: python main.py --mode train")
        
        print("\n[3] 初始化AutoFlow工作流生成器...")
        self.autoflow_generator = AutoFlowGenerator(
            deepseek_api_key=api_key,
            auto_model_name=model_name
        )
        
        self.api_names = self.dataset.mashup_ds.api_names
        
        print("\n" + "=" * 60)
        print("系统初始化完成!")
        print(f"  - APIs: {len(self.api_names)}")
        print(f"  - Mashups: {self.dataset.num_mashup}")
        print(f"  - Categories: {self.dataset.num_category}")
        print(f"  - Mode: {'RoBERTa' if self.use_roberta else 'Word Embedding'}")
        print(f"  - MTFM trained: {'Yes ✓' if self.mtfm_trained else 'No ✗'}")
        print(f"  - DeepSeek API: {'已配置 ✓' if api_key else '未配置 ✗'}")
        print("=" * 60)
    
    
    def generate_workflow_simple(self, user_request: str) -> Dict:
        print("\n[AutoFlow] 生成工作流 (简单模式)...")
        
        workflow_text = self.autoflow_generator.generate_simple(user_request)
        flow = self.autoflow_generator.parse_workflow(workflow_text)
        
        return {
            'workflow_text': workflow_text,
            'flow': flow,
            'method': 'simple'
        }
    
    def generate_workflow_with_optimization(self,
                                             user_request: str,
                                             method: str = "deepseek_icl",
                                             auto_epochs: int = None,
                                             execute_func=None,
                                             use_real_execution: bool = True,
                                             bind_mtfm_apis: bool = False,
                                             executor_max_round: int = 20) -> Dict:
        epochs = auto_epochs or AUTO_EPOCHS
        print(f"\n[AutoFlow] 生成工作流 (优化模式: {method}, epochs={epochs})...")

        if execute_func is None and use_real_execution:
            node_api_resolver = None
            if bind_mtfm_apis and self.mtfm_trained:
                def node_api_resolver(block, answer):
                    try:
                        recs = self.recommend_apis_for_task(block.get_instruction(), top_k=1)
                    except Exception as e:
                        logging.error(f"[Executor] MTFM API resolve failed at {block.name}: {e}")
                        return None
                    if not recs:
                        return None
                    top = recs[0]
                    return f"[Bound API: {top['api_name']} (score={top['score']:.4f})] {answer}"

            execute_func = make_execute_func(
                call_llm=lambda messages: self.autoflow_generator._call_deepseek(messages, temperature=0.3),
                task_description=user_request,
                node_api_resolver=node_api_resolver,
                max_round=executor_max_round,
            )

        if method == "deepseek_icl":
            best_workflow, reward_history = self.autoflow_generator.generate_with_deepseek_icl(
                task_description=user_request,
                auto_epochs=epochs,
                execute_func=execute_func
            )
        elif method == "mixtral_ppo":
            best_workflow, reward_history = self.autoflow_generator.generate_with_mixtral_ppo(
                task_description=user_request,
                auto_epochs=epochs,
                execute_func=execute_func
            )
        else:
            raise ValueError(f"Unknown method: {method}")
        
        flow = self.autoflow_generator.parse_workflow(best_workflow)
        
        return {
            'workflow_text': best_workflow,
            'flow': flow,
            'reward_history': reward_history,
            'method': method
        }
    
    
    def recommend_apis_for_task(self, task_instruction: str, top_k: int = 5) -> List[Dict]:
        if not self.mtfm_trained:
            print("Warning: MTFM model not trained, using fallback method")
            return self._fallback_api_recommendation(task_instruction, top_k)
        
        self.mtfm_model.eval()
        
        if self.use_roberta:
            return self._fallback_api_recommendation(task_instruction, top_k)
        else:
            indices = self.dataset.mashup_ds._text_to_indices(task_instruction)
            input_tensor = torch.LongTensor([indices]).to(self.mtfm_config.device)
            
            with torch.no_grad():
                api_pred, _ = self.mtfm_model(input_tensor)
                api_pred = api_pred.cpu().numpy()[0]
            
            top_k_indices = np.argsort(api_pred)[::-1][:top_k]
            
            recommendations = []
            for idx in top_k_indices:
                recommendations.append({
                    'api_name': self.api_names[idx],
                    'api_index': int(idx),
                    'score': float(api_pred[idx])
                })
            
            return recommendations
    
    def _fallback_api_recommendation(self, task_instruction: str, top_k: int = 5) -> List[Dict]:
        task_lower = task_instruction.lower()
        scores = np.zeros(len(self.api_names))
        
        keyword_mapping = {
            'search': ['search', 'find', 'query', 'lookup'],
            'map': ['map', 'location', 'geo', 'place', 'address'],
            'weather': ['weather', 'climate', 'forecast'],
            'social': ['social', 'facebook', 'twitter', 'share'],
            'payment': ['pay', 'payment', 'transaction', 'money'],
            'image': ['image', 'photo', 'picture', 'visual'],
            'video': ['video', 'youtube', 'stream'],
            'music': ['music', 'audio', 'sound', 'song'],
            'news': ['news', 'article', 'feed'],
            'email': ['email', 'mail', 'message', 'send']
        }
        
        for i, api_name in enumerate(self.api_names):
            api_lower = api_name.lower()
            for word in task_lower.split():
                if len(word) > 3 and word in api_lower:
                    scores[i] += 0.5
            for category, keywords in keyword_mapping.items():
                if any(kw in task_lower for kw in keywords):
                    if any(kw in api_lower for kw in keywords):
                        scores[i] += 0.3
        
        if scores.max() > 0:
            scores = scores / scores.max()
        
        top_k_indices = np.argsort(scores)[::-1][:top_k]
        
        recommendations = []
        for idx in top_k_indices:
            recommendations.append({
                'api_name': self.api_names[idx],
                'api_index': int(idx),
                'score': float(scores[idx])
            })
        
        return recommendations
    
    
    def process(self, 
                user_request: str,
                workflow_method: str = None,
                auto_epochs: int = None,
                api_top_k: int = 5,
                use_real_execution: bool = True,
                bind_mtfm_apis: bool = False) -> Dict:
        method = workflow_method or WORKFLOW_METHOD
        epochs = auto_epochs or AUTO_EPOCHS
        
        result = {
            'user_request': user_request,
            'method': f'AutoFlow ({method}) + MTFM ({"RoBERTa" if self.use_roberta else "Original"})',
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'workflow': None,
            'tasks': [],
            'api_bindings': {}
        }
        
        print("\n" + "=" * 50)
        print("[Step 1] 生成工作流")
        print("=" * 50)
        
        start_time = time.time()
        
        if method == "simple":
            workflow_result = self.generate_workflow_simple(user_request)
        else:
            workflow_result = self.generate_workflow_with_optimization(
                user_request, 
                method=method,
                auto_epochs=epochs,
                use_real_execution=use_real_execution,
                bind_mtfm_apis=bind_mtfm_apis
            )
        
        result['workflow'] = {
            'text': workflow_result['workflow_text'],
            'structure': workflow_result['flow'].to_dict(),
            'method': workflow_result['method']
        }
        
        if 'reward_history' in workflow_result:
            result['workflow']['reward_history'] = workflow_result['reward_history']
        
        print(f"  ✓ 工作流生成完成 ({time.time() - start_time:.2f}s)")
        
        print("\n" + "=" * 50)
        print("[Step 2] 提取任务节点")
        print("=" * 50)
        
        flow = workflow_result['flow']
        tasks = self.autoflow_generator.get_tasks_from_workflow(flow)
        result['tasks'] = tasks
        
        print(f"  ✓ 提取到 {len(tasks)} 个任务")
        
        print("\n" + "=" * 50)
        print("[Step 3] MTFM API推荐")
        print("=" * 50)
        
        for task in tasks:
            task_id = task['id']
            task_instruction = task['instruction']
            
            recommendations = self.recommend_apis_for_task(task_instruction, top_k=api_top_k)
            
            if recommendations:
                top_api = recommendations[0]
                result['api_bindings'][task_id] = {
                    'task_instruction': task_instruction,
                    'task_type': task['type'],
                    'api_name': top_api['api_name'],
                    'api_score': top_api['score'],
                    'top_candidates': [[r['api_name'], round(r['score'], 4)] for r in recommendations]
                }
                
                print(f"  [{task_id}] {task_instruction[:40]}...")
                print(f"       -> {top_api['api_name']} ({top_api['score']:.4f})")
        
        return result
    
    
    def train_mtfm(self, epochs: int = None, batch_size: int = None, log_path: str = None):
        epochs = epochs or TRAIN_EPOCHS
        batch_size = batch_size or BATCH_SIZE
        
        print("\n" + "=" * 60)
        print("训练MTFM模型 (完整原始版)")
        print("=" * 60)
        
        train_loader, val_loader, test_loader = create_data_loaders(
            self.dataset.mashup_ds,
            batch_size=batch_size
        )
        
        log_path = log_path or str(PROJECT_ROOT / LOG_PATH / "mtfm_train.log")
        model_path = str(PROJECT_ROOT / CHECKPOINT_PATH / "mtfm_best.pth")
        
        Path(log_path).parent.mkdir(parents=True, exist_ok=True)
        Path(model_path).parent.mkdir(parents=True, exist_ok=True)
        
        trainer = MTFMTrainer(
            model=self.mtfm_model,
            config=self.mtfm_config,
            train_loader=train_loader,
            val_loader=val_loader,
            test_loader=test_loader,
            log_path=log_path,
            model_path=model_path
        )
        
        trainer.epochs = epochs
        trainer.train()
        
        trainer.test()
        
        self.mtfm_trained = True
        self.model_path = Path(model_path)
        
        trainer.close()
        print(f"\n✓ MTFM模型训练完成，保存至: {model_path}")
    
    
    def save_result(self, result: Dict, output_path: str = None):
        output_path = output_path or str(PROJECT_ROOT / "output.json")
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
        
        print(f"\n✓ 结果已保存: {output_path}")
    
    def print_result(self, result: Dict):
        print("\n" + "=" * 60)
        print("处理结果")
        print("=" * 60)
        
        print(f"\n用户需求: {result['user_request'][:100]}...")
        print(f"方法: {result['method']}")

        reward_history = result.get('workflow', {}).get('reward_history')
        if reward_history:
            print(f"\n真实执行Reward历史 (来自沿flow真实执行，而非文本格式打分):")
            print(f"  {[round(r, 3) for r in reward_history]}")
            print(f"  最终最佳Reward: {max(reward_history):.3f}")
        
        print(f"\n任务列表 ({len(result['tasks'])} 个):")
        for task in result['tasks']:
            print(f"  [{task['id']}] {task['instruction'][:50]}... ({task['type']})")
        
        print(f"\nAPI绑定:")
        for task_id, binding in result['api_bindings'].items():
            print(f"  [{task_id}] {binding['task_instruction'][:40]}...")
            print(f"       -> {binding['api_name']} ({binding['api_score']:.4f})")


def main():
    parser = argparse.ArgumentParser(description='AutoFlow + MTFM 整合系统')
    
    parser.add_argument('--mode', type=str, default='demo',
                       choices=['demo', 'train', 'process'],
                       help='运行模式: demo, train, process')
    
    parser.add_argument('--data_path', type=str, default=None,
                       help='数据目录路径 (默认从config.py读取)')
    
    parser.add_argument('--embedding_path', type=str, default=None,
                       help='嵌入目录路径 (默认从config.py读取)')
    
    parser.add_argument('--use_roberta', action='store_true',
                       help='使用RoBERTa特征')
    
    parser.add_argument('--request', '-r', type=str, default=None,
                       help='用户需求描述')
    
    parser.add_argument('--workflow_method', type=str, default=None,
                       choices=['simple', 'deepseek_icl', 'mixtral_ppo'],
                       help='工作流生成方法 (默认从config.py读取)')
    
    parser.add_argument('--auto_epochs', type=int, default=None,
                       help='AutoFlow优化迭代次数 (默认从config.py读取)')
    
    parser.add_argument('--epochs', type=int, default=None,
                       help='MTFM训练轮数 (默认从config.py读取)')
    
    parser.add_argument('--batch_size', type=int, default=None,
                       help='批大小 (默认从config.py读取)')
    
    parser.add_argument('--deepseek_key', type=str, default=None,
                       help='DeepSeek API密钥 (默认从config.py读取)')

    parser.add_argument('--no_real_execution', action='store_true',
                       help='关闭"沿flow真实执行"的reward闭环，退回到关键词/格式打分(不推荐，仅用于对比调试)')

    parser.add_argument('--bind_mtfm_apis', action='store_true',
                       help='执行工作流时，让MTFM为每个节点推荐并绑定API，参与到执行轨迹中')

    args = parser.parse_args()
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    system = AutoFlowMTFMSystem(
        data_path=args.data_path,
        embedding_path=args.embedding_path,
        use_roberta=args.use_roberta if args.use_roberta else None,
        deepseek_api_key=args.deepseek_key
    )
    
    if args.mode == 'train':
        system.train_mtfm(epochs=args.epochs, batch_size=args.batch_size)
        
    elif args.mode == 'process':
        if not args.request:
            print("Error: --request is required for process mode")
            print("Example: python main.py --mode process -r \"Your task description\"")
            return
        
        result = system.process(
            user_request=args.request,
            workflow_method=args.workflow_method,
            auto_epochs=args.auto_epochs,
            use_real_execution=not args.no_real_execution,
            bind_mtfm_apis=args.bind_mtfm_apis
        )
        
        system.print_result(result)
        system.save_result(result)
        
    else:
        demo_request = """
        If goods shall be shipped, the secretary clarifies who will do the shipping. 
        If you have large amounts, special shipping will be necessary. In these cases 
        the secretary invites three logistic companies to make offers and she selects 
        one of them. In case of small amounts, normal post shipment is used.
        """
        
        print("\n[Demo] 用户需求:")
        print(demo_request)
        
        result = system.process(
            user_request=demo_request,
            workflow_method='simple'
        )
        
        system.print_result(result)
        system.save_result(result)


if __name__ == '__main__':
    main()
