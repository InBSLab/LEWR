
DEEPSEEK_API_KEY = ""

DEEPSEEK_BASE_URL = "https://api.deepseek.com/v1"

DEEPSEEK_MODEL = "deepseek-chat"


DATA_PATH = "./data"

EMBEDDING_PATH = "./embedding"

CHECKPOINT_PATH = "./checkpoints"

LOG_PATH = "./logs"


TRAIN_EPOCHS = 100

BATCH_SIZE = 128

USE_ROBERTA = False


AUTO_EPOCHS = 30

WORKFLOW_METHOD = "simple"
