
import os
import json
import time
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, SubsetRandomSampler
from pathlib import Path


class EarlyStopping:
    
    def __init__(self, patience=7, path='checkpoint.pth', verbose=True):
        self.patience = patience
        self.path = path
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = float('inf')
    
    def __call__(self, val_loss, model):
        score = -val_loss
        
        if self.best_score is None:
            self.best_score = score
            self.save_checkpoint(val_loss, model)
        elif score < self.best_score:
            self.counter += 1
            if self.verbose:
                print(f'EarlyStopping counter: {self.counter} out of {self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_score = score
            self.save_checkpoint(val_loss, model)
            self.counter = 0
    
    def save_checkpoint(self, val_loss, model):
        if self.verbose:
            print(f'Validation loss decreased ({self.val_loss_min:.6f} --> {val_loss:.6f}). Saving model...')
        torch.save(model.state_dict(), self.path)
        self.val_loss_min = val_loss


def metric(labels, predictions, top_k_list=[1, 5, 10, 15, 20, 25, 30]):
    if hasattr(labels, 'numpy'):
        labels = labels.numpy()
    if hasattr(predictions, 'numpy'):
        predictions = predictions.numpy()
    
    batch_size = labels.shape[0]
    ndcg_list = np.zeros(len(top_k_list))
    recall_list = np.zeros(len(top_k_list))
    ap_list = np.zeros(len(top_k_list))
    precision_list = np.zeros(len(top_k_list))
    
    for i in range(batch_size):
        pred = predictions[i]
        label = labels[i]
        total_relevant = label.sum()
        
        if total_relevant == 0:
            continue
        
        for k_idx, k in enumerate(top_k_list):
            top_k_idx = np.argsort(pred)[::-1][:k]
            
            hits = label[top_k_idx].sum()
            
            precision_list[k_idx] += hits / k
            
            recall_list[k_idx] += hits / total_relevant
            
            dcg = 0
            for j, idx in enumerate(top_k_idx):
                if label[idx] > 0:
                    dcg += 1 / np.log2(j + 2)
            
            ideal_num = min(int(total_relevant), k)
            idcg = sum(1 / np.log2(j + 2) for j in range(ideal_num))
            ndcg_list[k_idx] += dcg / idcg if idcg > 0 else 0
            
            ap = 0
            relevant_count = 0
            for j, idx in enumerate(top_k_idx):
                if label[idx] > 0:
                    relevant_count += 1
                    ap += relevant_count / (j + 1)
            ap_list[k_idx] += ap / min(total_relevant, k)
    
    return (ndcg_list / batch_size, recall_list / batch_size, 
            ap_list / batch_size, precision_list / batch_size)


class MTFMTrainer:
    
    def __init__(self, 
                 model, 
                 config, 
                 train_loader, 
                 val_loader, 
                 test_loader,
                 log_path=None,
                 model_path=None):
        self.model = model
        self.config = config
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.test_loader = test_loader
        
        self.api_criterion = nn.BCELoss()
        self.category_criterion = nn.BCELoss()
        
        self.optimizer = torch.optim.Adam(model.parameters(), lr=config.lr)
        
        self.epochs = 100
        self.top_k_list = [1, 5, 10, 15, 20, 25, 30]
        
        self.model_path = model_path or f'checkpoints/{config.model_name}.pth'
        Path(self.model_path).parent.mkdir(parents=True, exist_ok=True)
        
        self.log_path = log_path
        if log_path:
            Path(log_path).parent.mkdir(parents=True, exist_ok=True)
            self.log = open(log_path, mode='a', encoding='utf-8')
        else:
            self.log = None
        
        self.early_stopping = EarlyStopping(patience=7, path=self.model_path)
    
    def _log(self, message):
        print(message)
        if self.log:
            self.log.write(message + '\n')
            self.log.flush()
    
    def train(self):
        self._log('Start training MTFM...')
        self._log(f'Model: {self.config.model_name}')
        self._log(f'Device: {self.config.device}')
        self._log(f'Epochs: {self.epochs}')
        self._log(f'Batch size: {self.config.batch_size}')
        self._log(f'Learning rate: {self.config.lr}')
        self._log('-' * 50)
        
        for epoch in range(self.epochs):
            self.model.train()
            api_loss_list = []
            category_loss_list = []
            
            for batch_idx, batch_data in enumerate(self.train_loader):
                index = batch_data[0].to(self.config.device)
                features = batch_data[1].to(self.config.device)
                category_target = batch_data[2].float().to(self.config.device)
                api_target = batch_data[3].float().to(self.config.device)
                
                self.optimizer.zero_grad()
                
                api_pred, category_pred = self.model(features)
                
                api_loss = self.api_criterion(api_pred, api_target)
                category_loss = self.category_criterion(category_pred, category_target)
                loss = api_loss + category_loss
                
                loss.backward()
                self.optimizer.step()
                
                api_loss_list.append(api_loss.item())
                category_loss_list.append(category_loss.item())
            
            api_loss_avg = np.mean(api_loss_list)
            category_loss_avg = np.mean(category_loss_list)
            
            info = f'[Epoch {epoch+1}/{self.epochs}] API Loss: {api_loss_avg:.6f}, Category Loss: {category_loss_avg:.6f}'
            self._log(info)
            
            val_loss = self.evaluate(test=False)
            
            self.early_stopping(val_loss, self.model)
            if self.early_stopping.early_stop:
                self._log("Early stopping!")
                break
        
        self.model.load_state_dict(torch.load(self.model_path, map_location=self.config.device))
        self._log(f'Training completed. Best model loaded from {self.model_path}')
    
    def evaluate(self, test=False):
        if test:
            data_loader = self.test_loader
            label = 'Test'
        else:
            data_loader = self.val_loader
            label = 'Validation'
        
        self.model.eval()
        
        ndcg_a = np.zeros(len(self.top_k_list))
        recall_a = np.zeros(len(self.top_k_list))
        ap_a = np.zeros(len(self.top_k_list))
        pre_a = np.zeros(len(self.top_k_list))
        
        ndcg_c = np.zeros(len(self.top_k_list))
        recall_c = np.zeros(len(self.top_k_list))
        ap_c = np.zeros(len(self.top_k_list))
        pre_c = np.zeros(len(self.top_k_list))
        
        api_loss_list = []
        category_loss_list = []
        num_batch = len(data_loader)
        
        with torch.no_grad():
            for batch_idx, batch_data in enumerate(data_loader):
                index = batch_data[0].to(self.config.device)
                features = batch_data[1].to(self.config.device)
                category_target = batch_data[2].float().to(self.config.device)
                api_target = batch_data[3].float().to(self.config.device)
                
                api_pred, category_pred = self.model(features)
                
                api_loss = self.api_criterion(api_pred, api_target)
                category_loss = self.category_criterion(category_pred, category_target)
                api_loss_list.append(api_loss.item())
                category_loss_list.append(category_loss.item())
                
                api_pred_cpu = api_pred.cpu()
                category_pred_cpu = category_pred.cpu()
                
                ndcg_, recall_, ap_, pre_ = metric(batch_data[3], api_pred_cpu, self.top_k_list)
                ndcg_a += ndcg_
                recall_a += recall_
                ap_a += ap_
                pre_a += pre_
                
                ndcg_, recall_, ap_, pre_ = metric(batch_data[2], category_pred_cpu, self.top_k_list)
                ndcg_c += ndcg_
                recall_c += recall_
                ap_c += ap_
                pre_c += pre_
        
        api_loss_avg = np.mean(api_loss_list)
        category_loss_avg = np.mean(category_loss_list)
        total_loss = api_loss_avg + category_loss_avg
        
        ndcg_a /= num_batch
        recall_a /= num_batch
        ap_a /= num_batch
        pre_a /= num_batch
        ndcg_c /= num_batch
        recall_c /= num_batch
        ap_c /= num_batch
        pre_c /= num_batch
        
        info = f'[{label}] API Loss: {api_loss_avg:.6f}, Category Loss: {category_loss_avg:.6f}'
        self._log(info)
        
        if test:
            self._log(f'Top-K: {self.top_k_list}')
            self._log(f'NDCG_A:    {[f"{v:.4f}" for v in ndcg_a]}')
            self._log(f'Recall_A:  {[f"{v:.4f}" for v in recall_a]}')
            self._log(f'AP_A:      {[f"{v:.4f}" for v in ap_a]}')
            self._log(f'Pre_A:     {[f"{v:.4f}" for v in pre_a]}')
            self._log(f'NDCG_C:    {[f"{v:.4f}" for v in ndcg_c]}')
            self._log(f'Recall_C:  {[f"{v:.4f}" for v in recall_c]}')
            self._log(f'AP_C:      {[f"{v:.4f}" for v in ap_c]}')
            self._log(f'Pre_C:     {[f"{v:.4f}" for v in pre_c]}')
        
        return total_loss
    
    def test(self):
        self._log('-' * 50)
        self._log('Start testing...')
        self.evaluate(test=True)
    
    def close(self):
        if self.log:
            self.log.close()
