
import torch
import torch.nn as nn
import numpy as np


class MTFMConfig:
    def __init__(self, ds_config=None, **kwargs):
        self.model_name = 'MTFM'
        
        if ds_config is not None:
            self.embed_dim = getattr(ds_config, 'embed_dim', 128)
            self.max_doc_len = getattr(ds_config, 'max_doc_len', 100)
            self.num_category = getattr(ds_config, 'num_category', 20)
            self.num_mashup = getattr(ds_config, 'num_mashup', 1000)
            self.num_api = getattr(ds_config, 'num_api', 500)
            self.vocab_size = getattr(ds_config, 'vocab_size', 10000)
            self.embed = getattr(ds_config, 'embed', None)
        else:
            self.embed_dim = kwargs.get('embed_dim', 128)
            self.max_doc_len = kwargs.get('max_doc_len', 100)
            self.num_category = kwargs.get('num_category', 20)
            self.num_mashup = kwargs.get('num_mashup', 1000)
            self.num_api = kwargs.get('num_api', 500)
            self.vocab_size = kwargs.get('vocab_size', 10000)
            self.embed = kwargs.get('embed', None)
        
        self.feature_dim = 8
        self.num_kernel = 256
        self.dropout = 0.2
        self.kernel_size = [2, 3, 4, 5]
        self.lr = 1e-3
        self.batch_size = 128
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'


class MTFM(nn.Module):
    
    def __init__(self, config):
        super(MTFM, self).__init__()
        self.config = config
        
        if config.embed is not None:
            self.embedding = nn.Embedding.from_pretrained(config.embed, freeze=False)
        else:
            self.embedding = nn.Embedding(
                config.vocab_size, 
                config.embed_dim, 
                padding_idx=config.vocab_size - 1
            )
        
        self.sc_convs = nn.ModuleList([
            nn.Sequential(
                nn.Conv1d(
                    in_channels=config.embed_dim,
                    out_channels=config.num_kernel,
                    kernel_size=h
                ),
                nn.ReLU(),
                nn.MaxPool1d(kernel_size=config.max_doc_len - h + 1)
            )
            for h in config.kernel_size
        ])
        
        self.sc_fcl = nn.Linear(
            in_features=config.num_kernel * len(config.kernel_size),
            out_features=config.num_api
        )
        
        self.fic_fc = nn.Linear(
            in_features=config.num_kernel * len(config.kernel_size),
            out_features=config.feature_dim
        )
        
        self.fic_api_feature_embedding = nn.Parameter(
            torch.rand(config.feature_dim, config.num_api)
        )
        
        self.fic_mlp = nn.Sequential(
            nn.Linear(config.feature_dim * 2, config.feature_dim),
            nn.Linear(config.feature_dim, 1),
            nn.Tanh()
        )
        
        self.fic_fcl = nn.Linear(config.num_api * 2, config.num_api)
        
        self.fusion_layer = nn.Linear(config.num_api * 2, config.num_api)
        
        self.api_task_layer = nn.Linear(config.num_api, config.num_api)
        self.category_task_layer = nn.Linear(config.num_api, config.num_category)
        
        self.dropout = nn.Dropout(config.dropout)
        self.logistic = nn.Sigmoid()
        self.tanh = nn.Tanh()
        self.relu = nn.ReLU()
    
    def init_weight(self):
        nn.init.kaiming_normal_(self.fic_api_feature_embedding)
    
    def forward(self, mashup_des):
        embed = self.embedding(mashup_des)
        embed = embed.permute(0, 2, 1)
        
        e = [conv(embed) for conv in self.sc_convs]
        e = torch.cat(e, dim=2)
        e = e.view(e.size(0), -1)
        
        u_sc = self.sc_fcl(e)
        
        u_sc_trans = self.fic_fc(e)
        
        u_mm = torch.matmul(u_sc_trans, self.fic_api_feature_embedding)
        
        u_concate = []
        for u_sc_single in u_sc_trans:
            u_concate_single = torch.cat(
                (u_sc_single.repeat(self.fic_api_feature_embedding.size(1), 1), 
                 self.fic_api_feature_embedding.t()),
                dim=1
            )
            u_concate.append(self.fic_mlp(u_concate_single).squeeze())
        
        u_mlp = torch.cat(u_concate).view(u_mm.size(0), -1)
        
        u_fic = self.fic_fcl(torch.cat((u_mm, u_mlp), dim=1))
        u_fic = self.tanh(u_fic)
        
        u_mmf = self.fusion_layer(torch.cat((u_sc, u_fic), dim=1))
        
        u_mmf = self.dropout(u_mmf)
        
        y_m = self.api_task_layer(u_mmf)
        
        z_m = self.category_task_layer(u_mmf)
        
        return self.logistic(y_m), self.logistic(z_m)
    
    def predict_api(self, mashup_des, top_k=5):
        self.eval()
        with torch.no_grad():
            api_pred, _ = self.forward(mashup_des)
            
            scores, indices = torch.topk(api_pred, k=top_k, dim=1)
            
            return indices.cpu().numpy(), scores.cpu().numpy()


class MTFMRoBERTa(nn.Module):
    
    def __init__(self, config):
        super(MTFMRoBERTa, self).__init__()
        self.config = config
        
        roberta_dim = config.embed_dim
        hidden_dim = config.num_kernel * len(config.kernel_size)
        
        self.sc_encoder = nn.Sequential(
            nn.Linear(roberta_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(config.dropout)
        )
        
        self.sc_fcl = nn.Linear(hidden_dim, config.num_api)
        
        self.fic_fc = nn.Linear(hidden_dim, config.feature_dim)
        
        self.fic_api_feature_embedding = nn.Parameter(
            torch.rand(config.feature_dim, config.num_api)
        )
        
        self.fic_mlp = nn.Sequential(
            nn.Linear(config.feature_dim * 2, config.feature_dim),
            nn.Linear(config.feature_dim, 1),
            nn.Tanh()
        )
        
        self.fic_fcl = nn.Linear(config.num_api * 2, config.num_api)
        
        self.fusion_layer = nn.Linear(config.num_api * 2, config.num_api)
        
        self.api_task_layer = nn.Linear(config.num_api, config.num_api)
        self.category_task_layer = nn.Linear(config.num_api, config.num_category)
        
        self.dropout = nn.Dropout(config.dropout)
        self.logistic = nn.Sigmoid()
        self.tanh = nn.Tanh()
    
    def forward(self, roberta_features):
        e = self.sc_encoder(roberta_features)
        u_sc = self.sc_fcl(e)
        
        u_sc_trans = self.fic_fc(e)
        
        u_mm = torch.matmul(u_sc_trans, self.fic_api_feature_embedding)
        
        u_concate = []
        for u_sc_single in u_sc_trans:
            u_concate_single = torch.cat(
                (u_sc_single.repeat(self.fic_api_feature_embedding.size(1), 1), 
                 self.fic_api_feature_embedding.t()),
                dim=1
            )
            u_concate.append(self.fic_mlp(u_concate_single).squeeze())
        
        u_mlp = torch.cat(u_concate).view(u_mm.size(0), -1)
        
        u_fic = self.fic_fcl(torch.cat((u_mm, u_mlp), dim=1))
        u_fic = self.tanh(u_fic)
        
        u_mmf = self.fusion_layer(torch.cat((u_sc, u_fic), dim=1))
        u_mmf = self.dropout(u_mmf)
        
        y_m = self.api_task_layer(u_mmf)
        z_m = self.category_task_layer(u_mmf)
        
        return self.logistic(y_m), self.logistic(z_m)


if __name__ == '__main__':
    print("Testing MTFM model...")
    
    config = MTFMConfig(
        embed_dim=128,
        max_doc_len=100,
        num_api=500,
        num_category=20,
        vocab_size=10000
    )
    
    model = MTFM(config)
    print(f"Model parameters: {sum(p.numel() for p in model.parameters()):,}")
    
    x = torch.randint(0, 10000, (4, 100))
    api_pred, cat_pred = model(x)
    print(f"API prediction shape: {api_pred.shape}")
    print(f"Category prediction shape: {cat_pred.shape}")
