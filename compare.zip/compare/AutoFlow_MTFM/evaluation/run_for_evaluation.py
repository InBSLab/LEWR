# -*- coding: utf-8 -*-

import os
import sys
import json
import time
import re
import requests
import csv
import argparse
import statistics
import traceback
import numpy as np
import torch
import torch.nn as nn
from pathlib import Path
from typing import List, Dict, Any, Optional
from collections import Counter

SCRIPT_DIR = Path(__file__).parent.absolute()
PROJECT_ROOT = SCRIPT_DIR.parent.parent  # evaluation_framework_complete/
EVAL_ROOT = SCRIPT_DIR.parent  # evaluation_framework_complete/evaluation/

POSSIBLE_MODEL_PATHS = [
    PROJECT_ROOT / "models" / "AutoFlow" / "AutoFlow_MTFM_Complete" / "AutoFlow_MTFM_Complete",
    PROJECT_ROOT / "AutoFlow_MTFM_Complete" / "AutoFlow_MTFM_Complete",
    PROJECT_ROOT.parent / "AutoFlow_MTFM_Complete" / "AutoFlow_MTFM_Complete",
    SCRIPT_DIR / "AutoFlow_MTFM_Complete",
    SCRIPT_DIR,
]

def find_model_root():
    for path in POSSIBLE_MODEL_PATHS:
        checkpoint_path = path / "checkpoints" / "mtfm_best.pth"
        if checkpoint_path.exists():
            print(f"  找到模型目录: {path}")
            return path
        data_path = path / "data" / "api_name.json"
        if data_path.exists():
            print(f"  找到数据目录: {path}")
            return path
    return POSSIBLE_MODEL_PATHS[0]

MODEL_ROOT = find_model_root()

sys.path.insert(0, str(EVAL_ROOT / "common"))
sys.path.insert(0, str(MODEL_ROOT))

from scenarios import BPMN_TEST_SCENARIOS, UnifiedOutput, save_results



import re as _re_range


def _estimate_task_range(description: str):
    desc_lower = description.lower()

    branch_markers = [
        'if ', 'otherwise', 'in case', 'depending on', 'either', 'or else',
        'unless', 'when ', 'whenever'
    ]
    sequence_markers = [
        'then', 'after', 'afterwards', 'meanwhile', 'in the meantime',
        'once', 'subsequently', 'next,'
    ]

    branch_count = sum(desc_lower.count(m) for m in branch_markers)
    sequence_count = sum(desc_lower.count(m) for m in sequence_markers)

    sentence_count = max(1, len(_re_range.findall(r'[.!?](?:\s|$)', description)))

    base = sentence_count
    expansion = branch_count * 2 + sequence_count

    min_tasks = max(4, int(base * 0.8))
    max_tasks = max(min_tasks + 4, int((base + expansion) * 1.3))
    max_tasks = min(max_tasks, 30)

    return min_tasks, max_tasks


def _augment_description_with_task_requirement(process_description: str, min_tasks: int, max_tasks: int, level: str = "strong") -> str:
    if level == "strong":
        suffix = f"""

[GENERATION REQUIREMENT]
Based on the structure of the process description above (conditions, parallel
activities, sequential steps), generate a workflow with approximately
{min_tasks}-{max_tasks} steps. Split each distinct activity mentioned in the
text into its own step; do not merge multiple described actions into one step,
and do not invent activities that are not implied by the text.
Every "decision" step MUST have all of its branch targets be real step names
that also appear as their own step definition later in the output."""
    else:  # maximum
        suffix = f"""

[GENERATION REQUIREMENT - STRICT]
Re-read the process description carefully. Generate a workflow with
{min_tasks}-{max_tasks} steps total:
- If the text describes conditional branches, model them as a "decision" step
  with branches around exactly the branches described in the text, and make
  sure every branch target is itself defined as a step later in the output.
- Do not add steps that are not stated or clearly implied by the text.
  Do not omit a step that is explicitly stated.
Stay within the {min_tasks}-{max_tasks} step range."""

    return process_description + suffix


def _fix_workflow_structure(tasks: list, gateways: list, dependencies: list, step_map: dict, raw_dependencies: list):
    repair_log = []

    task_ids_in_order = [t['id'] for t in tasks]
    id_to_index = {tid: i for i, tid in enumerate(task_ids_in_order)}

    decision_task_ids = {g['source_task'] for g in gateways if 'source_task' in g}
    edges_from_decision = {tid: [] for tid in decision_task_ids}
    for dep in dependencies:
        if dep['from'] in edges_from_decision:
            edges_from_decision[dep['from']].append(dep)

    fixed_dependencies = list(dependencies)

    for dep in raw_dependencies:
        from_id = step_map.get(dep['from_step'])
        to_id = step_map.get(dep['to_step'])
        if from_id and not to_id:
            idx = id_to_index.get(from_id, -1)
            fallback_target = None
            if idx != -1 and idx + 1 < len(task_ids_in_order):
                fallback_target = task_ids_in_order[idx + 1]
            if fallback_target:
                fixed_dependencies.append({
                    'from': from_id,
                    'to': fallback_target,
                    'condition': dep.get('condition', '') + ' [repaired: dangling branch target redirected]'
                })
                if from_id in edges_from_decision:
                    edges_from_decision[from_id].append(fixed_dependencies[-1])
                repair_log.append({
                    'type': 'dangling_branch_redirected',
                    'from': from_id,
                    'original_target_step': dep['to_step'],
                    'redirected_to': fallback_target
                })

    end_task_ids = {t['id'] for t in tasks if t.get('type') == 'endEvent'}
    for tid in decision_task_ids:
        if not edges_from_decision.get(tid):
            idx = id_to_index.get(tid, -1)
            fallback_target = None
            if idx != -1 and idx + 1 < len(task_ids_in_order):
                fallback_target = task_ids_in_order[idx + 1]
            elif end_task_ids:
                fallback_target = next(iter(end_task_ids))
            if fallback_target:
                fixed_dependencies.append({
                    'from': tid,
                    'to': fallback_target,
                    'condition': 'default_repair'
                })
                repair_log.append({
                    'type': 'gateway_zero_outedge_fixed',
                    'gateway_task': tid,
                    'default_target': fallback_target
                })

    fixed_tasks = list(tasks)
    if not any(t.get('type') == 'endEvent' for t in fixed_tasks):
        end_id = f"t{len(fixed_tasks) + 1}"
        fixed_tasks.append({
            'id': end_id, 'name': 'Process complete', 'type': 'endEvent',
            'step_name': '__repaired_end__', 'full_instruction': 'Process complete'
        })
        if fixed_tasks:
            last_real_task = fixed_tasks[-2]['id'] if len(fixed_tasks) >= 2 else None
            if last_real_task:
                fixed_dependencies.append({'from': last_real_task, 'to': end_id, 'condition': 'default_repair'})
        repair_log.append({'type': 'missing_end_event_added', 'added_id': end_id})

    return fixed_tasks, gateways, fixed_dependencies, repair_log


def _validate_workflow_structure(tasks: list, gateways: list, dependencies: list) -> dict:
    errors = []
    warnings = []

    if not tasks:
        errors.append("Empty workflow")
        return {'is_valid': False, 'errors': errors, 'warnings': warnings}

    has_start = len(tasks) > 0
    has_end = any(t.get('type') == 'endEvent' for t in tasks)
    if not has_start:
        errors.append("Missing start step")
    if not has_end:
        errors.append("Missing endEvent/terminal step")

    task_ids = [t['id'] for t in tasks]
    if len(task_ids) != len(set(task_ids)):
        warnings.append("Duplicate task IDs found")

    task_id_set = set(task_ids)
    reachable = set()
    if tasks:
        stack = [tasks[0]['id']]
        adjacency = {}
        for dep in dependencies:
            adjacency.setdefault(dep['from'], []).append(dep['to'])
        while stack:
            cur = stack.pop()
            if cur in reachable:
                continue
            reachable.add(cur)
            for nxt in adjacency.get(cur, []):
                if nxt not in reachable:
                    stack.append(nxt)
    unreachable = task_id_set - reachable
    if unreachable:
        warnings.append(f"Unreachable tasks from start: {sorted(unreachable)[:5]}")

    decision_task_ids = {g['source_task'] for g in gateways if 'source_task' in g}

    collapsed_branch_gateways = []
    gateway_targets = {}
    for dep in dependencies:
        if dep['from'] in decision_task_ids:
            gateway_targets.setdefault(dep['from'], []).append(dep['to'])
    for tid, targets in gateway_targets.items():
        if len(targets) >= 2 and len(set(targets)) == 1:
            collapsed_branch_gateways.append(tid)
    if collapsed_branch_gateways:
        warnings.append(f"Gateways with all branches converging to one target (possible path coverage loss): {collapsed_branch_gateways[:5]}")

    zero_outedge_gateways = []
    outedges = {}
    for dep in dependencies:
        outedges.setdefault(dep['from'], 0)
        outedges[dep['from']] += 1
    for tid in decision_task_ids:
        if outedges.get(tid, 0) == 0:
            zero_outedge_gateways.append(tid)
    if zero_outedge_gateways:
        warnings.append(f"Gateways with zero out-edges: {zero_outedge_gateways[:5]}")

    return {
        'is_valid': len(errors) == 0,
        'errors': errors,
        'warnings': warnings,
        'statistics': {
            'task_count': len(tasks),
            'gateway_count': len(gateways),
            'dependency_count': len(dependencies),
            'unreachable_count': len(unreachable),
            'zero_outedge_gateway_count': len(zero_outedge_gateways),
            'collapsed_branch_gateway_count': len(collapsed_branch_gateways)
        }
    }


class AutoFlowGenerator:
    
    CORE_SYNTAX = '''You are a proficient expert in designing workflows for complex task planning.
Provide a workflow with several steps. Each step is a one-line string.
Each step is in the form of: [Step Name]:::[Step Type]:::[Step Instruction]:::[Step Branch]

[Step Type] could be "process", "terminal", or "decision".
[Step Branch] consists of branches in the form of "[Key]::[Branch Step Name]" separated by "::".

Rules:
- "process" step has exactly one branch with "next" as the key
- "decision" step has more than one branches (e.g., "Yes::Step X::No::Step Y")
- "terminal" step has zero branch, indicating the end
- At least one "terminal" step must exist'''

    EXAMPLE_WORKFLOW = '''Step 1:::Process:::Clarify who will handle the shipping based on order size.:::next::Step 2
Step 2:::Decision:::Check if special handling is required for large amounts.:::Yes::Step 3::No::Step 5
Step 3:::Process:::Invite three logistics companies to provide quotes.:::next::Step 4
Step 4:::Process:::Select the best logistics company and place order.:::next::Step 7
Step 5:::Process:::Write package label for standard shipping.:::next::Step 6
Step 6:::Decision:::Check if parcel insurance is necessary.:::Yes::Step 6a::No::Step 7
Step 6a:::Process:::Take parcel insurance from logistics department.:::next::Step 7
Step 7:::Process:::Package the goods in warehouse.:::next::Step 8
Step 8:::Process:::Prepare packaged goods for pickup by logistics company.:::next::Step 9
Step 9:::Terminal:::Shipment preparation complete.:::'''

    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.getenv("DEEPSEEK_API_KEY", "")
        self.base_url = "https://api.deepseek.com/v1"
    
    def _call_llm(self, prompt: str, system: str = None, temperature: float = 0.3, max_retries: int = 3,
                  max_tokens: int = 2500) -> str:
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        
        for attempt in range(max_retries):
            try:
                print(f"    正在调用DeepSeek API... (尝试 {attempt + 1}/{max_retries})")
                response = requests.post(
                    f"{self.base_url}/chat/completions",
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json"
                    },
                    json={
                        "model": "deepseek-chat",
                        "messages": messages,
                        "max_tokens": max_tokens,
                        "temperature": temperature
                    },
                    timeout=180
                )
                if response.status_code == 200:
                    print(f"    ✓ API调用成功")
                    return response.json()["choices"][0]["message"]["content"]
                else:
                    print(f"  LLM Error: HTTP {response.status_code}")
                    if attempt < max_retries - 1:
                        print(f"    等待10秒后重试...")
                        time.sleep(10)
            except requests.exceptions.Timeout:
                print(f"  ⚠ LLM Timeout (attempt {attempt + 1}/{max_retries})")
                if attempt < max_retries - 1:
                    print(f"    等待10秒后重试...")
                    time.sleep(10)
            except requests.exceptions.ConnectionError as e:
                print(f"  ⚠ 网络连接错误: {e}")
                if attempt < max_retries - 1:
                    print(f"    等待15秒后重试...")
                    time.sleep(15)
            except KeyboardInterrupt:
                print(f"\n  用户中断，跳过当前场景...")
                raise
            except Exception as e:
                print(f"  LLM Error: {e}")
                if attempt < max_retries - 1:
                    print(f"    等待5秒后重试...")
                    time.sleep(5)
        
        print(f"  ✗ API调用失败，已达最大重试次数")
        return ""
    
    def generate(self, user_request: str) -> Dict:
        print("\n[AutoFlow] 生成工作流...")
        
        prompt = f"""{self.CORE_SYNTAX}

Here is an example workflow for a shipping process:
{self.EXAMPLE_WORKFLOW}

Now generate a workflow for this task:
{user_request}

Output the workflow steps only, following the exact format shown above."""

        workflow_text = self._call_llm(prompt, temperature=0.3, max_tokens=GENERATION_MAX_TOKENS)
        
        tasks, gateways, dependencies, step_map, raw_dependencies = self._parse_workflow(workflow_text)
        
        return {
            'workflow_text': workflow_text,
            'tasks': tasks,
            'gateways': gateways,
            'dependencies': dependencies,
            'step_map': step_map,
            'raw_dependencies': raw_dependencies
        }
    
    def expand_task(self, task_text: str) -> str:
        prompt = f"""Convert this business process task into a web application description (mashup style).

Task: "{task_text}"

Requirements:
1. Describe what the application does functionally, in 15-25 words
2. Use common web/software terminology
3. Do NOT mention any specific API, product or company names
4. Output only the description, no quotes

Example:
Task: "write package label"
Output: web application creates shipping labels with address information barcode generation tracking number assignment delivery service integration

Task: "{task_text}"
Output:"""
        text = self._call_llm(prompt, temperature=0.3, max_tokens=2500)
        text = re.sub(r"[^a-z0-9\s]", " ", text.strip().lower())
        return " ".join(text.split())

    def _parse_workflow(self, workflow_text: str) -> tuple:
        tasks = []
        gateways = []
        dependencies = []
        
        lines = workflow_text.strip().split('\n')
        step_map = {}  # step_name -> task_id
        
        for i, line in enumerate(lines):
            line = line.strip()
            if not line or ':::' not in line:
                continue
            
            parts = line.split(':::')
            if len(parts) < 3:
                continue
            
            step_name = parts[0].strip()
            step_type = parts[1].strip().lower()
            instruction = parts[2].strip()
            branches = parts[3].strip() if len(parts) > 3 else ""
            
            task_id = f"t{len(tasks) + 1}"
            step_map[step_name] = task_id
            
            tasks.append({
                'id': task_id,
                'name': instruction[:60] if len(instruction) > 60 else instruction,
                'type': 'userTask' if step_type == 'process' else 
                        ('exclusiveGateway' if step_type == 'decision' else 'endEvent'),
                'step_name': step_name,
                'full_instruction': instruction
            })
            
            if step_type == 'decision':
                gateways.append({
                    'id': f"g{len(gateways) + 1}",
                    'type': 'exclusive',
                    'name': instruction[:40],
                    'source_task': task_id
                })
            
            if branches:
                branch_parts = branches.split('::')
                for j in range(0, len(branch_parts) - 1, 2):
                    if j + 1 < len(branch_parts):
                        target_step = branch_parts[j + 1].strip()
                        if target_step:
                            dependencies.append({
                                'from_step': step_name,
                                'to_step': target_step,
                                'condition': branch_parts[j].strip()
                            })
        
        resolved_deps = []
        for dep in dependencies:
            from_id = step_map.get(dep['from_step'])
            to_id = step_map.get(dep['to_step'])
            if from_id and to_id:
                resolved_deps.append({
                    'from': from_id,
                    'to': to_id,
                    'condition': dep.get('condition', '')
                })
        
        return tasks, gateways, resolved_deps, step_map, dependencies


class MTFMConfig:
    def __init__(self, **kwargs):
        self.model_name = 'MTFM'
        
        self.embed_dim = kwargs.get('embed_dim', 128)
        self.max_doc_len = kwargs.get('max_doc_len', 100)
        self.num_category = kwargs.get('num_category', 20)
        self.num_mashup = kwargs.get('num_mashup', 1000)
        self.num_api = kwargs.get('num_api', 500)
        self.vocab_size = kwargs.get('vocab_size', 5000)
        self.embed = kwargs.get('embed', None)
        
        self.feature_dim = kwargs.get('feature_dim', 8)
        self.num_kernel = kwargs.get('num_kernel', 128)
        self.dropout = kwargs.get('dropout', 0.2)
        self.kernel_size = kwargs.get('kernel_size', [2, 3, 4])
        self.lr = 1e-3
        self.batch_size = 128
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'


class MTFM(nn.Module):
    
    def __init__(self, config):
        super(MTFM, self).__init__()
        self.config = config
        
        if config.embed is not None:
            self.embedding = nn.Embedding.from_pretrained(config.embed, freeze=False)
        else:
            self.embedding = nn.Embedding(
                config.vocab_size, 
                config.embed_dim, 
                padding_idx=config.vocab_size - 1
            )
        
        # Multi-kernel CNN
        self.sc_convs = nn.ModuleList([
            nn.Sequential(
                nn.Conv1d(
                    in_channels=config.embed_dim,
                    out_channels=config.num_kernel,
                    kernel_size=h
                ),
                nn.ReLU(),
                nn.MaxPool1d(kernel_size=config.max_doc_len - h + 1)
            )
            for h in config.kernel_size
        ])
        
        self.sc_fcl = nn.Linear(
            in_features=config.num_kernel * len(config.kernel_size),
            out_features=config.num_api
        )
        
        self.fic_fc = nn.Linear(
            in_features=config.num_kernel * len(config.kernel_size),
            out_features=config.feature_dim
        )
        
        self.fic_api_feature_embedding = nn.Parameter(
            torch.rand(config.feature_dim, config.num_api)
        )
        
        self.fic_mlp = nn.Sequential(
            nn.Linear(config.feature_dim * 2, config.feature_dim),
            nn.Linear(config.feature_dim, 1),
            nn.Tanh()
        )
        
        self.fic_fcl = nn.Linear(config.num_api * 2, config.num_api)
        
        self.fusion_layer = nn.Linear(config.num_api * 2, config.num_api)
        
        self.api_task_layer = nn.Linear(config.num_api, config.num_api)
        self.category_task_layer = nn.Linear(config.num_api, config.num_category)
        
        self.dropout = nn.Dropout(config.dropout)
        self.logistic = nn.Sigmoid()
        self.tanh = nn.Tanh()
        self.relu = nn.ReLU()
    
    def forward(self, mashup_des):
        # ========== Semantic Component ==========
        embed = self.embedding(mashup_des)  # [batch, seq_len, embed_dim]
        embed = embed.permute(0, 2, 1)      # [batch, embed_dim, seq_len]
        
        # Multi-kernel CNN
        e = [conv(embed) for conv in self.sc_convs]
        e = torch.cat(e, dim=2)
        e = e.view(e.size(0), -1)
        
        u_sc = self.sc_fcl(e)
        
        # ========== Feature Interaction Component ==========
        u_sc_trans = self.fic_fc(e)
        
        u_mm = torch.matmul(u_sc_trans, self.fic_api_feature_embedding)
        
        u_concate = []
        for u_sc_single in u_sc_trans:
            u_concate_single = torch.cat(
                (u_sc_single.repeat(self.fic_api_feature_embedding.size(1), 1), 
                 self.fic_api_feature_embedding.t()),
                dim=1
            )
            u_concate.append(self.fic_mlp(u_concate_single).squeeze())
        
        u_mlp = torch.cat(u_concate).view(u_mm.size(0), -1)
        
        u_fic = self.fic_fcl(torch.cat((u_mm, u_mlp), dim=1))
        u_fic = self.tanh(u_fic)
        
        # ========== Fusion Layer ==========
        u_mmf = self.fusion_layer(torch.cat((u_sc, u_fic), dim=1))
        u_mmf = self.dropout(u_mmf)
        
        # ========== Multi-task Output ==========
        y_m = self.api_task_layer(u_mmf)
        z_m = self.category_task_layer(u_mmf)
        
        return self.logistic(y_m), self.logistic(z_m)


class _ImprovedVocabDataset:

    def __init__(self, data: dict, max_doc_len: int = 50, max_vocab_size: int = 8000):
        self.max_doc_len = max_doc_len
        self.api_names = data['api_names']
        self.num_api = len(self.api_names)
        self.descriptions = data['descriptions']
        self._build_vocab(max_vocab_size)

    def _build_vocab(self, max_vocab_size):
        word_freq = Counter()
        for desc in self.descriptions:
            words = [w.lower() for w in desc] if isinstance(desc, list) else str(desc).lower().split()
            word_freq.update(words)
        self.vocab = {'<PAD>': 0, '<UNK>': 1}
        for word, _ in word_freq.most_common(max_vocab_size - 2):
            self.vocab[word] = len(self.vocab)
        self.vocab_size = len(self.vocab)
        self.embed_dim = 128

    def _text_to_indices(self, text):
        words = [w.lower() for w in text] if isinstance(text, list) else str(text).lower().split()
        indices = [self.vocab.get(w, 1) for w in words[:self.max_doc_len]]
        indices += [0] * (self.max_doc_len - len(indices))
        return indices


API_MATCH_MODE = "hybrid"
GENERATION_MAX_TOKENS = 2500
USE_TASK_EXPANSION = True
HYBRID_WEIGHTS = {"retrieval": 0.40, "model": 0.35, "lexical": 0.25}
RETRIEVAL_TOP_MASHUPS = 50
POPULARITY_BETA = 0.3
MODEL_DEBIAS_ALPHA = 0.5
MODEL_TARGET_LEN = None
USE_DOMAIN_MAPPING = False
USE_FULL_INSTRUCTION = True

LEGACY_DOMAIN_MAPPING = {
    'ship': ['shipping', 'logistics', 'delivery', 'fedex', 'ups', 'dhl', 'post'],
    'pay': ['payment', 'stripe', 'paypal', 'checkout', 'transaction'],
    'send': ['email', 'sms', 'notification', 'twilio', 'sendgrid', 'message'],
    'search': ['search', 'find', 'google', 'query', 'lookup'],
    'map': ['map', 'location', 'geo', 'address', 'place'],
    'store': ['storage', 'database', 's3', 'firebase', 'cloud'],
    'verify': ['verification', 'auth', 'identity', 'validate'],
    'calculate': ['calculator', 'compute', 'math', 'score'],
    'image': ['image', 'photo', 'picture', 'visual'],
    'weather': ['weather', 'forecast', 'climate'],
    'insurance': ['insurance', 'policy', 'coverage'],
    'label': ['label', 'print', 'barcode'],
    'package': ['package', 'parcel', 'box'],
    'logistics': ['logistics', 'freight', 'carrier', 'warehouse'],
    'select': ['compare', 'choose', 'selection'],
    'offer': ['quote', 'price', 'bid', 'offer'],
    'recourse': ['complaint', 'refund', 'return', 'dispute', 'customer', 'service'],
    'order': ['order', 'purchase', 'buy', 'cart'],
}

_STOP = {"a", "an", "the", "of", "to", "for", "and", "or", "in", "on", "by", "with", "is", "are", "be",
         "it", "its", "this", "that", "as", "at", "from", "if", "who", "will", "do", "does", "can",
         "she", "he", "they", "we", "you", "i", "so", "than", "then", "into", "which", "also", "has",
         "have", "been", "all", "any", "not", "no", "yes"}


def _tokens(text: str) -> List[str]:
    return [w for w in re.sub(r"[^a-z0-9\s]", " ", str(text).lower()).split() if len(w) > 1]


def _content_tokens(text: str) -> List[str]:
    t = [w for w in _tokens(text) if w not in _STOP]
    return t or _tokens(text)


class HybridApiRecommender:

    def __init__(self, data_path, api_names: List[str], domain_mapping: Dict[str, List[str]],
                 model_fn=None, weights: Optional[Dict[str, float]] = None):
        import math
        from collections import defaultdict
        self._math, self._dd = math, defaultdict
        self.api_names = api_names
        self.api_to_idx = {n: i for i, n in enumerate(api_names)}
        self.domain_mapping = domain_mapping
        self.model_fn = model_fn
        self.weights = dict(weights or HYBRID_WEIGHTS)
        self.ok_retrieval = False

        desc_f, used_f = Path(data_path) / "mashup_description.json", Path(data_path) / "mashup_used_api.json"
        if desc_f.exists() and used_f.exists():
            with open(desc_f, "r", encoding="utf-8") as f:
                descs = json.load(f)
            with open(used_f, "r", encoding="utf-8") as f:
                used = json.load(f)
            self._build_retrieval(descs, used)
        else:
            print("  ⚠ 找不到 mashup_description.json / mashup_used_api.json，检索分支不可用")

        df = Counter()
        self.name_words = []
        for n in api_names:
            ws = [w for w in re.split(r"[-_\s.]+", n.lower()) if len(w) > 2]
            self.name_words.append(ws)
            df.update(set(ws))
        N = max(len(api_names), 1)
        self.name_idf = {w: math.log((N + 1) / (c + 1)) + 1.0 for w, c in df.items()}
        self.name_index = defaultdict(list)
        for i, ws in enumerate(self.name_words):
            for w in set(ws):
                self.name_index[w].append(i)
        print(f"  ✓ HybridApiRecommender: retrieval={'on' if self.ok_retrieval else 'off'} "
              f"model={'on' if model_fn else 'off'} lexical=on  weights={self.weights}")

    def _build_retrieval(self, descs, used):
        math, dd = self._math, self._dd
        docs = [_content_tokens(" ".join(d) if isinstance(d, list) else d) for d in descs]
        N = len(docs)
        df = Counter()
        for d in docs:
            df.update(set(d))
        self.idf = {w: math.log((N + 1) / (c + 1)) + 1.0 for w, c in df.items()}
        self.postings = dd(list)
        for mi, d in enumerate(docs):
            tf = Counter(d)
            vec = {w: (1 + math.log(c)) * self.idf[w] for w, c in tf.items()}
            norm = math.sqrt(sum(v * v for v in vec.values())) or 1.0
            for w, v in vec.items():
                self.postings[w].append((mi, v / norm))
        self.mashup_apis = [[self.api_to_idx[a] for a in (u or []) if a in self.api_to_idx] for u in used]
        self.usage = np.zeros(len(self.api_names), dtype=np.float32)
        for lst in self.mashup_apis:
            for a in lst:
                self.usage[a] += 1
        self.ok_retrieval = True

    def _retrieval_scores(self, query: Dict[str, float]) -> np.ndarray:
        math = self._math
        out = np.zeros(len(self.api_names), dtype=np.float32)
        if not self.ok_retrieval or not query:
            return out
        qv = {w: c * self.idf[w] for w, c in query.items() if w in self.idf}
        qn = math.sqrt(sum(v * v for v in qv.values())) or 1.0
        sims = self._dd(float)
        for w, v in qv.items():
            for mi, dv in self.postings[w]:
                sims[mi] += (v / qn) * dv
        for mi, sim in sorted(sims.items(), key=lambda x: -x[1])[:RETRIEVAL_TOP_MASHUPS]:
            for a in self.mashup_apis[mi]:
                out[a] += sim * sim
        return out / np.power(self.usage + 1.0, POPULARITY_BETA)

    def _lexical_scores(self, text: str) -> np.ndarray:
        scores = np.zeros(len(self.api_names), dtype=np.float32)
        kws = set(_content_tokens(text))
        for w in list(kws):
            for key, syn in self.domain_mapping.items():
                if w == key or w in syn:
                    kws.add(key)
                    kws.update(syn)
        for w in kws:
            for i in self.name_index.get(w, ()):
                scores[i] += self.name_idf[w]
        return scores

    def recommend(self, task_text: str, expansion: str = "", top_k: int = 5):
        q = self._dd(float)
        for w in _content_tokens(task_text):
            q[w] += 2.0
        for w in _content_tokens(expansion):
            q[w] += 1.0
        full_text = f"{task_text} {expansion}".strip()
        parts = {"retrieval": self._retrieval_scores(q) if self.weights.get("retrieval", 0) > 0 else None,
                 "model": self.model_fn(full_text) if (self.model_fn and self.weights.get("model", 0) > 0) else None,
                 "lexical": self._lexical_scores(full_text) if self.weights.get("lexical", 0) > 0 else None}
        total = np.zeros(len(self.api_names), dtype=np.float32)
        wsum = 0.0
        for name, vec in parts.items():
            if vec is None:
                continue
            m = float(vec.max())
            if m > 0:
                total += self.weights[name] * (vec / m)
                wsum += self.weights[name]
        if wsum > 0:
            total /= wsum
        order = np.argsort(total)[::-1][:top_k]
        return [{"api_name": self.api_names[i], "score": float(total[i]),
                 "parts": {k: (round(float(v[i] / v.max()), 3) if v is not None and v.max() > 0 else 0.0)
                           for k, v in parts.items()}} for i in order]


class AutoFlowMTFMSystem:
    
    def __init__(self, data_path: str = None, embedding_path: str = None, model_path: str = None):
        print("\n" + "=" * 60)
        print("初始化 AutoFlow + MTFM")
        print("=" * 60)
        print("  阶段1: AutoFlow (LLM + ICL 工作流生成)")
        print("  阶段2: MTFM (Multi-Task Feature Mapping)")
        
        self.data_path = Path(data_path) if data_path else SCRIPT_DIR / "data"
        self.embedding_path = Path(embedding_path) if embedding_path else SCRIPT_DIR / "embedding"
        
        print("\n[1/3] 初始化AutoFlow生成器...")
        self.autoflow = AutoFlowGenerator()
        print("  ✓ AutoFlow 初始化完成")
        
        print("\n[2/3] 加载API数据...")
        self.api_names = self._load_api_names()
        self.api_embeddings = self._load_api_embeddings()
        print(f"  ✓ API数量: {len(self.api_names)}")
        
        print("\n[3/3] 初始化MTFM模型...")
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.mtfm_model = self._init_mtfm_model(model_path)
        
        self._build_keyword_index()
        
        self.hybrid = None
        self._expansion_cache: Dict[str, str] = {}
        self._mtfm_prior = None
        if API_MATCH_MODE in ("hybrid", "mtfm_plus") and self.api_names:
            print(f"\n[+] 构建API推荐器 (mode={API_MATCH_MODE})...")
            try:
                use_model = self.mtfm_trained and self.mtfm_usable_for_inference
                weights = dict(HYBRID_WEIGHTS) if API_MATCH_MODE == "hybrid" \
                    else {"retrieval": 0.0, "model": 1.0, "lexical": 0.0}
                if not use_model:
                    weights["model"] = 0.0
                    print("  ⚠ MTFM 不可用于推理，model 分支关闭")
                self.hybrid = HybridApiRecommender(self.data_path, self.api_names,
                                                   LEGACY_DOMAIN_MAPPING if USE_DOMAIN_MAPPING else {},
                                                   model_fn=self._mtfm_plus_scores if use_model else None,
                                                   weights=weights)
            except Exception as e:
                print(f"  ⚠ 推荐器构建失败，回退到原行为: {e}")
                traceback.print_exc()
        
        print("\n" + "=" * 60)
        print("系统初始化完成!")
        print("=" * 60)
    
    def _load_api_names(self) -> List[str]:
        api_name_file = self.data_path / "api_name.json"
        if api_name_file.exists():
            with open(api_name_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return []
    
    def _load_api_embeddings(self) -> Optional[np.ndarray]:
        embed_file = self.embedding_path / "api_features_roberta.npy"
        if embed_file.exists():
            return np.load(str(embed_file))
        return None
    
    def _init_mtfm_model(self, model_path: str = None) -> Optional[MTFM]:
        self.mtfm_usable_for_inference = False
        self.mashup_ds_for_vocab = None
        self.checkpoint_kind = None

        if not self.api_names:
            print("  ⚠ 无API数据，MTFM模型未初始化")
            self.mtfm_trained = False
            return None

        if model_path is not None:
            candidates = [(Path(model_path), 'auto')]
        else:
            candidates = [
                (MODEL_ROOT / "checkpoints" / "mtfm_best.pth", 'best'),
                (MODEL_ROOT / "checkpoints" / "mtfm_improved.pth", 'improved'),
            ]

        for ckpt_path, kind in candidates:
            if not ckpt_path.exists():
                continue
            model = self._load_checkpoint(ckpt_path, kind)
            if model is not None:
                return model

        tried = ", ".join(str(c) for c, _ in candidates)
        print(f"  ⚠ 未找到可用的模型权重文件 (已尝试: {tried})")
        self.mtfm_trained = False
        return None

    def _load_checkpoint(self, model_path: Path, kind: str) -> Optional[MTFM]:
        try:
            checkpoint = torch.load(model_path, map_location=self.device, weights_only=False)

            # embedding.weight shape: [vocab_size, embed_dim]
            vocab_size = checkpoint['embedding.weight'].shape[0]
            embed_dim = checkpoint['embedding.weight'].shape[1]

            # sc_fcl.weight shape: [num_api, num_kernel * len(kernel_size)]
            num_api = checkpoint['sc_fcl.weight'].shape[0]

            # category_task_layer.weight shape: [num_category, num_api]
            num_category = checkpoint['category_task_layer.weight'].shape[0]

            # sc_convs.X.0.weight shape: [num_kernel, embed_dim, kernel_size]
            kernel_sizes = []
            num_kernel = None
            for key in checkpoint.keys():
                if key.startswith('sc_convs.') and key.endswith('.0.weight'):
                    idx = int(key.split('.')[1])
                    kernel_size = checkpoint[key].shape[2]
                    if num_kernel is None:
                        num_kernel = checkpoint[key].shape[0]
                    kernel_sizes.append((idx, kernel_size))

            kernel_sizes.sort(key=lambda x: x[0])
            kernel_size_list = [ks for _, ks in kernel_sizes]

            if kind == 'auto':
                kind = 'improved' if 'improved' in model_path.stem else 'best'
            max_doc_len = 50 if kind == 'improved' else 100

            print(f"  从checkpoint推断参数 ({model_path.name}, 按'{kind}'流程处理):")
            print(f"    - vocab_size: {vocab_size} | embed_dim: {embed_dim}")
            print(f"    - num_api: {num_api} | num_category: {num_category}")
            print(f"    - num_kernel: {num_kernel} | kernel_size: {kernel_size_list}")
            print(f"    - max_doc_len (按训练脚本推定): {max_doc_len}")

            api_names_for_model, mashup_ds = self._build_matching_vocab(kind, max_doc_len)

            if mashup_ds is None:
                print("  ⚠ 未能重建训练时的词表，权重仍会加载，但推理阶段会回退到关键词匹配")
            elif mashup_ds.vocab_size != vocab_size or len(api_names_for_model) != num_api:
                print(f"  ⚠ 重建的词表/API列表与checkpoint参数不一致 "
                      f"(vocab_size: {mashup_ds.vocab_size} vs {vocab_size}, "
                      f"num_api: {len(api_names_for_model)} vs {num_api})，"
                      f"推理阶段回退到关键词匹配")
                mashup_ds = None

            config = MTFMConfig(
                vocab_size=vocab_size,
                embed_dim=embed_dim,
                num_api=num_api,
                num_category=num_category,
                max_doc_len=max_doc_len,
                num_kernel=num_kernel,
                kernel_size=kernel_size_list
            )

            model = MTFM(config)
            model.load_state_dict(checkpoint)
            model.to(self.device)
            model.eval()

            print(f"  ✓ MTFM模型已加载: {model_path}")
            self.mtfm_trained = True
            self.mtfm_num_api = num_api
            self.checkpoint_kind = kind

            if mashup_ds is not None:
                self.mashup_ds_for_vocab = mashup_ds
                if len(api_names_for_model) != len(self.api_names):
                    print(f"  ℹ API列表已按'{kind}'checkpoint重新对齐: "
                          f"{len(self.api_names)} -> {len(api_names_for_model)}")
                self.api_names = api_names_for_model
                self.mtfm_usable_for_inference = True
                print(f"  ✓ 词表重建成功，评估阶段将真正调用MTFM模型推理 "
                      f"(共{len(api_names_for_model)}个API)")

            return model

        except Exception as e:
            print(f"  ⚠ 加载 {model_path.name} 失败: {e}")
            traceback.print_exc()
            return None

    def _build_matching_vocab(self, kind: str, max_doc_len: int):
        if kind == 'best':
            try:
                from tools.dataset import MashupDataset as _RealMashupDataset
            except Exception as e:
                print(f"  ⚠ 无法导入 tools.dataset.MashupDataset ({e})，跳过词表重建")
                return None, None
            try:
                mashup_ds = _RealMashupDataset(
                    data_path=str(self.data_path),
                    embedding_path=str(self.embedding_path),
                    use_roberta=False,
                    max_doc_len=max_doc_len,
                )
            except Exception as e:
                print(f"  ⚠ 重建训练时词表失败 (data_path={self.data_path}): {e}")
                return None, None
            return list(mashup_ds.api_names), mashup_ds

        elif kind == 'improved':
            min_usage = 5
            cfg_path = MODEL_ROOT / "checkpoints" / "mtfm_improved_config.json"
            if cfg_path.exists():
                try:
                    with open(cfg_path, 'r', encoding='utf-8') as f:
                        saved_cfg = json.load(f)
                    min_usage = saved_cfg.get('min_api_usage', min_usage)
                except Exception:
                    pass
            try:
                data = self._preprocess_data_for_improved(self.data_path, min_usage=min_usage)
                mashup_ds = _ImprovedVocabDataset(data, max_doc_len=max_doc_len, max_vocab_size=8000)
            except Exception as e:
                print(f"  ⚠ 重建improved流程词表失败: {e}")
                return None, None
            return list(mashup_ds.api_names), mashup_ds

        return None, None

    @staticmethod
    def _preprocess_data_for_improved(data_path: Path, min_usage: int = 5) -> dict:
        with open(data_path / "api_name.json", 'r', encoding='utf-8') as f:
            _ = json.load(f)
        with open(data_path / "mashup_description.json", 'r', encoding='utf-8') as f:
            mashup_descriptions = json.load(f)
        with open(data_path / "mashup_used_api.json", 'r', encoding='utf-8') as f:
            mashup_used_apis = json.load(f)
        with open(data_path / "mashup_category.json", 'r', encoding='utf-8') as f:
            mashup_categories = json.load(f)
        with open(data_path / "category_list.json", 'r', encoding='utf-8') as f:
            categories = json.load(f)

        api_counter = Counter()
        for apis in mashup_used_apis:
            for api in apis:
                api_counter[api] += 1

        valid_apis = [api for api, count in api_counter.items() if count >= min_usage]
        valid_api_set = set(valid_apis)
        valid_apis = sorted(valid_apis, key=lambda x: -api_counter[x])

        filtered_indices = [i for i, apis in enumerate(mashup_used_apis)
                            if any(api in valid_api_set for api in apis)]

        return {
            'api_names': valid_apis,
            'descriptions': [mashup_descriptions[i] for i in filtered_indices],
            'used_apis': [[api for api in mashup_used_apis[i] if api in valid_api_set] for i in filtered_indices],
            'categories': [mashup_categories[i] for i in filtered_indices],
            'category_list': categories
        }
    
    def _build_keyword_index(self):
        self.api_keywords = {}
        for i, name in enumerate(self.api_names):
            words = name.lower().replace('-', ' ').replace('_', ' ').split()
            for word in words:
                if len(word) > 2:
                    if word not in self.api_keywords:
                        self.api_keywords[word] = []
                    self.api_keywords[word].append(i)
    
    def _doc_len_median(self) -> int:
        ds = self.mashup_ds_for_vocab
        descs = getattr(ds, "mashup_descriptions", None) or getattr(ds, "descriptions", None) or []
        lens = sorted(len(d) if isinstance(d, list) else len(str(d).split()) for d in descs)
        return lens[len(lens) // 2] if lens else 30

    def _mtfm_plus_scores(self, text: str) -> np.ndarray:
        ds = self.mashup_ds_for_vocab
        vocab, L = ds.vocab, int(ds.max_doc_len)
        ids = [vocab[w] for w in _tokens(text) if w in vocab]
        if not ids:
            return np.zeros(len(self.api_names), dtype=np.float32)
        T = min(int(MODEL_TARGET_LEN or self._doc_len_median()), L)
        ids = (ids * (T // len(ids) + 1))[:T]
        ids = ids + [0] * (L - len(ids))

        def logit(pred):
            p = np.clip(pred, 1e-6, 1 - 1e-6)
            return np.log(p / (1 - p))

        def forward(x):
            with torch.no_grad():
                api_pred, _ = self.mtfm_model(torch.LongTensor([x]).to(self.device))
            return api_pred.cpu().numpy()[0]

        if self._mtfm_prior is None:
            self._mtfm_prior = logit(forward([0] * L))
        adj = logit(forward(ids)) - MODEL_DEBIAS_ALPHA * self._mtfm_prior
        if adj.shape[0] != len(self.api_names):
            return np.zeros(len(self.api_names), dtype=np.float32)
        k = min(50, adj.shape[0])
        kth, top = np.partition(adj, -k)[-k], adj.max()
        return np.clip((adj - kth) / (top - kth + 1e-9), 0, None).astype(np.float32)

    def recommend_api(self, task_text: str, top_k: int = 5) -> List[Dict]:
        if not self.api_names:
            return [{"api_name": "manual-task", "score": 0.5, "method": "fallback"}]

        if API_MATCH_MODE in ("hybrid", "mtfm_plus") and getattr(self, "hybrid", None) is not None:
            expansion = ""
            if USE_TASK_EXPANSION:
                if task_text not in self._expansion_cache:
                    self._expansion_cache[task_text] = self.autoflow.expand_task(task_text)
                expansion = self._expansion_cache[task_text]
                print(f"      改写: {expansion[:70]}")
            recs = self.hybrid.recommend(task_text, expansion, top_k=top_k)
            print(f"      分项(top1): {recs[0]['parts']}")
            return [{"api_name": r["api_name"], "score": r["score"], "method": f"{API_MATCH_MODE}"} for r in recs]

        method = "keyword_only"
        if self.mtfm_trained and self.mtfm_usable_for_inference:
            try:
                scores = self._mtfm_predict_score(task_text)
                method = "mtfm"
            except Exception as e:
                print(f"  ⚠ MTFM推理失败 ({e})，本次任务回退到关键词匹配")
                scores = self._keyword_match_score(task_text)
                method = "keyword_fallback"
        else:
            scores = self._keyword_match_score(task_text)
            method = "keyword_fallback" if self.mtfm_trained else "keyword_only"

        top_indices = np.argsort(scores)[::-1][:top_k]

        recommendations = []
        for idx in top_indices:
            recommendations.append({
                "api_name": self.api_names[idx],
                "score": float(scores[idx]),
                "method": method
            })

        return recommendations

    def _mtfm_predict_score(self, task_text: str) -> np.ndarray:
        indices = self.mashup_ds_for_vocab._text_to_indices(task_text)
        input_tensor = torch.LongTensor([indices]).to(self.device)
        with torch.no_grad():
            api_pred, _ = self.mtfm_model(input_tensor)
        return api_pred.cpu().numpy()[0]
    
    def _keyword_match_score(self, task_text: str) -> np.ndarray:
        scores = np.zeros(len(self.api_names), dtype=np.float32)
        task_lower = task_text.lower()
        
        domain_mapping = {
            'ship': ['shipping', 'logistics', 'delivery', 'fedex', 'ups', 'dhl', 'post'],
            'pay': ['payment', 'stripe', 'paypal', 'checkout', 'transaction'],
            'send': ['email', 'sms', 'notification', 'twilio', 'sendgrid', 'message'],
            'search': ['search', 'find', 'google', 'query', 'lookup'],
            'map': ['map', 'location', 'geo', 'address', 'place'],
            'store': ['storage', 'database', 's3', 'firebase', 'cloud'],
            'verify': ['verification', 'auth', 'identity', 'validate'],
            'calculate': ['calculator', 'compute', 'math', 'score'],
            'image': ['image', 'photo', 'picture', 'visual'],
            'weather': ['weather', 'forecast', 'climate'],
            'insurance': ['insurance', 'policy', 'coverage'],
            'label': ['label', 'print', 'barcode'],
            'package': ['package', 'parcel', 'box'],
            'logistics': ['logistics', 'freight', 'carrier', 'warehouse'],
            'select': ['compare', 'choose', 'selection'],
            'offer': ['quote', 'price', 'bid', 'offer'],
            'recourse': ['complaint', 'refund', 'return', 'dispute', 'customer', 'service'],
            'order': ['order', 'purchase', 'buy', 'cart'],
        }
        
        task_keywords = set()
        for word in task_lower.split():
            word = word.strip('.,!?;:')
            if len(word) > 2:
                task_keywords.add(word)
                for key, synonyms in domain_mapping.items():
                    if word == key or word in synonyms:
                        task_keywords.add(key)
                        task_keywords.update(synonyms)
        
        for i, api_name in enumerate(self.api_names):
            api_lower = api_name.lower()
            score = 0
            for kw in task_keywords:
                if kw in api_lower:
                    score += 1
            scores[i] = score
        
        if scores.max() > 0:
            scores = scores / scores.max()
        
        return scores
    
    def run(self, user_request: str, scenario_name: str):
        print(f"\n{'='*60}")
        print(f"AutoFlow_MTFM 处理场景: {scenario_name}")
        print(f"{'='*60}")
        
        start_time = time.time()
        self._expansion_cache = {}
        
        print("\n[Stage 1] AutoFlow - 生成工作流结构 (含结构公平性修复)")
        print("-" * 50)

        min_tasks, max_tasks = _estimate_task_range(user_request)
        print(f"  [任务数目标区间] {min_tasks}-{max_tasks} "
              f"(与LEWR相同启发式 _estimate_task_range 估计)")

        def target_score(count):
            if min_tasks <= count <= max_tasks:
                return 100 - abs(count - (min_tasks + max_tasks) // 2)
            elif count < min_tasks:
                return count - min_tasks
            else:
                return max_tasks - count

        best_result = None
        best_score = -999
        best_task_count = 0

        for attempt in range(3):
            print(f"\n  [Workflow Generation Attempt {attempt + 1}/3]")
            if attempt == 0:
                desc_to_use = user_request
            elif attempt == 1:
                desc_to_use = _augment_description_with_task_requirement(
                    user_request, min_tasks, max_tasks, level="strong"
                )
            else:
                desc_to_use = _augment_description_with_task_requirement(
                    user_request, min_tasks, max_tasks, level="maximum"
                )

            result = self.autoflow.generate(desc_to_use)
            task_count = len([t for t in result.get('tasks', []) if t.get('type') != 'endEvent'])
            print(f"    → 生成 {task_count} 个非终止任务 (目标 {min_tasks}-{max_tasks})")

            score = target_score(task_count)
            if score > best_score:
                best_score = score
                best_task_count = task_count
                best_result = result

            if min_tasks <= task_count <= max_tasks:
                print(f"    ✓ 任务数在目标区间内，停止重试")
                break

        workflow_result = best_result
        print(f"\n  → 最终采用结果: {best_task_count} 个非终止任务")

        tasks_raw = workflow_result.get('tasks', [])
        gateways_raw = workflow_result.get('gateways', [])
        deps_raw = workflow_result.get('dependencies', [])
        step_map = workflow_result.get('step_map', {})
        raw_dependency_records = workflow_result.get('raw_dependencies', [])

        print(f"  ✓ 任务数: {len(tasks_raw)}")
        print(f"  ✓ 网关数: {len(gateways_raw)}")
        print(f"  ✓ 依赖数 (raw, 悬空分支已被丢弃): {len(deps_raw)}")

        for task in tasks_raw[:5]:
            print(f"    [{task.get('id', '?')}] {task.get('name', '?')[:50]}")
        if len(tasks_raw) > 5:
            print(f"    ... 还有 {len(tasks_raw) - 5} 个任务")

        print("\n  [结构修复] 对应LEWR _fix_has_join_recursive 的CoRE版本")
        fixed_tasks, fixed_gateways, fixed_deps, repair_log = _fix_workflow_structure(
            tasks_raw, gateways_raw, deps_raw, step_map, raw_dependency_records
        )
        if repair_log:
            for action in repair_log:
                print(f"    🔧 {action['type']}: {action}")
        else:
            print(f"    (本次无需修复)")

        raw_validation = _validate_workflow_structure(tasks_raw, gateways_raw, deps_raw)
        repaired_validation = _validate_workflow_structure(fixed_tasks, fixed_gateways, fixed_deps)
        print(f"\n  [验证] raw is_valid={raw_validation['is_valid']} "
              f"errors={raw_validation['errors']}")
        print(f"  [验证] repaired is_valid={repaired_validation['is_valid']} "
              f"errors={repaired_validation['errors']}")

        print("\n[Stage 2] MTFM - API推荐")
        print("-" * 50)

        def build_api_bindings(task_list):
            bindings = {}
            for task in task_list:
                task_id = task.get('id', '')
                task_name = task.get('name', task.get('full_instruction', ''))
                if task.get('type') == 'endEvent':
                    continue
                query_text = task_name
                if USE_FULL_INSTRUCTION and API_MATCH_MODE != "legacy":
                    query_text = task.get('full_instruction') or task_name
                recommendations = self.recommend_api(query_text, top_k=5)
                if recommendations:
                    top_api = recommendations[0]
                    bindings[task_id] = {
                        "task_name": task_name,
                        "api_name": top_api['api_name'],
                        "confidence": top_api['score'],
                        "method": top_api.get('method', 'unknown'),
                        "top5_candidates": [
                            {"api_name": r['api_name'], "score": r['score'], "method": r.get('method', 'unknown')}
                            for r in recommendations
                        ]
                    }
                    print(f"  [{task_id}] {task_name[:40]}...")
                    print(f"      → Top-1: {top_api['api_name']} ({top_api['score']:.3f})")
            return bindings

        repaired_api_bindings = build_api_bindings(fixed_tasks)
        raw_task_ids = {t['id'] for t in tasks_raw}
        raw_api_bindings = {tid: b for tid, b in repaired_api_bindings.items() if tid in raw_task_ids}

        unique_apis_repaired = set(b['api_name'] for b in repaired_api_bindings.values())
        print(f"\n  📊 API多样性 (repaired): {len(unique_apis_repaired)}/{len(repaired_api_bindings)} 个不同Top-1 API")

        execution_time = time.time() - start_time

        def format_tasks(task_list):
            return [{"id": t.get('id', ''), "name": t.get('name', ''), "type": t.get('type', 'userTask')} for t in task_list]

        def format_gateways(gw_list):
            return [{"id": gw.get('id', ''), "type": gw.get('type', 'exclusive'), "name": gw.get('name', '')} for gw in gw_list]

        raw_output = UnifiedOutput(
            method="AutoFlow_MTFM_raw",
            scenario_name=scenario_name,
            user_request=user_request,
            tasks=format_tasks(tasks_raw),
            dependencies=deps_raw,
            gateways=format_gateways(gateways_raw),
            api_bindings=raw_api_bindings,
            roles=[],
            execution_time=execution_time,
            extra_info={
                "workflow_generator": "AutoFlow (ICL)",
                "api_recommender": "MTFM",
                "api_match_mode": API_MATCH_MODE,
                "mtfm_trained": self.mtfm_trained if hasattr(self, 'mtfm_trained') else False,
                "workflow_text": workflow_result.get('workflow_text', '')[:500],
                "api_diversity": f"{len(set(b['api_name'] for b in raw_api_bindings.values()))}/{len(raw_api_bindings)}",
                "structural_repair_applied": False,
                "task_count_target_range": [min_tasks, max_tasks],
                "generation_attempts_used": attempt + 1,
                "validation": raw_validation
            }
        )

        repaired_output = UnifiedOutput(
            method="AutoFlow_MTFM_repaired",
            scenario_name=scenario_name,
            user_request=user_request,
            tasks=format_tasks(fixed_tasks),
            dependencies=fixed_deps,
            gateways=format_gateways(fixed_gateways),
            api_bindings=repaired_api_bindings,
            roles=[],
            execution_time=execution_time,
            extra_info={
                "workflow_generator": "AutoFlow (ICL)",
                "api_recommender": "MTFM",
                "api_match_mode": API_MATCH_MODE,
                "mtfm_trained": self.mtfm_trained if hasattr(self, 'mtfm_trained') else False,
                "workflow_text": workflow_result.get('workflow_text', '')[:500],
                "api_diversity": f"{len(unique_apis_repaired)}/{len(repaired_api_bindings)}",
                "structural_repair_applied": True,
                "repair_log": repair_log,
                "task_count_target_range": [min_tasks, max_tasks],
                "generation_attempts_used": attempt + 1,
                "validation": repaired_validation
            }
        )

        return raw_output, repaired_output


EVAL_SCRIPT_DIR_OVERRIDE = None
ENGLISH_DIR_OVERRIDE = None
VARIANTS = ["raw", "repaired"]
REPORT_PREFIX = "autoflow_mtfm"
REPORT_SUBDIR = "autoflow_mtfm_report"


def _init_scorer():
    try:
        sys.path.insert(0, str(EVAL_SCRIPT_DIR_OVERRIDE or EVAL_ROOT))
        import evaluate_all_results_GED_v3 as ged_eval
        if ENGLISH_DIR_OVERRIDE is not None:
            ged_eval.ENGLISH_DIR = ENGLISH_DIR_OVERRIDE
        if not ged_eval.ENGLISH_DIR.exists():
            print(f"⚠ Ground Truth 目录不存在: {ged_eval.ENGLISH_DIR}，只统计结构指标（没有 AB/Overall）")
            return None, None
        scorer = ged_eval.BERTScorer()
        print(f"✓ 评分模块就绪，Ground Truth: {ged_eval.ENGLISH_DIR}")
        return ged_eval, scorer
    except Exception as e:
        print(f"⚠ 评分模块导入失败，只统计结构指标: {e}")
        return None, None


_AB_CONTAINERS = {"primary_metrics", "detailed_metrics", "detail", "details", "metrics"}
_ab_diag_printed = False


def _path_tokens(path) -> List[str]:
    return re.split(r"[^a-z0-9]+", ".".join(path).lower())


def _is_ab_sub_path(path, strict: bool) -> bool:
    toks = _path_tokens(path)
    if "ged" in toks:
        return False
    is_pn = any(t == "p" or re.fullmatch(r"p\d+", t) or t.startswith("precision") or "ndcg" in t
                for t in toks)
    if not is_pn:
        return False
    return (not strict) or any(t in ("api", "ab", "binding") for t in toks)


def _walk_numeric(obj, path=()):
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield from _walk_numeric(v, path + (str(k),))
    elif isinstance(obj, (int, float)) and not isinstance(obj, bool) and obj == obj:
        yield list(path), float(obj)


def extract_ab_submetrics(ev: Dict[str, Any]) -> Dict[str, float]:
    global _ab_diag_printed
    leaves = list(_walk_numeric(ev))
    hits = [(p, v) for p, v in leaves if _is_ab_sub_path(p, strict=True)]
    loose = False
    if not hits:
        hits = [(p, v) for p, v in leaves if _is_ab_sub_path(p, strict=False)]
        loose = True
    out: Dict[str, float] = {}
    for path, val in hits:
        parts = [x for x in path if x.lower() not in _AB_CONTAINERS]
        name = re.sub(r"[^a-z0-9]+", "_", "_".join(parts).lower()).strip("_")
        name = re.sub(r"^(api_binding_|api_|ab_)", "", name)
        key = "ab_" + name
        if key in out:
            key = "ab_" + re.sub(r"[^a-z0-9]+", "_", ".".join(path).lower()).strip("_")
        out[key] = val
    if (not out or loose) and not _ab_diag_printed:
        _ab_diag_printed = True
        if not out:
            print("    ⚠ [P/NDCG] 评分结果里没找到 P / NDCG 键。评分结果中的全部数值键如下，"
                  "请把它们发给我以便对上：")
            shown = [".".join(p) for p, _ in leaves]
        else:
            print("    ℹ [P/NDCG] 在 api/binding 路径下没找到，已按键名宽松匹配，请核对以下键是否确为 AB 的 P/NDCG：")
            shown = [".".join(p) for p, _ in hits]
        for line in shown[:60]:
            print(f"        {line}")
    return out


def _ab_label(key: str) -> str:
    n = key[3:].replace("_at_", "@")
    n = re.sub(r"^(p|ndcg|precision)_(\d+)$", r"\1@\2", n)
    n = re.sub(r"^precision", "p", n)                    # precision@5 -> P@5
    return "AB-" + n.upper()


def _ab_sort_key(key: str):
    n = key[3:]
    parts = re.split(r"(\d+)", n)
    return (1 if "ndcg" in n else 0, [int(t) if i % 2 else t for i, t in enumerate(parts)])


def collect_ab_keys(recs) -> List[str]:
    keys: List[str] = []
    for r in recs:
        for k, v in r.items():
            if k.startswith("ab_") and k not in keys and isinstance(v, (int, float)):
                keys.append(k)
    return sorted(keys, key=_ab_sort_key)


def build_record(result, scenario_name: str, elapsed: float,
                 scorer_module=None, scorer_instance=None) -> Dict[str, Any]:
    api_b = getattr(result, "api_bindings", {}) or {}
    extra = getattr(result, "extra_info", {}) or {}
    validation = extra.get("validation") or {}
    vstat = validation.get("statistics") or {}
    is_fallback = not str(extra.get("workflow_text", "")).strip()
    rec: Dict[str, Any] = {
        "scenario": scenario_name, "success": True, "error": None,
        "elapsed_sec": round(elapsed, 2),
        "task_count": len(getattr(result, "tasks", []) or []),
        "gateway_count": len(getattr(result, "gateways", []) or []),
        "dependency_count": len(getattr(result, "dependencies", []) or []),
        "api_binding_count": len(api_b),
        "api_diversity": len({b.get("api_name") for b in api_b.values()}),
        "is_fallback": is_fallback,
        "validation_is_valid": bool(validation.get("is_valid")) and not is_fallback,
        "validation_errors": validation.get("errors", []),
        "validation_warnings": validation.get("warnings", []),
        "unreachable_count": vstat.get("unreachable_count"),
        "zero_outedge_gateway_count": vstat.get("zero_outedge_gateway_count"),
        "collapsed_branch_gateway_count": vstat.get("collapsed_branch_gateway_count"),
        "generation_attempts_used": extra.get("generation_attempts_used"),
        "repair_count": len(extra.get("repair_log", []) or []),
        "api_match_mode": extra.get("api_match_mode"),
        "top1_apis": {tid: b.get("api_name") for tid, b in api_b.items()},
        "top5_apis": {tid: [c.get("api_name") for c in (b.get("top5_candidates") or [])]
                      for tid, b in api_b.items()},
    }
    if is_fallback:
        print("    ⚠ 本次没有拿到任何工作流文本（LLM 调用全部失败），下面的得分不可信，建议重跑该场景")
    if scorer_module is not None and scorer_instance is not None:
        try:
            normed = scorer_module.normalize_result(result.to_dict())
            gt_key = scorer_module.SCENARIO_NAME_MAPPING.get(scenario_name, scenario_name)
            gt = scorer_module.load_ground_truth(gt_key)
            if gt is None:
                print(f"    ⚠ 找不到 {gt_key} 的 ground truth，跳过打分")
            else:
                ann = scorer_module.load_api_annotations(gt_key)
                if not ann:
                    print(f"    ⚠ {gt_key} 没有加载到 API 标注，API 得分会失真")
                ev = scorer_module.evaluate_single(normed, gt, scorer_instance, ann)
                pm = ev["primary_metrics"]
                rec.update({"overall_score": ev["overall_score"], "ged_quality": pm["ged_quality"],
                            "api_binding_score": pm["api_binding"],
                            "structural_validity": pm["structural_validity"]})
                gd = ev.get("ged_distances") or {}
                dm = ev.get("detailed_metrics") or {}
                rec["ged_raw_greedy"] = gd.get("greedy", dm.get("ged_greedy"))
                rec["ged_raw_tabu"] = gd.get("tabu_search", dm.get("ged_tabu"))
                rec["ged_raw_ants"] = gd.get("ants", dm.get("ged_ants"))
                rec["ged_raw_simann"] = gd.get("sim_ann", dm.get("ged_sa"))
                rec["ged_raw_avg"] = gd.get("average", dm.get("ged_avg"))
                rec.update(extract_ab_submetrics(ev))
                rec["eval_detail"] = json.loads(json.dumps(ev, default=str))
        except Exception as err:
            print(f"    ⚠ 打分失败（不影响结构统计）: {err}")
            rec["score_error"] = str(err)
    return rec


def _failed_record(scenario_name: str, error: str, elapsed: float) -> Dict[str, Any]:
    return {"scenario": scenario_name, "success": False, "error": error, "elapsed_sec": round(elapsed, 2)}


def _print_run_line(variant: str, rec: Dict[str, Any]):
    msg = (f"  [{variant:<8}] tasks={rec['task_count']} api={rec['api_binding_count']} "
           f"div={rec['api_diversity']} valid={rec['validation_is_valid']}")
    if "overall_score" in rec:
        msg += (f" | Overall={rec['overall_score']:.3f} GQ={rec['ged_quality']:.3f} "
                f"AB={rec['api_binding_score']:.3f} SV={rec['structural_validity']:.3f}")
        for k in sorted((k for k, v in rec.items() if k.startswith("ab_") and isinstance(v, (int, float))),
                        key=_ab_sort_key):
            msg += f" {_ab_label(k)}={rec[k]:.3f}"
    print(msg)


_TABLE_COLS = [("Overall", "overall_score", 3), ("GQ", "ged_quality", 3), ("AB(API)", "api_binding_score", 3),
               ("SV", "structural_validity", 3), ("GED_raw_avg", "ged_raw_avg", 2),
               ("#Tasks", "task_count", 0), ("#API绑定", "api_binding_count", 0)]


def build_report_rows(recs: List[Dict[str, Any]], ab_keys: List[str]) -> List[Dict[str, str]]:
    cols = list(_TABLE_COLS)
    i = next(i for i, c in enumerate(cols) if c[1] == "api_binding_score") + 1
    cols[i:i] = [(_ab_label(k), k, 3) for k in ab_keys]

    def cell(r, key, nd):
        if not r.get("success"):
            return "FAIL"
        v = r.get(key)
        if v is None:
            return "N/A"
        return f"{v:.{nd}f}" if nd else str(int(v))

    rows = []
    for r in recs:
        row = {"Scenario": r["scenario"]}
        for label, key, nd in cols:
            row[label] = cell(r, key, nd)
        row["Valid"] = ("Y" if r.get("validation_is_valid") else "N") if r.get("success") else "FAIL"
        row["Fallback"] = ("Y" if r.get("is_fallback") else "-") if r.get("success") else "FAIL"
        rows.append(row)

    done = [r for r in recs if r.get("success")]
    ok = [r for r in done if not r.get("is_fallback")]
    mean_row = {"Scenario": f"Mean (跨场景, n={len(ok)}/{len(recs)})"}
    for label, key, nd in cols:
        vals = [r[key] for r in ok if r.get(key) is not None]
        mean_row[label] = "N/A" if not vals else f"{statistics.mean(vals):.{nd or 1}f}"
    mean_row["Valid"] = f"{sum(1 for r in done if r.get('validation_is_valid'))}/{len(done)}" if done else "N/A"
    mean_row["Fallback"] = f"{sum(1 for r in done if r.get('is_fallback'))}/{len(done)}" if done else "N/A"
    return rows + [mean_row]


def write_markdown(path: Path, title: str, rows: List[Dict[str, str]]):
    cols = list(rows[0].keys())
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"### {title}\n\n")
        f.write("| " + " | ".join(cols) + " |\n|" + "|".join(["---"] * len(cols)) + "|\n")
        for r in rows:
            f.write("| " + " | ".join(str(r[c]) for c in cols) + " |\n")
        f.write("\n")


def print_table(title: str, rows: List[Dict[str, str]]):
    cols = list(rows[0].keys())
    w = {c: max(len(c), *(len(str(r[c])) for r in rows)) for c in cols}
    print(f"\n{title}")
    print("  " + " | ".join(c.ljust(w[c]) for c in cols))
    print("  " + "-+-".join("-" * w[c] for c in cols))
    for r in rows:
        print("  " + " | ".join(str(r[c]).ljust(w[c]) for c in cols))


def write_csv(path: Path, rows: List[Dict[str, Any]]):
    fields: List[str] = []
    for r in rows:
        for k in r:
            if k not in fields:
                fields.append(k)
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k) for k in fields})


def save_records(records: List[Dict[str, Any]], report_dir: Path, prefix: str):
    report_dir.mkdir(parents=True, exist_ok=True)
    with open(report_dir / f"{prefix}_records.json", "w", encoding="utf-8") as f:
        json.dump(records, f, indent=2, ensure_ascii=False, default=str)


def write_report(records: List[Dict[str, Any]], api_mode: str, report_dir: Path):
    report_dir.mkdir(parents=True, exist_ok=True)
    prefix = f"{REPORT_PREFIX}_{api_mode}"
    for v in VARIANTS:
        recs = [item[v] for item in records if v in item]
        if not recs:
            continue
        rows = build_report_rows(recs, collect_ab_keys(recs))
        title = f"AutoFlow_MTFM [{v}] api_mode={api_mode}（单次运行）"
        print_table(title, rows)
        write_csv(report_dir / f"{prefix}_table_{v}.csv", rows)
        write_markdown(report_dir / f"{prefix}_table_{v}.md", title, rows)
    print(f"\n  ✓ 汇总表已保存: {report_dir}")
    print(f"      {prefix}_table_raw.(csv|md) / {prefix}_table_repaired.(csv|md)")
    print(f"      {prefix}_records.json  (含每个任务的 Top-1/Top-5 API 与完整评分明细)")


def _parse_args():
    p = argparse.ArgumentParser(description="AutoFlow_MTFM 单次评估运行（raw + repaired 双版本）")
    p.add_argument("--api-mode", choices=["hybrid", "mtfm_plus", "legacy"], default=API_MATCH_MODE,
                   help="API匹配模式：hybrid(默认) / mtfm_plus / legacy(原方法)")
    p.add_argument("--scenarios", type=str, default=None, help="逗号分隔的场景名（默认全部场景）")
    p.add_argument("--no-score", action="store_true", help="不加载评分模块，只做生成 + 结构统计")
    return p.parse_args()


def main():
    global API_MATCH_MODE
    args = _parse_args()
    API_MATCH_MODE = args.api_mode

    print("\n")
    print("╔" + "═" * 58 + "╗")
    print("║" + " " * 8 + "AutoFlow_MTFM 评估运行脚本 (修复版)" + " " * 4 + "║")
    print("║" + " " * 4 + "AutoFlow工作流生成 + MTFM API推荐" + " " * 10 + "║")
    print("╚" + "═" * 58 + "╝")
    print(f"  api_mode = {API_MATCH_MODE}   (每个场景单次运行)")

    data_path = SCRIPT_DIR / "data"
    embedding_path = SCRIPT_DIR / "embedding"

    if not data_path.exists():
        data_path = MODEL_ROOT / "data"
    if not embedding_path.exists():
        embedding_path = MODEL_ROOT / "embedding"

    scorer_module = scorer_instance = None
    if not args.no_score:
        scorer_module, scorer_instance = _init_scorer()
    else:
        print("  (--no-score: 跳过评分)")

    system = AutoFlowMTFMSystem(
        data_path=str(data_path),
        embedding_path=str(embedding_path)
    )

    scenarios = list(BPMN_TEST_SCENARIOS)
    if args.scenarios:
        wanted = [s.strip() for s in args.scenarios.split(",") if s.strip()]
        scenarios = [s for s in scenarios if s.name in wanted]
        missing = [w for w in wanted if w not in {s.name for s in scenarios}]
        if missing:
            print(f"  ⚠ 这些场景名没匹配上: {missing}；scenarios.py 里可用的场景: "
                  f"{[s.name for s in BPMN_TEST_SCENARIOS]}")
        if not scenarios:
            print("  ✗ 没有可运行的场景，退出")
            return

    print("\n" + "=" * 60)
    print("开始评估测试场景")
    print("=" * 60)
    print("[公平性修复 Comment #5] 每个场景现在产出两份结果:")
    print("  - raw: 未经结构修复的原始baseline输出 (与原v6行为一致)")
    print("  - repaired: 应用了与LEWR对等的结构修复后的输出")
    print(f"本次共 {len(scenarios)} 个场景: {[s.name for s in scenarios]}")
    print("=" * 60)

    output_dir = EVAL_ROOT / "results"
    report_dir = output_dir / REPORT_SUBDIR
    prefix = f"{REPORT_PREFIX}_{API_MATCH_MODE}"

    raw_results = []
    repaired_results = []
    records: List[Dict[str, Any]] = []
    aborted = False
    for i, scenario in enumerate(scenarios):
        print(f"\n>>> 场景 [{i+1}/{len(scenarios)}]: {scenario.name}")
        t0 = time.time()
        item: Dict[str, Any] = {"scenario": scenario.name}
        fail_reason = None
        try:
            raw_result, repaired_result = system.run(scenario.requirement, scenario.name)
            raw_results.append(raw_result)
            repaired_results.append(repaired_result)

            print(f"\n结果摘要 (raw / repaired):")
            print(f"  - 任务数: {len(raw_result.tasks)} / {len(repaired_result.tasks)}")
            print(f"  - 依赖数: {len(raw_result.dependencies)} / {len(repaired_result.dependencies)}")
            print(f"  - 网关数: {len(raw_result.gateways)} / {len(repaired_result.gateways)}")
            print(f"  - API绑定数: {len(raw_result.api_bindings)} / {len(repaired_result.api_bindings)}")
            print(f"  - raw is_valid: {raw_result.extra_info['validation']['is_valid']}")
            print(f"  - repaired is_valid: {repaired_result.extra_info['validation']['is_valid']}")
            print(f"  - 执行时间: {repaired_result.execution_time:.2f}s")

            print("\n[评分]" if scorer_module is not None else "\n[结构统计]")
            for v, res in zip(VARIANTS, (raw_result, repaired_result)):
                rec = build_record(res, scenario.name, repaired_result.execution_time,
                                   scorer_module, scorer_instance)
                item[v] = rec
                _print_run_line(v, rec)
        except KeyboardInterrupt:
            print(f"\n  ⚠ 用户中断，跳过场景 {scenario.name}")
            print(f"    (再次按Ctrl+C退出整个程序)")
            fail_reason = "interrupted"
            try:
                time.sleep(2)
            except KeyboardInterrupt:
                print(f"\n程序被用户终止")
                aborted = True
        except Exception as e:
            print(f"  ✗ 场景 {scenario.name} 处理失败: {e}")
            traceback.print_exc()
            fail_reason = str(e)

        if fail_reason is not None:
            for v in VARIANTS:
                item.setdefault(v, _failed_record(scenario.name, fail_reason, time.time() - t0))
        records.append(item)
        save_records(records, report_dir, prefix)
        if aborted:
            break

    if raw_results:
        save_results(raw_results, str(output_dir), "autoflow_mtfm_raw")
        save_results(repaired_results, str(output_dir), "autoflow_mtfm_repaired")
    else:
        print("\n  ⚠ 没有任何场景成功，未写出 raw / repaired 结果文件")

    repair_summary = []
    for r in repaired_results:
        repair_summary.append({
            "scenario_name": r.scenario_name,
            "repair_log": r.extra_info.get("repair_log", []),
            "raw_errors": None,
            "repaired_errors": r.extra_info["validation"]["errors"],
            "repaired_warnings": r.extra_info["validation"]["warnings"]
        })
    for entry, raw_r in zip(repair_summary, raw_results):
        entry["raw_errors"] = raw_r.extra_info["validation"]["errors"]
        entry["raw_warnings"] = raw_r.extra_info["validation"]["warnings"]

    summary_path = Path(output_dir) / "autoflow_mtfm_repair_error_analysis.json"
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    with open(summary_path, 'w', encoding='utf-8') as f:
        json.dump(repair_summary, f, indent=2, ensure_ascii=False)
    print(f"\n  ✓ 修复错误分析已保存: {summary_path}")

    write_report(records, API_MATCH_MODE, report_dir)

    print("\n" + "=" * 60)
    print("AutoFlow_MTFM 评估完成! (raw + repaired 双版本)")
    print("=" * 60)


if __name__ == "__main__":
    main()
