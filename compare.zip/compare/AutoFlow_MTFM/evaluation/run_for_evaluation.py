import os
import sys
import json
import time
import re
import requests
import traceback
import numpy as np
import torch
import torch.nn as nn
from pathlib import Path
from typing import List, Dict, Any, Optional
from collections import Counter


SCRIPT_DIR = Path(__file__).parent.absolute()
PROJECT_ROOT = SCRIPT_DIR.parent.parent  # evaluation_framework_complete/
EVAL_ROOT = SCRIPT_DIR.parent  # evaluation_framework_complete/evaluation/


POSSIBLE_MODEL_PATHS = [

    PROJECT_ROOT / "models" / "AutoFlow" / "AutoFlow_MTFM_Complete" / "AutoFlow_MTFM_Complete",
]

def find_model_root():

    for path in POSSIBLE_MODEL_PATHS:
        checkpoint_path = path / "checkpoints" / "mtfm_best.pth"
        if checkpoint_path.exists():
            print(f"  找到模型目录: {path}")
            return path

        data_path = path / "data" / "api_name.json"
        if data_path.exists():
            print(f"  找到数据目录: {path}")
            return path
    return POSSIBLE_MODEL_PATHS[0]

MODEL_ROOT = find_model_root()

sys.path.insert(0, str(EVAL_ROOT / "common"))
sys.path.insert(0, str(MODEL_ROOT))

from scenarios import BPMN_TEST_SCENARIOS, UnifiedOutput, save_results



class AutoFlowGenerator:

    CORE_SYNTAX = '''You are a proficient expert in designing workflows for complex task planning.
Provide a workflow with several steps. Each step is a one-line string.
Each step is in the form of: [Step Name]:::[Step Type]:::[Step Instruction]:::[Step Branch]

[Step Type] could be "process", "terminal", or "decision".
[Step Branch] consists of branches in the form of "[Key]::[Branch Step Name]" separated by "::".

Rules:
- "process" step has exactly one branch with "next" as the key
- "decision" step has more than one branches (e.g., "Yes::Step X::No::Step Y")
- "terminal" step has zero branch, indicating the end
- At least one "terminal" step must exist'''

    EXAMPLE_WORKFLOW = '''Step 1:::Process:::Clarify who will handle the shipping based on order size.:::next::Step 2
Step 2:::Decision:::Check if special handling is required for large amounts.:::Yes::Step 3::No::Step 5
Step 3:::Process:::Invite three logistics companies to provide quotes.:::next::Step 4
Step 4:::Process:::Select the best logistics company and place order.:::next::Step 7
Step 5:::Process:::Write package label for standard shipping.:::next::Step 6
Step 6:::Decision:::Check if parcel insurance is necessary.:::Yes::Step 6a::No::Step 7
Step 6a:::Process:::Take parcel insurance from logistics department.:::next::Step 7
Step 7:::Process:::Package the goods in warehouse.:::next::Step 8
Step 8:::Process:::Prepare packaged goods for pickup by logistics company.:::next::Step 9
Step 9:::Terminal:::Shipment preparation complete.:::'''

    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.getenv("DEEPSEEK_API_KEY", "sk-c4aef77338ed4dafa3afb7ea3841ffaa")
        self.base_url = "https://api.deepseek.com/v1"
    
    def _call_llm(self, prompt: str, system: str = None, temperature: float = 0.3, max_retries: int = 3) -> str:

        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        
        for attempt in range(max_retries):
            try:
                print(f"    正在调用DeepSeek API... (尝试 {attempt + 1}/{max_retries})")
                response = requests.post(
                    f"{self.base_url}/chat/completions",
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json"
                    },
                    json={
                        "model": "deepseek-chat",
                        "messages": messages,
                        "max_tokens": 2500,
                        "temperature": temperature
                    },
                    timeout=180
                )
                if response.status_code == 200:
                    print(f"    ✓ API调用成功")
                    return response.json()["choices"][0]["message"]["content"]
                else:
                    print(f"  LLM Error: HTTP {response.status_code}")
                    if attempt < max_retries - 1:
                        print(f"    等待10秒后重试...")
                        time.sleep(10)
            except requests.exceptions.Timeout:
                print(f"  ⚠ LLM Timeout (attempt {attempt + 1}/{max_retries})")
                if attempt < max_retries - 1:
                    print(f"    等待10秒后重试...")
                    time.sleep(10)
            except requests.exceptions.ConnectionError as e:
                print(f"  ⚠ 网络连接错误: {e}")
                if attempt < max_retries - 1:
                    print(f"    等待15秒后重试...")
                    time.sleep(15)
            except KeyboardInterrupt:
                print(f"\n  用户中断，跳过当前场景...")
                raise  # 重新抛出，让上层处理
            except Exception as e:
                print(f"  LLM Error: {e}")
                if attempt < max_retries - 1:
                    print(f"    等待5秒后重试...")
                    time.sleep(5)
        
        print(f"  ✗ API调用失败，已达最大重试次数")
        return ""
    
    def generate(self, user_request: str) -> Dict:

        print("\n[AutoFlow] 生成工作流...")
        
        prompt = f"""{self.CORE_SYNTAX}

Here is an example workflow for a shipping process:
{self.EXAMPLE_WORKFLOW}

Now generate a workflow for this task:
{user_request}

Output the workflow steps only, following the exact format shown above."""

        workflow_text = self._call_llm(prompt, temperature=0.3)
        

        tasks, gateways, dependencies = self._parse_workflow(workflow_text)
        
        return {
            'workflow_text': workflow_text,
            'tasks': tasks,
            'gateways': gateways,
            'dependencies': dependencies
        }
    
    def _parse_workflow(self, workflow_text: str) -> tuple:

        tasks = []
        gateways = []
        dependencies = []
        
        lines = workflow_text.strip().split('\n')
        step_map = {}  # step_name -> task_id
        
        for i, line in enumerate(lines):
            line = line.strip()
            if not line or ':::' not in line:
                continue
            
            parts = line.split(':::')
            if len(parts) < 3:
                continue
            
            step_name = parts[0].strip()
            step_type = parts[1].strip().lower()
            instruction = parts[2].strip()
            branches = parts[3].strip() if len(parts) > 3 else ""
            
            task_id = f"t{len(tasks) + 1}"
            step_map[step_name] = task_id
            
            tasks.append({
                'id': task_id,
                'name': instruction[:60] if len(instruction) > 60 else instruction,
                'type': 'userTask' if step_type == 'process' else 
                        ('exclusiveGateway' if step_type == 'decision' else 'endEvent'),
                'step_name': step_name,
                'full_instruction': instruction
            })
            

            if step_type == 'decision':
                gateways.append({
                    'id': f"g{len(gateways) + 1}",
                    'type': 'exclusive',
                    'name': instruction[:40],
                    'source_task': task_id
                })
            

            if branches:
                branch_parts = branches.split('::')
                for j in range(0, len(branch_parts) - 1, 2):
                    if j + 1 < len(branch_parts):
                        target_step = branch_parts[j + 1].strip()
                        if target_step:
                            dependencies.append({
                                'from_step': step_name,
                                'to_step': target_step,
                                'condition': branch_parts[j].strip()
                            })
        

        resolved_deps = []
        for dep in dependencies:
            from_id = step_map.get(dep['from_step'])
            to_id = step_map.get(dep['to_step'])
            if from_id and to_id:
                resolved_deps.append({
                    'from': from_id,
                    'to': to_id,
                    'condition': dep.get('condition', '')
                })
        
        return tasks, gateways, resolved_deps



class MTFMConfig:

    def __init__(self, **kwargs):
        self.model_name = 'MTFM'
        
        self.embed_dim = kwargs.get('embed_dim', 128)
        self.max_doc_len = kwargs.get('max_doc_len', 100)
        self.num_category = kwargs.get('num_category', 20)
        self.num_mashup = kwargs.get('num_mashup', 1000)
        self.num_api = kwargs.get('num_api', 500)
        self.vocab_size = kwargs.get('vocab_size', 5000)
        self.embed = kwargs.get('embed', None)
        

        self.feature_dim = kwargs.get('feature_dim', 8)
        self.num_kernel = kwargs.get('num_kernel', 128)
        self.dropout = kwargs.get('dropout', 0.2)
        self.kernel_size = kwargs.get('kernel_size', [2, 3, 4])
        self.lr = 1e-3
        self.batch_size = 128
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'


class MTFM(nn.Module):

    
    def __init__(self, config):
        super(MTFM, self).__init__()
        self.config = config
        
        # ========== Embedding层 ==========
        if config.embed is not None:
            self.embedding = nn.Embedding.from_pretrained(config.embed, freeze=False)
        else:
            self.embedding = nn.Embedding(
                config.vocab_size, 
                config.embed_dim, 
                padding_idx=config.vocab_size - 1
            )
        

        self.sc_convs = nn.ModuleList([
            nn.Sequential(
                nn.Conv1d(
                    in_channels=config.embed_dim,
                    out_channels=config.num_kernel,
                    kernel_size=h
                ),
                nn.ReLU(),
                nn.MaxPool1d(kernel_size=config.max_doc_len - h + 1)
            )
            for h in config.kernel_size
        ])
        

        self.sc_fcl = nn.Linear(
            in_features=config.num_kernel * len(config.kernel_size),
            out_features=config.num_api
        )
        

        self.fic_fc = nn.Linear(
            in_features=config.num_kernel * len(config.kernel_size),
            out_features=config.feature_dim
        )
        

        self.fic_api_feature_embedding = nn.Parameter(
            torch.rand(config.feature_dim, config.num_api)
        )
        

        self.fic_mlp = nn.Sequential(
            nn.Linear(config.feature_dim * 2, config.feature_dim),
            nn.Linear(config.feature_dim, 1),
            nn.Tanh()
        )
        

        self.fic_fcl = nn.Linear(config.num_api * 2, config.num_api)
        

        self.fusion_layer = nn.Linear(config.num_api * 2, config.num_api)
        

        self.api_task_layer = nn.Linear(config.num_api, config.num_api)
        self.category_task_layer = nn.Linear(config.num_api, config.num_category)
        

        self.dropout = nn.Dropout(config.dropout)
        self.logistic = nn.Sigmoid()
        self.tanh = nn.Tanh()
        self.relu = nn.ReLU()
    
    def forward(self, mashup_des):


        embed = self.embedding(mashup_des)  # [batch, seq_len, embed_dim]
        embed = embed.permute(0, 2, 1)      # [batch, embed_dim, seq_len]
        

        e = [conv(embed) for conv in self.sc_convs]
        e = torch.cat(e, dim=2)
        e = e.view(e.size(0), -1)
        

        u_sc = self.sc_fcl(e)
        

        u_sc_trans = self.fic_fc(e)
        
        u_mm = torch.matmul(u_sc_trans, self.fic_api_feature_embedding)
        

        u_concate = []
        for u_sc_single in u_sc_trans:
            u_concate_single = torch.cat(
                (u_sc_single.repeat(self.fic_api_feature_embedding.size(1), 1), 
                 self.fic_api_feature_embedding.t()),
                dim=1
            )
            u_concate.append(self.fic_mlp(u_concate_single).squeeze())
        
        u_mlp = torch.cat(u_concate).view(u_mm.size(0), -1)
        

        u_fic = self.fic_fcl(torch.cat((u_mm, u_mlp), dim=1))
        u_fic = self.tanh(u_fic)
        

        u_mmf = self.fusion_layer(torch.cat((u_sc, u_fic), dim=1))
        u_mmf = self.dropout(u_mmf)
        

        y_m = self.api_task_layer(u_mmf)
        z_m = self.category_task_layer(u_mmf)
        
        return self.logistic(y_m), self.logistic(z_m)



class _ImprovedVocabDataset:


    def __init__(self, data: dict, max_doc_len: int = 50, max_vocab_size: int = 8000):
        self.max_doc_len = max_doc_len
        self.api_names = data['api_names']
        self.num_api = len(self.api_names)
        self.descriptions = data['descriptions']
        self._build_vocab(max_vocab_size)

    def _build_vocab(self, max_vocab_size):
        word_freq = Counter()
        for desc in self.descriptions:
            words = [w.lower() for w in desc] if isinstance(desc, list) else str(desc).lower().split()
            word_freq.update(words)
        self.vocab = {'<PAD>': 0, '<UNK>': 1}
        for word, _ in word_freq.most_common(max_vocab_size - 2):
            self.vocab[word] = len(self.vocab)
        self.vocab_size = len(self.vocab)
        self.embed_dim = 128

    def _text_to_indices(self, text):
        words = [w.lower() for w in text] if isinstance(text, list) else str(text).lower().split()
        indices = [self.vocab.get(w, 1) for w in words[:self.max_doc_len]]
        indices += [0] * (self.max_doc_len - len(indices))
        return indices



class AutoFlowMTFMSystem:

    
    def __init__(self, data_path: str = None, embedding_path: str = None, model_path: str = None):

        print("\n" + "=" * 60)
        print("初始化 AutoFlow + MTFM")
        print("=" * 60)
        print("  阶段1: AutoFlow (LLM + ICL 工作流生成)")
        print("  阶段2: MTFM (Multi-Task Feature Mapping)")
        

        self.data_path = Path(data_path) if data_path else SCRIPT_DIR / "data"
        self.embedding_path = Path(embedding_path) if embedding_path else SCRIPT_DIR / "embedding"
        

        print("\n[1/3] 初始化AutoFlow生成器...")
        self.autoflow = AutoFlowGenerator()
        print("  ✓ AutoFlow 初始化完成")
        

        print("\n[2/3] 加载API数据...")
        self.api_names = self._load_api_names()
        self.api_embeddings = self._load_api_embeddings()
        print(f"  ✓ API数量: {len(self.api_names)}")
        

        print("\n[3/3] 初始化MTFM模型...")
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.mtfm_model = self._init_mtfm_model(model_path)
        

        self._build_keyword_index()
        
        print("\n" + "=" * 60)
        print("系统初始化完成!")
        print("=" * 60)
    
    def _load_api_names(self) -> List[str]:

        api_name_file = self.data_path / "api_name.json"
        if api_name_file.exists():
            with open(api_name_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return []
    
    def _load_api_embeddings(self) -> Optional[np.ndarray]:

        embed_file = self.embedding_path / "api_features_roberta.npy"
        if embed_file.exists():
            return np.load(str(embed_file))
        return None
    
    def _init_mtfm_model(self, model_path: str = None) -> Optional[MTFM]:

        self.mtfm_usable_for_inference = False
        self.mashup_ds_for_vocab = None
        self.checkpoint_kind = None

        if not self.api_names:
            print("  ⚠ 无API数据，MTFM模型未初始化")
            self.mtfm_trained = False
            return None


        if model_path is not None:
            candidates = [(Path(model_path), 'auto')]
        else:
            candidates = [
                (MODEL_ROOT / "checkpoints" / "mtfm_best.pth", 'best'),
                (MODEL_ROOT / "checkpoints" / "mtfm_improved.pth", 'improved'),
            ]

        for ckpt_path, kind in candidates:
            if not ckpt_path.exists():
                continue
            model = self._load_checkpoint(ckpt_path, kind)
            if model is not None:
                return model

        tried = ", ".join(str(c) for c, _ in candidates)
        print(f"  ⚠ 未找到可用的模型权重文件 (已尝试: {tried})")
        self.mtfm_trained = False
        return None

    def _load_checkpoint(self, model_path: Path, kind: str) -> Optional[MTFM]:

        try:

            checkpoint = torch.load(model_path, map_location=self.device, weights_only=False)


            vocab_size = checkpoint['embedding.weight'].shape[0]
            embed_dim = checkpoint['embedding.weight'].shape[1]


            num_api = checkpoint['sc_fcl.weight'].shape[0]


            num_category = checkpoint['category_task_layer.weight'].shape[0]


            kernel_sizes = []
            num_kernel = None
            for key in checkpoint.keys():
                if key.startswith('sc_convs.') and key.endswith('.0.weight'):
                    # 例如 sc_convs.0.0.weight
                    idx = int(key.split('.')[1])
                    kernel_size = checkpoint[key].shape[2]  # 第三维是kernel_size
                    if num_kernel is None:
                        num_kernel = checkpoint[key].shape[0]  # 第一维是num_kernel
                    kernel_sizes.append((idx, kernel_size))


            kernel_sizes.sort(key=lambda x: x[0])
            kernel_size_list = [ks for _, ks in kernel_sizes]


            if kind == 'auto':
                kind = 'improved' if 'improved' in model_path.stem else 'best'

            max_doc_len = 50 if kind == 'improved' else 100

            print(f"  从checkpoint推断参数 ({model_path.name}, 按'{kind}'流程处理):")
            print(f"    - vocab_size: {vocab_size} | embed_dim: {embed_dim}")
            print(f"    - num_api: {num_api} | num_category: {num_category}")
            print(f"    - num_kernel: {num_kernel} | kernel_size: {kernel_size_list}")
            print(f"    - max_doc_len (按训练脚本推定): {max_doc_len}")


            api_names_for_model, mashup_ds = self._build_matching_vocab(kind, max_doc_len)

            if mashup_ds is None:
                print("  ⚠ 未能重建训练时的词表，权重仍会加载，但推理阶段会回退到关键词匹配")
            elif mashup_ds.vocab_size != vocab_size or len(api_names_for_model) != num_api:
                print(f"  ⚠ 重建的词表/API列表与checkpoint参数不一致 "
                      f"(vocab_size: {mashup_ds.vocab_size} vs {vocab_size}, "
                      f"num_api: {len(api_names_for_model)} vs {num_api})，"
                      f"推理阶段回退到关键词匹配")
                mashup_ds = None


            config = MTFMConfig(
                vocab_size=vocab_size,
                embed_dim=embed_dim,
                num_api=num_api,
                num_category=num_category,
                max_doc_len=max_doc_len,
                num_kernel=num_kernel,
                kernel_size=kernel_size_list
            )


            model = MTFM(config)
            model.load_state_dict(checkpoint)
            model.to(self.device)
            model.eval()

            print(f"  ✓ MTFM模型已加载: {model_path}")
            self.mtfm_trained = True
            self.mtfm_num_api = num_api
            self.checkpoint_kind = kind

            if mashup_ds is not None:
                self.mashup_ds_for_vocab = mashup_ds
                if len(api_names_for_model) != len(self.api_names):
                    print(f"  ℹ API列表已按'{kind}'checkpoint重新对齐: "
                          f"{len(self.api_names)} -> {len(api_names_for_model)}")
                self.api_names = api_names_for_model
                self.mtfm_usable_for_inference = True
                print(f"  ✓ 词表重建成功，评估阶段将真正调用MTFM模型推理 "
                      f"(共{len(api_names_for_model)}个API)")

            return model

        except Exception as e:
            print(f"  ⚠ 加载 {model_path.name} 失败: {e}")
            traceback.print_exc()
            return None

    def _build_matching_vocab(self, kind: str, max_doc_len: int):

        if kind == 'best':

            try:
                from tools.dataset import MashupDataset as _RealMashupDataset
            except Exception as e:
                print(f"  ⚠ 无法导入 tools.dataset.MashupDataset ({e})，跳过词表重建")
                return None, None
            try:
                mashup_ds = _RealMashupDataset(
                    data_path=str(self.data_path),
                    embedding_path=str(self.embedding_path),
                    use_roberta=False,
                    max_doc_len=max_doc_len,
                )
            except Exception as e:
                print(f"  ⚠ 重建训练时词表失败 (data_path={self.data_path}): {e}")
                return None, None
            return list(mashup_ds.api_names), mashup_ds

        elif kind == 'improved':

            min_usage = 5
            cfg_path = MODEL_ROOT / "checkpoints" / "mtfm_improved_config.json"
            if cfg_path.exists():
                try:
                    with open(cfg_path, 'r', encoding='utf-8') as f:
                        saved_cfg = json.load(f)
                    min_usage = saved_cfg.get('min_api_usage', min_usage)
                except Exception:
                    pass
            try:
                data = self._preprocess_data_for_improved(self.data_path, min_usage=min_usage)
                mashup_ds = _ImprovedVocabDataset(data, max_doc_len=max_doc_len, max_vocab_size=8000)
            except Exception as e:
                print(f"  ⚠ 重建improved流程词表失败: {e}")
                return None, None
            return list(mashup_ds.api_names), mashup_ds

        return None, None

    @staticmethod
    def _preprocess_data_for_improved(data_path: Path, min_usage: int = 5) -> dict:

        with open(data_path / "api_name.json", 'r', encoding='utf-8') as f:
            _ = json.load(f)
        with open(data_path / "mashup_description.json", 'r', encoding='utf-8') as f:
            mashup_descriptions = json.load(f)
        with open(data_path / "mashup_used_api.json", 'r', encoding='utf-8') as f:
            mashup_used_apis = json.load(f)
        with open(data_path / "mashup_category.json", 'r', encoding='utf-8') as f:
            mashup_categories = json.load(f)
        with open(data_path / "category_list.json", 'r', encoding='utf-8') as f:
            categories = json.load(f)

        api_counter = Counter()
        for apis in mashup_used_apis:
            for api in apis:
                api_counter[api] += 1

        valid_apis = [api for api, count in api_counter.items() if count >= min_usage]
        valid_api_set = set(valid_apis)
        valid_apis = sorted(valid_apis, key=lambda x: -api_counter[x])

        filtered_indices = [i for i, apis in enumerate(mashup_used_apis)
                            if any(api in valid_api_set for api in apis)]

        return {
            'api_names': valid_apis,
            'descriptions': [mashup_descriptions[i] for i in filtered_indices],
            'used_apis': [[api for api in mashup_used_apis[i] if api in valid_api_set] for i in filtered_indices],
            'categories': [mashup_categories[i] for i in filtered_indices],
            'category_list': categories
        }
    
    def _build_keyword_index(self):

        self.api_keywords = {}
        for i, name in enumerate(self.api_names):
            words = name.lower().replace('-', ' ').replace('_', ' ').split()
            for word in words:
                if len(word) > 2:
                    if word not in self.api_keywords:
                        self.api_keywords[word] = []
                    self.api_keywords[word].append(i)
    
    def recommend_api(self, task_text: str, top_k: int = 5) -> List[Dict]:

        if not self.api_names:
            return [{"api_name": "manual-task", "score": 0.5, "method": "fallback"}]

        method = "keyword_only"
        if self.mtfm_trained and self.mtfm_usable_for_inference:
            try:
                scores = self._mtfm_predict_score(task_text)
                method = "mtfm"
            except Exception as e:
                print(f"  ⚠ MTFM推理失败 ({e})，本次任务回退到关键词匹配")
                scores = self._keyword_match_score(task_text)
                method = "keyword_fallback"
        else:
            scores = self._keyword_match_score(task_text)
            method = "keyword_fallback" if self.mtfm_trained else "keyword_only"


        top_indices = np.argsort(scores)[::-1][:top_k]

        recommendations = []
        for idx in top_indices:
            recommendations.append({
                "api_name": self.api_names[idx],
                "score": float(scores[idx]),
                "method": method
            })

        return recommendations

    def _mtfm_predict_score(self, task_text: str) -> np.ndarray:

        indices = self.mashup_ds_for_vocab._text_to_indices(task_text)
        input_tensor = torch.LongTensor([indices]).to(self.device)
        with torch.no_grad():
            api_pred, _ = self.mtfm_model(input_tensor)
        return api_pred.cpu().numpy()[0]
    
    def _keyword_match_score(self, task_text: str) -> np.ndarray:

        scores = np.zeros(len(self.api_names), dtype=np.float32)
        task_lower = task_text.lower()
        

        domain_mapping = {
            'ship': ['shipping', 'logistics', 'delivery', 'fedex', 'ups', 'dhl', 'post'],
            'pay': ['payment', 'stripe', 'paypal', 'checkout', 'transaction'],
            'send': ['email', 'sms', 'notification', 'twilio', 'sendgrid', 'message'],
            'search': ['search', 'find', 'google', 'query', 'lookup'],
            'map': ['map', 'location', 'geo', 'address', 'place'],
            'store': ['storage', 'database', 's3', 'firebase', 'cloud'],
            'verify': ['verification', 'auth', 'identity', 'validate'],
            'calculate': ['calculator', 'compute', 'math', 'score'],
            'image': ['image', 'photo', 'picture', 'visual'],
            'weather': ['weather', 'forecast', 'climate'],
            'insurance': ['insurance', 'policy', 'coverage'],
            'label': ['label', 'print', 'barcode'],
            'package': ['package', 'parcel', 'box'],
            'logistics': ['logistics', 'freight', 'carrier', 'warehouse'],
            'select': ['compare', 'choose', 'selection'],
            'offer': ['quote', 'price', 'bid', 'offer'],
            'recourse': ['complaint', 'refund', 'return', 'dispute', 'customer', 'service'],
            'order': ['order', 'purchase', 'buy', 'cart'],
        }
        

        task_keywords = set()
        for word in task_lower.split():
            word = word.strip('.,!?;:')
            if len(word) > 2:
                task_keywords.add(word)
                for key, synonyms in domain_mapping.items():
                    if word == key or word in synonyms:
                        task_keywords.add(key)
                        task_keywords.update(synonyms)
        

        for i, api_name in enumerate(self.api_names):
            api_lower = api_name.lower()
            score = 0
            for kw in task_keywords:
                if kw in api_lower:
                    score += 1
            scores[i] = score
        

        if scores.max() > 0:
            scores = scores / scores.max()
        
        return scores
    
    def run(self, user_request: str, scenario_name: str) -> UnifiedOutput:

        print(f"\n{'='*60}")
        print(f"AutoFlow_MTFM 处理场景: {scenario_name}")
        print(f"{'='*60}")
        
        start_time = time.time()
        

        print("\n[Stage 1] AutoFlow - 生成工作流结构")
        print("-" * 50)
        workflow_result = self.autoflow.generate(user_request)
        
        tasks_raw = workflow_result.get('tasks', [])
        gateways_raw = workflow_result.get('gateways', [])
        deps_raw = workflow_result.get('dependencies', [])
        
        print(f"  ✓ 任务数: {len(tasks_raw)}")
        print(f"  ✓ 网关数: {len(gateways_raw)}")
        print(f"  ✓ 依赖数: {len(deps_raw)}")
        
        for task in tasks_raw[:5]:
            print(f"    [{task.get('id', '?')}] {task.get('name', '?')[:50]}")
        if len(tasks_raw) > 5:
            print(f"    ... 还有 {len(tasks_raw) - 5} 个任务")
        

        print("\n[Stage 2] MTFM - API推荐")
        print("-" * 50)
        
        api_bindings = {}
        for task in tasks_raw:
            task_id = task.get('id', '')
            task_name = task.get('name', task.get('full_instruction', ''))
            
            if task.get('type') == 'endEvent':
                continue
            
            recommendations = self.recommend_api(task_name, top_k=5)
            
            if recommendations:
                top_api = recommendations[0]
                api_bindings[task_id] = {
                    "task_name": task_name,
                    "api_name": top_api['api_name'],
                    "confidence": top_api['score'],
                    "method": top_api.get('method', 'unknown'),
                    "top5_candidates": [
                        {"api_name": r['api_name'], "score": r['score'], "method": r.get('method', 'unknown')}
                        for r in recommendations
                    ]
                }
                print(f"  [{task_id}] {task_name[:40]}...")
                print(f"      → Top-1: {top_api['api_name']} ({top_api['score']:.3f})")
                for rank, r in enumerate(recommendations[1:], start=2):
                    print(f"         Top-{rank}: {r['api_name']} ({r['score']:.3f})")
        

        unique_apis = set(b['api_name'] for b in api_bindings.values())
        print(f"\n  📊 API多样性: {len(unique_apis)}/{len(api_bindings)} 个不同Top-1 API")
        
        execution_time = time.time() - start_time
        

        formatted_tasks = []
        for task in tasks_raw:
            formatted_tasks.append({
                "id": task.get('id', ''),
                "name": task.get('name', ''),
                "type": task.get('type', 'userTask')
            })
        

        gateways = []
        for gw in gateways_raw:
            gateways.append({
                "id": gw.get('id', ''),
                "type": gw.get('type', 'exclusive'),
                "name": gw.get('name', '')
            })
        
        return UnifiedOutput(
            method="AutoFlow_MTFM",
            scenario_name=scenario_name,
            user_request=user_request,
            tasks=formatted_tasks,
            dependencies=deps_raw,
            gateways=gateways,
            api_bindings=api_bindings,
            roles=[],
            execution_time=execution_time,
            extra_info={
                "workflow_generator": "AutoFlow (ICL)",
                "api_recommender": "MTFM",
                "mtfm_trained": self.mtfm_trained if hasattr(self, 'mtfm_trained') else False,
                "workflow_text": workflow_result.get('workflow_text', '')[:500],
                "api_diversity": f"{len(unique_apis)}/{len(api_bindings)}"
            }
        )



def main():
    """运行AutoFlow_MTFM评估"""
    print("\n")
    print("╔" + "═" * 58 + "╗")
    print("║" + " " * 8 + "AutoFlow_MTFM 评估运行脚本 (修复版)" + " " * 4 + "║")
    print("║" + " " * 4 + "AutoFlow工作流生成 + MTFM API推荐" + " " * 10 + "║")
    print("╚" + "═" * 58 + "╝")
    

    data_path = SCRIPT_DIR / "data"
    embedding_path = SCRIPT_DIR / "embedding"
    

    if not data_path.exists():
        data_path = MODEL_ROOT / "data"
    if not embedding_path.exists():
        embedding_path = MODEL_ROOT / "embedding"
    

    system = AutoFlowMTFMSystem(
        data_path=str(data_path),
        embedding_path=str(embedding_path)
    )
    

    print("\n" + "=" * 60)
    print("开始评估测试场景")
    print("=" * 60)
    
    results = []
    for i, scenario in enumerate(BPMN_TEST_SCENARIOS):
        print(f"\n>>> 场景 [{i+1}/{len(BPMN_TEST_SCENARIOS)}]: {scenario.name}")
        try:
            result = system.run(scenario.requirement, scenario.name)
            results.append(result)
            
            print(f"\n结果摘要:")
            print(f"  - 任务数: {len(result.tasks)}")
            print(f"  - 依赖数: {len(result.dependencies)}")
            print(f"  - 网关数: {len(result.gateways)}")
            print(f"  - API绑定数: {len(result.api_bindings)}")
            print(f"  - 执行时间: {result.execution_time:.2f}s")
        except KeyboardInterrupt:
            print(f"\n  ⚠ 用户中断，跳过场景 {scenario.name}")
            print(f"    (再次按Ctrl+C退出整个程序)")
            try:
                time.sleep(2)
            except KeyboardInterrupt:
                print(f"\n程序被用户终止")
                break
            continue
        except Exception as e:
            print(f"  ✗ 场景 {scenario.name} 处理失败: {e}")
            traceback.print_exc()
            continue
    

    output_dir = EVAL_ROOT / "results"
    save_results(results, str(output_dir), "autoflow_mtfm")
    
    print("\n" + "=" * 60)
    print("AutoFlow_MTFM 评估完成!")
    print("=" * 60)


if __name__ == "__main__":
    main()
