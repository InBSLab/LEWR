# AutoFlow + MTFM

一个把 **AutoFlow**（基于 CoRE 语法的工作流生成 + 执行闭环）和 **MTFM**（Multi-Task Feature Mapping，一个用于 API 推荐的多任务模型）整合在一起的项目：给定一段自然语言的流程描述，用 LLM 生成结构化工作流，再为流程中的每个节点用训练好的 MTFM 模型推荐合适的 API。

## 目录结构

```
AutoFlow_MTFM/
├── autoflow/                # 工作流生成与执行
│   ├── flow/                 # CoRE 语法的 Flow / Block 数据结构
│   ├── generator.py           # AutoFlowGenerator：调用 DeepSeek / Mixtral 生成工作流
│   └── executor.py            # 按工作流执行并收集 reward 反馈
├── mtfm/                    # API 推荐模型
│   ├── model.py               # MTFM / MTFMRoBERTa 网络结构
│   └── trainer.py             # 训练循环、EarlyStopping、评估指标
├── tools/
│   └── dataset.py             # MashupDataset：数据预处理、构建词表
├── data/                     # 数据集（MashupDataset 读取）
├── embedding/                # 预训练 RoBERTa 特征
├── evaluation/
│   └── run_for_evaluation.py  # 评估脚本
├── info/example_workflow_manual.txt
├── config.py                 # 集中配置（API Key、路径、超参数）
└── main.py                   # 整合系统入口（训练/加载 MTFM + 调用 AutoFlow）
```

## 安装

```bash
pip install torch numpy requests
# 如需使用 Mixtral + LoRA/PPO 微调（可选，需要 GPU）：
pip install transformers peft trl
```

## 配置

在 `config.py` 里填写你自己的 DeepSeek API Key，或者更推荐用环境变量，不要把密钥写进代码：

```bash
export DEEPSEEK_API_KEY="你的密钥"
```

`config.py` / `evaluation/run_for_evaluation.py` 都已经改为优先从环境变量 `DEEPSEEK_API_KEY` 读取密钥。

## 运行

```bash
# 训练/加载 MTFM，并调用 AutoFlow 生成工作流 + 为每个节点推荐 API
python main.py
```
