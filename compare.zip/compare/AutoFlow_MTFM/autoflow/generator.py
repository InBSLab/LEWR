
import os
import json
import logging
import requests
from typing import List, Dict, Any, Optional, Tuple
from pathlib import Path

try:
    import torch
    from transformers import AutoTokenizer, AutoModelForCausalLM
    from peft import LoraConfig, get_peft_model
    from trl import PPOConfig, PPOTrainer, AutoModelForCausalLMWithValueHead
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False
    print("Warning: torch/transformers/peft/trl not installed. Mixtral PPO methods will not be available.")

from .flow import Flow, Block


class AutoFlowGenerator:
    
    CORE_SYNTAX_INSTRUCTION = '''You are a proficient expert in designing workflows for complex task planning.
Provide a workflow with several steps. Each step is a one-line string.
Each step is in the form of: [Step Name]:::[Step Type]:::[Step Instruction]:::[Step Branch]

[Step Type] could be "process", "terminal", or "decision".
[Step Branch] consists of several branches. Each branch is in the form of "[Key]::[Branch Step Name]" and separated by "::".

Note:
- "process" step has exactly one branch, with "next" as the key
- "decision" step has more than one branches
- "terminal" step has zero branch, indicating the end of the workflow, but there could be multiple "terminal" steps
- At least one "terminal" step exists, meaning the last step of the workflow!
- [Key], [Step Name], and [Step Instruction] are all in the string form
- [Branch Step Name] should appear as a unique [Step Name] in the workflow
'''

    EXAMPLE_WORKFLOW = '''Step 1:::Process:::Get user current location using GPS or mapping service.:::next::Step 2
Step 2:::Process:::Search for nearby points of interest based on user preferences.:::next::Step 3
Step 3:::Decision:::Check if user wants detailed information.:::Yes::Step 4::No::Step 5
Step 4:::Process:::Fetch detailed information from relevant API.:::next::Step 5
Step 5:::Process:::Format and display results to user.:::next::Step 6
Step 6:::Terminal:::Complete the request and await next user input.:::'''

    DOMAIN_EXAMPLES = {
        'travel': '''Step 1:::Process:::Get user current location using GPS mapping API.:::next::Step 2
Step 2:::Process:::Search nearby hotels using location-based search API.:::next::Step 3
Step 3:::Process:::Get weather forecast using weather API.:::next::Step 4
Step 4:::Decision:::Check if user wants to book a flight.:::Yes::Step 5::No::Step 6
Step 5:::Process:::Search and book flight using airline API.:::next::Step 6
Step 6:::Process:::Send confirmation email via email service API.:::next::Step 7
Step 7:::Terminal:::Display trip summary to user.:::''',

        'ecommerce': '''Step 1:::Process:::Search products using product search API.:::next::Step 2
Step 2:::Process:::Filter results by user preferences and ratings.:::next::Step 3
Step 3:::Decision:::Check if user wants to compare prices.:::Yes::Step 4::No::Step 5
Step 4:::Process:::Compare prices across multiple vendors using price API.:::next::Step 5
Step 5:::Process:::Add selected item to shopping cart.:::next::Step 6
Step 6:::Process:::Process payment using payment gateway API.:::next::Step 7
Step 7:::Terminal:::Send order confirmation and tracking info.:::''',

        'social': '''Step 1:::Process:::Authenticate user using social media OAuth API.:::next::Step 2
Step 2:::Process:::Fetch user profile and preferences.:::next::Step 3
Step 3:::Process:::Create new post content with media attachments.:::next::Step 4
Step 4:::Decision:::Check if user wants to share to multiple platforms.:::Yes::Step 5::No::Step 6
Step 5:::Process:::Cross-post to Twitter, Facebook using respective APIs.:::next::Step 6
Step 6:::Terminal:::Confirm post published successfully.:::'''
    }

    def __init__(self, 
                 deepseek_api_key: str = None,
                 base_url: str = None,
                 auto_model_name: str = "deepseek-chat",
                 cache_dir: str = "./cache",
                 log_dir: str = "./logs"):
        self.api_key = deepseek_api_key or os.getenv("DEEPSEEK_API_KEY")
        self.base_url = base_url or "https://api.deepseek.com/v1"
        self.auto_model_name = auto_model_name
        self.cache_dir = Path(cache_dir)
        self.log_dir = Path(log_dir)
        
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        self.mixtral_model = None
        self.mixtral_tokenizer = None
        self.ppo_trainer = None
        
        if self.api_key:
            print(f"[AutoFlow] DeepSeek API initialized (model: {self.auto_model_name})")
        else:
            print("[AutoFlow] Warning: No API key provided")
    
    def _call_deepseek(self, messages: List[Dict], temperature: float = 0.3, max_tokens: int = 2500) -> str:
        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": self.auto_model_name,
                    "messages": messages,
                    "max_tokens": max_tokens,
                    "temperature": temperature
                },
                timeout=120
            )
            
            if response.status_code == 200:
                result = response.json()
                return result["choices"][0]["message"]["content"].strip()
            else:
                raise Exception(f"API error: {response.status_code} - {response.text}")
                
        except Exception as e:
            logging.error(f"DeepSeek API call failed: {e}")
            raise
    
    def _detect_domain(self, task_description: str) -> str:
        task_lower = task_description.lower()
        
        if any(kw in task_lower for kw in ['travel', 'trip', 'flight', 'hotel', 'weather', 'booking', 'destination']):
            return 'travel'
        elif any(kw in task_lower for kw in ['shop', 'buy', 'product', 'price', 'cart', 'payment', 'order']):
            return 'ecommerce'
        elif any(kw in task_lower for kw in ['social', 'post', 'share', 'facebook', 'twitter', 'instagram']):
            return 'social'
        else:
            return 'travel'
    
    
    def generate_with_deepseek_icl(self, 
                                    task_description: str,
                                    example_workflow: str = None,
                                    auto_epochs: int = 30,
                                    execute_func=None) -> Tuple[str, List[float]]:
        if not self.api_key:
            raise RuntimeError("DeepSeek API key not available.")
        
        domain = self._detect_domain(task_description)
        example_workflow = example_workflow or self.DOMAIN_EXAMPLES.get(domain, self.EXAMPLE_WORKFLOW)
        
        system_instruction = f'''You are a proficient expert in designing API-oriented workflows.

IMPORTANT: You must generate a workflow that DIRECTLY addresses the user's specific requirements.
Do NOT copy the example workflow structure - create a NEW workflow based on the actual task.

User's Task:
{task_description}

Your workflow should:
1. Include specific API calls relevant to the task (maps, weather, email, social media, etc.)
2. Have concrete, actionable steps (not abstract like "analyze data type")
3. Match the user's requirements exactly

An execution large language model will follow your workflow, and you will receive performance feedback.
The performance is a float between 0 and 1; higher is better.'''

        chat_history = [
            {'role': 'system', 'content': system_instruction},
            {'role': 'user', 'content': f'''Here is the CoRE workflow format:
{self.CORE_SYNTAX_INSTRUCTION}

Here is an example workflow for reference (but create a NEW one for the user's task):
{example_workflow}

Now generate a workflow for this specific task:
{task_description}

Remember: Create steps that match the user's actual requirements, not the example!'''},
        ]
        
        first_workflow = self._call_deepseek(chat_history, temperature=0.3, max_tokens=2500)
        chat_history.append({'role': 'assistant', 'content': first_workflow})
        
        if execute_func:
            baseline = execute_func(first_workflow)
        else:
            baseline = self._validate_workflow_format(first_workflow)
        
        best_workflow = first_workflow
        best_reward = baseline
        reward_history = [baseline]
        
        logging.info(f"[AutoFlow DeepSeek ICL] Starting with baseline reward: {baseline}")
        
        for epoch in range(auto_epochs):
            try:
                chat_history.append({
                    'role': 'user', 
                    'content': f'''The execution performance of your workflow is {reward_history[-1]:.2f}.

Please improve the workflow:
1. Make sure each step directly serves the user's goal: {task_description[:100]}...
2. Use specific API names (google-maps, weather-channel, mailchimp, etc.)
3. Ensure logical flow between steps

Provide an improved workflow:'''
                })
                
                new_workflow = self._call_deepseek(chat_history, temperature=0.3, max_tokens=2500)
                chat_history.append({'role': 'assistant', 'content': new_workflow})
                
                logging.info(f"[Epoch {epoch+1}/{auto_epochs}] Generated workflow")
                
                if execute_func:
                    try:
                        reward = execute_func(new_workflow)
                    except Exception as e:
                        logging.error(f"Execution error: {e}")
                        reward = 0.0
                else:
                    reward = self._validate_workflow_format(new_workflow)
                    reward = self._check_relevance(new_workflow, task_description, reward)
                
                reward_history.append(reward)
                logging.info(f"[Epoch {epoch+1}/{auto_epochs}] Reward: {reward}")
                
                if reward > best_reward:
                    best_reward = reward
                    best_workflow = new_workflow
                    logging.info(f"[Epoch {epoch+1}/{auto_epochs}] New best reward: {best_reward}")
                
                if len(chat_history) > 20:
                    chat_history = chat_history[:3] + chat_history[-10:]
                    
            except Exception as e:
                logging.error(f"[Epoch {epoch+1}] Error: {e}")
                continue
        
        logging.info(f"[AutoFlow DeepSeek ICL] Final best reward: {best_reward}")
        return best_workflow, reward_history
    
    def _check_relevance(self, workflow: str, task_description: str, base_reward: float) -> float:
        task_lower = task_description.lower()
        workflow_lower = workflow.lower()
        
        task_keywords = []
        keyword_groups = {
            'location': ['location', 'gps', 'map', 'position'],
            'weather': ['weather', 'forecast', 'temperature'],
            'hotel': ['hotel', 'accommodation', 'room'],
            'flight': ['flight', 'airline', 'book', 'ticket'],
            'email': ['email', 'mail', 'send', 'confirmation'],
            'social': ['social', 'share', 'facebook', 'twitter'],
            'storage': ['storage', 'cloud', 'photo', 'upload'],
            'restaurant': ['restaurant', 'food', 'dining'],
            'search': ['search', 'find', 'nearby']
        }
        
        required_features = []
        for feature, keywords in keyword_groups.items():
            if any(kw in task_lower for kw in keywords):
                required_features.append(feature)
        
        matched_features = 0
        for feature, keywords in keyword_groups.items():
            if feature in required_features:
                if any(kw in workflow_lower for kw in keywords):
                    matched_features += 1
        
        if required_features:
            relevance_score = matched_features / len(required_features)
        else:
            relevance_score = 0.5
        
        if 'data type' in workflow_lower or 'models list' in workflow_lower:
            relevance_score *= 0.3
        
        final_reward = base_reward * 0.5 + relevance_score * 0.5
        return min(final_reward, 1.0)
    
    
    def generate_simple(self, task_description: str, use_api: bool = True) -> str:
        if use_api and self.api_key:
            domain = self._detect_domain(task_description)
            example = self.DOMAIN_EXAMPLES.get(domain, self.EXAMPLE_WORKFLOW)
            
            prompt = f'''{self.CORE_SYNTAX_INSTRUCTION}

IMPORTANT: Generate a workflow that DIRECTLY addresses the user's specific task.
Each step should describe a concrete API operation relevant to the task.

Task Description:
{task_description}

Reference Example (for format only, create NEW content):
{example}

Generate a workflow for the task above. Each step must be relevant to: {task_description[:100]}
Output only the workflow steps, no explanations.'''
            
            try:
                return self._call_deepseek([
                    {"role": "system", "content": "You are a workflow expert. Generate workflows that match user requirements exactly. Use specific API names."},
                    {"role": "user", "content": prompt}
                ], temperature=0.3, max_tokens=2500)
            except Exception as e:
                logging.error(f"DeepSeek generation error: {e}")
                return self._generate_template_workflow(task_description)
        else:
            return self._generate_template_workflow(task_description)
    
    def _generate_template_workflow(self, task_description: str) -> str:
        task_lower = task_description.lower()
        steps = []
        step_id = 1
        
        if 'location' in task_lower or 'gps' in task_lower or 'map' in task_lower:
            steps.append(f"Step {step_id}:::Process:::Get user location using GPS mapping API.:::next::Step {step_id+1}")
            step_id += 1
        
        if 'hotel' in task_lower or 'restaurant' in task_lower or 'nearby' in task_lower:
            steps.append(f"Step {step_id}:::Process:::Search nearby places using location-based search API.:::next::Step {step_id+1}")
            step_id += 1
        
        if 'weather' in task_lower or 'forecast' in task_lower:
            steps.append(f"Step {step_id}:::Process:::Get weather forecast using weather API.:::next::Step {step_id+1}")
            step_id += 1
        
        if 'flight' in task_lower or 'book' in task_lower or 'ticket' in task_lower:
            steps.append(f"Step {step_id}:::Process:::Search and book using booking API.:::next::Step {step_id+1}")
            step_id += 1
        
        if 'email' in task_lower or 'mail' in task_lower or 'send' in task_lower:
            steps.append(f"Step {step_id}:::Process:::Send notification via email API.:::next::Step {step_id+1}")
            step_id += 1
        
        if 'social' in task_lower or 'share' in task_lower or 'facebook' in task_lower or 'twitter' in task_lower:
            steps.append(f"Step {step_id}:::Process:::Share content using social media API.:::next::Step {step_id+1}")
            step_id += 1
        
        if 'photo' in task_lower or 'storage' in task_lower or 'cloud' in task_lower:
            steps.append(f"Step {step_id}:::Process:::Upload files to cloud storage API.:::next::Step {step_id+1}")
            step_id += 1
        
        if not steps:
            steps.append(f"Step 1:::Process:::Analyze user requirements.:::next::Step 2")
            steps.append(f"Step 2:::Process:::Process the request.:::next::Step 3")
            step_id = 3
        
        steps.append(f"Step {step_id}:::Terminal:::Complete and return results.:::")
        
        return '\n'.join(steps)
    
    def _validate_workflow_format(self, workflow: str) -> float:
        score = 0.0
        lines = [l.strip() for l in workflow.strip().split('\n') if l.strip()]
        
        if not lines:
            return 0.0
        
        has_terminal = False
        valid_steps = 0
        
        for line in lines:
            if ':::' not in line:
                continue
            
            parts = line.split(':::')
            if len(parts) >= 3:
                step_type = parts[1].strip().lower()
                if step_type in ['process', 'decision', 'terminal']:
                    valid_steps += 1
                    if step_type == 'terminal':
                        has_terminal = True
        
        if valid_steps > 0:
            score = valid_steps / len(lines)
        
        if has_terminal:
            score += 0.2
        
        return min(score, 1.0)
    
    
    def parse_workflow(self, workflow_text: str) -> Flow:
        return Flow(flow_text=workflow_text)
    
    def get_tasks_from_workflow(self, workflow: Flow) -> List[Dict[str, Any]]:
        tasks = []
        for block in workflow.get_all_blocks():
            if block.type in ['process', 'decision']:
                tasks.append({
                    'id': block.name,
                    'type': block.type,
                    'instruction': block.instruction,
                    'branch': block.to_dict()['branch']
                })
        return tasks
    
    
    def init_mixtral_ppo(self, model_name: str = "mistralai/Mixtral-8x7B-Instruct-v0.1"):
        if not HAS_TORCH:
            raise RuntimeError("PyTorch and related libraries not available")
        
        print(f"[AutoFlow] Loading Mixtral model: {model_name}")
        
        self.mixtral_tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
        self.mixtral_tokenizer.pad_token = self.mixtral_tokenizer.eos_token
        
        base_model = AutoModelForCausalLM.from_pretrained(
            model_name,
            load_in_4bit=True,
            device_map="auto",
            trust_remote_code=True
        )
        
        lora_config = LoraConfig(
            r=8,
            lora_alpha=16,
            target_modules=["q_proj", "v_proj"],
            lora_dropout=0.05,
            bias="none",
            task_type="CAUSAL_LM"
        )
        
        self.mixtral_model = get_peft_model(base_model, lora_config)
        self.mixtral_model = AutoModelForCausalLMWithValueHead.from_pretrained(self.mixtral_model)
        
        ppo_config = PPOConfig(
            batch_size=1,
            mini_batch_size=1,
            gradient_accumulation_steps=1,
            learning_rate=1e-5
        )
        
        optimizer = torch.optim.Adam(
            filter(lambda p: p.requires_grad, self.mixtral_model.parameters()),
            lr=ppo_config.learning_rate
        )
        
        self.ppo_trainer = PPOTrainer(
            ppo_config,
            self.mixtral_model,
            ref_model=None,
            tokenizer=self.mixtral_tokenizer,
            optimizer=optimizer
        )
        
        print("[AutoFlow] Mixtral PPO initialized successfully")
    
    def grammar_check_with_deepseek(self, workflow: str) -> str:
        if not self.api_key:
            return workflow
        
        prompt = f'''Check and fix this workflow to ensure it follows the CoRE format:
{self.CORE_SYNTAX_INSTRUCTION}

Workflow to check:
{workflow}

If the workflow is correct, return it unchanged.
If there are errors, fix them and return the corrected workflow.
Output only the workflow, no explanations.'''
        
        try:
            return self._call_deepseek([
                {"role": "user", "content": prompt}
            ], temperature=0.3, max_tokens=2500)
        except:
            return workflow


if __name__ == '__main__':
    generator = AutoFlowGenerator()
    
    task_desc = """Build a travel planning application:
    1. Get user's current location
    2. Search for nearby hotels
    3. Get weather forecast
    4. Book flight tickets
    5. Send email confirmation"""
    
    workflow = generator.generate_simple(task_desc, use_api=False)
    print("Generated workflow:")
    print(workflow)
