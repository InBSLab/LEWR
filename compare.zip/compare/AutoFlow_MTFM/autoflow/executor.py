
import logging
from typing import Callable, Dict, List, Optional, Tuple

from .flow import Flow, Block


class ExecutionTrace:

    def __init__(self):
        self.steps: List[Dict] = []
        self.terminated: bool = False
        self.terminated_reason: str = ""
        self.visited_names: List[str] = []

    def add_step(self, block: Block, answer: str, chosen_branch: Optional[str],
                 tool_used: Optional[str] = None):
        self.steps.append({
            'block': block.name,
            'type': block.type,
            'instruction': block.instruction,
            'answer': answer,
            'branch': chosen_branch,
            'tool_used': tool_used,
        })
        self.visited_names.append(block.name)

    def to_dict(self) -> Dict:
        return {
            'steps': self.steps,
            'terminated': self.terminated,
            'terminated_reason': self.terminated_reason,
            'num_steps': len(self.steps),
            'visited_names': self.visited_names,
        }


class AutoFlowExecutor:

    def __init__(self,
                 call_llm: Callable[[List[Dict]], str],
                 node_api_resolver: Optional[Callable[[Block, str], Optional[str]]] = None,
                 max_round: int = 20):
        self.call_llm = call_llm
        self.node_api_resolver = node_api_resolver
        self.max_round = max_round

    def _answer_node(self, flow_ptr: Block, task_description: str,
                      progress: List[str]) -> str:
        progress_str = '\n'.join(progress)
        prompt = (
            f"Task description: {task_description}\n\n"
            f"Current Progress:\n{progress_str}\n\n"
            f"Question: {flow_ptr.get_instruction()}\n\n"
            f"Only answer the current instruction directly and do not be verbose."
        )
        messages = [{'role': 'user', 'content': prompt}]
        try:
            answer = self.call_llm(messages)
        except Exception as e:
            logging.error(f"[Executor] LLM call failed at node {flow_ptr.name}: {e}")
            answer = ""
        return (answer or "").strip()

    def _choose_branch(self, flow_ptr: Block, answer: str,
                        task_description: str) -> Optional[str]:
        possible_keys = list(flow_ptr.branch.keys())
        if not possible_keys:
            return None

        options_str = '\n'.join(f'{i + 1}: {k}.' for i, k in enumerate(possible_keys))
        prompt = (
            f"Given the question ```{flow_ptr.get_instruction()}```, "
            f"choose the closest representation of ```{answer}``` from the following options:\n"
            f"{options_str}\n"
            f"Your answer should be only a number, referring to the desired choice. Don't be verbose!"
        )
        messages = [{'role': 'user', 'content': prompt}]
        try:
            resp = self.call_llm(messages).strip()
        except Exception as e:
            logging.error(f"[Executor] Branch selection failed at node {flow_ptr.name}: {e}")
            return None

        digits = ''.join(ch for ch in resp if ch.isdigit())
        if digits:
            idx = int(digits[:len(str(len(possible_keys)))]) if len(digits) > 1 else int(digits)
            if 1 <= idx <= len(possible_keys):
                return possible_keys[idx - 1]

        lower_answer = answer.lower()
        for key in possible_keys:
            if key.lower() in lower_answer:
                return key

        return None

    def execute(self, flow: Flow, task_description: str) -> Tuple[ExecutionTrace, float]:
        trace = ExecutionTrace()

        if flow.header is None:
            trace.terminated_reason = "empty flow: no header block"
            return trace, 0.0

        flow_ptr = flow.header
        progress: List[str] = []
        empty_answer_count = 0
        branch_fail_count = 0

        for round_idx in range(self.max_round):
            answer = self._answer_node(flow_ptr, task_description, progress)
            if not answer:
                empty_answer_count += 1

            tool_used = None
            if self.node_api_resolver is not None:
                try:
                    tool_result = self.node_api_resolver(flow_ptr, answer)
                except Exception as e:
                    logging.error(f"[Executor] node_api_resolver failed at {flow_ptr.name}: {e}")
                    tool_result = None
                if tool_result:
                    answer = tool_result
                    tool_used = flow_ptr.name

            progress.append(f"Step [{flow_ptr.name}] ({flow_ptr.type}): {flow_ptr.get_instruction()}")
            progress.append(f"Answer: {answer}")

            if flow_ptr.type == 'terminal' or len(flow_ptr.branch) == 0:
                trace.add_step(flow_ptr, answer, None, tool_used)
                trace.terminated = True
                trace.terminated_reason = "reached terminal block"
                break

            if len(flow_ptr.branch) == 1:
                branch_key = list(flow_ptr.branch.keys())[0]
                next_block = flow_ptr.branch[branch_key]
                trace.add_step(flow_ptr, answer, branch_key, tool_used)
            else:
                branch_key = self._choose_branch(flow_ptr, answer, task_description)
                if branch_key is None:
                    branch_fail_count += 1
                    branch_key = list(flow_ptr.branch.keys())[0]
                next_block = flow_ptr.branch[branch_key]
                trace.add_step(flow_ptr, answer, branch_key, tool_used)

            if isinstance(next_block, str):
                trace.terminated = False
                trace.terminated_reason = f"dangling branch target: {next_block}"
                break

            flow_ptr = next_block
        else:
            trace.terminated = False
            trace.terminated_reason = f"exceeded max_round={self.max_round} without reaching terminal"

        reward = self._compute_reward(trace, empty_answer_count, branch_fail_count)
        return trace, reward

    def _compute_reward(self, trace: ExecutionTrace, empty_answer_count: int,
                         branch_fail_count: int) -> float:
        if not trace.steps:
            return 0.0

        score = 0.0

        if trace.terminated:
            score += 0.5
        else:
            score += 0.05
            return round(min(max(score, 0.0), 1.0), 4)

        num_steps = len(trace.steps)

        if num_steps >= 2:
            length_score = 0.2
        else:
            length_score = 0.05
        score += length_score

        empty_ratio = empty_answer_count / num_steps
        score += 0.15 * (1.0 - min(empty_ratio, 1.0))

        num_decisions = sum(1 for s in trace.steps if s['type'] == 'decision')
        if num_decisions > 0:
            branch_success_ratio = 1.0 - min(branch_fail_count / num_decisions, 1.0)
        else:
            branch_success_ratio = 1.0
        score += 0.15 * branch_success_ratio

        return round(min(max(score, 0.0), 1.0), 4)


def make_execute_func(call_llm: Callable[[List[Dict]], str],
                       task_description: str,
                       node_api_resolver: Optional[Callable[[Block, str], Optional[str]]] = None,
                       max_round: int = 20) -> Callable[[str], float]:
    executor = AutoFlowExecutor(call_llm=call_llm, node_api_resolver=node_api_resolver,
                                 max_round=max_round)

    def execute_func(workflow_text: str) -> float:
        try:
            flow = Flow(flow_text=workflow_text)
        except Exception as e:
            logging.error(f"[Executor] Failed to parse workflow: {e}")
            return 0.0
        _, reward = executor.execute(flow, task_description)
        return reward

    return execute_func
