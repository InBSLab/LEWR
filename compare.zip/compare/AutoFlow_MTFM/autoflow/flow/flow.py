
from .block import Block


def read_lines_from_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        return [line.strip() for line in f.readlines() if line.strip()]


class Flow(object):
    
    def __init__(self, flow_file=None, flow_text=None):
        
        if flow_file:
            flow_instruction = read_lines_from_file(flow_file)
        elif flow_text:
            flow_instruction = [line.strip() for line in flow_text.strip().split('\n') if line.strip()]
        else:
            raise ValueError("Either flow_file or flow_text must be provided")
        
        self.block_dict = dict()
        self.header = None
        
        for row in flow_instruction:
            if ':::' not in row:
                continue
            try:
                step_block = Block(row)
                self.block_dict[step_block.name] = step_block
                
                if self.header is None:
                    self.header = step_block
            except Exception as e:
                print(f"Warning: Failed to parse block: {row}, error: {e}")
                continue
                
        self.connect_blocks()
        
        
    def connect_blocks(self):
        for key, value in self.block_dict.items():
            try:
                for branch_condition, branch_block in value.branch.items():
                    if branch_block in self.block_dict:
                        value.branch[branch_condition] = self.block_dict[branch_block]
            except Exception as e:
                print(f"Warning: Error when connecting blocks: {e}")
        
    def __str__(self):
        flow_str = ''
        for key, value in self.block_dict.items():
            flow_str += value.__str__()
        return flow_str
    
    def to_dict(self):
        blocks = {}
        for key, value in self.block_dict.items():
            blocks[key] = value.to_dict()
        
        return {
            'header': self.header.name if self.header else None,
            'blocks': blocks
        }
    
    def get_all_blocks(self):
        return list(self.block_dict.values())
    
    def get_process_blocks(self):
        return [b for b in self.block_dict.values() if b.type == 'process']
    
    def get_decision_blocks(self):
        return [b for b in self.block_dict.values() if b.type == 'decision']
    
    def get_terminal_blocks(self):
        return [b for b in self.block_dict.values() if b.type == 'terminal']


if __name__ == '__main__':
    test_flow = """
Step 1:::Process:::identify the input data type based on the objective.:::next::step 2
Step 2:::Process:::identify the output data type based on the objective.:::next::Step 3
Step 3:::Process:::Select models in provided models list to generate a to-do list.:::next::step 4
Step 4:::decision:::Check whether every models in the to-do list is in the provided models.:::Yes::Step 5::No::Step 3
Step 5:::decision:::Check whether the previous model output data type is the input data type of the next model.:::Yes::Step 6::No::Step 3
Step 6:::terminal:::Output the to-do list solely with model name.:::
"""
    flow = Flow(flow_text=test_flow)
    print(flow)
    print("\nFlow dict:", flow.to_dict())
