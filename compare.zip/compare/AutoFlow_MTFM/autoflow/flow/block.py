

class Block(object):
    
    def __init__(self, des):
        structured_info = self.parser(des)
        self.name = structured_info['name'].lower()
        self.instruction = structured_info['instruction']
        self.type = structured_info['type'].lower()
        self.branch = structured_info['branch']
    
    def parser(self, des):
        structured_info = dict()
        info = [component.strip() for component in des.split(":::")]
        structured_info['name'] = info[0]
        
        if info[1].lower() not in ['process', 'decision', 'terminal']:
            raise Exception("The type is not in [process, decision, terminal]")
        
        structured_info['type'] = info[1]
        structured_info['instruction'] = info[2]
        structured_info['branch'] = dict()
        
        if len(info) > 3 and info[3].strip():
            branch_info = [branch.strip() for branch in info[3].split("::")]
            num = len(branch_info) // 2
            for i in range(num):
                structured_info['branch'][branch_info[2 * i].lower()] = branch_info[2 * i + 1].lower()
            
        return structured_info
    
    def __str__(self):
        branch_str = ''
        for key, value in self.branch.items():
            if isinstance(value, str):
                branch_str += f'if {key}, then go to {value}. '
            else:
                branch_str += f'if {key}, then go to {value.name}. '
        
        return f'{self.name}, the type is {self.type}, the instruction is {self.instruction} {branch_str}\n'

    def get_instruction(self):
        return self.instruction
    
    def to_dict(self):
        branch_dict = {}
        for key, value in self.branch.items():
            if isinstance(value, str):
                branch_dict[key] = value
            else:
                branch_dict[key] = value.name
        
        return {
            'name': self.name,
            'type': self.type,
            'instruction': self.instruction,
            'branch': branch_dict
        }
