
import os
import json
import random
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader, SubsetRandomSampler
from pathlib import Path
from collections import Counter


class MashupDataset(Dataset):
    
    def __init__(self, 
                 data_path: str = "./data",
                 embedding_path: str = "./embedding",
                 use_roberta: bool = False,
                 max_doc_len: int = 100,
                 min_word_freq: int = 2,
                 max_vocab_size: int = 10000):
        self.data_path = Path(data_path)
        self.embedding_path = Path(embedding_path)
        self.use_roberta = use_roberta
        self.max_doc_len = max_doc_len
        
        self._load_json_data()
        
        if use_roberta:
            self._load_roberta_features()
        else:
            self._build_vocab(min_word_freq, max_vocab_size)
            self._build_text_indices()
        
        self._build_labels()
        
        print(f"[MashupDataset] Initialized:")
        print(f"  - Mashups: {self.num_mashup}")
        print(f"  - APIs: {self.num_api}")
        print(f"  - Categories: {self.num_category}")
        print(f"  - Mode: {'RoBERTa' if self.use_roberta else 'Word Embedding'}")
    
    def _load_json_data(self):
        with open(self.data_path / "api_name.json", 'r', encoding='utf-8') as f:
            self.api_names = json.load(f)
        self.api_to_idx = {name: i for i, name in enumerate(self.api_names)}
        self.num_api = len(self.api_names)
        
        with open(self.data_path / "mashup_name.json", 'r', encoding='utf-8') as f:
            self.mashup_names = json.load(f)
        self.name = self.mashup_names
        self.num_mashup = len(self.mashup_names)
        
        with open(self.data_path / "mashup_description.json", 'r', encoding='utf-8') as f:
            self.mashup_descriptions = json.load(f)
        
        with open(self.data_path / "mashup_used_api.json", 'r', encoding='utf-8') as f:
            self.mashup_used_apis = json.load(f)
        
        with open(self.data_path / "category_list.json", 'r', encoding='utf-8') as f:
            self.categories = json.load(f)
        self.category_to_idx = {c: i for i, c in enumerate(self.categories)}
        self.num_category = len(self.categories)
        
        with open(self.data_path / "mashup_category.json", 'r', encoding='utf-8') as f:
            self.mashup_categories = json.load(f)
    
    def _load_roberta_features(self):
        mashup_feat_path = self.embedding_path / "mashup_features_roberta.npy"
        api_feat_path = self.embedding_path / "api_features_roberta.npy"
        
        if mashup_feat_path.exists():
            self.mashup_features = np.load(mashup_feat_path)
            self.embed_dim = self.mashup_features.shape[1]
            print(f"[MashupDataset] Loaded mashup RoBERTa features: {self.mashup_features.shape}")
        else:
            print(f"[MashupDataset] Warning: {mashup_feat_path} not found, falling back to word embedding mode")
            self.use_roberta = False
            self._build_vocab()
            self._build_text_indices()
            return
        
        if api_feat_path.exists():
            self.api_features = np.load(api_feat_path)
            print(f"[MashupDataset] Loaded API RoBERTa features: {self.api_features.shape}")
        else:
            self.api_features = None
            print(f"[MashupDataset] Warning: {api_feat_path} not found (optional)")
    
    def _build_vocab(self, min_freq: int = 2, max_vocab: int = 10000):
        word_freq = Counter()
        
        for desc in self.mashup_descriptions:
            if isinstance(desc, list):
                words = [w.lower() for w in desc]
            else:
                words = str(desc).lower().split()
            
            for word in words:
                word_freq[word] += 1
        
        self.vocab = {'<PAD>': 0, '<UNK>': 1}
        idx = 2
        for word, freq in word_freq.most_common(max_vocab - 2):
            if freq >= min_freq:
                self.vocab[word] = idx
                idx += 1
        
        self.vocab_size = len(self.vocab)
        self.embed_dim = 128
        print(f"[MashupDataset] Vocab size: {self.vocab_size}")
    
    def _text_to_indices(self, text) -> list:
        if isinstance(text, list):
            words = [w.lower() for w in text]
        else:
            words = str(text).lower().split()
        
        indices = []
        for word in words[:self.max_doc_len]:
            indices.append(self.vocab.get(word, 1))
        
        while len(indices) < self.max_doc_len:
            indices.append(0)
        
        return indices[:self.max_doc_len]
    
    def _build_text_indices(self):
        self.mashup_indices = []
        for desc in self.mashup_descriptions:
            self.mashup_indices.append(self._text_to_indices(desc))
    
    def _build_labels(self):
        self.api_labels = np.zeros((self.num_mashup, self.num_api), dtype=np.float32)
        for i, apis in enumerate(self.mashup_used_apis):
            for api in apis:
                if api in self.api_to_idx:
                    self.api_labels[i, self.api_to_idx[api]] = 1.0
        
        self.category_labels = np.zeros((self.num_mashup, self.num_category), dtype=np.float32)
        for i, cats in enumerate(self.mashup_categories):
            for cat in cats:
                if cat in self.category_to_idx:
                    self.category_labels[i, self.category_to_idx[cat]] = 1.0
    
    def __len__(self):
        return self.num_mashup
    
    def __getitem__(self, idx):
        if self.use_roberta:
            features = torch.FloatTensor(self.mashup_features[idx])
        else:
            features = torch.LongTensor(self.mashup_indices[idx])
        
        category_target = torch.FloatTensor(self.category_labels[idx])
        api_target = torch.FloatTensor(self.api_labels[idx])
        
        return idx, features, category_target, api_target
    
    def get_api_name(self, idx):
        return self.api_names[idx]
    
    def get_api_names_by_indices(self, indices):
        return [self.api_names[i] for i in indices]


class TextDataset:
    
    def __init__(self, 
                 data_path: str = "./data",
                 embedding_path: str = "./embedding",
                 use_roberta: bool = False):
        self.mashup_ds = MashupDataset(data_path, embedding_path, use_roberta)
        
        self.embed_dim = self.mashup_ds.embed_dim
        self.max_doc_len = self.mashup_ds.max_doc_len
        self.num_category = self.mashup_ds.num_category
        self.num_mashup = self.mashup_ds.num_mashup
        self.num_api = self.mashup_ds.num_api
        self.vocab_size = getattr(self.mashup_ds, 'vocab_size', 10000)
        self.embed = None
        self.use_roberta = self.mashup_ds.use_roberta


def get_indices(dataset, train_ratio=0.8, val_ratio=0.1, seed=42):
    random.seed(seed)
    np.random.seed(seed)
    
    n = len(dataset)
    indices = list(range(n))
    random.shuffle(indices)
    
    train_size = int(n * train_ratio)
    val_size = int(n * val_ratio)
    
    train_idx = indices[:train_size]
    val_idx = indices[train_size:train_size + val_size]
    test_idx = indices[train_size + val_size:]
    
    print(f"[Dataset Split] Train: {len(train_idx)}, Val: {len(val_idx)}, Test: {len(test_idx)}")
    
    return train_idx, val_idx, test_idx


def create_data_loaders(dataset, batch_size=128, train_ratio=0.8, val_ratio=0.1, seed=42):
    train_idx, val_idx, test_idx = get_indices(dataset, train_ratio, val_ratio, seed)
    
    train_loader = DataLoader(
        dataset, 
        batch_size=batch_size,
        sampler=SubsetRandomSampler(train_idx)
    )
    
    val_loader = DataLoader(
        dataset,
        batch_size=len(val_idx),
        sampler=SubsetRandomSampler(val_idx)
    )
    
    test_loader = DataLoader(
        dataset,
        batch_size=len(test_idx),
        sampler=SubsetRandomSampler(test_idx)
    )
    
    return train_loader, val_loader, test_loader


if __name__ == '__main__':
    print("Testing data loading...")
    
    try:
        ds = TextDataset(data_path="./data", use_roberta=False)
        print(f"Loaded dataset with {ds.num_mashup} mashups")
    except Exception as e:
        print(f"Could not load dataset: {e}")
        print("This is expected if data directory does not exist.")
