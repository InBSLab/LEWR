

from typing import Optional

SUPPORTED_TASK_TYPES = {
    "task",
    "userTask",
    "serviceTask",
    "sendTask",
    "receiveTask",
    "businessRuleTask",
    "manualTask",
    "scriptTask",
}

SUPPORTED_EVENT_TYPES = {
    "startEvent",
    "endEvent",
    "intermediateThrowEvent",
    "intermediateCatchEvent",
}

SUPPORTED_GATEWAY_TYPES = {
    "exclusiveGateway",
    "inclusiveGateway",
    "parallelGateway",
}

SUPPORTED_ELEMENT_TYPES = SUPPORTED_TASK_TYPES | SUPPORTED_EVENT_TYPES | SUPPORTED_GATEWAY_TYPES

SUPPORTED_EVENT_DEFINITIONS = {"timerEventDefinition", "messageEventDefinition"}


class BPMNValidationError(ValueError):
    pass


def validate_bpmn(process: list, is_top_level: bool = True, _seen_ids: Optional[set] = None) -> None:
    if not isinstance(process, list):
        raise BPMNValidationError(f"'process' must be a list, got: {type(process).__name__}")

    seen_ids = _seen_ids if _seen_ids is not None else set()
    start_event_count = 0

    for element in process:
        validate_element(element)

        elem_id = element["id"]
        if elem_id in seen_ids:
            raise BPMNValidationError(f"Duplicate element ID found: {elem_id}")
        seen_ids.add(elem_id)

        if is_top_level and element["type"] == "startEvent":
            start_event_count += 1

        if element["type"] in ("exclusiveGateway", "inclusiveGateway"):
            for branch in element["branches"]:
                validate_bpmn(branch["path"], is_top_level=False, _seen_ids=seen_ids)
        elif element["type"] == "parallelGateway":
            for branch in element["branches"]:
                validate_bpmn(branch, is_top_level=False, _seen_ids=seen_ids)

    if is_top_level:
        if start_event_count != 1:
            raise BPMNValidationError(
                f"Process must contain exactly one start event, found {start_event_count}"
            )
        if not _process_has_end_event(process):
            raise BPMNValidationError("Process must contain at least one end event")


        from bpmn_xml_generator import BpmnProcessTransformer

        BpmnProcessTransformer().transform(process)


def validate_element(element: dict) -> None:
    if not isinstance(element, dict):
        raise BPMNValidationError(f"Element must be an object, got: {element}")

    if "id" not in element:
        raise BPMNValidationError(f"Element is missing an ID: {element}")
    if "type" not in element:
        raise BPMNValidationError(f"Element is missing a type: {element}")

    elem_type = element["type"]

    if elem_type not in SUPPORTED_ELEMENT_TYPES:
        raise BPMNValidationError(
            f"Unsupported element type: '{elem_type}'. "
            f"Supported types: {sorted(SUPPORTED_ELEMENT_TYPES)}"
        )

    if elem_type in SUPPORTED_TASK_TYPES:
        _validate_task(element)
    elif elem_type == "exclusiveGateway":
        _validate_exclusive_or_inclusive_gateway(element, "exclusiveGateway")
    elif elem_type == "inclusiveGateway":
        _validate_exclusive_or_inclusive_gateway(element, "inclusiveGateway")
    elif elem_type == "parallelGateway":
        _validate_parallel_gateway(element)
    elif elem_type in SUPPORTED_EVENT_TYPES:
        _validate_event(element)


def _validate_task(element: dict) -> None:
    if "label" not in element or not str(element["label"]).strip():
        raise BPMNValidationError(f"Task element is missing a label: {element}")


def _validate_event(element: dict) -> None:
    if "eventDefinition" in element and element["eventDefinition"] is not None:
        if element["eventDefinition"] not in SUPPORTED_EVENT_DEFINITIONS:
            raise BPMNValidationError(
                f"Unsupported eventDefinition '{element['eventDefinition']}' on element "
                f"{element['id']}. Supported: {sorted(SUPPORTED_EVENT_DEFINITIONS)}"
            )


def _validate_exclusive_or_inclusive_gateway(element: dict, gateway_type: str) -> None:
    if "label" not in element or not str(element["label"]).strip():
        raise BPMNValidationError(f"{gateway_type} is missing a label: {element}")

    if "branches" not in element or not isinstance(element["branches"], list):
        raise BPMNValidationError(f"{gateway_type} is missing or has invalid 'branches': {element}")

    branch_paths = []
    for branch in element["branches"]:
        if "path" not in branch:
            raise BPMNValidationError(f"Invalid branch in {gateway_type} (missing 'path'): {branch}")
        if not isinstance(branch["path"], list):
            raise BPMNValidationError(f"{gateway_type} branch 'path' must be a list: {branch}")

        if gateway_type == "exclusiveGateway":
            if "condition" not in branch:
                raise BPMNValidationError(f"Invalid branch in exclusiveGateway (missing 'condition'): {branch}")
        else:
            if not branch.get("is_default", False) and "condition" not in branch:
                raise BPMNValidationError(
                    f"Invalid branch in inclusiveGateway (non-default branch missing 'condition'): {branch}"
                )

        branch_paths.append(branch["path"])

    if branch_paths and all(len(p) == 0 for p in branch_paths):
        raise BPMNValidationError(
            f"{gateway_type} '{element.get('id')}' must have at least one branch with elements; "
            "all branch paths are empty."
        )


def _validate_parallel_gateway(element: dict) -> None:
    if "branches" not in element or not isinstance(element["branches"], list):
        raise BPMNValidationError(f"parallelGateway is missing or has invalid 'branches': {element}")

    for branch in element["branches"]:
        if not isinstance(branch, list):
            raise BPMNValidationError(
                f"parallelGateway '{element.get('id')}' branches must each be a list of elements: {branch}"
            )
        if len(branch) == 0:
            raise BPMNValidationError(
                f"parallelGateway '{element.get('id')}' cannot have an empty branch."
            )


def _process_has_end_event(process: list) -> bool:
    for element in process:
        if element["type"] == "endEvent":
            return True
        if element["type"] in ("exclusiveGateway", "inclusiveGateway"):
            for branch in element["branches"]:
                if _process_has_end_event(branch["path"]):
                    return True
        elif element["type"] == "parallelGateway":
            for branch in element["branches"]:
                if _process_has_end_event(branch):
                    return True
    return False
