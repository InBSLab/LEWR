

import torch
import torch.nn as nn
import numpy as np
from typing import Optional


class MLPConfig:
    def __init__(self, ds_config):
        self.model_name = 'MLP_Model'
        self.embed_dim = ds_config.embed_dim
        self.max_doc_len = ds_config.max_doc_len
        self.dropout = 0.2
        self.num_category = ds_config.num_category
        self.feature_dim = 8
        self.num_mashup = ds_config.num_mashup
        self.num_api = ds_config.num_api
        self.vocab_size = ds_config.vocab_size
        self.embed = ds_config.embed
        self.lr = 1e-3
        self.batch_size = 128
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'


        self.use_roberta = getattr(ds_config, 'use_roberta', False)


class MLP(nn.Module):

    def __init__(self, config: MLPConfig):
        super(MLP, self).__init__()

        self.config = config
        self.use_roberta = config.use_roberta

        if not self.use_roberta:

            if config.embed is not None:
                self.embedding = nn.Embedding.from_pretrained(config.embed, freeze=False)
            else:
                self.embedding = nn.Embedding(
                    config.vocab_size,
                    config.embed_dim,
                    padding_idx=config.vocab_size - 1
                )


        self.fc1 = nn.Linear(config.embed_dim, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, config.num_api)

        self.dropout = nn.Dropout(config.dropout)
        self.relu = nn.ReLU()

    def forward(self, x):
        if self.use_roberta:

            embed = x
        else:

            embed = self.embedding(x)

            embed = embed.mean(dim=1)


        x = self.relu(self.fc1(embed))
        x = self.dropout(x)
        x = self.relu(self.fc2(x))
        x = self.dropout(x)
        output = self.fc3(x)


        return output

    def predict(self, x, top_k: int = 5) -> tuple:
        self.eval()
        with torch.no_grad():
            logits = self.forward(x)
            probs = torch.sigmoid(logits)

            top_scores, top_indices = torch.topk(probs, k=top_k, dim=-1)

        return top_indices.cpu().numpy(), top_scores.cpu().numpy()


class MLPTrainer:

    def __init__(self, model: MLP, config: MLPConfig,
                 train_loader, val_loader, test_loader,
                 checkpoint_path: str = None):
        self.model = model
        self.config = config
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.test_loader = test_loader


        self.criterion = nn.BCEWithLogitsLoss()


        self.optimizer = torch.optim.Adam(model.parameters(), lr=config.lr)


        self.epochs = 100
        self.top_k_list = [1, 5, 10, 15, 20, 25, 30]


        self.checkpoint_path = checkpoint_path or 'checkpoints/mlp_best.pth'


        self.patience = 7
        self.best_val_loss = float('inf')
        self.patience_counter = 0

    def train(self):
        print('=' * 60)
        print('Start training MLP...')
        print('=' * 60)

        for epoch in range(self.epochs):

            self.model.train()
            train_losses = []

            for batch_data in self.train_loader:
                idx = batch_data[0].to(self.config.device)
                features = batch_data[1].to(self.config.device)
                api_target = batch_data[3].float().to(self.config.device)

                self.optimizer.zero_grad()
                prediction = self.model(features)

                loss = self.criterion(prediction, api_target)
                loss.backward()
                self.optimizer.step()

                train_losses.append(loss.item())

            train_loss = np.mean(train_losses)


            val_loss = self._evaluate(self.val_loader)

            print(f'[Epoch {epoch+1}/{self.epochs}] Train_Loss: {train_loss:.6f}, Val_Loss: {val_loss:.6f}')


            if val_loss < self.best_val_loss:
                self.best_val_loss = val_loss
                self.patience_counter = 0
                torch.save(self.model.state_dict(), self.checkpoint_path)
                print(f'  → Model saved (best val_loss: {val_loss:.6f})')
            else:
                self.patience_counter += 1
                if self.patience_counter >= self.patience:
                    print('Early stopping!')
                    break


        self.model.load_state_dict(torch.load(self.checkpoint_path, map_location=self.config.device))
        print(f'\n✓ Training complete. Best model loaded from {self.checkpoint_path}')

    def _evaluate(self, data_loader, verbose: bool = False) -> float:
        self.model.eval()
        losses = []

        ndcg_a = np.zeros(len(self.top_k_list))
        recall_a = np.zeros(len(self.top_k_list))
        ap_a = np.zeros(len(self.top_k_list))
        pre_a = np.zeros(len(self.top_k_list))

        num_batch = len(data_loader)

        with torch.no_grad():
            for batch_data in data_loader:
                features = batch_data[1].to(self.config.device)
                api_target = batch_data[3].float().to(self.config.device)

                prediction = self.model(features)
                loss = self.criterion(prediction, api_target)
                losses.append(loss.item())

                if verbose:

                    pred_np = prediction.cpu().numpy()
                    target_np = batch_data[3].numpy()

                    ndcg_, recall_, ap_, pre_ = self._compute_metrics(target_np, pred_np)
                    ndcg_a += ndcg_
                    recall_a += recall_
                    ap_a += ap_
                    pre_a += pre_

        avg_loss = np.mean(losses)

        if verbose:
            ndcg_a /= num_batch
            recall_a /= num_batch
            ap_a /= num_batch
            pre_a /= num_batch

            print(f'\nTop-K: {self.top_k_list}')
            print(f'NDCG:      {[f"{v:.4f}" for v in ndcg_a]}')
            print(f'Recall:    {[f"{v:.4f}" for v in recall_a]}')
            print(f'Precision: {[f"{v:.4f}" for v in pre_a]}')
            print(f'AP:        {[f"{v:.4f}" for v in ap_a]}')

        return avg_loss

    def test(self):
        print('\n' + '=' * 60)
        print('Testing on test set...')
        print('=' * 60)
        test_loss = self._evaluate(self.test_loader, verbose=True)
        print(f'\nTest Loss: {test_loss:.6f}')

    def _compute_metrics(self, labels, predictions):
        batch_size = labels.shape[0]
        ndcg_list = np.zeros(len(self.top_k_list))
        recall_list = np.zeros(len(self.top_k_list))
        ap_list = np.zeros(len(self.top_k_list))
        precision_list = np.zeros(len(self.top_k_list))

        for i in range(batch_size):
            pred = predictions[i]
            label = labels[i]
            total_relevant = label.sum()

            for k_idx, k in enumerate(self.top_k_list):
                top_k_idx = np.argsort(pred)[::-1][:k]

                hits = label[top_k_idx].sum()
                precision_list[k_idx] += hits / k

                if total_relevant > 0:
                    recall_list[k_idx] += hits / total_relevant


                dcg = sum(1 / np.log2(j + 2) for j, idx in enumerate(top_k_idx) if label[idx] > 0)
                ideal_num = min(int(total_relevant), k)
                idcg = sum(1 / np.log2(j + 2) for j in range(ideal_num))
                ndcg_list[k_idx] += dcg / idcg if idcg > 0 else 0


                ap = 0
                relevant_count = 0
                for j, idx in enumerate(top_k_idx):
                    if label[idx] > 0:
                        relevant_count += 1
                        ap += relevant_count / (j + 1)
                ap_list[k_idx] += ap / min(total_relevant, k) if total_relevant > 0 else 0

        return (ndcg_list / batch_size, recall_list / batch_size,
                ap_list / batch_size, precision_list / batch_size)
