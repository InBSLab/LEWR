

import os
import sys
import random
import numpy as np
import torch
from torch.utils.data import DataLoader, SubsetRandomSampler
from pathlib import Path


PROJECT_ROOT = Path(__file__).parent.absolute()
sys.path.insert(0, str(PROJECT_ROOT))


from tools import TextDataset, get_indices, get_time, EarlyStopping, metric
from mlp_model import MLP, MLPConfig, MLPTrainer


def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)


def main():
    print("=" * 70)
    print("MLP模型训练")
    print("=" * 70)


    set_seed(42)


    data_path = PROJECT_ROOT / "data"
    embedding_path = PROJECT_ROOT / "embedding"
    checkpoint_dir = PROJECT_ROOT / "checkpoints"
    log_dir = PROJECT_ROOT / "logs"


    checkpoint_dir.mkdir(exist_ok=True)
    log_dir.mkdir(exist_ok=True)


    print("\n[1] 检查数据文件...")
    required_files = [
        "api_name.json",
        "mashup_name.json",
        "mashup_description.json",
        "mashup_used_api.json",
        "mashup_category.json",
        "category_list.json"
    ]

    missing_files = []
    for f in required_files:
        if not (data_path / f).exists():
            missing_files.append(f)

    if missing_files:
        print(f"  ✗ 缺少数据文件:")
        for f in missing_files:
            print(f"      - {f}")
        print(f"\n请将数据文件放入 {data_path} 目录")
        return
    else:
        print("  ✓ 所有数据文件已就绪")


    roberta_file = embedding_path / "mashup_features_roberta.npy"
    use_roberta = roberta_file.exists()

    if use_roberta:
        print(f"  ✓ 发现RoBERTa特征文件，将使用RoBERTa模式")
    else:
        print(f"  ⚠ 未发现RoBERTa特征文件，将使用词嵌入模式")
        print(f"    (可选: 将 mashup_features_roberta.npy 放入 {embedding_path})")


    print("\n[2] 加载数据集...")
    ds = TextDataset(str(data_path), str(embedding_path), use_roberta=use_roberta)


    print("\n[3] 划分数据集...")
    train_idx, val_idx, test_idx = get_indices(ds.mashup_ds)


    config = MLPConfig(ds)

    train_loader = DataLoader(
        ds.mashup_ds,
        batch_size=config.batch_size,
        sampler=SubsetRandomSampler(train_idx)
    )
    val_loader = DataLoader(
        ds.mashup_ds,
        batch_size=len(val_idx),
        sampler=SubsetRandomSampler(val_idx)
    )
    test_loader = DataLoader(
        ds.mashup_ds,
        batch_size=len(test_idx),
        sampler=SubsetRandomSampler(test_idx)
    )


    print("\n[4] 模型配置:")
    print(f"  - 模型: {config.model_name}")
    print(f"  - 嵌入维度: {config.embed_dim}")
    print(f"  - API数量: {config.num_api}")
    print(f"  - 类别数量: {config.num_category}")
    print(f"  - Mashup数量: {config.num_mashup}")
    print(f"  - 批大小: {config.batch_size}")
    print(f"  - 学习率: {config.lr}")
    print(f"  - Dropout: {config.dropout}")
    print(f"  - 设备: {config.device}")
    print(f"  - 模式: {'RoBERTa' if ds.use_roberta else 'Word Embedding'}")


    print("\n[5] 创建模型...")
    model = MLP(config)
    model.to(config.device)


    print(f"\n模型结构:")
    print(model)


    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"\n参数数量: {total_params:,} (可训练: {trainable_params:,})")


    checkpoint_path = str(checkpoint_dir / "mlp_best.pth")
    trainer = MLPTrainer(
        model=model,
        config=config,
        train_loader=train_loader,
        val_loader=val_loader,
        test_loader=test_loader,
        checkpoint_path=checkpoint_path
    )


    print("\n" + "=" * 70)
    trainer.train()


    trainer.test()

    print("\n" + "=" * 70)
    print("训练完成!")
    print(f"模型已保存到: {checkpoint_path}")
    print("=" * 70)
    print("\n现在可以运行 main.py 进行工作流生成和API推荐")


if __name__ == "__main__":
    main()
