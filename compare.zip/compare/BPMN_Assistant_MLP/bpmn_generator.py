

import os
import json
import re
import requests
from typing import Dict, List, Any, Optional


from bpmn_validator import validate_bpmn, BPMNValidationError
from bpmn_xml_generator import BpmnXmlGenerator


BPMN_REPRESENTATION_PROMPT = '''The BPMN JSON representation uses a sequence of elements to describe the process. Each element is executed in order based on its position in the "process" array unless gateways (exclusive or parallel) specify branching paths.

# Representation of various BPMN elements

## Tasks

Specify the task type in the 'type' field. The following task types are supported: "task", "userTask", "serviceTask", "sendTask", "receiveTask", "businessRuleTask", "manualTask", "scriptTask".
Always try to specify the most specific task type:
- Use 'userTask' for human interaction tasks (reviewing, deciding, entering data)
- Use 'serviceTask' for automated system actions (calculations, database operations, API calls)
- Use 'sendTask' for automated sending operations (emails, notifications, messages)
- Use 'receiveTask' for automated receiving operations (waiting for messages, webhooks)
- Use 'businessRuleTask' for decision engine or rule evaluation tasks
- Use 'manualTask' for manual work performed without system support (physical activities, paper forms)
- Use 'scriptTask' for script or code execution tasks
- Use 'task' only if the action cannot be clearly classified as any of the above
Each task must be atomic - representing a single unit of work. Break down complex activities into multiple separate tasks.
Labels must be clear and concise (ideally 2-4 words).

```json
{
    "type": String = "task" | "userTask" | "serviceTask" | "sendTask" | "receiveTask" | "businessRuleTask" | "manualTask" | "scriptTask"
    "id": String,
    "label": String, // short task description
}
```

## Events

Specify the event type in the 'type' field. The following event types are supported: "startEvent", "endEvent", "intermediateThrowEvent", "intermediateCatchEvent".

Events can optionally have an event definition that specifies what triggers or is triggered by the event:
- Use 'timerEventDefinition' for time-based events (schedules, delays, timeouts)
- Use 'messageEventDefinition' for message-based events (sending or receiving messages)
- Omit 'eventDefinition' for generic/none events

```json
{
    "type": String = "startEvent" | "endEvent" | "intermediateThrowEvent" | "intermediateCatchEvent",
    "id": String,
    "label": String, // OPTIONAL: short event description
    "eventDefinition": String = "timerEventDefinition" | "messageEventDefinition", // OPTIONAL
}
```

## Gateways

### Exclusive gateway
Each branch must include a condition and an array of elements that are executed if the condition is met.

```json
{
    "type": String = "exclusiveGateway",
    "id": String,
    "label": String, // label for the gateway
    "has_join": Boolean, // whether the gateway contains a join element
    "branches": [
        {
            "condition": String,
            "path": [], // array of elements
            "next": String, // OPTIONAL: ID of the next element
        }
    ],
}
```

### Parallel gateway
Specify "branches" as an array of arrays, where each sub-array lists elements executed in parallel.

```json
{
    "type": String = "parallelGateway",
    "id": String,
    "branches": [
        [], // array of elements executed in parallel
        []
    ],
}
```

### Inclusive gateway
An inclusive gateway allows multiple branches to be taken simultaneously based on their conditions.

```json
{
    "type": String = "inclusiveGateway",
    "id": String,
    "label": String,
    "has_join": Boolean,
    "branches": [
        {
            "condition": String,
            "path": [],
            "is_default": Boolean, // OPTIONAL
        }
    ],
}
```
'''

BPMN_EXAMPLES_PROMPT = '''# Process examples

Example 1:
Textual description: "The student sends an email to the professor. The professor receives the email. If the professor agrees with the proposal, he replies to the student."

```json
{
    "process": [
        {"type": "startEvent", "id": "start"},
        {"type": "userTask", "id": "task1", "label": "Send email to professor"},
        {"type": "task", "id": "task2", "label": "Receive the email"},
        {
            "type": "exclusiveGateway",
            "id": "exclusive1",
            "label": "Professor agrees?",
            "has_join": true,
            "branches": [
                {
                    "condition": "If the professor agrees",
                    "path": [{"type": "task", "id": "task3", "label": "Reply to the student"}]
                },
                {"condition": "If the professor does not agree", "path": []}
            ]
        },
        {"type": "endEvent", "id": "end1"}
    ]
}
```

Example 2:
Textual description: "The manager sends the mail to the supplier and prepares the documents. At the same time, the customer searches for the goods and picks up the goods."

```json
{
    "process": [
        {"type": "startEvent", "id": "start"},
        {
            "type": "parallelGateway",
            "id": "parallel1",
            "branches": [
                [
                    {"type": "serviceTask", "id": "task1", "label": "Send mail to supplier"},
                    {"type": "task", "id": "task2", "label": "Prepare the documents"}
                ],
                [
                    {"type": "task", "id": "task3", "label": "Search for the goods"},
                    {"type": "task", "id": "task4", "label": "Pick up the goods"}
                ]
            ]
        },
        {"type": "endEvent", "id": "end1"}
    ]
}
```

Example 3:
Textual description: "A customer fills out an order form manually. The system sends a confirmation email and then waits to receive payment confirmation. A script validates the payment data."

```json
{
    "process": [
        {"type": "startEvent", "id": "start"},
        {"type": "manualTask", "id": "task1", "label": "Fill out order form"},
        {"type": "sendTask", "id": "task2", "label": "Send confirmation email"},
        {"type": "receiveTask", "id": "task3", "label": "Receive payment confirmation"},
        {"type": "scriptTask", "id": "task4", "label": "Validate payment data"},
        {"type": "endEvent", "id": "end"}
    ]
}
```
'''


class BPMNGenerator:

    def __init__(self, api_key: str = None, base_url: str = None):
        self.api_key = api_key or os.getenv("DEEPSEEK_API_KEY")
        if not self.api_key:
            raise ValueError(
                "No DeepSeek API key provided. Pass api_key=... or set the "
                "DEEPSEEK_API_KEY environment variable."
            )
        self.base_url = base_url or "https://api.deepseek.com/v1"


        self.system_prompt = self._build_system_prompt()


        self.xml_generator = BpmnXmlGenerator()


        self.last_conversation: List[dict] = []

    def _build_system_prompt(self) -> str:
        return f"""You are an expert in BPMN (Business Process Model and Notation) workflow design.
Your task is to convert natural language process descriptions into BPMN JSON representations.

{BPMN_REPRESENTATION_PROMPT}

{BPMN_EXAMPLES_PROMPT}

---

IMPORTANT RULES:
1. Always start with a startEvent and end with an endEvent
2. Use the most specific task type possible
3. Task labels should be clear and concise (2-4 words)
4. Each task must be atomic - one unit of work
5. Use gateways appropriately for conditional/parallel flows
6. Output ONLY valid JSON, no additional text

Now generate a BPMN JSON representation for the given process description."""

    def generate(self, process_description: str, max_retries: int = 4) -> dict:
        messages = [
            {"role": "system", "content": self.system_prompt},
            {
                "role": "user",
                "content": f"Process description:\n{process_description}\n\nGenerate the BPMN JSON representation:",
            },
        ]

        last_error: Optional[Exception] = None

        for attempt in range(max_retries):
            try:
                content = self._call_llm(messages)

                messages.append({"role": "assistant", "content": content})

                bpmn_workflow = self._parse_json(content)
                if not bpmn_workflow or "process" not in bpmn_workflow:
                    raise BPMNValidationError(
                        "Invalid BPMN structure: response is not valid JSON or missing 'process' key."
                    )


                validate_bpmn(bpmn_workflow["process"])

                self.last_conversation = messages
                print(f"[BPMNGenerator] ✓ Generated & validated workflow "
                      f"with {self._count_tasks(bpmn_workflow)} tasks (attempt {attempt + 1})")
                return bpmn_workflow

            except (BPMNValidationError, ValueError, Exception) as e:
                last_error = e
                print(f"[BPMNGenerator] Attempt {attempt + 1} failed: {e}")

                messages.append(
                    {
                        "role": "user",
                        "content": f"Error: {str(e)}. Fix the JSON and try again. "
                                    f"Output ONLY the corrected JSON.",
                    }
                )

        print(f"[BPMNGenerator] → Max retries reached ({last_error}). Using fallback template.")
        self.last_conversation = messages
        return self._generate_fallback(process_description)

    def _call_llm(self, messages: List[dict]) -> str:
        response = requests.post(
            f"{self.base_url}/chat/completions",
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": "deepseek-chat",
                "messages": messages,
                "max_tokens": 2500,
                "temperature": 0.3,
            },
            timeout=60,
        )
        if response.status_code != 200:
            raise Exception(f"API error: {response.status_code} - {response.text}")
        result = response.json()
        return result["choices"][0]["message"]["content"]

    def to_bpmn_xml(
        self,
        bpmn_workflow: dict,
        process_id: str = "Process_1",
        api_bindings: Optional[dict] = None,
    ) -> str:
        process = bpmn_workflow["process"]

        validate_bpmn(process)
        return self.xml_generator.create_bpmn_xml(process, process_id=process_id, api_bindings=api_bindings)

    def _parse_json(self, content: str) -> Optional[dict]:

        json_pattern = r'```(?:json)?\s*(.*?)\s*```'
        matches = re.findall(json_pattern, content, re.DOTALL)

        if matches:
            try:
                return json.loads(matches[0])
            except json.JSONDecodeError:
                pass


        try:
            start = content.find('{')
            end = content.rfind('}') + 1
            if start != -1 and end > start:
                return json.loads(content[start:end])
        except json.JSONDecodeError:
            pass

        return None

    def _count_tasks(self, workflow: dict) -> int:
        return len(self.extract_tasks(workflow))

    def extract_tasks(self, workflow: dict) -> List[dict]:
        tasks = []
        self._extract_tasks_recursive(workflow.get("process", []), tasks)
        return tasks

    def _extract_tasks_recursive(self, elements: list, tasks: list):
        task_types = {"task", "userTask", "serviceTask", "sendTask",
                      "receiveTask", "businessRuleTask", "manualTask", "scriptTask"}

        for elem in elements:
            elem_type = elem.get("type", "")

            if elem_type in task_types:
                tasks.append({
                    "id": elem.get("id", f"task_{len(tasks)+1}"),
                    "name": elem.get("label", "Unknown Task"),
                    "type": elem_type,
                    "description": elem.get("label", "")
                })


            if "branches" in elem:
                for branch in elem["branches"]:
                    if isinstance(branch, list):
                        self._extract_tasks_recursive(branch, tasks)
                    elif isinstance(branch, dict) and "path" in branch:
                        self._extract_tasks_recursive(branch["path"], tasks)

    def _generate_fallback(self, process_description: str) -> dict:

        keywords = {
            "send": "sendTask", "receive": "receiveTask", "check": "userTask",
            "validate": "scriptTask", "review": "userTask", "approve": "userTask",
            "process": "serviceTask", "calculate": "serviceTask", "store": "serviceTask",
            "notify": "sendTask", "wait": "receiveTask", "decide": "businessRuleTask",
            "fill": "manualTask", "write": "manualTask", "prepare": "manualTask"
        }

        tasks = []
        words = process_description.lower().split()
        task_id = 1

        for i, word in enumerate(words):
            for keyword, task_type in keywords.items():
                if keyword in word:

                    task_words = []
                    for j in range(i, min(i+5, len(words))):
                        if words[j] not in ['the', 'a', 'an', 'is', 'are', 'will', 'be', 'to', 'and', 'or']:
                            task_words.append(words[j].capitalize())
                            if len(task_words) >= 4:
                                break

                    task_name = ' '.join(task_words) if task_words else f"Task {task_id}"

                    if task_name not in [t['label'] for t in tasks]:
                        tasks.append({
                            "type": task_type,
                            "id": f"task{task_id}",
                            "label": task_name
                        })
                        task_id += 1
                    break

        if not tasks:
            tasks = [
                {"type": "userTask", "id": "task1", "label": "Process Request"},
                {"type": "serviceTask", "id": "task2", "label": "Execute Action"},
                {"type": "userTask", "id": "task3", "label": "Complete Process"}
            ]

        return {
            "process": [
                {"type": "startEvent", "id": "start"}
            ] + tasks + [
                {"type": "endEvent", "id": "end"}
            ],
            "_fallback": True
        }


def create_bpmn_generator(api_key: str = None) -> BPMNGenerator:
    return BPMNGenerator(api_key=api_key)


if __name__ == "__main__":
    generator = BPMNGenerator()

    test_description = """
    If goods shall be shipped, the secretary clarifies who will do the shipping. 
    If you have large amounts, special shipping will be necessary. In these cases 
    the secretary invites three logistic companies to make offers and she selects 
    one of them. In case of small amounts, normal post shipment is used.
    """

    print("Testing BPMN Generator...")
    workflow = generator.generate(test_description)
    print(json.dumps(workflow, indent=2))

    tasks = generator.extract_tasks(workflow)
    print(f"\nExtracted {len(tasks)} tasks:")
    for task in tasks:
        print(f"  [{task['id']}] {task['name']} ({task['type']})")


    xml_string = generator.to_bpmn_xml(workflow)
    with open("test_output.bpmn", "w", encoding="utf-8") as f:
        f.write(xml_string)
    print("\n✓ 已导出 test_output.bpmn（可用 https://bpmn.io/ 或 Camunda Modeler 打开查看）")
