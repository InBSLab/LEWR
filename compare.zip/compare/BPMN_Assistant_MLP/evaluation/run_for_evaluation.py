# -*- coding: utf-8 -*-

import os
import sys
import json
import time
import traceback
import requests
import numpy as np
import torch
from pathlib import Path
from typing import List, Dict, Any, Optional
from collections import defaultdict

SCRIPT_DIR = Path(__file__).parent.absolute()
PROJECT_ROOT = SCRIPT_DIR.parent.parent  # evaluation_framework_complete/
EVAL_ROOT = SCRIPT_DIR.parent            # evaluation_framework_complete/evaluation/

POSSIBLE_MODEL_PATHS = [
    PROJECT_ROOT / "models" / "BPMN_MLP" / "BPMN_Assistant_MLP" / "BPMN_Assistant_MLP",
]


def find_model_root() -> Path:
    for path in POSSIBLE_MODEL_PATHS:
        checkpoint_path = path / "checkpoints" / "mlp_best.pth"
        if checkpoint_path.exists():
            print(f"  找到模型目录: {path}")
            return path
        data_path = path / "data" / "api_name.json"
        if data_path.exists():
            print(f"  找到数据目录: {path}")
            return path
    return POSSIBLE_MODEL_PATHS[0]


MODEL_ROOT = find_model_root()

sys.path.insert(0, str(EVAL_ROOT / "common"))
sys.path.insert(0, str(MODEL_ROOT))
sys.path.insert(0, str(SCRIPT_DIR))

from scenarios import BPMN_TEST_SCENARIOS, UnifiedOutput, save_results

from structural_validity import StructuralValidator, StructuralRepairer

from bpmn_generator import BPMNGenerator
from mlp_model import MLP, MLPConfig
from tools import TextDataset

from bpmn_validator import validate_bpmn, BPMNValidationError


class RobustBPMNGenerator(BPMNGenerator):

    def generate(self, process_description: str, max_retries: int = 3) -> dict:
        messages = [
            {"role": "system", "content": self.system_prompt},
            {
                "role": "user",
                "content": (
                    f"Process description:\n{process_description}\n\n"
                    f"Generate the BPMN JSON representation:"
                ),
            },
        ]

        for attempt in range(max_retries):
            try:
                print(f"    正在调用DeepSeek API... (尝试 {attempt + 1}/{max_retries})")
                response = requests.post(
                    f"{self.base_url}/chat/completions",
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "model": "deepseek-chat",
                        "messages": messages,
                        "max_tokens": 2500,
                        "temperature": 0.3,
                    },
                    timeout=180,
                )

                if response.status_code == 200:
                    content = response.json()["choices"][0]["message"]["content"]
                    messages.append({"role": "assistant", "content": content})

                    workflow = self._parse_json(content)
                    if not workflow or "process" not in workflow:
                        error_msg = (
                            "Invalid BPMN structure: response is not valid JSON "
                            "or missing 'process' key."
                        )
                        print(f"    ⚠ {error_msg}，准备重试")
                        messages.append({
                            "role": "user",
                            "content": f"Error: {error_msg}. Fix the JSON and try "
                                       f"again. Output ONLY the corrected JSON.",
                        })
                    else:
                        validate_bpmn(workflow["process"])
                        print(f"    ✓ 生成成功，共 {self._count_tasks(workflow)} 个任务")
                        self.last_conversation = messages
                        return workflow
                else:
                    print(f"    ⚠ HTTP {response.status_code}: {response.text[:200]}")

            except (BPMNValidationError, ValueError) as e:
                print(f"    ⚠ 结构校验失败 (尝试 {attempt + 1}/{max_retries}): {e}")
                messages.append({
                    "role": "user",
                    "content": f"Error: {str(e)}. Fix the JSON and try again. "
                               f"Output ONLY the corrected JSON.",
                })
            except requests.exceptions.Timeout:
                print(f"    ⚠ 请求超时 (尝试 {attempt + 1}/{max_retries})")
            except requests.exceptions.ConnectionError as e:
                print(f"    ⚠ 网络连接错误: {e}")
            except KeyboardInterrupt:
                raise
            except Exception as e:
                print(f"    ⚠ 生成失败: {e}")

            if attempt < max_retries - 1:
                wait = 10 if attempt == 0 else 15
                print(f"    等待{wait}秒后重试...")
                time.sleep(wait)

        print("  ✗ API调用失败，已达最大重试次数，使用回退模板")
        self.last_conversation = messages
        return self._generate_fallback(process_description)


TASK_TYPES = {
    "task", "userTask", "serviceTask", "sendTask",
    "receiveTask", "businessRuleTask", "manualTask", "scriptTask",
}
EVENT_TYPES = {"startEvent", "endEvent", "intermediateThrowEvent", "intermediateCatchEvent"}


def _add_edge(dependencies: list, frm: str, to: str, condition: Optional[str] = None):
    dependencies.append({"from": frm, "to": to, "condition": condition})


def flatten_workflow(elements: list, tasks: list, gateways: list,
                      dependencies: list, prev_ids: list,
                      incoming_condition: Optional[str] = None) -> list:
    current_prev = list(prev_ids)
    first = True

    for elem in elements:
        eid = elem.get("id") or f"elem_{len(tasks) + len(gateways)}"
        etype = elem.get("type", "")
        cond = incoming_condition if first else None

        if etype in TASK_TYPES:
            tasks.append({"id": eid, "name": elem.get("label", ""), "type": etype})
            for p in current_prev:
                _add_edge(dependencies, p, eid, cond)
            current_prev = [eid]

        elif etype in EVENT_TYPES:
            for p in current_prev:
                _add_edge(dependencies, p, eid, cond)
            current_prev = [eid]

        elif etype in ("exclusiveGateway", "inclusiveGateway"):
            gw_type = "exclusive" if etype == "exclusiveGateway" else "inclusive"
            gateways.append({"id": eid, "type": gw_type, "name": elem.get("label", "")})
            for p in current_prev:
                _add_edge(dependencies, p, eid, cond)

            branch_exits = []
            for branch in elem.get("branches", []):
                path = branch.get("path", [])
                b_cond = branch.get("condition")
                if path:
                    exits = flatten_workflow(path, tasks, gateways, dependencies,
                                              [eid], incoming_condition=b_cond)
                    branch_exits.extend(exits)
                else:
                    branch_exits.append(eid)
            current_prev = branch_exits if branch_exits else [eid]

        elif etype == "parallelGateway":
            gateways.append({"id": eid, "type": "parallel", "name": elem.get("label", "")})
            for p in current_prev:
                _add_edge(dependencies, p, eid, cond)

            branch_exits = []
            for branch in elem.get("branches", []):
                if branch:
                    exits = flatten_workflow(branch, tasks, gateways, dependencies, [eid])
                    branch_exits.extend(exits)
            current_prev = branch_exits if branch_exits else [eid]

        first = False

    return current_prev


class BPMNMLPSystem:

    def __init__(self, data_path: str = None, embedding_path: str = None,
                 model_path: str = None, api_key: str = None,
                 use_roberta: bool = True):

        print("\n" + "=" * 60)
        print("初始化 BPMN_Assistant + MLP (真实模型调用版)")
        print("=" * 60)

        self.data_path = Path(data_path) if data_path else MODEL_ROOT / "data"
        self.embedding_path = Path(embedding_path) if embedding_path else MODEL_ROOT / "embedding"

        # 1. BPMN Assistant
        print("\n[1/3] 初始化BPMN Assistant (BPMNGenerator)...")
        self.bpmn_generator = RobustBPMNGenerator(api_key=api_key)
        print("  ✓ BPMN Assistant 初始化完成")

        print("\n[2/3] 加载数据集 & 初始化MLP模型...")
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.mlp_ready = False
        self.ds = None
        self.model = None
        self.config = None
        self.use_roberta = use_roberta
        self.api_names: List[str] = []

        try:
            self.ds = TextDataset(str(self.data_path), str(self.embedding_path),
                                   use_roberta=use_roberta)
            self.use_roberta = self.ds.use_roberta
            self.api_names = self.ds.mashup_ds.api_names

            self.config = MLPConfig(self.ds)
            self.model = MLP(self.config).to(self.device)

            ckpt_path = Path(model_path) if model_path else MODEL_ROOT / "checkpoints" / "mlp_best.pth"
            if ckpt_path.exists():
                state_dict = torch.load(ckpt_path, map_location=self.device, weights_only=False)
                self.model.load_state_dict(state_dict)
                self.model.eval()
                self.mlp_ready = True
                print(f"  ✓ MLP模型已加载，将用于真实推理: {ckpt_path}")
            else:
                print(f"  ⚠ 未找到权重文件: {ckpt_path}")
                print("    MLP不会参与推理，将仅使用关键词匹配兜底")

        except Exception as e:
            print(f"  ⚠ 加载完整数据集/模型失败: {e}")
            print("    → 本次运行将退回关键词匹配，不会用到MLP权重")
            traceback.print_exc()
            if not self.api_names:
                self.api_names = self._load_api_names_fallback()

        print(f"  ✓ API数量: {len(self.api_names)}")
        print(f"  ✓ MLP是否真正参与推理: {self.mlp_ready}")

        print("\n[3/3] 构建API关键词索引...")
        self._build_api_index()

        print("\n" + "=" * 60)
        print("系统初始化完成!")
        print("=" * 60)

    def _load_api_names_fallback(self) -> List[str]:
        api_name_file = self.data_path / "api_name.json"
        if api_name_file.exists():
            with open(api_name_file, "r", encoding="utf-8") as f:
                return json.load(f)
        return []

    def _build_api_index(self):
        self.api_keywords: Dict[str, list] = {}
        for i, name in enumerate(self.api_names):
            words = name.lower().replace("-", " ").replace("_", " ").split()
            for word in words:
                if len(word) > 2:
                    self.api_keywords.setdefault(word, []).append(i)

    def recommend_api(self, task_text: str, top_k: int = 5) -> List[Dict]:
        if not self.api_names:
            return [{"api_name": "manual-task", "score": 0.5, "method": "fallback"}]

        if self.mlp_ready:
            try:
                return self._recommend_via_mlp(task_text, top_k)
            except Exception as e:
                print(f"    ⚠ MLP推理失败，本次退回关键词匹配: {e}")

        scores = self._keyword_match_score(task_text)
        top_indices = np.argsort(scores)[::-1][:top_k]
        return [
            {"api_name": self.api_names[idx], "score": float(scores[idx]), "method": "keyword_only"}
            for idx in top_indices
        ]

    def _recommend_via_mlp(self, task_text: str, top_k: int) -> List[Dict]:
        self.model.eval()

        if self.use_roberta:
            similar_indices, similarities = self.ds.mashup_ds.find_similar_mashups(task_text, top_n=5)
            features = np.zeros(self.config.embed_dim, dtype=np.float32)
            total_weight = sum(similarities) + 1e-8
            for idx, sim in zip(similar_indices, similarities):
                features += self.ds.mashup_ds.mashup_features[idx] * (sim + 0.1)
            features /= (total_weight + 0.5)
            features_t = torch.FloatTensor(features).unsqueeze(0).to(self.device)
        else:
            features_t = self.ds.mashup_ds.encode_text(task_text).to(self.device)

        with torch.no_grad():
            logits = self.model(features_t)
            mlp_scores = torch.sigmoid(logits).cpu().numpy()[0]

        name_scores = self._keyword_match_score(task_text)
        final_scores = 0.5 * mlp_scores + 0.5 * name_scores

        top_indices = np.argsort(final_scores)[::-1][:top_k]
        return [
            {
                "api_name": self.api_names[idx],
                "score": float(final_scores[idx]),
                "mlp_score": float(mlp_scores[idx]),
                "name_score": float(name_scores[idx]),
                "method": "mlp",
            }
            for idx in top_indices
        ]

    def _keyword_match_score(self, task_text: str) -> np.ndarray:
        scores = np.zeros(len(self.api_names), dtype=np.float32)
        task_lower = task_text.lower()

        domain_mapping = {
            "ship": ["shipping", "logistics", "delivery", "fedex", "ups", "dhl", "post"],
            "pay": ["payment", "stripe", "paypal", "checkout", "transaction"],
            "send": ["email", "sms", "notification", "twilio", "sendgrid", "message"],
            "search": ["search", "find", "google", "query", "lookup"],
            "map": ["map", "location", "geo", "address", "place"],
            "store": ["storage", "database", "s3", "firebase", "cloud"],
            "verify": ["verification", "auth", "identity", "validate"],
            "calculate": ["calculator", "compute", "math", "score"],
            "image": ["image", "photo", "picture", "visual"],
            "weather": ["weather", "forecast", "climate"],
            "insurance": ["insurance", "policy", "coverage"],
            "label": ["label", "print", "barcode"],
            "package": ["package", "parcel", "box"],
            "logistics": ["logistics", "freight", "carrier", "warehouse"],
            "select": ["compare", "choose", "selection"],
            "offer": ["quote", "price", "bid", "offer"],
            "recourse": ["complaint", "refund", "return", "dispute", "customer", "service"],
            "order": ["order", "purchase", "buy", "cart"],
        }

        task_keywords = set()
        for word in task_lower.split():
            word = word.strip(".,!?;:")
            if len(word) > 2:
                task_keywords.add(word)
                for key, synonyms in domain_mapping.items():
                    if word == key or word in synonyms:
                        task_keywords.add(key)
                        task_keywords.update(synonyms)

        for i, api_name in enumerate(self.api_names):
            api_lower = api_name.lower()
            score = sum(1 for kw in task_keywords if kw in api_lower)
            scores[i] = score

        if scores.max() > 0:
            scores = scores / scores.max()

        return scores

    def run(self, user_request: str, scenario_name: str) -> Dict[str, Any]:
        print(f"\n{'='*60}")
        print(f"BPMN_MLP 处理场景: {scenario_name}")
        print(f"{'='*60}")

        start_time = time.time()

        print("\n[Stage 1] BPMN Assistant - 生成工作流结构")
        print("-" * 50)
        bpmn_workflow = self.bpmn_generator.generate(user_request)

        formatted_tasks: List[dict] = []
        gateways: List[dict] = []
        dependencies: List[dict] = []
        flatten_workflow(bpmn_workflow.get("process", []),
                          formatted_tasks, gateways, dependencies, prev_ids=[])

        print(f"  ✓ 任务数: {len(formatted_tasks)}")
        print(f"  ✓ 网关数: {len(gateways)}")
        print(f"  ✓ 依赖数: {len(dependencies)}")
        for task in formatted_tasks[:5]:
            print(f"    [{task['id']}] {task['name'][:50]} ({task['type']})")
        if len(formatted_tasks) > 5:
            print(f"    ... 还有 {len(formatted_tasks) - 5} 个任务")

        print("\n[Stage 2] MLP - API推荐 (每节点Top-5)")
        print("-" * 50)

        api_bindings = {}
        for task in formatted_tasks:
            task_id = task["id"]
            task_name = task["name"]

            recommendations = self.recommend_api(task_name, top_k=5)
            if recommendations:
                top_apis = [
                    {
                        "rank": idx + 1,
                        "api_name": rec["api_name"],
                        "confidence": rec["score"],
                        "method": rec.get("method", "unknown"),
                    }
                    for idx, rec in enumerate(recommendations)
                ]
                api_bindings[task_id] = {
                    "task_name": task_name,
                    "api_name": top_apis[0]["api_name"],
                    "confidence": top_apis[0]["confidence"],
                    "method": top_apis[0]["method"],
                    "top_5_apis": top_apis,
                }
                print(f"  [{task_id}] {task_name[:45]}")
                for rec in top_apis:
                    print(f"      #{rec['rank']} → {rec['api_name']:<35} ({rec['confidence']:.3f})")

        execution_time = time.time() - start_time

        # -------------------------------------------------------------- #
        # -------------------------------------------------------------- #
        print("\n[Stage 3] 结构有效性校验 + 通用结构修复（与 LEWR 同一套流程）")
        print("-" * 50)

        validator = StructuralValidator()
        repairer = StructuralRepairer()

        raw_validity = validator.validate(formatted_tasks, dependencies, gateways)
        print(f"  RAW      is_valid={raw_validity['is_valid']}  "
              f"connectivity={raw_validity['connectivity']}  "
              f"start_end={raw_validity['start_end_validity']}  "
              f"gateway_ok={raw_validity['gateway_rationality']}  "
              f"path_coverage={raw_validity['path_coverage']:.0%}")
        if raw_validity["violations"]:
            for v in raw_validity["violations"]:
                print(f"    ⚠ [{v['type']}] {v.get('detail', v)}")

        repaired_tasks, repaired_deps, repaired_gateways, repair_log = repairer.repair(
            formatted_tasks, dependencies, gateways, max_attempts=3
        )
        repaired_validity = validator.validate(repaired_tasks, repaired_deps, repaired_gateways)
        print(f"  REPAIRED is_valid={repaired_validity['is_valid']}  "
              f"connectivity={repaired_validity['connectivity']}  "
              f"start_end={repaired_validity['start_end_validity']}  "
              f"gateway_ok={repaired_validity['gateway_rationality']}  "
              f"path_coverage={repaired_validity['path_coverage']:.0%}")
        if repair_log.get("unrepaired_issues"):
            print("  ⚠ 无法安全修复的问题（保留，计入错误分析）:")
            for v in repair_log["unrepaired_issues"]:
                print(f"    - [{v['type']}] {v.get('detail', v)}")

        shared_extra_info = {
            "workflow_generator": "BPMN Assistant (bpmn_generator.BPMNGenerator)",
            "api_recommender": "MLP (mlp_model.MLP)" if self.mlp_ready else "keyword_only (MLP权重未加载)",
            "mlp_trained": self.mlp_ready,
            "process_name": bpmn_workflow.get("process_name", ""),
            "is_fallback_workflow": bpmn_workflow.get("_fallback", False),
            "structural_validation_procedure": "shared_structural_validity.py (method-agnostic, identical to LEWR)",
        }

        raw_output = UnifiedOutput(
            method="BPMN_MLP",
            scenario_name=scenario_name,
            user_request=user_request,
            tasks=formatted_tasks,
            dependencies=dependencies,
            gateways=gateways,
            api_bindings=api_bindings,
            roles=[],
            execution_time=execution_time,
            extra_info={
                **shared_extra_info,
                "output_variant": "raw",
                "structural_validity": raw_validity,
            },
        )

        repaired_output = UnifiedOutput(
            method="BPMN_MLP",
            scenario_name=scenario_name,
            user_request=user_request,
            tasks=repaired_tasks,
            dependencies=repaired_deps,
            gateways=repaired_gateways,
            api_bindings=api_bindings,
            roles=[],
            execution_time=execution_time,
            extra_info={
                **shared_extra_info,
                "output_variant": "repaired",
                "structural_validity": repaired_validity,
                "repair_log": repair_log,
            },
        )

        return {
            "raw": raw_output,
            "repaired": repaired_output,
            "structural_analysis": {
                "scenario_name": scenario_name,
                "raw_validity": raw_validity,
                "repaired_validity": repaired_validity,
                "repair_log": repair_log,
            },
        }


def _aggregate_structural_error_analysis(structural_analyses: List[Dict]) -> Dict[str, Any]:
    n = len(structural_analyses)
    raw_valid_count = sum(1 for s in structural_analyses if s["raw_validity"]["is_valid"])
    repaired_valid_count = sum(1 for s in structural_analyses if s["repaired_validity"]["is_valid"])

    violation_type_counts: Dict[str, int] = defaultdict(int)
    violation_type_scenarios: Dict[str, List[str]] = defaultdict(list)
    gateway_issue_counts: Dict[str, int] = defaultdict(int)

    for s in structural_analyses:
        seen_types_this_scenario = set()
        for v in s["raw_validity"]["violations"]:
            vtype = v["type"]
            violation_type_counts[vtype] += 1
            if vtype not in seen_types_this_scenario:
                violation_type_scenarios[vtype].append(s["scenario_name"])
                seen_types_this_scenario.add(vtype)
            if vtype == "gateway_rationality":
                gateway_issue_counts[v.get("issue", "unknown")] += 1

    root_cause_notes = {
        "connectivity": ("部分任务节点未被 BPMNGenerator 生成的 process 结构连接进主流程，"
                          "成为孤立节点（例如 fallback 模板生成、或 LLM 输出的分支未闭合）。"),
        "start_end_validity": ("生成的依赖图存在多个入度为0或多个出度为0的节点，"
                                "说明生成的流程结构未收敛到单一起止点。"),
        "gateway_rationality": ("flatten_workflow() 会把 exclusiveGateway/parallelGateway/"
                                 "inclusiveGateway 的 id 真正写入 dependencies 边（与 "
                                 "ProMoAI_NCF baseline 的网关\"仅标注、未接入图\"不同），"
                                 "因此这里的网关问题多为 insufficient_branching_degree —— "
                                 "即某个网关在 LLM 生成的 JSON 里只给出了1条分支/汇合路径，"
                                 "语义上退化成了普通节点。具体以下方 "
                                 "gateway_issue_breakdown_raw 的实际统计为准。"),
        "path_coverage": ("由于连通性/起止点问题，部分节点无法从起点经有向边到达，"
                           "与 connectivity / start_end_validity 问题同源。"),
    }

    return {
        "num_scenarios": n,
        "raw_structural_validity_rate": (raw_valid_count / n) if n else None,
        "repaired_structural_validity_rate": (repaired_valid_count / n) if n else None,
        "violation_type_counts_raw": dict(violation_type_counts),
        "violation_type_scenarios_raw": dict(violation_type_scenarios),
        "gateway_issue_breakdown_raw": dict(gateway_issue_counts),
        "root_cause_notes": root_cause_notes,
    }


def main():
    print("\n")
    print("╔" + "═" * 58 + "╗")
    print("║" + " " * 4 + "BPMN_Assistant + MLP 评估运行脚本 (真实模型调用版)" + " " * 2 + "║")
    print("║" + " " * 6 + "两阶段方法: LLM工作流 + 真正的MLP推荐" + " " * 8 + "║")
    print("║" + " " * 6 + "+ 与 LEWR 共享的结构校验/修复流程 (回应 Comment #5)" + " " * 2 + "║")
    print("╚" + "═" * 58 + "╝")

    data_path = SCRIPT_DIR / "data"
    embedding_path = SCRIPT_DIR / "embedding"

    if not data_path.exists():
        data_path = MODEL_ROOT / "data"
    if not embedding_path.exists():
        embedding_path = MODEL_ROOT / "embedding"

    system = BPMNMLPSystem(data_path=str(data_path), embedding_path=str(embedding_path))

    print("\n" + "=" * 60)
    print("开始评估测试场景")
    print("=" * 60)

    raw_results: List[UnifiedOutput] = []
    repaired_results: List[UnifiedOutput] = []
    structural_analyses: List[Dict] = []

    for i, scenario in enumerate(BPMN_TEST_SCENARIOS):
        print(f"\n>>> 场景 [{i+1}/{len(BPMN_TEST_SCENARIOS)}]: {scenario.name}")
        try:
            outcome = system.run(scenario.requirement, scenario.name)
            raw_result = outcome["raw"]
            repaired_result = outcome["repaired"]
            raw_results.append(raw_result)
            repaired_results.append(repaired_result)
            structural_analyses.append(outcome["structural_analysis"])

            print("\n结果摘要 (repaired，用于主表对比):")
            print(f"  - 任务数: {len(repaired_result.tasks)}")
            print(f"  - 依赖数: {len(repaired_result.dependencies)}")
            print(f"  - 网关数: {len(repaired_result.gateways)}")
            print(f"  - API绑定数: {len(repaired_result.api_bindings)}")
            print(f"  - 执行时间: {repaired_result.execution_time:.2f}s")
            print(f"  - raw is_valid={outcome['structural_analysis']['raw_validity']['is_valid']}  "
                  f"repaired is_valid={outcome['structural_analysis']['repaired_validity']['is_valid']}")
        except KeyboardInterrupt:
            print(f"\n  ⚠ 用户中断，跳过场景 {scenario.name}")
            print("    (再次按Ctrl+C退出整个程序)")
            try:
                time.sleep(2)
            except KeyboardInterrupt:
                print("\n程序被用户终止")
                break
            continue
        except Exception as e:
            print(f"  ✗ 场景 {scenario.name} 处理失败: {e}")
            traceback.print_exc()
            continue

    output_dir = EVAL_ROOT / "results"

    save_results(repaired_results, str(output_dir), "bpmn_mlp")
    save_results(raw_results, str(output_dir), "bpmn_mlp_raw")

    error_analysis = _aggregate_structural_error_analysis(structural_analyses)
    output_dir.mkdir(parents=True, exist_ok=True)
    error_analysis_path = output_dir / "bpmn_mlp_structural_error_analysis.json"
    with open(error_analysis_path, "w", encoding="utf-8") as f:
        json.dump(
            {"per_scenario": structural_analyses, "summary": error_analysis},
            f, ensure_ascii=False, indent=2
        )

    print("\n" + "=" * 60)
    print("结构有效性汇总（详细错误分析，回应 Comment #5）")
    print("=" * 60)
    print(f"  raw      结构有效率: {error_analysis['raw_structural_validity_rate']:.0%}"
          if error_analysis["raw_structural_validity_rate"] is not None else "  raw 无数据")
    print(f"  repaired 结构有效率: {error_analysis['repaired_structural_validity_rate']:.0%}"
          if error_analysis["repaired_structural_validity_rate"] is not None else "  repaired 无数据")
    print(f"  raw 违规类型分布: {error_analysis['violation_type_counts_raw']}")
    print(f"  网关问题细分: {error_analysis['gateway_issue_breakdown_raw']}")
    print(f"  → 完整分析已保存至: {error_analysis_path}")

    print("\n" + "=" * 60)
    print("BPMN_MLP 评估完成!")
    print("=" * 60)


if __name__ == "__main__":
    main()
