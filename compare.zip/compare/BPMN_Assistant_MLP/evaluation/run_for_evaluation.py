import os
import sys
import json
import time
import traceback
import requests
import numpy as np
import torch
from pathlib import Path
from typing import List, Dict, Any, Optional


SCRIPT_DIR = Path(__file__).parent.absolute()
PROJECT_ROOT = SCRIPT_DIR.parent.parent
EVAL_ROOT = SCRIPT_DIR.parent

POSSIBLE_MODEL_PATHS = [
    PROJECT_ROOT / "models" / "BPMN_MLP" / "BPMN_Assistant_MLP" / "BPMN_Assistant_MLP",
]


def find_model_root() -> Path:
    """查找模型根目录（需要包含 bpmn_generator.py / mlp_model.py / tools/）"""
    for path in POSSIBLE_MODEL_PATHS:
        checkpoint_path = path / "checkpoints" / "mlp_best.pth"
        if checkpoint_path.exists():
            print(f"  找到模型目录: {path}")
            return path
        data_path = path / "data" / "api_name.json"
        if data_path.exists():
            print(f"  找到数据目录: {path}")
            return path
    return POSSIBLE_MODEL_PATHS[0]


MODEL_ROOT = find_model_root()

sys.path.insert(0, str(EVAL_ROOT / "common"))
sys.path.insert(0, str(MODEL_ROOT))

from scenarios import BPMN_TEST_SCENARIOS, UnifiedOutput, save_results

from bpmn_generator import BPMNGenerator
from mlp_model import MLP, MLPConfig
from tools import TextDataset


class RobustBPMNGenerator(BPMNGenerator):
    """
    完全复用 BPMNGenerator 的 system_prompt / JSON schema / fallback模板 /
    extract_tasks，只重写 generate() 增加更长超时、更细致的重试逻辑。
    """

    def generate(self, process_description: str, max_retries: int = 3) -> dict:
        user_prompt = (
            f"Process description:\n{process_description}\n\n"
            f"Generate the BPMN JSON representation:"
        )

        for attempt in range(max_retries):
            try:
                print(f"    正在调用DeepSeek API... (尝试 {attempt + 1}/{max_retries})")
                response = requests.post(
                    f"{self.base_url}/chat/completions",
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "model": "deepseek-chat",
                        "messages": [
                            {"role": "system", "content": self.system_prompt},
                            {"role": "user", "content": user_prompt},
                        ],
                        "max_tokens": 2500,
                        "temperature": 0.3,
                    },
                    timeout=180,
                )
                if response.status_code == 200:
                    content = response.json()["choices"][0]["message"]["content"]
                    workflow = self._parse_json(content)
                    if workflow and "process" in workflow:
                        self._validate_workflow(workflow)
                        print(f"    ✓ 生成成功，共 {self._count_tasks(workflow)} 个任务")
                        return workflow
                    print("    ⚠ 返回内容缺少 'process' 字段，准备重试")
                else:
                    print(f"    ⚠ HTTP {response.status_code}: {response.text[:200]}")

            except requests.exceptions.Timeout:
                print(f"    ⚠ 请求超时 (尝试 {attempt + 1}/{max_retries})")
            except requests.exceptions.ConnectionError as e:
                print(f"    ⚠ 网络连接错误: {e}")
            except KeyboardInterrupt:
                raise
            except Exception as e:
                print(f"    ⚠ 生成失败: {e}")

            if attempt < max_retries - 1:
                wait = 10 if attempt == 0 else 15
                print(f"    等待{wait}秒后重试...")
                time.sleep(wait)

        print("  ✗ API调用失败，已达最大重试次数，使用回退模板")
        return self._generate_fallback(process_description)


TASK_TYPES = {
    "task", "userTask", "serviceTask", "sendTask",
    "receiveTask", "businessRuleTask", "manualTask", "scriptTask",
}
EVENT_TYPES = {"startEvent", "endEvent", "intermediateThrowEvent", "intermediateCatchEvent"}


def _add_edge(dependencies: list, frm: str, to: str, condition: Optional[str] = None):
    dependencies.append({"from": frm, "to": to, "condition": condition})


def flatten_workflow(elements: list, tasks: list, gateways: list,
                      dependencies: list, prev_ids: list,
                      incoming_condition: Optional[str] = None) -> list:
    """
    递归遍历 BPMNGenerator 生成的 process 数组 (含 exclusive/parallel/inclusive
    gateway 的嵌套分支)，把它展平成 tasks / gateways / dependencies。
    返回值: 这一段元素执行完之后的"出口" id 列表，供上一层继续连接后续节点。
    """
    current_prev = list(prev_ids)
    first = True

    for elem in elements:
        eid = elem.get("id") or f"elem_{len(tasks) + len(gateways)}"
        etype = elem.get("type", "")
        cond = incoming_condition if first else None

        if etype in TASK_TYPES:
            tasks.append({"id": eid, "name": elem.get("label", ""), "type": etype})
            for p in current_prev:
                _add_edge(dependencies, p, eid, cond)
            current_prev = [eid]

        elif etype in EVENT_TYPES:
            for p in current_prev:
                _add_edge(dependencies, p, eid, cond)
            current_prev = [eid]

        elif etype in ("exclusiveGateway", "inclusiveGateway"):
            gw_type = "exclusive" if etype == "exclusiveGateway" else "inclusive"
            gateways.append({"id": eid, "type": gw_type, "name": elem.get("label", "")})
            for p in current_prev:
                _add_edge(dependencies, p, eid, cond)

            branch_exits = []
            for branch in elem.get("branches", []):
                path = branch.get("path", [])
                b_cond = branch.get("condition")
                if path:
                    exits = flatten_workflow(path, tasks, gateways, dependencies,
                                              [eid], incoming_condition=b_cond)
                    branch_exits.extend(exits)
                else:
                    branch_exits.append(eid)
            current_prev = branch_exits if branch_exits else [eid]

        elif etype == "parallelGateway":
            gateways.append({"id": eid, "type": "parallel", "name": elem.get("label", "")})
            for p in current_prev:
                _add_edge(dependencies, p, eid, cond)

            branch_exits = []
            for branch in elem.get("branches", []):
                if branch:
                    exits = flatten_workflow(branch, tasks, gateways, dependencies, [eid])
                    branch_exits.extend(exits)
            current_prev = branch_exits if branch_exits else [eid]

        first = False

    return current_prev


class BPMNMLPSystem:
    """
    BPMN Assistant + MLP 两阶段系统

    阶段1: RobustBPMNGenerator (继承官方 BPMNGenerator) 生成 BPMN 工作流
    阶段2: 官方 MLP 网络对每个任务节点做 Top-5 API 推荐
    """

    def __init__(self, data_path: str = None, embedding_path: str = None,
                 model_path: str = None, api_key: str = None,
                 use_roberta: bool = True):

        print("\n" + "=" * 60)
        print("初始化 BPMN_Assistant + MLP (真实模型调用版)")
        print("=" * 60)

        self.data_path = Path(data_path) if data_path else MODEL_ROOT / "data"
        self.embedding_path = Path(embedding_path) if embedding_path else MODEL_ROOT / "embedding"

        print("\n[1/3] 初始化BPMN Assistant (BPMNGenerator)...")
        self.bpmn_generator = RobustBPMNGenerator(api_key=api_key)
        print("  ✓ BPMN Assistant 初始化完成")

        print("\n[2/3] 加载数据集 & 初始化MLP模型...")
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.mlp_ready = False
        self.ds = None
        self.model = None
        self.config = None
        self.use_roberta = use_roberta
        self.api_names: List[str] = []

        try:
            self.ds = TextDataset(str(self.data_path), str(self.embedding_path),
                                   use_roberta=use_roberta)
            self.use_roberta = self.ds.use_roberta
            self.api_names = self.ds.mashup_ds.api_names

            self.config = MLPConfig(self.ds)
            self.model = MLP(self.config).to(self.device)

            ckpt_path = Path(model_path) if model_path else MODEL_ROOT / "checkpoints" / "mlp_best.pth"
            if ckpt_path.exists():
                state_dict = torch.load(ckpt_path, map_location=self.device, weights_only=False)
                self.model.load_state_dict(state_dict)
                self.model.eval()
                self.mlp_ready = True
                print(f"  ✓ MLP模型已加载，将用于真实推理: {ckpt_path}")
            else:
                print(f"  ⚠ 未找到权重文件: {ckpt_path}")
                print("    MLP不会参与推理，将仅使用关键词匹配兜底")

        except Exception as e:
            print(f"  ⚠ 加载完整数据集/模型失败: {e}")
            print("    → 本次运行将退回关键词匹配，不会用到MLP权重")
            traceback.print_exc()
            if not self.api_names:
                self.api_names = self._load_api_names_fallback()

        print(f"  ✓ API数量: {len(self.api_names)}")
        print(f"  ✓ MLP是否真正参与推理: {self.mlp_ready}")

        print("\n[3/3] 构建API关键词索引...")
        self._build_api_index()

        print("\n" + "=" * 60)
        print("系统初始化完成!")
        print("=" * 60)

    def _load_api_names_fallback(self) -> List[str]:
        api_name_file = self.data_path / "api_name.json"
        if api_name_file.exists():
            with open(api_name_file, "r", encoding="utf-8") as f:
                return json.load(f)
        return []

    def _build_api_index(self):
        self.api_keywords: Dict[str, list] = {}
        for i, name in enumerate(self.api_names):
            words = name.lower().replace("-", " ").replace("_", " ").split()
            for word in words:
                if len(word) > 2:
                    self.api_keywords.setdefault(word, []).append(i)

    def recommend_api(self, task_text: str, top_k: int = 5) -> List[Dict]:
        if not self.api_names:
            return [{"api_name": "manual-task", "score": 0.5, "method": "fallback"}]

        if self.mlp_ready:
            try:
                return self._recommend_via_mlp(task_text, top_k)
            except Exception as e:
                print(f"    ⚠ MLP推理失败，本次退回关键词匹配: {e}")

        scores = self._keyword_match_score(task_text)
        top_indices = np.argsort(scores)[::-1][:top_k]
        return [
            {"api_name": self.api_names[idx], "score": float(scores[idx]), "method": "keyword_only"}
            for idx in top_indices
        ]

    def _recommend_via_mlp(self, task_text: str, top_k: int) -> List[Dict]:
        """真正跑一次 MLP 前向推理，与官方 bpmn_mlp/main.py 的 _recommend_apis 一致"""
        self.model.eval()

        if self.use_roberta:
            similar_indices, similarities = self.ds.mashup_ds.find_similar_mashups(task_text, top_n=5)
            features = np.zeros(self.config.embed_dim, dtype=np.float32)
            total_weight = sum(similarities) + 1e-8
            for idx, sim in zip(similar_indices, similarities):
                features += self.ds.mashup_ds.mashup_features[idx] * (sim + 0.1)
            features /= (total_weight + 0.5)
            features_t = torch.FloatTensor(features).unsqueeze(0).to(self.device)
        else:
            features_t = self.ds.mashup_ds.encode_text(task_text).to(self.device)

        with torch.no_grad():
            logits = self.model(features_t)
            mlp_scores = torch.sigmoid(logits).cpu().numpy()[0]

        name_scores = self._keyword_match_score(task_text)
        final_scores = 0.5 * mlp_scores + 0.5 * name_scores

        top_indices = np.argsort(final_scores)[::-1][:top_k]
        return [
            {
                "api_name": self.api_names[idx],
                "score": float(final_scores[idx]),
                "mlp_score": float(mlp_scores[idx]),
                "name_score": float(name_scores[idx]),
                "method": "mlp",
            }
            for idx in top_indices
        ]

    def _keyword_match_score(self, task_text: str) -> np.ndarray:
        """关键词打分：MLP可用时作为融合项之一，MLP不可用时作为唯一兜底方案"""
        scores = np.zeros(len(self.api_names), dtype=np.float32)
        task_lower = task_text.lower()

        domain_mapping = {
            "ship": ["shipping", "logistics", "delivery", "fedex", "ups", "dhl", "post"],
            "pay": ["payment", "stripe", "paypal", "checkout", "transaction"],
            "send": ["email", "sms", "notification", "twilio", "sendgrid", "message"],
            "search": ["search", "find", "google", "query", "lookup"],
            "map": ["map", "location", "geo", "address", "place"],
            "store": ["storage", "database", "s3", "firebase", "cloud"],
            "verify": ["verification", "auth", "identity", "validate"],
            "calculate": ["calculator", "compute", "math", "score"],
            "image": ["image", "photo", "picture", "visual"],
            "weather": ["weather", "forecast", "climate"],
            "insurance": ["insurance", "policy", "coverage"],
            "label": ["label", "print", "barcode"],
            "package": ["package", "parcel", "box"],
            "logistics": ["logistics", "freight", "carrier", "warehouse"],
            "select": ["compare", "choose", "selection"],
            "offer": ["quote", "price", "bid", "offer"],
            "recourse": ["complaint", "refund", "return", "dispute", "customer", "service"],
            "order": ["order", "purchase", "buy", "cart"],
        }

        task_keywords = set()
        for word in task_lower.split():
            word = word.strip(".,!?;:")
            if len(word) > 2:
                task_keywords.add(word)
                for key, synonyms in domain_mapping.items():
                    if word == key or word in synonyms:
                        task_keywords.add(key)
                        task_keywords.update(synonyms)

        for i, api_name in enumerate(self.api_names):
            api_lower = api_name.lower()
            score = sum(1 for kw in task_keywords if kw in api_lower)
            scores[i] = score

        if scores.max() > 0:
            scores = scores / scores.max()

        return scores

    def run(self, user_request: str, scenario_name: str) -> UnifiedOutput:
        print(f"\n{'='*60}")
        print(f"BPMN_MLP 处理场景: {scenario_name}")
        print(f"{'='*60}")

        start_time = time.time()

        print("\n[Stage 1] BPMN Assistant - 生成工作流结构")
        print("-" * 50)
        bpmn_workflow = self.bpmn_generator.generate(user_request)

        formatted_tasks: List[dict] = []
        gateways: List[dict] = []
        dependencies: List[dict] = []
        flatten_workflow(bpmn_workflow.get("process", []),
                          formatted_tasks, gateways, dependencies, prev_ids=[])

        print(f"  ✓ 任务数: {len(formatted_tasks)}")
        print(f"  ✓ 网关数: {len(gateways)}")
        print(f"  ✓ 依赖数: {len(dependencies)}")
        for task in formatted_tasks[:5]:
            print(f"    [{task['id']}] {task['name'][:50]} ({task['type']})")
        if len(formatted_tasks) > 5:
            print(f"    ... 还有 {len(formatted_tasks) - 5} 个任务")

        print("\n[Stage 2] MLP - API推荐 (每节点Top-5)")
        print("-" * 50)

        api_bindings = {}
        for task in formatted_tasks:
            task_id = task["id"]
            task_name = task["name"]

            recommendations = self.recommend_api(task_name, top_k=5)
            if recommendations:
                top_apis = [
                    {
                        "rank": idx + 1,
                        "api_name": rec["api_name"],
                        "confidence": rec["score"],
                        "method": rec.get("method", "unknown"),
                    }
                    for idx, rec in enumerate(recommendations)
                ]
                api_bindings[task_id] = {
                    "task_name": task_name,
                    "api_name": top_apis[0]["api_name"],
                    "confidence": top_apis[0]["confidence"],
                    "method": top_apis[0]["method"],
                    "top_5_apis": top_apis,
                }
                print(f"  [{task_id}] {task_name[:45]}")
                for rec in top_apis:
                    print(f"      #{rec['rank']} → {rec['api_name']:<35} ({rec['confidence']:.3f})")

        execution_time = time.time() - start_time

        return UnifiedOutput(
            method="BPMN_MLP",
            scenario_name=scenario_name,
            user_request=user_request,
            tasks=formatted_tasks,
            dependencies=dependencies,
            gateways=gateways,
            api_bindings=api_bindings,
            roles=[],
            execution_time=execution_time,
            extra_info={
                "workflow_generator": "BPMN Assistant (bpmn_generator.BPMNGenerator)",
                "api_recommender": "MLP (mlp_model.MLP)" if self.mlp_ready else "keyword_only (MLP权重未加载)",
                "mlp_trained": self.mlp_ready,
                "process_name": bpmn_workflow.get("process_name", ""),
                "is_fallback_workflow": bpmn_workflow.get("_fallback", False),
            },
        )


def main():
    print("\n")
    print("╔" + "═" * 58 + "╗")
    print("║" + " " * 4 + "BPMN_Assistant + MLP 评估运行脚本 (真实模型调用版)" + " " * 2 + "║")
    print("║" + " " * 6 + "两阶段方法: LLM工作流 + 真正的MLP推荐" + " " * 8 + "║")
    print("╚" + "═" * 58 + "╝")

    data_path = SCRIPT_DIR / "data"
    embedding_path = SCRIPT_DIR / "embedding"

    if not data_path.exists():
        data_path = MODEL_ROOT / "data"
    if not embedding_path.exists():
        embedding_path = MODEL_ROOT / "embedding"

    system = BPMNMLPSystem(data_path=str(data_path), embedding_path=str(embedding_path))

    print("\n" + "=" * 60)
    print("开始评估测试场景")
    print("=" * 60)

    results = []
    for i, scenario in enumerate(BPMN_TEST_SCENARIOS):
        print(f"\n>>> 场景 [{i+1}/{len(BPMN_TEST_SCENARIOS)}]: {scenario.name}")
        try:
            result = system.run(scenario.requirement, scenario.name)
            results.append(result)

            print("\n结果摘要:")
            print(f"  - 任务数: {len(result.tasks)}")
            print(f"  - 依赖数: {len(result.dependencies)}")
            print(f"  - 网关数: {len(result.gateways)}")
            print(f"  - API绑定数: {len(result.api_bindings)}")
            print(f"  - 执行时间: {result.execution_time:.2f}s")
        except KeyboardInterrupt:
            print(f"\n  ⚠ 用户中断，跳过场景 {scenario.name}")
            print("    (再次按Ctrl+C退出整个程序)")
            try:
                time.sleep(2)
            except KeyboardInterrupt:
                print("\n程序被用户终止")
                break
            continue
        except Exception as e:
            print(f"  ✗ 场景 {scenario.name} 处理失败: {e}")
            traceback.print_exc()
            continue

    output_dir = EVAL_ROOT / "results"
    save_results(results, str(output_dir), "bpmn_mlp")

    print("\n" + "=" * 60)
    print("BPMN_MLP 评估完成!")
    print("=" * 60)


if __name__ == "__main__":
    main()
