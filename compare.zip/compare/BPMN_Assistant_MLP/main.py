

import os
import sys
import json
import time
import numpy as np
import torch
from pathlib import Path


PROJECT_ROOT = Path(__file__).parent.absolute()
sys.path.insert(0, str(PROJECT_ROOT))


from bpmn_generator import BPMNGenerator
from mlp_model import MLP, MLPConfig
from tools import TextDataset, get_indices, get_time


class BPMNAssistantMLPSystem:

    def __init__(self,
                 data_path: str = None,
                 embedding_path: str = None,
                 model_path: str = None,
                 use_roberta: bool = True,
                 api_key: str = None):
        print("=" * 70)
        print("BPMN Assistant + MLP 整合系统")
        print("=" * 70)
        print("  - BPMN生成: BPMN Assistant (arXiv:2509.24592)")
        print("  - API推荐: MLP (原始实现)")
        print("=" * 70)


        self.data_path = Path(data_path) if data_path else PROJECT_ROOT / "data"
        self.embedding_path = Path(embedding_path) if embedding_path else PROJECT_ROOT / "embedding"


        print("\n[1/4] 加载ProgrammableWeb数据集...")
        self.ds = TextDataset(
            str(self.data_path),
            str(self.embedding_path),
            use_roberta=use_roberta
        )
        self.use_roberta = self.ds.use_roberta


        print(f"\n[2/4] 创建MLP模型 (use_roberta={self.use_roberta})...")
        self.config = MLPConfig(self.ds)
        self.model = MLP(self.config)
        self.model.to(self.config.device)


        if model_path is None:
            model_path = PROJECT_ROOT / "checkpoints" / "mlp_best.pth"

        self.model_path = Path(model_path)
        if self.model_path.exists():
            self.model.load_state_dict(torch.load(model_path, map_location=self.config.device))
            self.is_trained = True
            print(f"  ✓ 已加载模型: {model_path}")
        else:
            self.is_trained = False
            print(f"  ⚠ 模型未训练，请先运行 train.py")

        self.model.eval()


        print("\n[3/4] 初始化BPMN生成器 (BPMN Assistant)...")
        self.bpmn_generator = BPMNGenerator(api_key=api_key)


        with open(self.data_path / "api_name.json", 'r', encoding='utf-8') as f:
            self.api_names = json.load(f)


        print("\n[4/4] 构建API索引...")
        self._build_api_index()

        print("\n" + "=" * 70)
        print("系统初始化完成!")
        print(f"  - APIs数量: {len(self.api_names)}")
        print(f"  - Mashups数量: {self.ds.num_mashup}")
        print(f"  - Categories数量: {self.ds.num_category}")
        print(f"  - 特征模式: {'RoBERTa (768维)' if self.use_roberta else 'Word Embedding'}")
        print(f"  - 模型状态: {'已训练 ✓' if self.is_trained else '未训练 ✗'}")
        print("=" * 70)

    def _build_api_index(self):
        self.api_keywords = {}
        for i, name in enumerate(self.api_names):
            words = name.lower().replace('-', ' ').replace('_', ' ').split()
            for word in words:
                if len(word) > 2:
                    if word not in self.api_keywords:
                        self.api_keywords[word] = []
                    self.api_keywords[word].append(i)

    def process(self, user_request: str, use_llm: bool = True) -> dict:
        result = {
            "user_request": user_request,
            "method": "BPMN_Assistant + MLP",
            "bpmn_generator": "BPMN Assistant (arXiv:2509.24592)",
            "api_recommender": f"MLP ({'RoBERTa' if self.use_roberta else 'Word Embedding'})",
            "bpmn_workflow": None,
            "tasks": [],
            "api_bindings": {}
        }


        print("\n" + "-" * 50)
        print("[Step 1] BPMN工作流生成 (BPMN Assistant)")
        print("-" * 50)

        start_time = time.time()

        if use_llm:
            try:
                bpmn_workflow = self.bpmn_generator.generate(user_request)
            except Exception as e:
                print(f"  ⚠ LLM生成失败: {e}")
                bpmn_workflow = self.bpmn_generator._generate_fallback(user_request)
        else:
            bpmn_workflow = self.bpmn_generator._generate_fallback(user_request)

        result["bpmn_workflow"] = bpmn_workflow
        print(f"  ✓ 工作流生成完成 ({time.time() - start_time:.2f}s)")


        print("\n[Step 2] 提取任务列表")
        print("-" * 50)

        tasks = self.bpmn_generator.extract_tasks(bpmn_workflow)
        result["tasks"] = tasks
        print(f"  ✓ 提取到 {len(tasks)} 个任务:")
        for task in tasks:
            print(f"      [{task['id']}] {task['name']} ({task['type']})")


        print("\n[Step 3] MLP API推荐")
        print("-" * 50)

        api_bindings = {}

        for task in tasks:
            task_id = task["id"]
            task_name = task["name"]


            recommendations = self._recommend_apis(task_name, top_k=5)

            if recommendations:
                top_api = recommendations[0]
                api_bindings[task_id] = {
                    "task_name": task_name,
                    "task_type": task.get("type", "userTask"),
                    "recommended_api": top_api["api_name"],
                    "confidence": round(top_api["score"], 4),
                    "top_5_candidates": [
                        {"api": r["api_name"], "score": round(r["score"], 4)}
                        for r in recommendations
                    ]
                }
                print(f"  [{task_id}] {task_name}")
                print(f"      → {top_api['api_name']} (score: {top_api['score']:.4f})")

        result["api_bindings"] = api_bindings


        print("\n[Step 4] 导出BPMN 2.0 XML（含API绑定）")
        print("-" * 50)
        try:
            bpmn_xml = self.bpmn_generator.to_bpmn_xml(
                bpmn_workflow, api_bindings=api_bindings
            )
            result["bpmn_xml"] = bpmn_xml
            print("  ✓ BPMN XML生成完成，可用 bpmn.io / Camunda Modeler 打开查看")
        except Exception as e:
            print(f"  ⚠ BPMN XML生成失败: {e}")
            result["bpmn_xml"] = None

        return result

    def _recommend_apis(self, task_text: str, top_k: int = 5) -> list:
        self.model.eval()

        if self.use_roberta:

            similar_indices, similarities = self.ds.mashup_ds.find_similar_mashups(task_text, top_n=5)


            features = np.zeros(768, dtype=np.float32)
            total_weight = sum(similarities) + 1e-8

            for idx, sim in zip(similar_indices, similarities):
                features += self.ds.mashup_ds.mashup_features[idx] * (sim + 0.1)
            features /= (total_weight + 0.5)

            features = torch.FloatTensor(features).unsqueeze(0).to(self.config.device)
        else:

            features = self.ds.mashup_ds.encode_text(task_text).to(self.config.device)


        with torch.no_grad():
            logits = self.model(features)
            scores = torch.sigmoid(logits).cpu().numpy()[0]


        name_scores = self._compute_api_name_relevance(task_text)


        final_scores = 0.5 * scores + 0.5 * name_scores


        top_indices = np.argsort(final_scores)[::-1][:top_k]

        recommendations = []
        for idx in top_indices:
            recommendations.append({
                "api_name": self.api_names[idx],
                "score": float(final_scores[idx]),
                "mlp_score": float(scores[idx]),
                "name_score": float(name_scores[idx])
            })

        return recommendations

    def _compute_api_name_relevance(self, text: str) -> np.ndarray:
        text_lower = text.lower()
        scores = np.zeros(len(self.api_names), dtype=np.float32)


        task_api_mapping = {
            'send': ['mail', 'email', 'message', 'sms', 'notification', 'push'],
            'receive': ['mail', 'email', 'message', 'notification', 'webhook'],
            'ship': ['shipping', 'logistics', 'delivery', 'post', 'carrier', 'freight'],
            'pay': ['payment', 'checkout', 'billing', 'transaction', 'stripe', 'paypal'],
            'search': ['search', 'find', 'lookup', 'query', 'browse'],
            'store': ['storage', 'database', 'save', 'cloud', 'backup'],
            'track': ['tracking', 'trace', 'monitor', 'status'],
            'map': ['maps', 'location', 'geo', 'address', 'geocode'],
            'weather': ['weather', 'forecast', 'climate', 'temperature'],
            'social': ['facebook', 'twitter', 'linkedin', 'instagram', 'social'],
            'photo': ['image', 'photo', 'picture', 'gallery', 'flickr'],
            'video': ['video', 'youtube', 'vimeo', 'stream'],
            'music': ['music', 'audio', 'spotify', 'soundcloud'],
            'translate': ['translation', 'translate', 'language'],
            'analyze': ['analytics', 'analysis', 'insight', 'statistics'],
        }


        text_words = set(text_lower.replace('-', ' ').replace('_', ' ').split())
        relevant_terms = set()

        for word in text_words:
            if word in task_api_mapping:
                relevant_terms.update(task_api_mapping[word])

            for keyword, terms in task_api_mapping.items():
                if keyword in word or word in keyword:
                    relevant_terms.update(terms)


        for i, api_name in enumerate(self.api_names):
            api_lower = api_name.lower().replace('-', ' ').replace('_', ' ')
            api_words = set(api_lower.split())


            for term in relevant_terms:
                if term in api_lower:
                    scores[i] += 0.3
                if term in api_words:
                    scores[i] += 0.2


            for word in text_words:
                if len(word) > 3:
                    if word in api_lower:
                        scores[i] += 0.4


            for word in text_words:
                if word in self.api_keywords and i in self.api_keywords[word]:
                    scores[i] += 0.2


        if scores.max() > 0:
            scores = scores / scores.max()

        return scores

    def save_result(self, result: dict, output_path: str = None, bpmn_output_path: str = None):
        if output_path is None:
            output_path = PROJECT_ROOT / "output.json"


        result_to_dump = dict(result)
        bpmn_xml = result_to_dump.pop("bpmn_xml", None)

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(result_to_dump, f, indent=2, ensure_ascii=False)
        print(f"\n✓ 结果已保存: {output_path}")

        if bpmn_xml:
            if bpmn_output_path is None:
                bpmn_output_path = PROJECT_ROOT / "output.bpmn"
            with open(bpmn_output_path, 'w', encoding='utf-8') as f:
                f.write(bpmn_xml)
            print(f"✓ BPMN文件已保存: {bpmn_output_path} (可用 bpmn.io / Camunda Modeler 打开，"
                  f"每个task节点的 extensionElements 里含MLP推荐的API绑定)")

    def print_result(self, result: dict):
        print("\n" + "=" * 70)
        print("处理结果")
        print("=" * 70)

        print(f"\n【用户需求】\n{result['user_request'][:200]}...")

        print(f"\n【方法】")
        print(f"  - BPMN生成: {result['bpmn_generator']}")
        print(f"  - API推荐: {result['api_recommender']}")

        print(f"\n【任务列表】({len(result['tasks'])} 个)")
        for task in result["tasks"]:
            print(f"  [{task['id']}] {task['name']} ({task['type']})")

        print(f"\n【API绑定】")
        for task_id, binding in result["api_bindings"].items():
            print(f"  [{task_id}] {binding['task_name']}")
            print(f"      → API: {binding['recommended_api']}")
            print(f"      → 置信度: {binding['confidence']}")


def demo():

    system = BPMNAssistantMLPSystem()


    test_request = """
    If goods shall be shipped, the secretary clarifies who will do the shipping. 
    If you have large amounts, special shipping will be necessary. In these cases 
    the secretary invites three logistic companies to make offers and she selects 
    one of them. In case of small amounts, normal post shipment is used. 
    Therefore a package label is written by the secretary and a parcel insurance 
    taken by the logistics department head if necessary. In the meantime the goods 
    can be already packaged by the warehousemen. If everything is ready, the 
    packaged goods are prepared for being picked up by the logistic company.
    """

    print("\n" + "=" * 70)
    print("演示: 处理物流发货流程")
    print("=" * 70)

    result = system.process(test_request, use_llm=True)
    system.print_result(result)
    system.save_result(result)


if __name__ == "__main__":
    demo()
