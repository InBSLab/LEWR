# BPMN Assistant + MLP

A two-stage baseline system for turning a natural-language process description into a BPMN workflow and recommending an API for every task node:

1. **BPMN Assistant** (`bpmn_generator.py`) — prompts an LLM (DeepSeek `deepseek-chat` by default) to produce a structured BPMN JSON representation (tasks, events, exclusive/parallel/inclusive gateways), validates it (`bpmn_validator.py`), and can export it to standard BPMN 2.0 XML (`bpmn_xml_generator.py`) that opens directly in [bpmn.io](https://bpmn.io/) or Camunda Modeler.
2. **MLP API recommender** (`mlp_model.py`, `tools/`) — a 3-layer fully-connected network (`embed_dim → 128 → 64 → num_api`) that, given a task's text, recommends the Top-K most relevant APIs from a ProgrammableWeb-style mashup/API dataset, using either RoBERTa features or a trained word-embedding lookup.

## Repository layout

```
BPMN_Assistant_MLP/
├── main.py                    # end-to-end demo: description -> BPMN + API bindings -> .bpmn/.json
├── train.py                   # trains the MLP recommender, saves checkpoints/mlp_best.pth
├── bpmn_generator.py          # BPMN Assistant: prompt design, LLM call, JSON parsing/retry, fallback template
├── bpmn_validator.py          # structural validation of generated BPMN JSON (raises BPMNValidationError)
├── bpmn_xml_generator.py      # BPMN JSON -> BPMN 2.0 XML, with API bindings written into extensionElements
├── mlp_model.py                # MLP / MLPConfig / MLPTrainer
├── tools/
│   └── __init__.py            # MashupDataset / TextDataset, train/val/test split, metrics, early stopping
├── evaluation/
│   └── run_for_evaluation.py  # evaluation harness entry point (see "Evaluation harness" below)
└── requirements.txt
```

## Setup

```bash
pip install -r requirements.txt
export DEEPSEEK_API_KEY="your-deepseek-key"   # required — see note below
```

`BPMNGenerator` no longer ships with any default key baked in; you must supply one via the `DEEPSEEK_API_KEY` environment variable or the `api_key=` constructor argument, or it raises `ValueError` at construction time.


## Data requirements

`tools/TextDataset` expects (paths default to `data/` and `embedding/` next to the script that instantiates it, or pass `data_path=`/`embedding_path=` explicitly):

- `data/` (required):
  - `api_name.json`
  - `mashup_name.json`
  - `mashup_description.json`
  - `mashup_used_api.json`
  - `mashup_category.json`
  - `category_list.json`
- `embedding/` (optional, only used when `use_roberta=True`):
  - `mashup_features_roberta.npy` — shape `[num_mashup, 768]`
  - `api_features_roberta.npy` — shape `[num_api, 768]` (optional)

If the RoBERTa feature files are missing, `TextDataset` automatically falls back to a trainable word-embedding mode.

None of this trained checkpoint, ships in this repository — bring your own dataset and either train your own weights or supply a pre-trained `checkpoints/mlp_best.pth`.

## Usage

Train the MLP recommender:
```bash
python train.py
```
Saves the best checkpoint to `checkpoints/mlp_best.pth` (early stopping, patience 7).

Run the end-to-end demo:
```bash
python main.py
```
Generates a BPMN workflow for a sample logistics process description, recommends APIs for each task, and writes both a `.json` result and a `.bpmn` (BPMN 2.0 XML) file with the recommended APIs embedded in each task's `extensionElements`.


## License

No license file is included yet — add one (MIT/Apache-2.0/etc.) before publishing if you intend this to be reused by others.
