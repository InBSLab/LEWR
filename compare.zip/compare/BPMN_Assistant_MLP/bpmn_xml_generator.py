

import xml.etree.ElementTree as ET
from typing import Optional


class BpmnProcessTransformer:

    def transform(self, process: list, parent_next_element_id: Optional[str] = None) -> dict:
        elements: list = []
        flows: list = []

        def add_flow(source_ref, target_ref, flow_id=None, condition=None):
            for flow in flows:
                if flow["sourceRef"] == source_ref and flow["targetRef"] == target_ref:
                    return
            flow_id = flow_id or f"{source_ref}-{target_ref}"
            flows.append(
                {"id": flow_id, "sourceRef": source_ref, "targetRef": target_ref, "condition": condition}
            )

        def handle_exclusive_or_inclusive_gateway(element: dict, gateway_type: str,
                                                    next_element_id: Optional[str]) -> Optional[str]:
            join_gateway_id = None
            default_flow_id = None
            if element.get("has_join", False):
                join_gateway_id = f"{element['id']}-join"
                elements.append({"id": join_gateway_id, "type": gateway_type, "label": None})

            for branch in element["branches"]:
                is_default = branch.get("is_default", False)

                if not branch.get("path"):
                    target_ref = branch.get("next", next_element_id)
                    if target_ref:
                        flow_id = f"{element['id']}-{target_ref}"
                        add_flow(element["id"], target_ref, flow_id=flow_id, condition=branch.get("condition"))
                        if is_default:
                            default_flow_id = flow_id
                    continue

                branch_next = branch.get("next")
                if branch_next:
                    branch_structure = self.transform(branch["path"], branch_next)
                else:
                    branch_structure = self.transform(branch["path"], join_gateway_id or next_element_id)

                elements.extend(branch_structure["elements"])
                flows.extend(branch_structure["flows"])

                first_element = branch_structure["elements"][0] if branch_structure["elements"] else None
                if first_element:
                    flow_id = f"{element['id']}-{first_element['id']}"
                    add_flow(element["id"], first_element["id"], flow_id=flow_id, condition=branch.get("condition"))
                    if is_default:
                        default_flow_id = flow_id

            if default_flow_id:
                for elem in elements:
                    if elem["id"] == element["id"]:
                        elem["default_flow"] = default_flow_id
                        break

            return join_gateway_id

        def handle_parallel_gateway(element: dict) -> str:
            join_gateway_id = f"{element['id']}-join"
            elements.append({"id": join_gateway_id, "type": "parallelGateway", "label": None})

            for branch in element["branches"]:
                branch_structure = self.transform(branch, join_gateway_id)
                if not branch_structure["elements"]:
                    raise ValueError(
                        f"Parallel gateway '{element['id']}' cannot have an empty branch."
                    )
                elements.extend(branch_structure["elements"])
                flows.extend(branch_structure["flows"])

                first_element = branch_structure["elements"][0]
                add_flow(element["id"], first_element["id"])

                last_element = branch_structure["elements"][-1]
                add_flow(last_element["id"], join_gateway_id)

            return join_gateway_id

        for index, element in enumerate(process):
            next_element_id = (
                process[index + 1]["id"] if index < len(process) - 1 else parent_next_element_id
            )

            transformed_element = {
                "id": element["id"],
                "type": element["type"],
                "label": element.get("label"),
            }
            if "eventDefinition" in element:
                transformed_element["eventDefinition"] = element["eventDefinition"]
            elements.append(transformed_element)

            if element["type"] == "exclusiveGateway":
                join_id = handle_exclusive_or_inclusive_gateway(element, "exclusiveGateway", next_element_id)
                if join_id and next_element_id:
                    add_flow(join_id, next_element_id)
            elif element["type"] == "inclusiveGateway":
                join_id = handle_exclusive_or_inclusive_gateway(element, "inclusiveGateway", next_element_id)
                if join_id and next_element_id:
                    add_flow(join_id, next_element_id)
            elif element["type"] == "parallelGateway":
                join_id = handle_parallel_gateway(element)
                if next_element_id:
                    add_flow(join_id, next_element_id)
            elif next_element_id and element["type"] != "endEvent":
                add_flow(element["id"], next_element_id)

        for element in elements:
            element["incoming"] = [f["id"] for f in flows if f["targetRef"] == element["id"]]
            element["outgoing"] = [f["id"] for f in flows if f["sourceRef"] == element["id"]]

        return {"elements": elements, "flows": flows}


_ELEMENT_SIZE = {

    "task_like": (100, 80),
    "gateway": (50, 50),
    "event": (36, 36),
}

_COL_GAP = 150
_ROW_GAP = 120
_START_X = 150
_START_Y = 150


def _element_size(elem_type: str):
    if elem_type in ("exclusiveGateway", "inclusiveGateway", "parallelGateway"):
        return _ELEMENT_SIZE["gateway"]
    if elem_type in ("startEvent", "endEvent", "intermediateThrowEvent", "intermediateCatchEvent"):
        return _ELEMENT_SIZE["event"]
    return _ELEMENT_SIZE["task_like"]


def _compute_layout(elements: list, flows: list) -> dict:
    outgoing = {}
    incoming_count = {e["id"]: 0 for e in elements}
    for f in flows:
        outgoing.setdefault(f["sourceRef"], []).append(f["targetRef"])
        if f["targetRef"] in incoming_count:
            incoming_count[f["targetRef"]] += 1

    column = {e["id"]: 0 for e in elements}
    order = [e["id"] for e in elements]


    for _ in range(len(elements) + 1):
        changed = False
        for eid in order:
            for target in outgoing.get(eid, []):
                if target in column and column[target] < column[eid] + 1:
                    column[target] = column[eid] + 1
                    changed = True
        if not changed:
            break

    rows_used = {}
    position = {}
    for eid in order:
        col = column[eid]
        row = rows_used.get(col, 0)
        rows_used[col] = row + 1
        position[eid] = (col, row)

    coords = {}
    for e in elements:
        col, row = position[e["id"]]
        w, h = _element_size(e["type"])
        x = _START_X + col * _COL_GAP
        y = _START_Y + row * _ROW_GAP
        coords[e["id"]] = {"x": x, "y": y, "width": w, "height": h}

    return coords


class BpmnXmlGenerator:

    def __init__(self):
        self.transformer = BpmnProcessTransformer()

    def create_bpmn_xml(
        self,
        process: list,
        process_id: str = "Process_1",
        api_bindings: Optional[dict] = None,
    ) -> str:
        transformed = self.transformer.transform(process)
        elements = transformed["elements"]
        flows = transformed["flows"]
        coords = _compute_layout(elements, flows)

        ns = {
            "bpmn": "http://www.omg.org/spec/BPMN/20100524/MODEL",
            "bpmndi": "http://www.omg.org/spec/BPMN/20100524/DI",
            "dc": "http://www.omg.org/spec/DD/20100524/DC",
            "di": "http://www.omg.org/spec/DD/20100524/DI",
            "custom": "http://bpmn-assistant-mlp/api-binding",
        }

        root = ET.Element("bpmn:definitions")
        root.set("xmlns:bpmn", ns["bpmn"])
        root.set("xmlns:bpmndi", ns["bpmndi"])
        root.set("xmlns:dc", ns["dc"])
        root.set("xmlns:di", ns["di"])
        root.set("xmlns:custom", ns["custom"])
        root.set("id", "definitions_1")
        root.set("targetNamespace", "http://bpmn-assistant-mlp")

        process_el = ET.SubElement(root, "bpmn:process")
        process_el.set("id", process_id)
        process_el.set("isExecutable", "false")

        api_bindings = api_bindings or {}

        for element in elements:
            elem = ET.SubElement(process_el, f"bpmn:{element['type']}")
            elem.set("id", element["id"])
            if element["label"]:
                elem.set("name", element["label"])
            if element.get("default_flow"):
                elem.set("default", element["default_flow"])

            for incoming in element["incoming"]:
                ET.SubElement(elem, "bpmn:incoming").text = incoming
            for outgoing in element["outgoing"]:
                ET.SubElement(elem, "bpmn:outgoing").text = outgoing

            if element.get("eventDefinition"):
                event_def_el = ET.SubElement(elem, f"bpmn:{element['eventDefinition']}")
                event_def_el.set("id", f"{element['eventDefinition']}_{element['id']}")

            binding = api_bindings.get(element["id"])
            if binding:
                ext = ET.SubElement(elem, "bpmn:extensionElements")
                api_el = ET.SubElement(ext, "custom:apiBinding")
                api_el.set("recommendedApi", str(binding.get("recommended_api", "")))
                api_el.set("confidence", str(binding.get("confidence", "")))
                candidates = binding.get("top_5_candidates") or []
                for cand in candidates:
                    cand_el = ET.SubElement(api_el, "custom:candidate")
                    cand_el.set("api", str(cand.get("api", "")))
                    cand_el.set("score", str(cand.get("score", "")))

        for flow in flows:
            seq_flow = ET.SubElement(process_el, "bpmn:sequenceFlow")
            seq_flow.set("id", flow["id"])
            seq_flow.set("sourceRef", flow["sourceRef"])
            seq_flow.set("targetRef", flow["targetRef"])
            if flow["condition"]:
                seq_flow.set("name", flow["condition"])


        diagram = ET.SubElement(root, "bpmndi:BPMNDiagram")
        diagram.set("id", "BPMNDiagram_1")
        plane = ET.SubElement(diagram, "bpmndi:BPMNPlane")
        plane.set("id", "BPMNPlane_1")
        plane.set("bpmnElement", process_id)

        for element in elements:
            c = coords[element["id"]]
            shape = ET.SubElement(plane, "bpmndi:BPMNShape")
            shape.set("id", f"{element['id']}_di")
            shape.set("bpmnElement", element["id"])
            bounds = ET.SubElement(shape, "dc:Bounds")
            bounds.set("x", str(c["x"]))
            bounds.set("y", str(c["y"]))
            bounds.set("width", str(c["width"]))
            bounds.set("height", str(c["height"]))

        for flow in flows:
            src = coords.get(flow["sourceRef"])
            tgt = coords.get(flow["targetRef"])
            if not src or not tgt:
                continue
            edge = ET.SubElement(plane, "bpmndi:BPMNEdge")
            edge.set("id", f"{flow['id']}_di")
            edge.set("bpmnElement", flow["id"])
            for point in (
                (src["x"] + src["width"], src["y"] + src["height"] // 2),
                (tgt["x"], tgt["y"] + tgt["height"] // 2),
            ):
                wp = ET.SubElement(edge, "di:waypoint")
                wp.set("x", str(point[0]))
                wp.set("y", str(point[1]))

        return '<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(root, encoding="unicode")
