import os
import re
import json
import numpy as np
import torch
import torch.nn as nn
import requests
from datetime import datetime

DEEPSEEK_API_KEY = os.environ.get("DEEPSEEK_API_KEY", "")
DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

BPMN_FORMAT = """
<process>
  <activity role='' action='' objects='' id=''/>
  <exclusiveGateway id=''>
    <branch condition='' id=''>...</branch>
  </exclusiveGateway>
  <parallelGateway id=''>
    <branch id=''>...</branch>
  </parallelGateway>
</process>
"""

BPMN_EXAMPLE = """
<process>
  <activity role='sender' action='Prepare to send a package' objects='package' id='activity1'/>
  <exclusiveGateway id='exclusivegateway1'>
    <branch condition='select pick-up' id='branch1'>
      <parallelGateway id='parallelgateway1'>
        <branch id='branch2'>
          <activity role='Sender' action='Select pickup location' objects='package' id='activity2'/>
        </branch>
        <branch id='branch3'>
          <activity role='Company' action='Arrange a Courier' objects='' id='activity3'/>
        </branch>
      </parallelGateway>
    </branch>
    <branch condition='send by yourself' id='branch4'>
      <activity role='Sender' action='go to mailing point' objects='package' id='activity4'/>
    </branch>
  </exclusiveGateway>
</process>
"""


class DeepSeekLLM:
    def __init__(self):
        self.api_key = DEEPSEEK_API_KEY

    def chat(self, system: str, user: str) -> str:
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        data = {
            "model": "deepseek-chat",
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
            "max_tokens": 2500, "temperature": 0.7
        }
        response = requests.post(DEEPSEEK_API_URL, headers=headers, json=data, timeout=120)
        return response.json()["choices"][0]["message"]["content"]


class MAOGenerator:
    def __init__(self):
        self.llm = DeepSeekLLM()

    def generate(self, task: str) -> str:
        print("\n" + "="*60)
        print("MAO四阶段流程")
        print("="*60)

        print("\n[Phase 1/4] Generation...")
        process = self._generation(task)

        print("[Phase 2/4] Refinement...")
        process = self._refinement(task, process)

        print("[Phase 3/4] Reviewing...")
        for i in range(5):
            process, has_error = self._reviewing(task, process)
            if not has_error:
                print(f"  第{i+1}轮: 无错误")
                break

        print("[Phase 4/4] Modifying...")
        for i in range(3):
            errors = self._check_format(process)
            if not errors:
                break
            process = self._fix_format(task, process, errors)

        print("\n✓ MAO完成!")
        return process

    def _generation(self, task: str) -> str:
        system = "You are a Process Design Expert skilled in BPMN modeling."
        user = f"Task: {task}\n\nDesign a BPMN process. Format:\n{BPMN_FORMAT}\n\nExample:\n{BPMN_EXAMPLE}\n\nOutput only <process>...</process>."
        return self._extract(self.llm.chat(system, user))

    def _refinement(self, task: str, process: str) -> str:
        system = "You are a Process Design Expert."
        user = f"Task: {task}\n\nProcess:\n{process}\n\nExpand important activities. Output <process>...</process>."
        result = self._extract(self.llm.chat(system, user))
        return result if result else process

    def _reviewing(self, task: str, process: str) -> tuple:
        system = "You are a Process Reviewer."
        user = f"Task: {task}\n\nProcess:\n{process}\n\nCheck for errors. If none, say 'no error'."
        suggestion = self.llm.chat(system, user)
        if "no error" in suggestion.lower():
            return process, False
        system2 = "You are a Process Design Expert."
        user2 = f"Process:\n{process}\n\nFix: {suggestion}\n\nOutput <process>...</process>."
        result = self._extract(self.llm.chat(system2, user2))
        return (result if result else process), True

    def _check_format(self, process: str) -> list:
        errors = []
        for gw in ['exclusiveGateway', 'parallelGateway']:
            if len(re.findall(f'<{gw}[^>]*>', process)) != len(re.findall(f'</{gw}>', process)):
                errors.append(f"{gw}不匹配")
        return errors

    def _fix_format(self, task: str, process: str, errors: list) -> str:
        system = "You are a Process Design Expert."
        user = f"Process:\n{process}\n\nFix: {', '.join(errors)}\n\nOutput <process>...</process>."
        result = self._extract(self.llm.chat(system, user))
        return result if result else process

    def _extract(self, text: str) -> str:
        m = re.search(r'<process>.*?</process>', text, re.DOTALL)
        return m.group(0) if m else ""


class MTFMPPLite(nn.Module):


    def __init__(self, num_api, num_category, embed_dim=768, feature_dim=32,
                 api_tag_embed=None, dropout=0.2):
        super(MTFMPPLite, self).__init__()

        if api_tag_embed is not None:
            self.api_tag_embed = nn.Embedding.from_pretrained(api_tag_embed, freeze=True)
        else:
            self.api_tag_embed = nn.Embedding(num_api, num_category)

        self.api_tag_layer = nn.Sequential(
            nn.Linear(num_category, feature_dim),
            nn.Tanh()
        )

        self.mashup_encoder = nn.Sequential(
            nn.Linear(embed_dim, 256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, 128),
            nn.ReLU()
        )

        self.sc_output = nn.Linear(128, num_api)
        self.fic_input = nn.Sequential(nn.Linear(128, feature_dim), nn.Tanh())
        self.fusion_layer = nn.Linear(num_api * 2, num_api)
        self.api_output = nn.Linear(num_api, num_api)
        self.cat_output = nn.Linear(num_api, num_category)

        self.dropout = nn.Dropout(dropout)
        self.sigmoid = nn.Sigmoid()
        self.tanh = nn.Tanh()

    def forward(self, x):
        api_tag = self.api_tag_layer(self.api_tag_embed.weight).t()
        h = self.mashup_encoder(x)
        u_sc = self.sc_output(h)
        u_fic = self.tanh(torch.matmul(self.fic_input(h), api_tag))
        u = self.fusion_layer(torch.cat([u_sc, u_fic], dim=1))
        u = self.dropout(u)
        return self.sigmoid(self.api_output(u)), self.sigmoid(self.cat_output(u))


class MTFMPPRecommender:
    def __init__(self):
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.model = None
        self.api_names = []
        self.category_list = []
        self.mashup_features = None
        self.mashup_descriptions = []
        self._load()

    def _load(self):
        print("\n加载MTFM++...")

        config_file = os.path.join(BASE_DIR, "checkpoints", "mtfmpp_config.json")
        if os.path.exists(config_file):
            with open(config_file, 'r') as f:
                config = json.load(f)
            self.api_names = config.get('api_names', [])
            self.category_list = config.get('category_list', [])
            feature_dim = config.get('feature_dim', 32)
            print(f"  ✓ {len(self.api_names)} APIs, {len(self.category_list)} 类别")
        else:
            print("  ✗ 未找到配置，请先运行 train_mtfmpp.py")
            return

        tag_file = os.path.join(BASE_DIR, "checkpoints", "api_tag_embed.npy")
        api_tag_embed = None
        if os.path.exists(tag_file):
            api_tag_embed = torch.FloatTensor(np.load(tag_file))

        feat_file = os.path.join(BASE_DIR, "embedding", "mashup_features_roberta.npy")
        if os.path.exists(feat_file):
            self.mashup_features = np.load(feat_file)
            print(f"  ✓ Mashup特征: {self.mashup_features.shape}")

        desc_file = os.path.join(BASE_DIR, "data", "mashup_description.json")
        if os.path.exists(desc_file):
            with open(desc_file, 'r') as f:
                self.mashup_descriptions = json.load(f)

        model_file = os.path.join(BASE_DIR, "checkpoints", "mtfmpp_best.pth")
        if os.path.exists(model_file):
            try:
                self.model = MTFMPPLite(
                    num_api=len(self.api_names),
                    num_category=len(self.category_list),
                    embed_dim=768,
                    feature_dim=feature_dim,
                    api_tag_embed=api_tag_embed
                )
                self.model.load_state_dict(torch.load(model_file, map_location=self.device))
                self.model.to(self.device)
                self.model.eval()
                print(f"  ✓ 模型已加载")
            except Exception as e:
                print(f"  ✗ 加载失败: {e}")

    def _find_similar(self, query: str, top_n=10):
        """找相似Mashup（修复：处理词列表格式）"""
        if not self.mashup_descriptions:
            return np.array([]), np.array([])

        query_words = set(query.lower().replace('-', ' ').replace('_', ' ').split())

        scores = []
        for desc in self.mashup_descriptions:
            if isinstance(desc, list):
                desc_words = set(w.lower() for w in desc)
            else:
                desc_words = set(desc.lower().split())

            overlap = len(query_words & desc_words)
            scores.append(overlap / max(len(query_words), 1))

        scores = np.array(scores)
        top_idx = np.argsort(scores)[::-1][:top_n]
        top_scores = scores[top_idx]

        mask = top_scores > 0
        return top_idx[mask], top_scores[mask]

    def _text_relevance(self, query: str):
        """计算API名称文本相关性"""
        scores = np.zeros(len(self.api_names), dtype=np.float32)
        words = set(query.lower().replace('-', ' ').replace('_', ' ').split())

        mapping = {
            'ship': ['shipping', 'logistics', 'fedex', 'ups', 'delivery', 'freight', 'post'],
            'shipping': ['shipping', 'logistics', 'fedex', 'ups', 'delivery', 'freight'],
            'logistic': ['logistics', 'shipping', 'fedex', 'ups', 'delivery', 'freight'],
            'payment': ['payment', 'paypal', 'stripe', 'pay'],
            'map': ['google-maps', 'mapbox', 'mapping', 'location', 'geo'],
            'email': ['email', 'sendgrid', 'mailchimp', 'mail'],
            'send': ['sendgrid', 'email', 'mail', 'notification'],
            'social': ['facebook', 'twitter', 'linkedin'],
            'notify': ['notification', 'push', 'alert', 'twilio'],
            'document': ['document', 'pdf', 'file', 'storage'],
            'track': ['tracking', 'trace', 'monitor'],
            'deliver': ['delivery', 'shipping', 'logistics'],
            'company': ['company', 'business', 'enterprise'],
            'offer': ['offer', 'quote', 'pricing'],
            'select': ['select', 'choose', 'pick'],
            'package': ['package', 'parcel', 'shipping'],
            'post': ['postal', 'post', 'mail', 'usps'],
            'postal': ['postal', 'post', 'mail', 'usps'],
        }

        terms = set()
        for w in words:
            if w in mapping:
                terms.update(mapping[w])
            for key in mapping:
                if key in w or w in key:
                    terms.update(mapping[key])

        for i, api in enumerate(self.api_names):
            api_lower = api.lower().replace('-', ' ').replace('_', ' ')
            api_words = set(api_lower.split())

            for t in terms:
                if t in api_lower:
                    scores[i] += 0.5
                if t in api_words:
                    scores[i] += 0.3

            for w in words:
                if len(w) > 3 and w in api_lower:
                    scores[i] += 0.4

        if scores.max() > 0:
            scores /= scores.max()
        return scores

    def recommend(self, action: str, role: str = "", objects: str = "", top_k: int = 5):
        """推荐API"""
        if not self.api_names:
            return []

        query = f"{role} {action} {objects}"

        if self.model is not None and self.mashup_features is not None:
            try:
                idx, sims = self._find_similar(query)
                if len(idx) > 0:
                    features = np.average(self.mashup_features[idx], axis=0, weights=sims)
                else:
                    features = self.mashup_features.mean(axis=0)

                x = torch.FloatTensor(features).unsqueeze(0).to(self.device)
                with torch.no_grad():
                    api_scores, cat_scores = self.model(x)
                    api_scores = api_scores.cpu().numpy()[0]
                    cat_scores = cat_scores.cpu().numpy()[0]

                text_scores = self._text_relevance(query)
                combined = 0.6 * api_scores + 0.4 * text_scores

                top_cats = [self.category_list[i] for i in np.argsort(cat_scores)[::-1][:3]
                            if cat_scores[i] > 0.1]

                top_idx = np.argsort(combined)[::-1][:top_k]
                return [
                    {"api": self.api_names[i], "score": float(combined[i]),
                     "categories": top_cats, "method": "MTFM++"}
                    for i in top_idx if combined[i] > 0.01
                ]
            except Exception as e:
                print(f"  MTFM++推理失败: {e}")

        scores = self._text_relevance(query)
        top_idx = np.argsort(scores)[::-1][:top_k]
        return [{"api": self.api_names[i], "score": float(scores[i]), "method": "keyword"}
                for i in top_idx if scores[i] > 0]


class BPMNMAOMTFMPPSystem:
    def __init__(self):
        print("\n" + "="*60)
        print("BPMN + MAO + MTFM++ 系统")
        print("="*60)
        self.mao = MAOGenerator()
        self.mtfmpp = MTFMPPRecommender()

    def run(self, requirement: str) -> dict:
        print(f"\n需求: {requirement[:100]}...")

        bpmn = self.mao.generate(requirement)
        activities = self._extract_activities(bpmn)
        print(f"\n✓ {len(activities)} 个activity")

        print("\nAPI推荐:")
        bindings = []
        for act in activities:
            apis = self.mtfmpp.recommend(act['action'], act['role'], act['objects'])
            bindings.append({"activity_id": act['id'], "action": act['action'], "apis": apis})
            if apis:
                method = apis[0].get('method', 'MTFM++')
                print(f"  [{act['id']}] {act['action'][:30]}... → {apis[0]['api']} ({apis[0]['score']:.3f}, {method})")
            else:
                print(f"  [{act['id']}] {act['action'][:30]}... → 无匹配")

        result = {"requirement": requirement, "bpmn": bpmn, "bindings": bindings}

        out_file = os.path.join(BASE_DIR, f"result_mtfmpp_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        with open(out_file, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print(f"\n✓ 保存到: {out_file}")

        return result

    def _extract_activities(self, bpmn: str):
        pattern = r"<activity[^>]*role='([^']*)'[^>]*action='([^']*)'[^>]*objects='([^']*)'[^>]*id='([^']*)'"
        return [{"role": m[0], "action": m[1], "objects": m[2], "id": m[3]}
                for m in re.findall(pattern, bpmn)]


def main():
    system = BPMNMAOMTFMPPSystem()

    default = """If goods shall be shipped, the secretary clarifies who will do the shipping.
    If large amounts, special shipping is needed. The secretary invites logistic companies
    to make offers and selects one. For small amounts, normal post is used."""

    while True:
        req = input("\n请输入需求 (回车用默认, q退出): ").strip()
        if req.lower() in ['q', 'quit']:
            break
        if not req:
            req = default
        try:
            system.run(req)
        except Exception as e:
            print(f"错误: {e}")
            import traceback
            traceback.print_exc()


if __name__ == "__main__":
    main()
