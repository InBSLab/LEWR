# =========== Copyright 2023 @ CAMEL-AI.org. All Rights Reserved. ===========
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# =========== Copyright 2023 @ CAMEL-AI.org. All Rights Reserved. ===========
"""
Model Backend - 统一使用DeepSeek API
====================================
修改自原MAO的model_backend.py
将OpenAI API替换为DeepSeek API
"""

from abc import ABC, abstractmethod
from typing import Any, Dict
import os
import requests

from camel.typing import ModelType
from MAO.utils import log_and_print_online


# ==================== DeepSeek API 配置 ====================
DEEPSEEK_API_KEY = os.environ.get("DEEPSEEK_API_KEY", "")
DEEPSEEK_BASE_URL = "https://api.deepseek.com/v1"


class ModelBackend(ABC):
    r"""Base class for different model backends.
    May be OpenAI API, a local LLM, a stub for unit tests, etc."""

    @abstractmethod
    def run(self, *args, **kwargs) -> Dict[str, Any]:
        r"""Runs the query to the backend model.

        Raises:
            RuntimeError: if the return value from API
            is not a dict that is expected.

        Returns:
            Dict[str, Any]: All backends must return a dict in OpenAI format.
        """
        pass


class DeepSeekModel(ModelBackend):
    r"""DeepSeek API in a unified ModelBackend interface."""

    def __init__(self, model_type: ModelType, model_config_dict: Dict) -> None:
        super().__init__()
        self.model_type = model_type
        self.model_config_dict = model_config_dict
        self.api_key = DEEPSEEK_API_KEY
        self.base_url = DEEPSEEK_BASE_URL
        
        # DeepSeek模型映射
        self.model_mapping = {
            "gpt-3.5-turbo": "deepseek-chat",
            "gpt-3.5-turbo-16k": "deepseek-chat",
            "gpt-3.5-turbo-0613": "deepseek-chat",
            "gpt-3.5-turbo-16k-0613": "deepseek-chat",
            "gpt-4": "deepseek-chat",
            "gpt-4-0613": "deepseek-chat",
            "gpt-4-32k": "deepseek-chat",
        }

    def _estimate_tokens(self, text: str) -> int:
        """简单估算token数量"""
        # 粗略估计: 英文约4字符=1token, 中文约2字符=1token
        return len(text) // 3

    def run(self, *args, **kwargs) -> Dict[str, Any]:
        messages = kwargs.get("messages", [])
        
        # 计算prompt tokens
        string = "\n".join([message["content"] for message in messages])
        num_prompt_tokens = self._estimate_tokens(string)
        gap_between_send_receive = 15 * len(messages)
        num_prompt_tokens += gap_between_send_receive

        # DeepSeek最大token限制
        num_max_token = 8192
        num_max_completion_tokens = min(num_max_token - num_prompt_tokens, 4096)
        
        # 获取DeepSeek模型名称
        original_model = self.model_type.value if hasattr(self.model_type, 'value') else str(self.model_type)
        deepseek_model = self.model_mapping.get(original_model, "deepseek-chat")
        
        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": deepseek_model,
                    "messages": messages,
                    "max_tokens": num_max_completion_tokens,
                    "temperature": self.model_config_dict.get("temperature", 0.7),
                },
                timeout=120
            )
            
            if response.status_code == 200:
                result = response.json()
                
                # 记录使用信息
                usage = result.get("usage", {})
                log_and_print_online(
                    "**[DeepSeek_Usage_Info Receive]**\nprompt_tokens: {}\ncompletion_tokens: {}\ntotal_tokens: {}\n".format(
                        usage.get("prompt_tokens", 0), 
                        usage.get("completion_tokens", 0),
                        usage.get("total_tokens", 0)))
                
                return result
            else:
                raise RuntimeError(f"DeepSeek API error: {response.status_code} - {response.text}")
                
        except requests.exceptions.Timeout:
            raise RuntimeError("DeepSeek API timeout")
        except Exception as e:
            raise RuntimeError(f"DeepSeek API error: {str(e)}")


class StubModel(ModelBackend):
    r"""A dummy model used for unit tests."""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__()

    def run(self, *args, **kwargs) -> Dict[str, Any]:
        ARBITRARY_STRING = "Lorem Ipsum"

        return dict(
            id="stub_model_id",
            usage=dict(),
            choices=[
                dict(finish_reason="stop",
                     message=dict(content=ARBITRARY_STRING, role="assistant"))
            ],
        )


class ModelFactory:
    r"""Factory of backend models.

    Raises:
        ValueError: in case the provided model type is unknown.
    """

    @staticmethod
    def create(model_type: ModelType, model_config_dict: Dict) -> ModelBackend:
        default_model_type = ModelType.GPT_4
        
        if model_type in {
            ModelType.GPT_3_5_TURBO, ModelType.GPT_4, ModelType.GPT_4_32k,
            None
        }:
            # 使用DeepSeek替代OpenAI
            model_class = DeepSeekModel
        elif model_type == ModelType.STUB:
            model_class = StubModel
        else:
            raise ValueError("Unknown model")

        if model_type is None:
            model_type = default_model_type

        inst = model_class(model_type, model_config_dict)
        return inst
