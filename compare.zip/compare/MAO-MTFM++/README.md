# MAO-MTFM++

Given a natural-language process description, this system generates a **BPMN
workflow** with a multi-agent LLM pipeline and then recommends a Web API for
each activity in that workflow using an **MTFM++ / MLP** recommender.

- **Generation half — "MAO":** a multi-agent role-playing pipeline (built on
  CAMEL + ChatDev) turns the description into BPMN activities and structure.
- **Recommendation half — "MTFM++":** a two-task network (`MTFMPPLite`) trained on
  the ProgrammableWeb Mashup dataset scores APIs for each activity.

This repository bundles **both halves**, including the multi-agent framework.

## Layout

```
BPMN_MAO_MLP/
├── camel/                 # CAMEL agent framework (Apache-2.0, CAMEL-AI) — adapted to DeepSeek
├── MAO/                   # multi-agent BPMN pipeline (ChatDev-derived, Apache-2.0)
├── mmm/                   # experience / memory modules (ChatDev-derived, Apache-2.0)
├── CompanyConfig/         # agent role / phase / chat-chain configs
├── online_log/            # web log / visualizer
├── models/
│   └── mtfmpp_model.py    # MTFM++ — MTFMPPLite is the trained model;
│                          #   MTFMPP / MTFMPPSimple are the fuller (unused) design
├── tools_mlp/__init__.py  # MashupDataset, TextDataset, metrics, EarlyStopping
├── HallucinationTest/     # standalone BPMN-structure sanity checker
├── train_mtfmpp.py        # train MTFM++ -> checkpoints/mtfmpp_best.pth
├── main_mtfmpp.py         # self-contained pipeline (direct DeepSeek calls, no framework)
├── run_evaluation.py      # batch evaluation via the multi-agent framework
├── requirements.txt
├── .env.example
└── .gitignore
```

## Two ways to run

**`main_mtfmpp.py` — self-contained.** Its `MAOGenerator` calls the DeepSeek chat
API directly to produce the BPMN activities, then `MTFMPPRecommender` binds an
API to each. Depends only on the model-side packages plus a trained checkpoint —
it does not use the `camel/` / `MAO/` framework.

**`run_evaluation.py` — uses the bundled multi-agent framework.** It imports
`camel` and `MAO` (`from MAO.chat_chain import ChatChain`) to run the full
multi-agent generation. It also imports `BPMN_TEST_SCENARIOS`, `UnifiedOutput`,
and `save_results` from a `scenarios` module that lives in a separate evaluation
harness — provide it or adapt the runner.

## Requirements

- Python 3.9 (the bundled frameworks were built/compiled against 3.9)
- Model side: `torch`, `numpy`, `requests` (see `requirements.txt`)
- Framework side: `camel/` + `MAO/` + `mmm/` bring their own dependencies
  (e.g. `openai`, `tenacity`, `tiktoken`, `regex`, `flask`) — install per the
  CAMEL / ChatDev upstream requirements.

```bash
pip install -r requirements.txt
```

## Configuration

All LLM calls read the key from the `DEEPSEEK_API_KEY` environment variable —
**no key is hard-coded** anywhere (model scripts and the bundled `camel/` /
`MAO/` fall back to an empty string). The framework layer also uses
`OPENAI_API_KEY` as a presence check, so set both to the same value:

```bash
export DEEPSEEK_API_KEY="your-api-key-here"
export OPENAI_API_KEY="$DEEPSEEK_API_KEY"
```

See `.env.example`.

## Data and checkpoints (not included)

- **Dataset** under `data/` — e.g. `used_api_list.json`, `mashup_description.json`,
  and the other ProgrammableWeb Mashup JSON files the loader expects.
- **Mashup features** — `embedding/mashup_features_roberta.npy`.


## Usage

```bash
python train_mtfmpp.py        # train the recommender
python main_mtfmpp.py         # self-contained end-to-end run
python run_evaluation.py      # batch evaluation via the multi-agent framework (+ scenarios)
```

## Licensing (please read before publishing)

This repository includes third-party code under the **Apache License 2.0**:

- **CAMEL** (`camel/`) — © CAMEL-AI.org. The per-file Apache headers are kept intact.
- **ChatDev-derived** code (`MAO/`, `mmm/`, `CompanyConfig/`, `online_log/`).

For a compliant release you should **add the upstream `LICENSE` (Apache-2.0) and
`NOTICE` files** for CAMEL and ChatDev at the repo root (they were not present in
the source), keep the existing file headers, and state your modifications
(OpenAI → DeepSeek backend, plus your own additions).

## Known issues

- **`mmm/Reviewer_comment/comment_cluster.py` contains an unresolved Git merge
  conflict** (`<<<<<<< HEAD` / `=======` / `>>>>>>>` markers). The file will not
  import as-is — resolve the conflict (or delete the file if unused) before
  publishing.


## Acknowledgements

Built on **CAMEL** (CAMEL-AI, Apache-2.0) and **ChatDev** (Apache-2.0). The
recommender uses the ProgrammableWeb Mashup dataset.
