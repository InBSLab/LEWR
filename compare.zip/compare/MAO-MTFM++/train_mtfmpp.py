import os
import json
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
import random
import gc

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


class MashupDataset(Dataset):

    def __init__(self, features, api_labels, cat_labels):
        self.features = features
        self.api_labels = api_labels
        self.cat_labels = cat_labels

    def __len__(self):
        return len(self.features)

    def __getitem__(self, idx):
        x = torch.FloatTensor(self.features[idx])
        y_api = torch.FloatTensor(self.api_labels[idx])
        y_cat = torch.FloatTensor(self.cat_labels[idx])
        return x, y_api, y_cat


class MTFMPPLite(nn.Module):


    def __init__(self, num_api, num_category, embed_dim=768, feature_dim=32,
                 api_tag_embed=None, dropout=0.2):
        super(MTFMPPLite, self).__init__()

        if api_tag_embed is not None:
            self.api_tag_embed = nn.Embedding.from_pretrained(api_tag_embed, freeze=True)
        else:
            self.api_tag_embed = nn.Embedding(num_api, num_category)

        self.api_tag_layer = nn.Sequential(
            nn.Linear(num_category, feature_dim),
            nn.Tanh()
        )

        self.mashup_encoder = nn.Sequential(
            nn.Linear(embed_dim, 256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, 128),
            nn.ReLU()
        )

        self.sc_output = nn.Linear(128, num_api)

        self.fic_input = nn.Sequential(
            nn.Linear(128, feature_dim),
            nn.Tanh()
        )

        self.fusion_layer = nn.Linear(num_api * 2, num_api)

        self.api_output = nn.Linear(num_api, num_api)
        self.cat_output = nn.Linear(num_api, num_category)

        self.dropout = nn.Dropout(dropout)
        self.sigmoid = nn.Sigmoid()
        self.tanh = nn.Tanh()

    def forward(self, x):
        api_tag = self.api_tag_layer(self.api_tag_embed.weight).t()

        h = self.mashup_encoder(x)

        u_sc = self.sc_output(h)

        u_fic = self.tanh(torch.matmul(self.fic_input(h), api_tag))

        u = self.fusion_layer(torch.cat([u_sc, u_fic], dim=1))
        u = self.dropout(u)

        api_pred = self.sigmoid(self.api_output(u))
        cat_pred = self.sigmoid(self.cat_output(u))

        return api_pred, cat_pred


def train():
    set_seed(42)

    print("=" * 60)
    print("MTFM++ 训练（内存优化版）")
    print("=" * 60)

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"Device: {device}")

    print("\n[1] 加载数据...")

    with open(os.path.join(BASE_DIR, "data", "used_api_list.json"), 'r') as f:
        api_names = json.load(f)
    num_api = len(api_names)
    print(f"  API: {num_api}")

    with open(os.path.join(BASE_DIR, "data", "category_list.json"), 'r') as f:
        category_list = json.load(f)
    num_category = len(category_list)
    print(f"  类别: {num_category}")

    print("\n[2] 构建API标签嵌入...")

    with open(os.path.join(BASE_DIR, "data", "api_category.json"), 'r') as f:
        all_api_categories = json.load(f)
    with open(os.path.join(BASE_DIR, "data", "api_name.json"), 'r') as f:
        all_api_names = json.load(f)

    all_api_to_idx = {name: i for i, name in enumerate(all_api_names)}
    category_to_idx = {cat: i for i, cat in enumerate(category_list)}

    api_tag_matrix = np.zeros((num_api, num_category), dtype=np.float32)
    for i, api_name in enumerate(api_names):
        if api_name in all_api_to_idx:
            full_idx = all_api_to_idx[api_name]
            if full_idx < len(all_api_categories):
                for cat in all_api_categories[full_idx]:
                    if cat in category_to_idx:
                        api_tag_matrix[i, category_to_idx[cat]] = 1.0

    api_tag_embed = torch.FloatTensor(api_tag_matrix)
    print(f"  API标签嵌入: {api_tag_embed.shape}")

    del all_api_categories, all_api_names, all_api_to_idx
    gc.collect()

    print("\n[3] 加载特征...")

    features = np.load(os.path.join(BASE_DIR, "embedding", "mashup_features_roberta.npy"))
    print(f"  Mashup特征: {features.shape}")

    with open(os.path.join(BASE_DIR, "data", "mashup_used_api.json"), 'r') as f:
        mashup_apis = json.load(f)
    with open(os.path.join(BASE_DIR, "data", "mashup_category.json"), 'r') as f:
        mashup_categories = json.load(f)

    api_to_idx = {name: i for i, name in enumerate(api_names)}
    num_samples = min(len(features), len(mashup_apis), len(mashup_categories))

    print("\n[4] 构建标签...")

    api_labels = np.zeros((num_samples, num_api), dtype=np.float32)
    cat_labels = np.zeros((num_samples, num_category), dtype=np.float32)

    for i in range(num_samples):
        for api_name in mashup_apis[i]:
            if api_name in api_to_idx:
                api_labels[i, api_to_idx[api_name]] = 1.0
        for cat in mashup_categories[i]:
            if cat in category_to_idx:
                cat_labels[i, category_to_idx[cat]] = 1.0

    features = features[:num_samples]

    print(f"  样本数: {num_samples}")
    print(f"  内存: 特征{features.nbytes//1024//1024}MB + "
          f"API标签{api_labels.nbytes//1024//1024}MB + "
          f"类别标签{cat_labels.nbytes//1024//1024}MB")

    del mashup_apis, mashup_categories
    gc.collect()

    print("\n[5] 准备数据集...")

    indices = np.random.permutation(num_samples)
    train_size = int(0.8 * num_samples)
    train_idx, val_idx = indices[:train_size], indices[train_size:]

    train_dataset = MashupDataset(
        features[train_idx], api_labels[train_idx], cat_labels[train_idx]
    )
    val_dataset = MashupDataset(
        features[val_idx], api_labels[val_idx], cat_labels[val_idx]
    )

    batch_size = 32
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size)

    print(f"  训练集: {len(train_dataset)}, 验证集: {len(val_dataset)}")
    print(f"  Batch size: {batch_size}")

    print("\n[6] 创建模型...")

    model = MTFMPPLite(
        num_api=num_api,
        num_category=num_category,
        embed_dim=768,
        feature_dim=32,
        api_tag_embed=api_tag_embed
    )
    model.to(device)

    total_params = sum(p.numel() for p in model.parameters())
    print(f"  参数量: {total_params:,}")

    api_criterion = nn.BCELoss()
    cat_criterion = nn.BCELoss()
    optimizer = optim.Adam(model.parameters(), lr=1e-3)

    print("\n[7] 开始训练...")
    print("-" * 50)

    checkpoint_dir = os.path.join(BASE_DIR, "checkpoints")
    os.makedirs(checkpoint_dir, exist_ok=True)

    best_loss = float('inf')
    patience = 7
    patience_counter = 0

    for epoch in range(100):
        model.train()
        train_loss = 0
        for bx, by_api, by_cat in train_loader:
            bx, by_api, by_cat = bx.to(device), by_api.to(device), by_cat.to(device)

            optimizer.zero_grad()
            api_pred, cat_pred = model(bx)
            loss = api_criterion(api_pred, by_api) + cat_criterion(cat_pred, by_cat)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()

        train_loss /= len(train_loader)

        model.eval()
        val_loss = 0
        with torch.no_grad():
            for bx, by_api, by_cat in val_loader:
                bx, by_api, by_cat = bx.to(device), by_api.to(device), by_cat.to(device)
                api_pred, cat_pred = model(bx)
                val_loss += (api_criterion(api_pred, by_api) + cat_criterion(cat_pred, by_cat)).item()
        val_loss /= len(val_loader)

        if (epoch + 1) % 10 == 0:
            print(f"  Epoch {epoch+1}: train={train_loss:.4f}, val={val_loss:.4f}")

        if val_loss < best_loss:
            best_loss = val_loss
            torch.save(model.state_dict(), os.path.join(checkpoint_dir, "mtfmpp_best.pth"))
            patience_counter = 0
        else:
            patience_counter += 1
            if patience_counter >= patience:
                print(f"  Early stopping at epoch {epoch+1}")
                break

    print("-" * 50)
    print(f"✓ 训练完成！最佳损失: {best_loss:.4f}")

    config = {
        'model_name': 'MTFMPP',
        'num_api': num_api,
        'num_category': num_category,
        'embed_dim': 768,
        'feature_dim': 32,
        'api_names': api_names,
        'category_list': category_list
    }
    with open(os.path.join(checkpoint_dir, "mtfmpp_config.json"), 'w') as f:
        json.dump(config, f, ensure_ascii=False, indent=2)

    np.save(os.path.join(checkpoint_dir, "api_tag_embed.npy"), api_tag_embed.numpy())

    print(f"✓ 保存到 checkpoints/")


if __name__ == "__main__":
    train()
