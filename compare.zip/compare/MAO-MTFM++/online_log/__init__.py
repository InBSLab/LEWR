# -*- coding: utf-8 -*-
"""
Online Log Module - 简化版
"""

from .app import send_msg, get_messages, clear_messages
