# -*- coding: utf-8 -*-
"""
简化版在线日志模块
==================
原版需要Flask依赖，这个简化版移除了Flask依赖
仅保留send_msg函数用于日志记录
"""

import logging

# 消息存储
messages = []


def send_msg(role, text):
    """
    发送/记录消息
    
    简化版：仅记录到内存列表，不需要Flask服务
    
    Args:
        role: 角色名称
        text: 消息内容
    """
    try:
        message = {"role": str(role), "text": str(text)}
        messages.append(message)
        # 可选：也可以记录到日志文件
        # logging.debug(f"[{role}] {text}")
    except Exception as e:
        logging.debug(f"send_msg error: {e}")


def get_messages():
    """获取所有消息"""
    return messages


def clear_messages():
    """清空消息"""
    global messages
    messages = []
