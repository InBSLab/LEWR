import torch
import torch.nn as nn
import numpy as np


class MTFMPPConfig(object):

    def __init__(self, ds_config):
        self.model_name = 'MTFMPP_Model'

        self.embed_dim = ds_config.embed_dim
        self.num_category = ds_config.num_category
        self.num_api = ds_config.num_api
        self.num_mashup = ds_config.num_mashup

        self.feature_dim = 64
        self.dropout = 0.2
        self.lr = 1e-3
        self.batch_size = 128
        self.device = ('cuda' if torch.cuda.is_available() else 'cpu')

        self.api_tag_embed = ds_config.api_tag_embed

        self.api_quality_embed = getattr(ds_config, 'api_quality_embed', None)
        self.quality_dim = 13 if self.api_quality_embed is not None else 0


class MTFMPP(nn.Module):


    def __init__(self, config):
        super(MTFMPP, self).__init__()
        self.config = config


        if config.api_tag_embed is not None:
            self.api_tag_embed = nn.Embedding.from_pretrained(
                config.api_tag_embed, freeze=False
            )
        else:
            self.api_tag_embed = nn.Embedding(config.num_api, config.num_category)

        self.api_tag_layer = nn.Sequential(
            nn.Linear(config.num_category, config.feature_dim),
            nn.Tanh()
        )

        if config.api_quality_embed is not None:
            self.api_quality_embed = nn.Embedding.from_pretrained(
                config.api_quality_embed, freeze=True
            )
            self.api_quality_layer = nn.Linear(config.quality_dim, 1)
            self.has_quality = True
        else:
            self.has_quality = False

        self.api_semantic_layer = nn.Sequential(
            nn.Linear(config.embed_dim, 256),
            nn.ReLU(),
            nn.Dropout(config.dropout),
            nn.Linear(256, config.feature_dim),
            nn.Tanh()
        )

        self.api_fusion_layer = nn.Linear(
            config.feature_dim * 2, config.feature_dim
        )


        self.mashup_semantic_layer = nn.Sequential(
            nn.Linear(config.embed_dim, 512),
            nn.ReLU(),
            nn.Dropout(config.dropout),
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Dropout(config.dropout)
        )

        self.sc_output = nn.Linear(256, config.num_api)


        self.fic_input = nn.Sequential(
            nn.Linear(256, config.feature_dim),
            nn.Tanh()
        )


        fusion_input_dim = config.num_api * 2
        if self.has_quality:
            fusion_input_dim += config.num_api

        self.fusion_layer = nn.Sequential(
            nn.Linear(fusion_input_dim, config.num_api),
            nn.Dropout(config.dropout)
        )


        self.api_task_layer = nn.Linear(config.num_api, config.num_api)

        self.category_task_layer = nn.Linear(config.num_api, config.num_category)

        self.dropout = nn.Dropout(config.dropout)
        self.logistic = nn.Sigmoid()
        self.tanh = nn.Tanh()

    def forward(self, mashup_features, api_features=None):

        batch_size = mashup_features.size(0)


        api_tag_value = self.api_tag_layer(self.api_tag_embed.weight)
        api_tag_value = api_tag_value.permute(1, 0)

        if api_features is not None:
            api_semantic = self.api_semantic_layer(api_features)
            api_semantic = api_semantic.permute(1, 0)

            api_combined = self.tanh(api_semantic + api_tag_value)
        else:
            api_combined = api_tag_value


        mashup_semantic = self.mashup_semantic_layer(mashup_features)

        u_sc = self.sc_output(mashup_semantic)


        u_fic_input = self.fic_input(mashup_semantic)

        u_fic = torch.matmul(u_fic_input, api_combined)
        u_fic = self.tanh(u_fic)


        if self.has_quality:
            api_quality_value = self.api_quality_layer(
                self.api_quality_embed.weight
            ).permute(1, 0)
            api_quality_value = self.tanh(api_quality_value)

            api_quality_expanded = api_quality_value.expand(batch_size, -1)

            u_mmf = self.fusion_layer(
                torch.cat((u_sc, u_fic, api_quality_expanded), dim=1)
            )
        else:
            u_mmf = self.fusion_layer(
                torch.cat((u_sc, u_fic), dim=1)
            )

        u_mmf = self.dropout(u_mmf)


        api_pred = self.api_task_layer(u_mmf)

        category_pred = self.category_task_layer(u_mmf)

        return self.logistic(api_pred), self.logistic(category_pred)

    def predict_api_only(self, mashup_features, api_features=None):

        api_pred, _ = self.forward(mashup_features, api_features)
        return api_pred


class MTFMPPSimple(nn.Module):


    def __init__(self, config):
        super(MTFMPPSimple, self).__init__()
        self.config = config

        if config.api_tag_embed is not None:
            self.api_tag_embed = nn.Embedding.from_pretrained(
                config.api_tag_embed, freeze=False
            )
        else:
            self.api_tag_embed = nn.Embedding(config.num_api, config.num_category)

        self.api_tag_layer = nn.Sequential(
            nn.Linear(config.num_category, config.feature_dim),
            nn.Tanh()
        )

        self.mashup_encoder = nn.Sequential(
            nn.Linear(config.embed_dim, 512),
            nn.ReLU(),
            nn.Dropout(config.dropout),
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Dropout(config.dropout)
        )

        self.sc_output = nn.Linear(256, config.num_api)

        self.fic_input = nn.Sequential(
            nn.Linear(256, config.feature_dim),
            nn.Tanh()
        )

        self.fusion_layer = nn.Sequential(
            nn.Linear(config.num_api * 2, config.num_api),
            nn.Dropout(config.dropout)
        )

        self.api_task_layer = nn.Linear(config.num_api, config.num_api)
        self.category_task_layer = nn.Linear(config.num_api, config.num_category)

        self.logistic = nn.Sigmoid()
        self.tanh = nn.Tanh()
        self.dropout = nn.Dropout(config.dropout)

    def forward(self, mashup_features):

        api_tag_value = self.api_tag_layer(self.api_tag_embed.weight)
        api_tag_value = api_tag_value.permute(1, 0)

        mashup_semantic = self.mashup_encoder(mashup_features)

        u_sc = self.sc_output(mashup_semantic)

        u_fic_input = self.fic_input(mashup_semantic)
        u_fic = torch.matmul(u_fic_input, api_tag_value)
        u_fic = self.tanh(u_fic)

        u_mmf = self.fusion_layer(torch.cat((u_sc, u_fic), dim=1))
        u_mmf = self.dropout(u_mmf)

        api_pred = self.logistic(self.api_task_layer(u_mmf))
        category_pred = self.logistic(self.category_task_layer(u_mmf))

        return api_pred, category_pred


class MTFMPPLite(nn.Module):


    def __init__(self, num_api, num_category, embed_dim=768, feature_dim=32,
                 api_tag_embed=None, dropout=0.2):
        super(MTFMPPLite, self).__init__()

        if api_tag_embed is not None:
            self.api_tag_embed = nn.Embedding.from_pretrained(api_tag_embed, freeze=True)
        else:
            self.api_tag_embed = nn.Embedding(num_api, num_category)

        self.api_tag_layer = nn.Sequential(
            nn.Linear(num_category, feature_dim),
            nn.Tanh()
        )

        self.mashup_encoder = nn.Sequential(
            nn.Linear(embed_dim, 256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, 128),
            nn.ReLU()
        )

        self.sc_output = nn.Linear(128, num_api)

        self.fic_input = nn.Sequential(
            nn.Linear(128, feature_dim),
            nn.Tanh()
        )

        self.fusion_layer = nn.Linear(num_api * 2, num_api)

        self.api_output = nn.Linear(num_api, num_api)
        self.cat_output = nn.Linear(num_api, num_category)

        self.dropout = nn.Dropout(dropout)
        self.sigmoid = nn.Sigmoid()
        self.tanh = nn.Tanh()

    def forward(self, x):
        api_tag = self.api_tag_layer(self.api_tag_embed.weight).t()

        h = self.mashup_encoder(x)

        u_sc = self.sc_output(h)

        u_fic = self.tanh(torch.matmul(self.fic_input(h), api_tag))

        u = self.fusion_layer(torch.cat([u_sc, u_fic], dim=1))
        u = self.dropout(u)

        api_pred = self.sigmoid(self.api_output(u))
        cat_pred = self.sigmoid(self.cat_output(u))

        return api_pred, cat_pred


class DatasetConfig:

    def __init__(self, num_api, num_category, num_mashup, embed_dim=768,
                 api_tag_embed=None, api_quality_embed=None):
        self.num_api = num_api
        self.num_category = num_category
        self.num_mashup = num_mashup
        self.embed_dim = embed_dim
        self.api_tag_embed = api_tag_embed
        self.api_quality_embed = api_quality_embed
