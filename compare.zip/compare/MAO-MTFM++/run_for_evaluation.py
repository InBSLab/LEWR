# -*- coding: utf-8 -*-

import os
import sys
import re
import json
import time
import csv
import logging
import argparse
import statistics
import traceback
import numpy as np
import torch
import torch.nn as nn
from pathlib import Path
from collections import Counter
from typing import List, Dict, Any, Optional, Tuple

ADD_START_END = True
USE_FALLBACK_TEMPLATE = True
REPAIR_RETRIES = 0
FORCE_PARALLEL_JOIN = False
APPLY_TASK_TRIM = False

SCRIPT_DIR = Path(__file__).parent.absolute()
PROJECT_ROOT = SCRIPT_DIR.parent.parent  # evaluation_framework_complete/
EVAL_ROOT = SCRIPT_DIR.parent  # evaluation_framework_complete/evaluation/

POSSIBLE_MODEL_PATHS = [
    PROJECT_ROOT / "models" / "MAO" / "MAO_MTFMPP" / "BPMN_MAO_MLP",
    PROJECT_ROOT / "MAO_MTFMPP1" / "BPMN_MAO_MLP",
    PROJECT_ROOT.parent / "MAO_MTFMPP1" / "BPMN_MAO_MLP",
    SCRIPT_DIR / "BPMN_MAO_MLP",
    SCRIPT_DIR,
]


def find_model_root():
    for path in POSSIBLE_MODEL_PATHS:
        checkpoint_path = path / "checkpoints" / "mtfmpp_best.pth"
        if checkpoint_path.exists():
            print(f"  找到模型目录: {path}")
            return path
        data_path = path / "data" / "api_name.json"
        if data_path.exists():
            print(f"  找到数据目录: {path}")
            return path
        mao_path = path / "MAO" / "chat_chain.py"
        if mao_path.exists():
            print(f"  找到MAO多智能体框架目录: {path}")
            return path
    return POSSIBLE_MODEL_PATHS[0]


MODEL_ROOT = find_model_root()

if MODEL_ROOT.exists():
    os.chdir(str(MODEL_ROOT))
    print(f"  已切换工作目录到: {MODEL_ROOT} (mmm/记忆模块的相对路径依赖这个)")
else:
    print(f"  ⚠ MODEL_ROOT ({MODEL_ROOT}) 不存在，未切换工作目录，"
          f"with_memory 相关的相对路径 (./mmm/config.yaml 等) 大概率会失败。")

sys.path.insert(0, str(EVAL_ROOT / "common"))
sys.path.insert(0, str(MODEL_ROOT))

from scenarios import BPMN_TEST_SCENARIOS, UnifiedOutput, save_results

# ============================================================================
# DeepSeek API Key
# ============================================================================
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "")
os.environ.setdefault("DEEPSEEK_API_KEY", DEEPSEEK_API_KEY)

os.environ.setdefault("OPENAI_API_KEY", DEEPSEEK_API_KEY)

try:
    from camel.typing import ModelType
    from MAO.chat_chain import ChatChain
    _MAO_IMPORT_ERROR = None
except Exception as _e:
    ChatChain = None
    ModelType = None
    _MAO_IMPORT_ERROR = _e


# ============================================================================
# mashup_encoder / sc_output / fic_input / fusion_layer / api_output /
# ============================================================================


class MTFMPPLite(nn.Module):

    def __init__(self, num_api, num_category, embed_dim=768, feature_dim=32,
                 api_tag_embed=None, dropout=0.2):
        super(MTFMPPLite, self).__init__()

        if api_tag_embed is not None:
            self.api_tag_embed = nn.Embedding.from_pretrained(api_tag_embed, freeze=True)
        else:
            self.api_tag_embed = nn.Embedding(num_api, num_category)

        self.api_tag_layer = nn.Sequential(
            nn.Linear(num_category, feature_dim),
            nn.Tanh()
        )

        self.mashup_encoder = nn.Sequential(
            nn.Linear(embed_dim, 256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, 128),
            nn.ReLU()
        )

        self.sc_output = nn.Linear(128, num_api)

        self.fic_input = nn.Sequential(
            nn.Linear(128, feature_dim),
            nn.Tanh()
        )

        self.fusion_layer = nn.Linear(num_api * 2, num_api)

        self.api_output = nn.Linear(num_api, num_api)
        self.cat_output = nn.Linear(num_api, num_category)

        self.dropout = nn.Dropout(dropout)
        self.sigmoid = nn.Sigmoid()
        self.tanh = nn.Tanh()

    def forward(self, x):
        api_tag = self.api_tag_layer(self.api_tag_embed.weight).t()
        h = self.mashup_encoder(x)
        u_sc = self.sc_output(h)
        u_fic = self.tanh(torch.matmul(self.fic_input(h), api_tag))
        u = self.fusion_layer(torch.cat([u_sc, u_fic], dim=1))
        u = self.dropout(u)
        return self.sigmoid(self.api_output(u)), self.sigmoid(self.cat_output(u))


MTFMPPModel = MTFMPPLite


class MAOGenerator:

    def __init__(self, config_name: str = "Default", org_name: str = "MAO_MTFMPP_Eval",
                 model_type=None):
        if ChatChain is None:
            raise ImportError(
                f"无法导入压缩包中的MAO多智能体模块 (MAO.chat_chain.ChatChain)。\n"
                f"原始错误: {_MAO_IMPORT_ERROR}\n"
                f"请确认 MODEL_ROOT ({MODEL_ROOT}) 下存在 MAO/、camel/、CompanyConfig/ 目录，"
                f"并且 camel/MAO 所需的第三方依赖包已安装。"
            )
        self.config_name = config_name
        self.org_name = org_name
        self.model_type = model_type if model_type is not None else ModelType.GPT_4
        self._call_count = 0
        self.last_run_info: Dict[str, Any] = {}

    def _get_config_paths(self) -> Tuple[str, str, str]:
        config_dir = MODEL_ROOT / "CompanyConfig" / self.config_name
        default_config_dir = MODEL_ROOT / "CompanyConfig" / "Default"

        paths = []
        for fname in ["ChatChainConfig.json", "PhaseConfig.json", "RoleConfig.json"]:
            company_path = config_dir / fname
            default_path = default_config_dir / fname
            paths.append(str(company_path if company_path.exists() else default_path))
        return tuple(paths)

    @staticmethod
    def _sanitize_name(name: str) -> str:
        safe = re.sub(r'[^\w\-]+', '_', str(name)).strip('_')
        return safe or "Scenario"

    def generate(self, task: str, scenario_name: str = "Scenario") -> str:
        self._call_count += 1
        project_name = f"{self._sanitize_name(scenario_name)}_{self._call_count}"

        config_path, config_phase_path, config_role_path = self._get_config_paths()

        print("\n[MAO] 调用真实多智能体框架 (MAO.chat_chain.ChatChain)")
        print(f"  config_path       : {config_path}")
        print(f"  config_phase_path : {config_phase_path}")
        print(f"  config_role_path  : {config_role_path}")
        print(f"  project_name      : {project_name}")

        chat_chain = ChatChain(
            config_path=config_path,
            config_phase_path=config_phase_path,
            config_role_path=config_role_path,
            task_prompt=task,
            project_name=project_name,
            org_name=self.org_name,
            model_type=self.model_type,
        )

        log_dir = os.path.dirname(chat_chain.log_filepath)
        if log_dir and not os.path.exists(log_dir):
            os.makedirs(log_dir, exist_ok=True)

        logging.basicConfig(
            filename=chat_chain.log_filepath,
            level=logging.INFO,
            format='[%(asctime)s %(levelname)s] %(message)s',
            datefmt='%Y-%d-%m %H:%M:%S',
            encoding="utf-8",
            force=True,
        )

        try:
            print("  [1/4] 预处理 (pre_processing)...")
            chat_chain.pre_processing()

            print("  [2/4] 招募人员 (make_recruitment)...")
            chat_chain.make_recruitment()

            print("  [3/4] 执行处理链 (execute_chain): "
                  "ProcessGeneration -> ActivityRefinement -> Review -> Test ...")
            chat_chain.execute_chain()

            print("  [4/4] 后处理 (post_processing)...")
            chat_chain.post_processing()

        except KeyboardInterrupt:
            raise
        except Exception as e:
            print(f"  ✗ MAO ChatChain 执行失败: {e}")
            traceback.print_exc()
            env_dict = chat_chain.chat_env.env_dict
            source = ("reviewed" if env_dict.get('reviewed_process_text', '')
                      else "refinement" if env_dict.get('refinement_process_text', '')
                      else "initial" if env_dict.get('initial_process_text', '')
                      else "none")
            partial = (env_dict.get('reviewed_process_text', '')
                       or env_dict.get('refinement_process_text', '')
                       or env_dict.get('initial_process_text', ''))
            self.last_run_info = {"chain_failed": True, "error": str(e)[:300],
                                  "text_source": source}
            return partial if partial else "<process></process>"

        process_text = chat_chain.chat_env.env_dict.get('reviewed_process_text', '')
        print("  ✓ MAO完成!")
        self.last_run_info = {"chain_failed": False, "error": "",
                              "text_source": "reviewed" if process_text else "none"}
        return process_text if process_text else "<process></process>"

    def extract_activities(self, process: str) -> List[Dict]:
        activities = []
        pattern = r'<activity[^>]*role=[\'"]([^\'"]*)[\'"][^>]*action=[\'"]([^\'"]*)[\'"][^>]*objects=[\'"]([^\'"]*)[\'"][^>]*id=[\'"]([^\'"]*)[\'"][^>]*/>'

        for match in re.finditer(pattern, process):
            activities.append({
                'id': match.group(4),
                'role': match.group(1),
                'action': match.group(2),
                'objects': match.group(3)
            })

        if not activities:
            pattern2 = r'<activity[^>]*id=[\'"]([^\'"]*)[\'"][^>]*>'
            for i, match in enumerate(re.finditer(pattern2, process)):
                activities.append({
                    'id': match.group(1),
                    'role': '',
                    'action': f'Activity {i+1}',
                    'objects': ''
                })

        return activities

    def extract_gateways(self, process: str) -> List[Dict]:
        gateways = []

        for gw_type in ['exclusiveGateway', 'parallelGateway', 'inclusiveGateway']:
            pattern = f'<{gw_type}[^>]*id=[\'"]([^\'"]*)[\'"][^>]*>'
            for match in re.finditer(pattern, process):
                gateways.append({
                    'id': match.group(1),
                    'type': gw_type.replace('Gateway', '').lower(),
                    'name': gw_type
                })

        return gateways


# ============================================================================
# ============================================================================
#
# ----------------------------------------------------------------------------

_TASK_TYPES = {"task", "userTask", "serviceTask", "sendTask", "receiveTask",
               "businessRuleTask", "manualTask", "scriptTask"}
_GATEWAY_TYPES = {"exclusiveGateway", "parallelGateway", "inclusiveGateway", "eventBasedGateway"}

_TAG_RE = re.compile(
    r"<\s*(/?)\s*([A-Za-z_][\w\-]*)\b((?:'[^']*'|\"[^\"]*\"|[^<>'\"]|['\"])*?)(/?)\s*>",
    re.S)
_ATTR_RE = re.compile(r"([\w:\-]+)\s*=\s*(?:'([^']*)'|\"([^\"]*)\")", re.S)


def _parse_attrs(raw: str) -> Dict[str, str]:
    attrs = {}
    for m in _ATTR_RE.finditer(raw or ""):
        attrs[m.group(1)] = m.group(2) if m.group(2) is not None else (m.group(3) or "")
    if "id" not in attrs:
        m = re.search(r"\bid\s*=\s*['\"]?([\w\-\.]+)", raw or "")
        if m:
            attrs["id"] = m.group(1)
    return attrs


def estimate_task_range(description: str) -> Tuple[int, int]:
    desc_lower = description.lower()
    branch_markers = ['if ', 'otherwise', 'in case', 'depending on', 'either', 'or else',
                      'unless', 'when ', 'whenever']
    sequence_markers = ['then', 'after', 'afterwards', 'meanwhile', 'in the meantime',
                        'once', 'subsequently', 'next,']
    branch_count = sum(desc_lower.count(m) for m in branch_markers)
    sequence_count = sum(desc_lower.count(m) for m in sequence_markers)
    sentence_count = max(1, len(re.findall(r'[.!?](?:\s|$)', description)))
    base = sentence_count
    expansion = branch_count * 2 + sequence_count
    min_tasks = max(4, int(base * 0.8))
    max_tasks = max(min_tasks + 4, int((base + expansion) * 1.3))
    max_tasks = min(max_tasks, 30)
    return min_tasks, max_tasks


class MAOStructureRepair:

    # ------------------------------------------------------------------ #
    # ------------------------------------------------------------------ #
    def parse(self, text: str) -> Dict[str, Any]:
        defects: Dict[str, int] = {}

        def bump(key: str, n: int = 1):
            defects[key] = defects.get(key, 0) + n

        body = text or ""
        m_open = re.search(r"<\s*process\b[^>]*>", body)
        if m_open:
            body = body[m_open.end():]
            m_close = list(re.finditer(r"<\s*/\s*process\s*>", body))
            if m_close:
                body = body[:m_close[-1].start()]
            else:
                bump("process_tag_unclosed")
        else:
            if "<activity" in body or "Gateway" in body:
                bump("process_tag_missing")
            else:
                bump("no_process_content")

        process: List[Dict] = []
        stack: List[Dict] = [{"kind": "root", "elem": None, "path": process}]
        counters = {"act": 0, "gw": 0}
        unknown_tags: Dict[str, int] = {}

        def current_path() -> List[Dict]:
            top = stack[-1]
            if top["kind"] == "gateway":
                gw = top["elem"]
                bump("element_directly_in_gateway")
                if not gw.get("_implicit_branch"):
                    br = {"condition": "", "path": [], "_implicit": True}
                    gw["branches"].append(br)
                    gw["_implicit_branch"] = br
                return gw["_implicit_branch"]["path"]
            return top["path"]

        def new_id(kind: str, attrs: Dict[str, str]) -> str:
            if attrs.get("id"):
                return attrs["id"]
            counters[kind] += 1
            bump("missing_id")
            return ("activity_%d" if kind == "act" else "gateway_%d") % counters[kind]

        def pop_until(kind_set, tag_name):
            idx = None
            for i in range(len(stack) - 1, 0, -1):
                if stack[i]["kind"] in kind_set and \
                        (tag_name is None or stack[i]["elem"].get("type") == tag_name
                         or stack[i]["kind"] != "gateway"):
                    idx = i
                    break
            if idx is None:
                bump("unmatched_close_tag")
                return
            for _ in range(len(stack) - 1 - idx):
                bump("unclosed_tag")
                stack.pop()
            stack.pop()

        for m in _TAG_RE.finditer(body):
            is_close, tag, raw_attrs, self_close = m.group(1) == "/", m.group(2), m.group(3), m.group(4) == "/"
            attrs = _parse_attrs(raw_attrs)

            if tag == "activity":
                if is_close:
                    continue
                counters["act"] += 1
                if not all(k in attrs for k in ("role", "action", "objects")):
                    bump("activity_missing_attrs")
                action = attrs.get("action", "")
                objects = attrs.get("objects", "")
                role = attrs.get("role", "")
                if not action and not objects:
                    action = "Activity %d" % counters["act"]
                elem = {
                    "type": "userTask",
                    "id": new_id("act", attrs),
                    "label": ("%s %s" % (action, objects)).strip(),
                    "_meta": {"role": role, "action": action, "objects": objects},
                }
                current_path().append(elem)

            elif tag in ("startEvent", "endEvent"):
                if is_close:
                    continue
                bump("mao_native_" + tag)
                current_path().append({"type": tag, "id": attrs.get("id") or tag})

            elif tag in _GATEWAY_TYPES:
                if is_close:
                    pop_until({"gateway"}, tag)
                    continue
                gw = {"type": tag, "id": new_id("gw", attrs),
                      "label": attrs.get("name", "") or attrs.get("condition", ""),
                      "branches": []}
                current_path().append(gw)
                if not self_close:
                    stack.append({"kind": "gateway", "elem": gw, "path": None})
                else:
                    bump("gateway_selfclosed_empty")

            elif tag == "branch":
                if is_close:
                    pop_until({"branch", "orphan"}, None)
                    continue
                top = stack[-1]
                if top["kind"] == "gateway":
                    gw = top["elem"]
                    gw["_implicit_branch"] = None
                    br = {"condition": attrs.get("condition", ""), "path": []}
                    gw["branches"].append(br)
                    if not self_close:
                        stack.append({"kind": "branch", "elem": br, "path": br["path"]})
                    else:
                        bump("empty_branch")
                else:
                    bump("branch_outside_gateway")
                    if not self_close:
                        stack.append({"kind": "orphan", "elem": None, "path": current_path()})
            else:
                if not is_close and tag != "process":
                    unknown_tags[tag] = unknown_tags.get(tag, 0) + 1

        while len(stack) > 1:
            stack.pop()
            bump("unclosed_tag")

        if unknown_tags:
            defects["unknown_tags"] = sum(unknown_tags.values())

        stats = {"activities": 0, "gateways": 0, "single_branch_gateways": 0,
                 "zero_branch_gateways": 0, "empty_branches": 0,
                 "has_start": False, "has_end": False}

        def walk(elems):
            for e in elems:
                t = e.get("type")
                if t == "startEvent":
                    stats["has_start"] = True
                elif t == "endEvent":
                    stats["has_end"] = True
                elif t in _TASK_TYPES:
                    stats["activities"] += 1
                elif t in _GATEWAY_TYPES:
                    stats["gateways"] += 1
                    n = len(e["branches"])
                    if n == 0:
                        stats["zero_branch_gateways"] += 1
                    elif n == 1:
                        stats["single_branch_gateways"] += 1
                    for br in e["branches"]:
                        if not br["path"]:
                            stats["empty_branches"] += 1
                        walk(br["path"])
        walk(process)

        ids: List[str] = []

        def collect(elems):
            for e in elems:
                if e.get("id"):
                    ids.append(e["id"])
                for br in e.get("branches", []):
                    collect(br["path"])
        collect(process)
        dup = len(ids) - len(set(ids))
        if dup:
            defects["duplicate_ids"] = dup

        def clean(elems):
            for e in elems:
                e.pop("_implicit_branch", None)
                for br in e.get("branches", []):
                    clean(br["path"])
        clean(process)

        usable = stats["activities"] > 0
        return {"process": process, "defects": defects, "stats": stats,
                "unknown_tags": unknown_tags, "usable": usable}

    # ------------------------------------------------------------------ #
    # ------------------------------------------------------------------ #
    def _fix_has_join_recursive(self, elements: List, counter: Dict[str, int]):
        for elem in elements:
            if not isinstance(elem, dict):
                continue
            et = elem.get("type", "")
            if et in ("exclusiveGateway", "inclusiveGateway"):
                if not elem.get("has_join", False):
                    counter["has_join_forced"] += 1
                elem["has_join"] = True
            elif et in _GATEWAY_TYPES and FORCE_PARALLEL_JOIN:
                if not elem.get("has_join", False):
                    counter["has_join_forced"] += 1
                elem["has_join"] = True
            for branch in elem.get("branches", []):
                if isinstance(branch, list):
                    self._fix_has_join_recursive(branch, counter)
                elif isinstance(branch, dict) and "path" in branch:
                    self._fix_has_join_recursive(branch["path"], counter)

    def _ensure_unique_ids(self, elements: List, seen_ids: Optional[set] = None) -> int:
        if seen_ids is None:
            seen_ids = set()
        counter = [0]

        def fix_ids(elems):
            for elem in elems:
                if not isinstance(elem, dict):
                    continue
                elem_id = elem.get("id", "")
                if elem_id:
                    if elem_id in seen_ids:
                        counter[0] += 1
                        new_id = f"{elem_id}_dup{counter[0]}"
                        elem["id"] = new_id
                        seen_ids.add(new_id)
                    else:
                        seen_ids.add(elem_id)
                for branch in elem.get("branches", []):
                    if isinstance(branch, list):
                        fix_ids(branch)
                    elif isinstance(branch, dict) and "path" in branch:
                        fix_ids(branch["path"])

        fix_ids(elements)
        return counter[0]

    @staticmethod
    def _all_ids(elements: List) -> set:
        out = set()
        for e in elements:
            if isinstance(e, dict):
                if e.get("id"):
                    out.add(e["id"])
                for br in e.get("branches", []):
                    out |= MAOStructureRepair._all_ids(br["path"] if isinstance(br, dict) else br)
        return out

    @staticmethod
    def _has_type_recursive(elements: List, type_name: str) -> bool:
        for e in elements:
            if not isinstance(e, dict):
                continue
            if e.get("type") == type_name:
                return True
            for br in e.get("branches", []):
                path = br["path"] if isinstance(br, dict) and "path" in br else (br if isinstance(br, list) else [])
                if MAOStructureRepair._has_type_recursive(path, type_name):
                    return True
        return False

    # ------------------------------------------------------------------ #
    # ------------------------------------------------------------------ #
    def _extract_enhanced_info(self, bpmn: Dict) -> Dict[str, Any]:
        info = {"task_count": 0, "gateway_count": 0, "exclusive_count": 0, "parallel_count": 0,
                "inclusive_count": 0, "eventbased_count": 0, "tasks": [], "gateways": []}

        def extract_recursive(elements, depth=0):
            for elem in elements:
                elem_type = elem.get("type", "")
                if elem_type in _TASK_TYPES:
                    info["tasks"].append({"id": elem.get("id"), "name": elem.get("label", ""),
                                          "type": elem_type, "depth": depth})
                    info["task_count"] += 1
                elif elem_type in _GATEWAY_TYPES:
                    gateway_info = {"id": elem.get("id"), "type": elem_type.replace("Gateway", ""),
                                    "label": elem.get("label", ""), "has_join": elem.get("has_join", False),
                                    "branch_count": len(elem.get("branches", [])), "depth": depth,
                                    "conditions": []}
                    for branch in elem.get("branches", []):
                        if isinstance(branch, dict) and "condition" in branch:
                            gateway_info["conditions"].append(branch["condition"])
                    info["gateways"].append(gateway_info)
                    info["gateway_count"] += 1
                    key = {"exclusiveGateway": "exclusive_count", "parallelGateway": "parallel_count",
                           "inclusiveGateway": "inclusive_count", "eventBasedGateway": "eventbased_count"}[elem_type]
                    info[key] += 1
                for branch in elem.get("branches", []):
                    if isinstance(branch, list):
                        extract_recursive(branch, depth + 1)
                    elif isinstance(branch, dict) and "path" in branch:
                        extract_recursive(branch["path"], depth + 1)

        extract_recursive(bpmn.get("process", []))
        return info

    def _build_complete_dependencies(self, process: List) -> List[Dict]:
        dependencies = []

        def build_recursive(elements, predecessor_id=None):
            if not elements:
                return predecessor_id
            prev_id = predecessor_id
            for elem in elements:
                if not isinstance(elem, dict):
                    continue
                elem_type = elem.get("type", "")
                elem_id = elem.get("id")
                if not elem_id:
                    continue
                if prev_id:
                    dependencies.append({"source": prev_id, "target": elem_id})
                if elem_type in _GATEWAY_TYPES:
                    gateway_id = elem_id
                    branch_endings = []
                    for branch in elem.get("branches", []):
                        if isinstance(branch, list):
                            last_id = build_recursive(branch, gateway_id)
                            if last_id:
                                branch_endings.append(last_id)
                        elif isinstance(branch, dict) and "path" in branch:
                            last_id = build_recursive(branch["path"], gateway_id)
                            if last_id:
                                branch_endings.append(last_id)
                    if elem.get("has_join", False) and branch_endings:
                        join_id = f"{gateway_id}_join"
                        for ending_id in branch_endings:
                            dependencies.append({"source": ending_id, "target": join_id})
                        prev_id = join_id
                    elif branch_endings:
                        prev_id = branch_endings[-1]
                    else:
                        prev_id = gateway_id
                else:
                    prev_id = elem_id
            return prev_id

        build_recursive(process)
        return dependencies

    def _extract_task_ids(self, elements: List) -> List[str]:
        task_ids = []
        for elem in elements:
            if elem.get("type") in _TASK_TYPES:
                task_ids.append(elem.get("id"))
            for branch in elem.get("branches", []):
                if isinstance(branch, list):
                    task_ids.extend(self._extract_task_ids(branch))
                elif isinstance(branch, dict) and "path" in branch:
                    task_ids.extend(self._extract_task_ids(branch["path"]))
        return task_ids

    def _extract_gateway_tasks(self, bpmn: Dict, gateway_id: str) -> List[str]:
        tasks: List[str] = []

        def find_gateway_and_extract(elements):
            for elem in elements:
                if elem.get("id") == gateway_id and "branches" in elem:
                    for branch in elem["branches"]:
                        if isinstance(branch, list):
                            tasks.extend(self._extract_task_ids(branch))
                        elif isinstance(branch, dict) and "path" in branch:
                            tasks.extend(self._extract_task_ids(branch["path"]))
                    return True
                for branch in elem.get("branches", []):
                    if isinstance(branch, list):
                        if find_gateway_and_extract(branch):
                            return True
                    elif isinstance(branch, dict) and "path" in branch:
                        if find_gateway_and_extract(branch["path"]):
                            return True
            return False

        find_gateway_and_extract(bpmn.get("process", []))
        return tasks

    def _infer_gateway_entry(self, bpmn: Dict, gateway_id: str) -> Optional[str]:
        process = bpmn.get("process", [])
        for i, elem in enumerate(process):
            if elem.get("id") == gateway_id:
                if i > 0:
                    return process[i - 1].get("id")
                break
        return None

    def _infer_gateway_merge(self, bpmn: Dict, gateway_id: str) -> Optional[str]:
        process = bpmn.get("process", [])
        for i, elem in enumerate(process):
            if elem.get("id") == gateway_id:
                if i < len(process) - 1:
                    return process[i + 1].get("id")
                break
        return None

    def _convert_to_evaluation_format(self, bpmn: Dict, enhanced_info: Dict) -> Dict[str, Any]:
        tasks = enhanced_info["tasks"]
        dependencies = self._build_complete_dependencies(bpmn.get("process", []))
        gateways = []
        for gw in enhanced_info["gateways"]:
            gw_type = gw["type"]
            original_id = gw["id"]
            gw_tasks = self._extract_gateway_tasks(bpmn, original_id)
            entry_point = self._infer_gateway_entry(bpmn, original_id)
            merge_point = self._infer_gateway_merge(bpmn, original_id) if gw["has_join"] else None
            gateway_obj = {
                "id": original_id,
                "type": gw_type,
                "tasks": {"tasks": gw_tasks, "type": gw_type, "pattern": "fork",
                          "id": original_id, "entry_point": entry_point}
            }
            if merge_point:
                gateway_obj["tasks"]["merge_point"] = merge_point
            if gw["conditions"]:
                gateway_obj["tasks"]["conditions"] = gw["conditions"]
            gateways.append(gateway_obj)
        return {
            "tasks": [{"task_id": t["id"], "name": t["name"], "type": t["type"], "description": t["name"]}
                      for t in tasks],
            "dependencies": dependencies,
            "gateways": gateways,
        }

    @staticmethod
    def _fallback_process() -> Dict[str, Any]:
        return {"process": [
            {"type": "startEvent", "id": "start"},
            {"type": "userTask", "id": "task1", "label": "Process request",
             "_meta": {"role": "", "action": "Process request", "objects": ""}},
            {"type": "serviceTask", "id": "task2", "label": "Execute action",
             "_meta": {"role": "", "action": "Execute action", "objects": ""}},
            {"type": "userTask", "id": "task3", "label": "Complete process",
             "_meta": {"role": "", "action": "Complete process", "objects": ""}},
            {"type": "endEvent", "id": "end"},
        ]}

    # ------------------------------------------------------------------ #
    # ------------------------------------------------------------------ #
    def repair(self, parsed: Dict[str, Any], user_request: str = "") -> Dict[str, Any]:
        applied: List[str] = []
        counter = {"has_join_forced": 0}
        fallback_used = False

        if parsed["usable"]:
            bpmn = {"process": json.loads(json.dumps(parsed["process"]))}
        elif USE_FALLBACK_TEMPLATE:
            bpmn = self._fallback_process()
            fallback_used = True
            applied.append("R6_fallback_template")
        else:
            bpmn = {"process": []}

        process = bpmn["process"]
        if parsed["defects"].get("process_tag_missing") or parsed["defects"].get("process_tag_unclosed") \
                or parsed["defects"].get("unclosed_tag") or parsed["defects"].get("unmatched_close_tag") \
                or parsed["defects"].get("element_directly_in_gateway") or parsed["defects"].get("branch_outside_gateway"):
            applied.append("R1_tolerant_parse")

        # R2
        self._fix_has_join_recursive(process, counter)
        if counter["has_join_forced"]:
            applied.append(f"R2_has_join_forced(x{counter['has_join_forced']})")

        # R3
        n_dup = self._ensure_unique_ids(process)
        if n_dup:
            applied.append(f"R3_unique_ids(x{n_dup})")

        if ADD_START_END and process:
            used = self._all_ids(process)

            def fresh(base: str) -> str:
                cand, i = base, 0
                while cand in used:
                    i += 1
                    cand = f"{base}_{i}"
                used.add(cand)
                return cand

            if not self._has_type_recursive(process, "startEvent"):
                process.insert(0, {"type": "startEvent", "id": fresh("start")})
                applied.append("R4_add_startEvent")
            if not self._has_type_recursive(process, "endEvent"):
                process.append({"type": "endEvent", "id": fresh("end")})
                applied.append("R4_add_endEvent")

        info = self._extract_enhanced_info(bpmn)
        evaluation_format = self._convert_to_evaluation_format(bpmn, info)
        applied.append("R5_dependencies_built_from_nesting")

        if APPLY_TASK_TRIM and user_request:
            _, max_tasks = estimate_task_range(user_request)
            tasks = evaluation_format["tasks"]
            if len(tasks) > max_tasks:
                trimmed = tasks[:max_tasks]
                ids = {t["task_id"] for t in trimmed}
                evaluation_format["tasks"] = trimmed
                evaluation_format["dependencies"] = [
                    d for d in evaluation_format["dependencies"]
                    if d["source"] in ids and d["target"] in ids]
                applied.append(f"R8_task_trim({len(tasks)}->{max_tasks})")

        meta: Dict[str, Dict[str, str]] = {}

        def collect_meta(elems):
            for e in elems:
                if e.get("type") in _TASK_TYPES:
                    meta[e["id"]] = e.get("_meta", {"role": "", "action": e.get("label", ""), "objects": ""})
                for br in e.get("branches", []):
                    collect_meta(br["path"] if isinstance(br, dict) else br)
        collect_meta(process)

        return {"bpmn": bpmn, "enhanced_info": info, "evaluation_format": evaluation_format,
                "task_meta": meta, "applied": applied, "fallback_used": fallback_used}


def structural_proxy(tasks: List[Dict], dependencies: List[Dict], gateways: List[Dict]) -> Dict[str, Any]:
    task_ids = [t.get("id") or t.get("task_id") for t in tasks]
    gw_ids = [g.get("id") for g in gateways]
    nodes = set(i for i in task_ids + gw_ids if i)
    edges = []
    for d in dependencies:
        s, t = d.get("source", d.get("from")), d.get("target", d.get("to"))
        if s and t:
            edges.append((s, t))
            nodes.add(s)
            nodes.add(t)

    if not nodes:
        return {"connectivity": 0.0, "start_end": 0.0, "gateway": 0.0, "path_coverage": 0.0,
                "proxy_score": 0.0, "num_nodes": 0, "num_edges": 0, "sources": 0, "sinks": 0}

    succ: Dict[str, set] = {n: set() for n in nodes}
    pred: Dict[str, set] = {n: set() for n in nodes}
    und: Dict[str, set] = {n: set() for n in nodes}
    for s, t in edges:
        succ[s].add(t)
        pred[t].add(s)
        und[s].add(t)
        und[t].add(s)

    seen, best = set(), 0
    for n in nodes:
        if n in seen:
            continue
        comp, q = {n}, [n]
        while q:
            x = q.pop()
            for y in und[x]:
                if y not in comp:
                    comp.add(y)
                    q.append(y)
        seen |= comp
        best = max(best, len(comp))
    connectivity = best / len(nodes)

    sources = [n for n in nodes if not pred[n] and succ[n]]
    sinks = [n for n in nodes if not succ[n] and pred[n]]
    start_end = (0.5 if sources else 0.0) + (0.5 if sinks else 0.0)

    if gw_ids:
        ok = sum(1 for g in gw_ids if len(succ.get(g, ())) >= 2 and len(pred.get(g, ())) >= 1)
        gateway = ok / len(gw_ids)
    else:
        gateway = 1.0

    def reach(starts, nxt):
        vis, q = set(starts), list(starts)
        while q:
            x = q.pop()
            for y in nxt[x]:
                if y not in vis:
                    vis.add(y)
                    q.append(y)
        return vis
    fwd, bwd = reach(sources, succ), reach(sinks, pred)
    tids = [t for t in task_ids if t]
    path_cov = (sum(1 for t in tids if t in fwd and t in bwd) / len(tids)) if tids else 0.0

    score = (connectivity + start_end + gateway + path_cov) / 4.0
    return {"connectivity": round(connectivity, 4), "start_end": round(start_end, 4),
            "gateway": round(gateway, 4), "path_coverage": round(path_cov, 4),
            "proxy_score": round(score, 4), "num_nodes": len(nodes), "num_edges": len(edges),
            "sources": len(sources), "sinks": len(sinks)}


class MAOMTFMPPSystem:

    def __init__(self, data_path: str = None, embedding_path: str = None, model_path: str = None,
                 mao_config_name: str = "Default", mao_org_name: str = "MAO_MTFMPP_Eval"):
        print("\n" + "=" * 60)
        print("初始化 MAO + MTFM++")
        print("=" * 60)
        print("  阶段1: MAO (真实四阶段多智能体BPMN生成)")
        print("  阶段2: MTFM++ (SC + FIC + 双任务推荐，真实模型推理)")

        self.data_path = Path(data_path) if data_path else SCRIPT_DIR / "data"
        self.embedding_path = Path(embedding_path) if embedding_path else SCRIPT_DIR / "embedding"

        print("\n[1/4] 初始化MAO生成器...")
        self.mao = MAOGenerator(config_name=mao_config_name, org_name=mao_org_name)
        self.repairer = MAOStructureRepair()
        print("  ✓ MAO (真实四阶段多智能体) 初始化完成")

        print("\n[2/4] 加载API数据...")
        self.api_names = self._load_api_names()
        self.category_list = self._load_categories()
        print(f"  ✓ API数量: {len(self.api_names)}")
        print(f"  ✓ 类别数量: {len(self.category_list)}")

        print("\n[3/4] 初始化MTFM++模型...")
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.mtfmpp_model = self._init_mtfmpp_model(model_path)

        print("\n[4/4] 加载Mashup嵌入特征（用于MTFM++真实推理）...")
        self.mashup_features, self.mashup_descriptions = self._load_mashup_embeddings()

        self._build_keyword_index()

        print("\n" + "=" * 60)
        print("系统初始化完成!")
        print("=" * 60)

    def _load_api_names(self) -> List[str]:
        api_name_file = self.data_path / "api_name.json"
        if api_name_file.exists():
            with open(api_name_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return []

    def _load_categories(self) -> List[str]:
        config_file = MODEL_ROOT / "checkpoints" / "mtfmpp_config.json"
        if config_file.exists():
            with open(config_file, 'r', encoding='utf-8') as f:
                config = json.load(f)
                return config.get('category_list', [])
        return []

    def _init_mtfmpp_model(self, model_path: str = None) -> Optional[MTFMPPModel]:
        if not self.api_names:
            print("  ⚠ 无API数据，MTFM++模型未初始化")
            self.mtfmpp_trained = False
            return None

        if model_path is None:
            model_path = MODEL_ROOT / "checkpoints" / "mtfmpp_best.pth"

        model_path = Path(model_path)

        if model_path.exists():
            try:
                checkpoint = torch.load(model_path, map_location=self.device, weights_only=False)

                # api_tag_embed.weight shape: [num_api, num_category]
                if 'api_tag_embed.weight' in checkpoint:
                    num_api = checkpoint['api_tag_embed.weight'].shape[0]
                    num_category = checkpoint['api_tag_embed.weight'].shape[1]
                else:
                    num_api = len(self.api_names)
                    num_category = max(len(self.category_list), 20)

                if 'mashup_encoder.0.weight' in checkpoint:
                    embed_dim = checkpoint['mashup_encoder.0.weight'].shape[1]
                else:
                    embed_dim = 768

                if 'fic_input.0.weight' in checkpoint:
                    feature_dim = checkpoint['fic_input.0.weight'].shape[0]
                else:
                    feature_dim = 32

                print(f"  从checkpoint推断参数:")
                print(f"    - num_api: {num_api}")
                print(f"    - num_category: {num_category}")
                print(f"    - embed_dim: {embed_dim}")
                print(f"    - feature_dim: {feature_dim}")

                api_tag_embed = None
                tag_file = MODEL_ROOT / "checkpoints" / "api_tag_embed.npy"
                if tag_file.exists():
                    api_tag_embed = torch.FloatTensor(np.load(str(tag_file)))

                model = MTFMPPModel(
                    num_api=num_api,
                    num_category=num_category,
                    embed_dim=embed_dim,
                    feature_dim=feature_dim,
                    api_tag_embed=api_tag_embed
                )

                model.load_state_dict(checkpoint)
                model.to(self.device)
                model.eval()

                print(f"  ✓ MTFM++模型已加载: {model_path}")
                self.mtfmpp_trained = True

                return model

            except Exception as e:
                print(f"  ⚠ 加载模型失败: {e}")
                traceback.print_exc()
                self.mtfmpp_trained = False
        else:
            print(f"  ⚠ 模型文件不存在: {model_path}")
            print(f"    将使用关键词匹配作为回退方案")
            self.mtfmpp_trained = False

        return None

    def _load_mashup_embeddings(self) -> Tuple[Optional[np.ndarray], List[Any]]:
        features = None
        descriptions: List[Any] = []

        feat_file = self.embedding_path / "mashup_features_roberta.npy"
        if feat_file.exists():
            try:
                features = np.load(str(feat_file))
                print(f"  ✓ Mashup特征已加载: {features.shape}")
            except Exception as e:
                print(f"  ⚠ Mashup特征加载失败: {e}")
                features = None
        else:
            print(f"  ⚠ 未找到Mashup特征文件: {feat_file}")
            print(f"    MTFM++模型将无法进行真实推理，Stage2会自动回退到关键词匹配")

        desc_file = self.data_path / "mashup_description.json"
        if desc_file.exists():
            try:
                with open(desc_file, 'r', encoding='utf-8') as f:
                    descriptions = json.load(f)
                print(f"  ✓ Mashup描述已加载: {len(descriptions)} 条")
            except Exception as e:
                print(f"  ⚠ Mashup描述加载失败: {e}")
                descriptions = []
        else:
            print(f"  ⚠ 未找到Mashup描述文件: {desc_file}")

        return features, descriptions

    def _find_similar_mashups(self, query: str, top_n: int = 10) -> Tuple[np.ndarray, np.ndarray]:
        if not self.mashup_descriptions:
            return np.array([]), np.array([])

        query_words = set(query.lower().replace('-', ' ').replace('_', ' ').split())

        scores = []
        for desc in self.mashup_descriptions:
            if isinstance(desc, list):
                desc_words = set(str(w).lower() for w in desc)
            else:
                desc_words = set(str(desc).lower().split())

            overlap = len(query_words & desc_words)
            scores.append(overlap / max(len(query_words), 1))

        scores = np.array(scores)
        top_idx = np.argsort(scores)[::-1][:top_n]
        top_scores = scores[top_idx]

        mask = top_scores > 0
        return top_idx[mask], top_scores[mask]

    def _build_keyword_index(self):
        self.keyword_mapping = {
            'ship': ['shipping', 'logistics', 'fedex', 'ups', 'delivery', 'freight', 'post'],
            'shipping': ['shipping', 'logistics', 'fedex', 'ups', 'delivery', 'freight'],
            'logistic': ['logistics', 'shipping', 'fedex', 'ups', 'delivery', 'freight'],
            'payment': ['payment', 'paypal', 'stripe', 'pay'],
            'map': ['google-maps', 'mapbox', 'mapping', 'location', 'geo'],
            'email': ['email', 'sendgrid', 'mailchimp', 'mail'],
            'send': ['sendgrid', 'email', 'mail', 'notification'],
            'package': ['package', 'parcel', 'shipping'],
            'label': ['label', 'print', 'barcode'],
            'insurance': ['insurance', 'policy', 'coverage'],
            'offer': ['offer', 'quote', 'pricing', 'bid'],
            'select': ['select', 'choose', 'pick', 'compare'],
            'warehouse': ['warehouse', 'storage', 'inventory'],
            'order': ['order', 'purchase', 'buy'],
            'clarify': ['clarify', 'check', 'verify', 'determine'],
            'invite': ['invite', 'request', 'ask'],
            'write': ['write', 'create', 'generate'],
            'prepare': ['prepare', 'ready', 'arrange'],
        }

    def _text_relevance(self, query: str) -> np.ndarray:
        scores = np.zeros(len(self.api_names), dtype=np.float32)
        words = set(query.lower().replace('-', ' ').replace('_', ' ').split())

        terms = set()
        for w in words:
            if w in self.keyword_mapping:
                terms.update(self.keyword_mapping[w])
            for key in self.keyword_mapping:
                if key in w or w in key:
                    terms.update(self.keyword_mapping[key])

        for i, api in enumerate(self.api_names):
            api_lower = api.lower().replace('-', ' ').replace('_', ' ')
            api_words = set(api_lower.split())

            for t in terms:
                if t in api_lower:
                    scores[i] += 0.5
                if t in api_words:
                    scores[i] += 0.3

            for w in words:
                if len(w) > 3 and w in api_lower:
                    scores[i] += 0.4

        if scores.max() > 0:
            scores /= scores.max()

        return scores

    def recommend_api(self, action: str, role: str = "", objects: str = "", top_k: int = 5) -> List[Dict]:
        if not self.api_names:
            return [{"api_name": "manual-task", "score": 0.5}]

        query = f"{role} {action} {objects}"

        text_scores = self._text_relevance(query)

        combined = text_scores
        method = "keyword"

        if self.mtfmpp_trained and self.mtfmpp_model is not None and self.mashup_features is not None:
            try:
                idx, sims = self._find_similar_mashups(query)
                if len(idx) > 0:
                    feature_vec = np.average(self.mashup_features[idx], axis=0, weights=sims)
                else:
                    feature_vec = self.mashup_features.mean(axis=0)

                x = torch.FloatTensor(feature_vec).unsqueeze(0).to(self.device)
                with torch.no_grad():
                    api_scores, _cat_scores = self.mtfmpp_model(x)
                    api_scores = api_scores.cpu().numpy()[0]

                combined = 0.6 * api_scores + 0.4 * text_scores
                method = "mtfmpp"
            except Exception as e:
                print(f"  ⚠ MTFM++模型推理失败，本次回退为关键词匹配: {e}")
                combined = text_scores
                method = "keyword"

        top_indices = np.argsort(combined)[::-1][:top_k]

        return [
            {
                "api_name": self.api_names[idx],
                "score": float(combined[idx]),
                "method": method
            }
            for idx in top_indices if combined[idx] > 0
        ]

    # ------------------------------------------------------------------ #
    # ------------------------------------------------------------------ #
    def _bind_apis(self, items: List[Dict], verbose: bool = False) -> Dict[str, Dict]:
        api_bindings = {}
        for act in items:
            recommendations = self.recommend_api(
                action=act.get('action', ''),
                role=act.get('role', ''),
                objects=act.get('objects', ''),
                top_k=5
            )
            if recommendations:
                top_api = recommendations[0]
                api_bindings[act['id']] = {
                    "task_name": f"{act.get('role', '')} {act.get('action', '')} {act.get('objects', '')}".strip(),
                    "api_name": top_api['api_name'],
                    "confidence": top_api['score'],
                    "method": top_api.get('method', 'unknown'),
                    "top5_recommendations": [
                        {
                            "rank": idx + 1,
                            "api_name": rec['api_name'],
                            "score": round(rec['score'], 4),
                            "method": rec.get('method', 'unknown')
                        }
                        for idx, rec in enumerate(recommendations)
                    ]
                }
                if verbose:
                    action_label = act.get('action', '')[:22]
                    print(f"  [{act['id']}] {action_label}")
                    for idx, rec in enumerate(recommendations):
                        prefix = "    ★ 1." if idx == 0 else f"      {idx+1}."
                        print(f"  {prefix} {rec['api_name']} ({rec['score']:.3f}) [{rec.get('method')}]")
        return api_bindings

    def run(self, user_request: str, scenario_name: str) -> Dict[str, Any]:
        print(f"\n{'='*60}")
        print(f"MAO_MTFMPP 处理场景: {scenario_name}")
        print(f"{'='*60}")

        print("\n[Stage 1] MAO - 真实四阶段多智能体BPMN生成")
        t0 = time.time()
        bpmn_xml = self.mao.generate(user_request, scenario_name)
        mao_info = dict(getattr(self.mao, "last_run_info", {}) or {})
        mao_time = time.time() - t0

        t1 = time.time()
        activities = self.mao.extract_activities(bpmn_xml)
        gateways_raw = self.mao.extract_gateways(bpmn_xml)

        print(f"\n  [RAW] 提取到 {len(activities)} 个活动, {len(gateways_raw)} 个网关")
        for act in activities[:5]:
            print(f"    [{act['id']}] {act['role']}: {act['action']} {act['objects']}")
        if len(activities) > 5:
            print(f"    ... 还有 {len(activities) - 5} 个活动")

        print("\n[Stage 2] MTFM++ - API推荐 (RAW)")
        print("-" * 50)
        raw_bindings = self._bind_apis(activities, verbose=True)

        raw_tasks = [{"id": a['id'],
                      "name": f"{a.get('action', '')} {a.get('objects', '')}".strip(),
                      "type": "userTask"} for a in activities]
        raw_roles = list(set(a.get('role', '') for a in activities if a.get('role')))
        raw_time = mao_time + (time.time() - t1)

        raw_out = UnifiedOutput(
            method="MAO_MTFMPP",
            scenario_name=scenario_name,
            user_request=user_request,
            tasks=raw_tasks,
            dependencies=[],
            gateways=gateways_raw,
            api_bindings=raw_bindings,
            roles=raw_roles,
            execution_time=raw_time,
            extra_info={
                "variant": "raw (no repair)",
                "workflow_generator": "MAO (真实多智能体, 4-Phase: Generation→Refinement→Reviewing→Modifying)",
                "api_recommender": "MTFM++ (SC + FIC + 双任务, 真实模型推理)",
                "mtfmpp_trained": getattr(self, 'mtfmpp_trained', False),
                "bpmn_xml": bpmn_xml[:800] if bpmn_xml else ""
            }
        )

        print("\n[Repair] 对同一份MAO输出施加 LEWR 等价结构修复 (无额外LLM调用)")
        t2 = time.time()
        xml_used = bpmn_xml
        parsed = self.repairer.parse(xml_used)
        retries_done = 0
        while (not parsed["usable"]) and retries_done < REPAIR_RETRIES:
            retries_done += 1
            print(f"  ⚠ MAO输出无可用活动，按 REPAIR_RETRIES 重跑 MAO ({retries_done}/{REPAIR_RETRIES}) ...")
            xml_used = self.mao.generate(user_request, f"{scenario_name}_retry{retries_done}")
            parsed = self.repairer.parse(xml_used)

        t3 = time.time()
        rep = self.repairer.repair(parsed, user_request)
        ef = rep["evaluation_format"]
        applied = list(rep["applied"])
        if retries_done:
            applied.insert(0, f"R7_rerun_MAO(x{retries_done})")

        rep_tasks = [{"id": t["task_id"], "name": t["name"], "type": t.get("type", "userTask")}
                     for t in ef["tasks"]]
        rep_gateways = [{"id": g["id"], "type": g["type"], "tasks": g["tasks"]} for g in ef["gateways"]]
        items = []
        for t in ef["tasks"]:
            m = rep["task_meta"].get(t["task_id"], {"role": "", "action": t["name"], "objects": ""})
            items.append({"id": t["task_id"], "role": m.get("role", ""),
                          "action": m.get("action", ""), "objects": m.get("objects", "")})
        print("[Stage 2] MTFM++ - API推荐 (REPAIRED) ...")
        rep_bindings = self._bind_apis(items, verbose=False)
        rep_roles = list(set(m.get("role", "") for m in rep["task_meta"].values() if m.get("role")))
        rep_time = mao_time + (time.time() - t2)

        rep_out = UnifiedOutput(
            method="MAO_MTFMPP_Repaired",
            scenario_name=scenario_name,
            user_request=user_request,
            tasks=rep_tasks,
            dependencies=ef["dependencies"],
            gateways=rep_gateways,
            api_bindings=rep_bindings,
            roles=rep_roles,
            execution_time=rep_time,
            extra_info={
                "variant": "repaired (LEWR-equivalent structural post-processing)",
                "repairs_applied": applied,
                "fallback_template_used": rep["fallback_used"],
                "workflow_generator": "MAO (同一份原始输出) + LEWR等价结构修复",
                "api_recommender": "MTFM++ (SC + FIC + 双任务, 真实模型推理)",
                "mtfmpp_trained": getattr(self, 'mtfmpp_trained', False),
            }
        )

        raw_proxy = structural_proxy(raw_tasks, [], gateways_raw)
        rep_proxy = structural_proxy(rep_tasks, ef["dependencies"], rep_gateways)
        analysis = {
            "scenario": scenario_name,
            "mao_chain": mao_info,
            "raw_text_length": len(bpmn_xml or ""),
            "raw_extracted": {"activities": len(activities), "gateways": len(gateways_raw),
                              "dependencies": 0,
                              "note": "RAW适配器不产出依赖边，也无start/end事件"},
            "tolerant_parse": {"stats": parsed["stats"], "defects": parsed["defects"],
                               "unknown_tags": parsed["unknown_tags"],
                               "usable": parsed["usable"]},
            "repairs_applied": applied,
            "fallback_template_used": rep["fallback_used"],
            "repaired_extracted": {"tasks": len(rep_tasks), "gateways": len(rep_gateways),
                                   "dependencies": len(ef["dependencies"])},
            "proxy_raw": raw_proxy,
            "proxy_repaired": rep_proxy,
        }
        print(f"\n  [Proxy结构分] raw={raw_proxy['proxy_score']:.3f}  repaired={rep_proxy['proxy_score']:.3f}"
              f"   (repairs: {', '.join(applied)})")

        return {"raw": raw_out, "repaired": rep_out, "analysis": analysis, "raw_text": bpmn_xml or ""}


EVAL_SCRIPT_DIR = EVAL_ROOT / "evaluation"
if not (EVAL_SCRIPT_DIR / "evaluate_all_results_GED_v3.py").exists():
    EVAL_SCRIPT_DIR = EVAL_ROOT

ENGLISH_DIR_OVERRIDE = None

VARIANTS = ["raw", "repaired"]
REPORT_PREFIX = "mao_mtfmpp"
REPORT_SUBDIR = "mao_mtfmpp_report"


def _init_scorer():
    try:
        sys.path.insert(0, str(EVAL_SCRIPT_DIR))
        import evaluate_all_results_GED_v3 as ged_eval
        if ENGLISH_DIR_OVERRIDE is not None:
            ged_eval.ENGLISH_DIR = ENGLISH_DIR_OVERRIDE
        if not ged_eval.ENGLISH_DIR.exists():
            print(f"⚠ 评分模块已加载，但 Ground Truth 目录不存在: {ged_eval.ENGLISH_DIR}")
            print(f"  将只统计结构性指标，不计算 GQ/AB/SV/Overall 分数。")
            return None, None
        scorer = ged_eval.BERTScorer()
        print(f"✓ 评分模块加载成功，Ground Truth目录存在: {ged_eval.ENGLISH_DIR}")
        print(f"  将同时计算每个场景的 GQ / AB / SV / Overall 分数")
        return ged_eval, scorer
    except Exception as e:
        print(f"⚠ 评分模块导入失败，将只统计结构性指标，不打分: {e}")
        return None, None


def check_bpmn_format(process: str) -> List[str]:
    errors = []
    for gw in ['exclusiveGateway', 'parallelGateway', 'inclusiveGateway']:
        opens = len(re.findall(f'<{gw}[^>]*>', process))
        closes = len(re.findall(f'</{gw}>', process))
        if opens != closes:
            errors.append(f"{gw} tags mismatch ({opens} opens, {closes} closes)")
    return errors


_AB_CONTAINERS = {"primary_metrics", "detailed_metrics", "detail", "details", "metrics"}
_ab_diag_printed = False


def _path_tokens(path) -> List[str]:
    return re.split(r"[^a-z0-9]+", ".".join(path).lower())


def _is_ab_sub_path(path, strict: bool) -> bool:
    toks = _path_tokens(path)
    if "ged" in toks:
        return False
    is_pn = any(t == "p" or re.fullmatch(r"p\d+", t) or "precision" in t or "ndcg" in t for t in toks)
    if not is_pn:
        return False
    return (not strict) or any(t in ("api", "ab", "binding") for t in toks)


def _walk_numeric(obj, path=()):
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield from _walk_numeric(v, path + (str(k),))
    elif isinstance(obj, (int, float)) and not isinstance(obj, bool) and obj == obj:
        yield list(path), float(obj)


def extract_ab_submetrics(ev: Dict[str, Any]) -> Dict[str, float]:
    global _ab_diag_printed
    leaves = list(_walk_numeric(ev))
    hits = [(p, v) for p, v in leaves if _is_ab_sub_path(p, strict=True)]
    loose = False
    if not hits:
        hits = [(p, v) for p, v in leaves if _is_ab_sub_path(p, strict=False)]
        loose = True
    out: Dict[str, float] = {}
    for path, val in hits:
        parts = [x for x in path if x.lower() not in _AB_CONTAINERS]
        name = re.sub(r"[^a-z0-9]+", "_", "_".join(parts).lower()).strip("_")
        name = re.sub(r"^(api_binding_|api_|ab_)", "", name)
        key = "ab_" + name
        if key in out:
            key = "ab_" + re.sub(r"[^a-z0-9]+", "_", ".".join(path).lower()).strip("_")
        out[key] = val
    if (not out or loose) and not _ab_diag_printed:
        _ab_diag_printed = True
        if not out:
            print("    ⚠ [P/NDCG] 评分结果里没找到 P / NDCG 键。评分结果中的全部数值键如下，"
                  "请把它们发给我以便对上：")
            shown = [".".join(p) for p, _ in leaves]
        else:
            print("    ℹ [P/NDCG] 在 api/binding 路径下没找到，已按键名宽松匹配，请核对以下键是否确为 AB 的 P/NDCG：")
            shown = [".".join(p) for p, _ in hits]
        for line in shown[:60]:
            print(f"        {line}")
    return out


def _ab_label(key: str) -> str:
    n = key[3:].replace("_at_", "@")
    n = re.sub(r"^api_", "", n)
    n = re.sub(r"^(p|ndcg|precision)_(\d+)$", r"\1@\2", n)
    n = re.sub(r"^precision", "p", n)                    # precision@5 -> P@5
    return "AB-" + n.upper()


def _ab_sort_key(key: str):
    n = key[3:]
    parts = re.split(r"(\d+)", n)
    return (1 if "ndcg" in n else 0, [int(t) if i % 2 else t for i, t in enumerate(parts)])


def collect_ab_keys(recs) -> List[str]:
    keys: List[str] = []
    for r in recs:
        for k, v in r.items():
            if k.startswith("ab_") and k not in keys and isinstance(v, (int, float)):
                keys.append(k)
    return sorted(keys, key=_ab_sort_key)


def _score_into(rec: Dict[str, Any], result, scenario_name: str, variant: str,
                scorer_module, scorer_instance):
    normed = scorer_module.normalize_result(result.to_dict())
    gt_key = scorer_module.SCENARIO_NAME_MAPPING.get(scenario_name, scenario_name)
    gt = scorer_module.load_ground_truth(gt_key)
    if gt is None:
        print(f"    ⚠ [{variant}] 找不到场景 {gt_key} 的 ground truth，跳过打分")
        return
    ann = scorer_module.load_api_annotations(gt_key)
    if not ann:
        print(f"    ⚠ [{variant}] {gt_key} 没有加载到 API 标注，API 得分会失真")
    ev = scorer_module.evaluate_single(normed, gt, scorer_instance, ann)
    pm = ev["primary_metrics"]
    rec.update({"overall_score": ev["overall_score"], "ged_quality": pm["ged_quality"],
                "api_binding_score": pm["api_binding"], "structural_validity": pm["structural_validity"]})

    gd = ev.get("ged_distances") or {}
    if gd:
        rec["ged_raw_greedy"], rec["ged_raw_tabu"] = gd.get("greedy"), gd.get("tabu_search")
        rec["ged_raw_ants"], rec["ged_raw_simann"] = gd.get("ants"), gd.get("sim_ann")
        rec["ged_raw_avg"] = gd.get("average")
    else:
        dm = ev.get("detailed_metrics") or {}
        rec["ged_raw_greedy"], rec["ged_raw_tabu"] = dm.get("ged_greedy"), dm.get("ged_tabu")
        rec["ged_raw_ants"], rec["ged_raw_simann"] = dm.get("ged_ants"), dm.get("ged_sa")
        rec["ged_raw_avg"] = dm.get("ged_avg")
    if rec.get("ged_raw_avg") is None:
        print(f"    ⚠ [{variant}] 未能从评分结果中读到原始GED距离字段（ev keys: {list(ev.keys())}），本次原始GED记为空")

    rec.update(extract_ab_submetrics(ev))
    rec["eval_detail"] = json.loads(json.dumps(ev, default=str))


def build_record(variant: str, result, scenario_name: str, elapsed: float, raw_text: str,
                 format_errors: List[str], analysis: Dict[str, Any],
                 scorer_module=None, scorer_instance=None) -> Dict[str, Any]:
    api_b = getattr(result, "api_bindings", {}) or {}
    extra = getattr(result, "extra_info", {}) or {}
    gw_types = [g.get("type") for g in (getattr(result, "gateways", []) or [])]
    chain = analysis.get("mao_chain") or {}
    parse = analysis.get("tolerant_parse") or {}
    proxy = analysis.get("proxy_raw" if variant == "raw" else "proxy_repaired") or {}
    methods = Counter(b.get("method", "unknown") for b in api_b.values())
    rec: Dict[str, Any] = {
        "scenario": scenario_name, "variant": variant, "success": True, "error": None,
        "elapsed_sec": round(elapsed, 2),
        "execution_time_sec": round(getattr(result, "execution_time", 0.0) or 0.0, 2),
        "task_count": len(getattr(result, "tasks", []) or []),
        "dependency_count": len(getattr(result, "dependencies", []) or []),
        "gateway_count": len(gw_types),
        "exclusive_gateway_count": gw_types.count("exclusive"),
        "parallel_gateway_count": gw_types.count("parallel"),
        "inclusive_gateway_count": gw_types.count("inclusive"),
        "api_binding_count": len(api_b),
        "api_diversity": len({b.get("api_name") for b in api_b.values()}),
        "role_count": len(getattr(result, "roles", []) or []),
        "mtfmpp_trained": extra.get("mtfmpp_trained"),
        "api_method_counts": dict(methods),
        "format_errors": format_errors,
        "format_valid": len(format_errors) == 0,
        "bpmn_xml_length": len(raw_text),
        "mao_chain_failed": bool(chain.get("chain_failed")),
        "mao_text_source": chain.get("text_source"),
        "unusable": not parse.get("usable", True),
        "proxy_score": proxy.get("proxy_score"),
        "repairs_applied": extra.get("repairs_applied", []),
        "fallback_template_used": extra.get("fallback_template_used", False),
        "top1_apis": {tid: b.get("api_name") for tid, b in api_b.items()},
        "top5_apis": {tid: [c.get("api_name") for c in (b.get("top5_recommendations") or [])]
                      for tid, b in api_b.items()},
    }
    if rec["unusable"]:
        print(f"    ⚠ [{variant}] MAO 没有产出任何可用活动（chain_failed={rec['mao_chain_failed']}），"
              f"得分不可信，建议重跑该场景")
    if scorer_module is not None and scorer_instance is not None:
        try:
            _score_into(rec, result, scenario_name, variant, scorer_module, scorer_instance)
        except Exception as err:
            print(f"    ⚠ [{variant}] 打分失败（不影响结构统计）: {err}")
            rec["score_error"] = str(err)
    return rec


def _failed_record(scenario_name: str, variant: str, error: str, elapsed: float) -> Dict[str, Any]:
    return {"scenario": scenario_name, "variant": variant, "success": False, "error": error,
            "elapsed_sec": round(elapsed, 2)}


def _print_run_line(variant: str, rec: Dict[str, Any]):
    mc = rec.get("api_method_counts") or {}
    msg = (f"  [{variant:<8}] tasks={rec['task_count']} deps={rec['dependency_count']} gw={rec['gateway_count']} "
           f"api={rec['api_binding_count']} div={rec['api_diversity']} fmt_ok={rec['format_valid']} "
           f"mtfmpp={mc.get('mtfmpp', 0)}/{rec['api_binding_count']}")
    if "overall_score" in rec:
        msg += (f" | Overall={rec['overall_score']:.3f} GQ={rec['ged_quality']:.3f} "
                f"AB={rec['api_binding_score']:.3f} SV={rec['structural_validity']:.3f}")
        for k in sorted((k for k, v in rec.items() if k.startswith("ab_") and isinstance(v, (int, float))),
                        key=_ab_sort_key):
            msg += f" {_ab_label(k)}={rec[k]:.3f}"
        if rec.get("ged_raw_avg") is not None:
            msg += f" GED_raw_avg={rec['ged_raw_avg']:.2f}"
    print(msg)


_TABLE_COLS = [("Overall", "overall_score", 3), ("GQ", "ged_quality", 3), ("AB(API)", "api_binding_score", 3),
               ("SV", "structural_validity", 3), ("GED_raw_avg", "ged_raw_avg", 2),
               ("#Tasks", "task_count", 0), ("#Deps", "dependency_count", 0), ("#GW", "gateway_count", 0),
               ("#API绑定", "api_binding_count", 0), ("Proxy", "proxy_score", 3)]


def build_report_rows(recs: List[Dict[str, Any]], ab_keys: List[str]) -> List[Dict[str, str]]:
    cols = list(_TABLE_COLS)
    i = next(i for i, c in enumerate(cols) if c[1] == "api_binding_score") + 1
    cols[i:i] = [(_ab_label(k), k, 3) for k in ab_keys]

    def cell(r, key, nd):
        if not r.get("success"):
            return "FAIL"
        v = r.get(key)
        if v is None:
            return "N/A"
        return f"{v:.{nd}f}" if nd else str(int(v))

    rows = []
    for r in recs:
        row = {"Scenario": r["scenario"]}
        for label, key, nd in cols:
            row[label] = cell(r, key, nd)
        row["FmtOK"] = ("Y" if r.get("format_valid") else "N") if r.get("success") else "FAIL"
        row["Unusable"] = ("Y" if r.get("unusable") else "-") if r.get("success") else "FAIL"
        rows.append(row)

    done = [r for r in recs if r.get("success")]
    ok = [r for r in done if not r.get("unusable")]
    n_scored = sum(1 for r in ok if r.get("overall_score") is not None)
    scored_note = f", 打分n={n_scored}" if 0 < n_scored < len(ok) else ""
    mean_row = {"Scenario": f"Mean (跨场景, n={len(ok)}/{len(recs)}{scored_note})"}
    for label, key, nd in cols:
        vals = [r[key] for r in ok if r.get(key) is not None]
        mean_row[label] = "N/A" if not vals else f"{statistics.mean(vals):.{nd or 1}f}"
    mean_row["FmtOK"] = f"{sum(1 for r in done if r.get('format_valid'))}/{len(done)}" if done else "N/A"
    mean_row["Unusable"] = f"{sum(1 for r in done if r.get('unusable'))}/{len(done)}" if done else "N/A"
    return rows + [mean_row]


def write_markdown(path: Path, title: str, rows: List[Dict[str, str]]):
    cols = list(rows[0].keys())
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"### {title}\n\n")
        f.write("| " + " | ".join(cols) + " |\n|" + "|".join(["---"] * len(cols)) + "|\n")
        for r in rows:
            f.write("| " + " | ".join(str(r[c]) for c in cols) + " |\n")
        f.write("\n")


def print_table(title: str, rows: List[Dict[str, str]]):
    cols = list(rows[0].keys())
    w = {c: max(len(c), *(len(str(r[c])) for r in rows)) for c in cols}
    print(f"\n{title}")
    print("  " + " | ".join(c.ljust(w[c]) for c in cols))
    print("  " + "-+-".join("-" * w[c] for c in cols))
    for r in rows:
        print("  " + " | ".join(str(r[c]).ljust(w[c]) for c in cols))


def write_csv(path: Path, rows: List[Dict[str, Any]]):
    fields: List[str] = []
    for r in rows:
        for k in r:
            if k not in fields:
                fields.append(k)
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k) for k in fields})


def save_records(records: List[Dict[str, Any]], report_dir: Path, file_tag: str = ""):
    report_dir.mkdir(parents=True, exist_ok=True)
    with open(report_dir / f"{REPORT_PREFIX}_records{file_tag}.json", "w", encoding="utf-8") as f:
        json.dump(records, f, indent=2, ensure_ascii=False, default=str)


def write_report(records: List[Dict[str, Any]], variants: List[str], report_dir: Path, file_tag: str = ""):
    report_dir.mkdir(parents=True, exist_ok=True)
    for v in variants:
        recs = [item[v] for item in records if v in item]
        if not recs:
            continue
        rows = build_report_rows(recs, collect_ab_keys(recs))
        title = f"MAO_MTFMPP [{v}]（单次运行）"
        print_table(title, rows)
        write_csv(report_dir / f"{REPORT_PREFIX}_table_{v}.csv", rows)
        write_markdown(report_dir / f"{REPORT_PREFIX}_table_{v}.md", title, rows)
    print(f"\n  ✓ 汇总表已保存: {report_dir}")
    print(f"      {', '.join(f'{REPORT_PREFIX}_table_{v}.(csv|md)' for v in variants)}")
    print(f"      {REPORT_PREFIX}_records{file_tag}.json  (含每个任务的 Top-1/Top-5 API 与完整评分明细)")


def print_comparison(analyses: List[Dict[str, Any]]):
    if not analyses:
        return
    print("\n" + "=" * 78)
    print("RAW vs REPAIRED 结构对比 (proxy 自检分，非正式评估器)")
    print("=" * 78)
    hdr = f"{'scenario':<22}{'tasks r/R':>10}{'deps r/R':>10}{'gw r/R':>8}{'proxy raw':>11}{'proxy rep':>11}"
    print(hdr)
    print("-" * len(hdr))
    sums = {"raw": 0.0, "rep": 0.0}
    for a in analyses:
        rr, rp = a["raw_extracted"], a["repaired_extracted"]
        print(f"{a['scenario'][:21]:<22}"
              f"{str(rr['activities']) + '/' + str(rp['tasks']):>10}"
              f"{str(rr['dependencies']) + '/' + str(rp['dependencies']):>10}"
              f"{str(rr['gateways']) + '/' + str(rp['gateways']):>8}"
              f"{a['proxy_raw']['proxy_score']:>11.3f}{a['proxy_repaired']['proxy_score']:>11.3f}")
        sums["raw"] += a["proxy_raw"]["proxy_score"]
        sums["rep"] += a["proxy_repaired"]["proxy_score"]
    n = len(analyses)
    print("-" * len(hdr))
    print(f"{'MEAN':<22}{'':>10}{'':>10}{'':>8}{sums['raw']/n:>11.3f}{sums['rep']/n:>11.3f}")

    agg: Dict[str, int] = {}
    for a in analyses:
        for k, v in a["tolerant_parse"]["defects"].items():
            agg[k] = agg.get(k, 0) + v
        if a["tolerant_parse"]["stats"]["single_branch_gateways"]:
            agg["single_branch_gateways"] = agg.get("single_branch_gateways", 0) + a["tolerant_parse"]["stats"]["single_branch_gateways"]
        if a["tolerant_parse"]["stats"]["empty_branches"]:
            agg["empty_branches"] = agg.get("empty_branches", 0) + a["tolerant_parse"]["stats"]["empty_branches"]
        if not a["tolerant_parse"]["stats"]["has_start"]:
            agg["scenarios_without_startEvent"] = agg.get("scenarios_without_startEvent", 0) + 1
        if not a["tolerant_parse"]["stats"]["has_end"]:
            agg["scenarios_without_endEvent"] = agg.get("scenarios_without_endEvent", 0) + 1
        if a["fallback_template_used"]:
            agg["scenarios_fallback_template"] = agg.get("scenarios_fallback_template", 0) + 1
        if a["mao_chain"].get("chain_failed"):
            agg["scenarios_mao_chain_failed"] = agg.get("scenarios_mao_chain_failed", 0) + 1
    print("\nMAO 原始输出缺陷汇总 (跨场景累计):")
    if agg:
        for k in sorted(agg):
            print(f"  - {k}: {agg[k]}")
    else:
        print("  (未发现XML层面的缺陷)")
    print("  - 所有场景: RAW适配器不产出 dependencies (MAO的嵌套XML里边是隐含的)")
    print("=" * 78)


def _parse_args():
    p = argparse.ArgumentParser(description="MAO_MTFMPP 单次评估运行（raw + repaired 双版本）")
    p.add_argument("--variant", choices=["raw", "repaired", "both"], default="both",
                   help="给哪个输出版本打分/出报告（一次 MAO 生成本来就同时产出两个版本，save_results 仍两份都存）")
    p.add_argument("--scenarios", type=str, default=None, help="逗号分隔的场景名（默认全部场景）")
    p.add_argument("--no-score", action="store_true", help="不加载评分模块，只做生成 + 结构统计")
    return p.parse_args()


def main():
    args = _parse_args()
    variants = list(VARIANTS) if args.variant == "both" else [args.variant]
    file_tag = "" if args.variant == "both" else f"_{args.variant}"

    print("\n")
    print("╔" + "═" * 58 + "╗")
    print("║" + " " * 4 + "MAO_MTFMPP 评估运行脚本 (v3: raw + repaired)" + " " * 5 + "║")
    print("║" + " " * 4 + "真实MAO四阶段多智能体 + 真实MTFM++双任务推荐" + " " * 3 + "║")
    print("╚" + "═" * 58 + "╝")
    print(f"  评分/报告版本: {variants}   (每个场景单次运行)")

    data_path = SCRIPT_DIR / "data"
    embedding_path = SCRIPT_DIR / "embedding"

    if not data_path.exists():
        data_path = MODEL_ROOT / "data"
    if not embedding_path.exists():
        embedding_path = MODEL_ROOT / "embedding"

    scorer_module = scorer_instance = None
    if not args.no_score:
        scorer_module, scorer_instance = _init_scorer()
    else:
        print("  (--no-score: 跳过评分)")

    system = MAOMTFMPPSystem(
        data_path=str(data_path),
        embedding_path=str(embedding_path)
    )

    scenarios = list(BPMN_TEST_SCENARIOS)
    if args.scenarios:
        wanted = [s.strip() for s in args.scenarios.split(",") if s.strip()]
        scenarios = [s for s in scenarios if s.name in wanted]
        missing = [w for w in wanted if w not in {s.name for s in scenarios}]
        if missing:
            print(f"  ⚠ 这些场景名没匹配上: {missing}；scenarios.py 里可用的场景: "
                  f"{[s.name for s in BPMN_TEST_SCENARIOS]}")
        if not scenarios:
            print("  ✗ 没有可运行的场景，退出")
            return

    output_dir = EVAL_ROOT / "results"
    raw_dir = output_dir / "mao_raw_outputs"
    raw_dir.mkdir(parents=True, exist_ok=True)
    report_dir = output_dir / REPORT_SUBDIR

    print("\n" + "=" * 60)
    print("开始评估测试场景")
    print("=" * 60)
    print(f"本次共 {len(scenarios)} 个场景: {[s.name for s in scenarios]}")

    raw_results, repaired_results, analyses = [], [], []
    records: List[Dict[str, Any]] = []
    aborted = False
    for i, scenario in enumerate(scenarios):
        print(f"\n>>> 场景 [{i+1}/{len(scenarios)}]: {scenario.name}")
        t0 = time.time()
        item: Dict[str, Any] = {"scenario": scenario.name}
        fail_reason = None
        try:
            out = system.run(scenario.requirement, scenario.name)
            elapsed = time.time() - t0
            raw_results.append(out["raw"])
            repaired_results.append(out["repaired"])
            analyses.append(out["analysis"])

            try:
                fname = MAOGenerator._sanitize_name(scenario.name) + ".xml"
                (raw_dir / fname).write_text(out["raw_text"], encoding="utf-8")
            except Exception as e:
                print(f"  ⚠ 原始XML保存失败: {e}")

            r, p = out["raw"], out["repaired"]
            print(f"\n结果摘要 (raw → repaired):")
            print(f"  - 任务数:   {len(r.tasks)} → {len(p.tasks)}")
            print(f"  - 依赖数:   {len(r.dependencies)} → {len(p.dependencies)}")
            print(f"  - 网关数:   {len(r.gateways)} → {len(p.gateways)}")
            print(f"  - API绑定数: {len(r.api_bindings)} → {len(p.api_bindings)}")
            print(f"  - 执行时间: {r.execution_time:.2f}s → {p.execution_time:.2f}s")

            raw_text = out["raw_text"] or ""
            format_errors = check_bpmn_format(raw_text) if raw_text else ["empty bpmn_xml"]
            print("\n[评分]" if scorer_module is not None else "\n[结构统计]")
            for v in variants:
                res = out["raw"] if v == "raw" else out["repaired"]
                rec = build_record(v, res, scenario.name, elapsed, raw_text, format_errors,
                                   out["analysis"], scorer_module, scorer_instance)
                item[v] = rec
                _print_run_line(v, rec)
        except KeyboardInterrupt:
            print(f"\n  ⚠ 用户中断，跳过场景 {scenario.name}")
            print(f"    (再次按Ctrl+C退出整个程序)")
            fail_reason = "interrupted"
            try:
                time.sleep(2)
            except KeyboardInterrupt:
                print(f"\n程序被用户终止")
                aborted = True
        except Exception as e:
            print(f"  ✗ 场景 {scenario.name} 处理失败: {e}")
            traceback.print_exc()
            fail_reason = str(e)

        if fail_reason is not None:
            for v in variants:
                item.setdefault(v, _failed_record(scenario.name, v, fail_reason, time.time() - t0))
        records.append(item)
        save_records(records, report_dir, file_tag)
        if aborted:
            break

    if raw_results:
        save_results(raw_results, str(output_dir), "mao_mtfmpp_raw")
        save_results(repaired_results, str(output_dir), "mao_mtfmpp_repaired")
    else:
        print("\n  ⚠ 没有任何场景成功，未写出 raw / repaired 结果文件")

    analysis_file = output_dir / "mao_mtfmpp_structure_analysis.json"
    try:
        with open(analysis_file, "w", encoding="utf-8") as f:
            json.dump({
                "config": {"ADD_START_END": ADD_START_END, "USE_FALLBACK_TEMPLATE": USE_FALLBACK_TEMPLATE,
                           "REPAIR_RETRIES": REPAIR_RETRIES, "FORCE_PARALLEL_JOIN": FORCE_PARALLEL_JOIN,
                           "APPLY_TASK_TRIM": APPLY_TASK_TRIM},
                "note": "proxy_* 为脚本内置自检分，非正式 Structural Validity；正式数值请用评估器分别评估 raw/repaired 两份JSON。",
                "scenarios": analyses,
            }, f, indent=2, ensure_ascii=False)
        print(f"\n✓ 错误分析已保存: {analysis_file}")
    except Exception as e:
        print(f"\n⚠ 错误分析保存失败: {e}")

    print_comparison(analyses)

    write_report(records, variants, report_dir, file_tag)

    print("\n" + "=" * 60)
    print("MAO_MTFMPP 评估完成! (raw + repaired 已分别保存)")
    print("=" * 60)


if __name__ == "__main__":
    main()
