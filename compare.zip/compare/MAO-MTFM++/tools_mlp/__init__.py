"""
tools模块 - 数据加载支持
========================
支持两种模式:
1. 词嵌入模式 (use_roberta=False)
2. RoBERTa特征模式 (use_roberta=True) - 推荐

数据要求:
- data/: JSON数据文件
- embedding/: RoBERTa预计算特征
  - mashup_features_roberta.npy [num_mashup, 768]
  - api_features_roberta.npy [num_api, 768]
"""

import os
import json
import numpy as np
import torch
from torch.utils.data import Dataset
from pathlib import Path
from collections import Counter
import random
import time


class MashupDataset(Dataset):
    """
    Mashup数据集 - 支持词嵌入和RoBERTa两种模式

    返回格式: (index, features, category_labels, api_labels)
    """

    def __init__(self, data_path: str = None, embedding_path: str = None, use_roberta: bool = True):
        self.data_path = Path(data_path) if data_path else Path(__file__).parent.parent / "data"
        self.embedding_path = Path(embedding_path) if embedding_path else Path(__file__).parent.parent / "embedding"
        self.use_roberta = use_roberta

        self._load_data()

        if use_roberta:
            self._load_roberta_features()
        else:
            self._build_vocab()
            self._build_indices()

        self._build_labels()

    def _load_data(self):
        """加载ProgrammableWeb数据"""
        with open(self.data_path / "api_name.json", 'r', encoding='utf-8') as f:
            self.api_names = json.load(f)
        self.api_to_idx = {name: i for i, name in enumerate(self.api_names)}

        with open(self.data_path / "mashup_name.json", 'r', encoding='utf-8') as f:
            self.mashup_names = json.load(f)
        self.name = self.mashup_names

        with open(self.data_path / "mashup_description.json", 'r', encoding='utf-8') as f:
            self.mashup_descriptions = json.load(f)

        with open(self.data_path / "mashup_used_api.json", 'r', encoding='utf-8') as f:
            self.mashup_used_apis = json.load(f)

        with open(self.data_path / "category_list.json", 'r', encoding='utf-8') as f:
            self.categories = json.load(f)
        self.category_to_idx = {c: i for i, c in enumerate(self.categories)}

        with open(self.data_path / "mashup_category.json", 'r', encoding='utf-8') as f:
            self.mashup_categories = json.load(f)

        self.num_api = len(self.api_names)
        self.num_mashup = len(self.mashup_names)
        self.num_category = len(self.categories)

        print(f"[Dataset] Loaded: {self.num_mashup} mashups, {self.num_api} APIs, {self.num_category} categories")

    def _load_roberta_features(self):
        """加载RoBERTa预计算特征"""
        mashup_feat_path = self.embedding_path / "mashup_features_roberta.npy"
        api_feat_path = self.embedding_path / "api_features_roberta.npy"

        if mashup_feat_path.exists():
            self.mashup_features = np.load(mashup_feat_path)
            self.embed_dim = self.mashup_features.shape[1]
            print(f"[Dataset] ✓ Loaded mashup RoBERTa features: {self.mashup_features.shape}")
        else:
            print(f"[Dataset] ✗ mashup_features_roberta.npy not found!")
            print(f"[Dataset] → Falling back to word embedding mode")
            self.use_roberta = False
            self._build_vocab()
            self._build_indices()
            return

        if api_feat_path.exists():
            self.api_features = np.load(api_feat_path)
            print(f"[Dataset] ✓ Loaded API RoBERTa features: {self.api_features.shape}")
        else:
            self.api_features = None
            print(f"[Dataset] ⚠ api_features_roberta.npy not found (optional)")

    def _build_vocab(self, min_freq: int = 2, max_vocab: int = 10000):
        """构建词汇表 (词嵌入模式)"""
        word_freq = Counter()
        for desc in self.mashup_descriptions:
            if isinstance(desc, list):
                for word in desc:
                    word_freq[word.lower()] += 1
            else:
                for word in str(desc).lower().split():
                    word_freq[word] += 1

        self.vocab = {'<PAD>': 0, '<UNK>': 1}
        idx = 2
        for word, freq in word_freq.most_common(max_vocab - 2):
            if freq >= min_freq:
                self.vocab[word] = idx
                idx += 1

        self.vocab_size = len(self.vocab)
        self.embed_dim = 128
        print(f"[Dataset] Vocab size: {self.vocab_size}")

    def _text_to_indices(self, text, max_len: int = 100) -> list:
        """文本转词索引"""
        if isinstance(text, list):
            words = [w.lower() for w in text]
        else:
            words = str(text).lower().split()

        indices = []
        for word in words[:max_len]:
            indices.append(self.vocab.get(word, 1))

        while len(indices) < max_len:
            indices.append(0)

        return indices[:max_len]

    def _build_indices(self, max_len: int = 100):
        """构建所有Mashup的词索引"""
        self.max_doc_len = max_len
        self.mashup_indices = []
        for desc in self.mashup_descriptions:
            self.mashup_indices.append(self._text_to_indices(desc, max_len))

    def _build_labels(self):
        """构建标签矩阵"""
        self.api_labels = np.zeros((self.num_mashup, self.num_api), dtype=np.float32)
        for i, apis in enumerate(self.mashup_used_apis):
            for api in apis:
                if api in self.api_to_idx:
                    self.api_labels[i, self.api_to_idx[api]] = 1.0

        self.category_labels = np.zeros((self.num_mashup, self.num_category), dtype=np.float32)
        for i, cats in enumerate(self.mashup_categories):
            for cat in cats:
                if cat in self.category_to_idx:
                    self.category_labels[i, self.category_to_idx[cat]] = 1.0

    def __len__(self):
        return self.num_mashup

    def __getitem__(self, idx):
        """返回: (index, features, category_labels, api_labels)"""
        if self.use_roberta:
            features = torch.FloatTensor(self.mashup_features[idx])
        else:
            features = torch.LongTensor(self.mashup_indices[idx])

        category_target = torch.FloatTensor(self.category_labels[idx])
        api_target = torch.FloatTensor(self.api_labels[idx])

        return idx, features, category_target, api_target

    def encode_text(self, text: str) -> torch.Tensor:
        """编码文本 (词嵌入模式)"""
        if self.use_roberta:
            raise NotImplementedError("RoBERTa mode requires pre-computed features")
        indices = self._text_to_indices(text)
        return torch.LongTensor(indices).unsqueeze(0)


class TextDataset:
    """数据集配置类"""
    def __init__(self, data_path: str = None, embedding_path: str = None, use_roberta: bool = True):
        self.mashup_ds = MashupDataset(data_path, embedding_path, use_roberta)

        self.embed_dim = self.mashup_ds.embed_dim
        self.max_doc_len = getattr(self.mashup_ds, 'max_doc_len', 100)
        self.num_category = self.mashup_ds.num_category
        self.num_mashup = self.mashup_ds.num_mashup
        self.num_api = self.mashup_ds.num_api
        self.vocab_size = getattr(self.mashup_ds, 'vocab_size', 10000)
        self.embed = None
        self.use_roberta = self.mashup_ds.use_roberta


def get_indices(dataset, train_ratio=0.8, val_ratio=0.1, seed=42):
    """划分训练/验证/测试集"""
    random.seed(seed)
    n = len(dataset)
    indices = list(range(n))
    random.shuffle(indices)

    train_size = int(n * train_ratio)
    val_size = int(n * val_ratio)

    train_idx = indices[:train_size]
    val_idx = indices[train_size:train_size + val_size]
    test_idx = indices[train_size + val_size:]

    return train_idx, val_idx, test_idx


def get_time(start_time):
    """计算耗时"""
    return f"{time.time() - start_time:.2f}s"


class EarlyStopping:
    """早停机制"""
    def __init__(self, patience=7, path='checkpoint.pth'):
        self.patience = patience
        self.path = path
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = float('inf')

    def __call__(self, val_loss, model):
        score = -val_loss
        if self.best_score is None:
            self.best_score = score
            self.save_checkpoint(val_loss, model)
        elif score < self.best_score:
            self.counter += 1
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_score = score
            self.save_checkpoint(val_loss, model)
            self.counter = 0

    def save_checkpoint(self, val_loss, model):
        torch.save(model.state_dict(), self.path)
        self.val_loss_min = val_loss


def metric(labels, predictions, top_k_list=[1, 5, 10, 15, 20]):
    """计算评估指标"""
    labels = labels.numpy() if hasattr(labels, 'numpy') else labels
    predictions = predictions.numpy() if hasattr(predictions, 'numpy') else predictions

    batch_size = labels.shape[0]
    ndcg_list = np.zeros(len(top_k_list))
    recall_list = np.zeros(len(top_k_list))
    ap_list = np.zeros(len(top_k_list))
    precision_list = np.zeros(len(top_k_list))

    for i in range(batch_size):
        pred = predictions[i]
        label = labels[i]
        total_relevant = label.sum()

        for k_idx, k in enumerate(top_k_list):
            top_k_idx = np.argsort(pred)[::-1][:k]

            hits = label[top_k_idx].sum()
            precision_list[k_idx] += hits / k

            if total_relevant > 0:
                recall_list[k_idx] += hits / total_relevant

            dcg = 0
            for j, idx in enumerate(top_k_idx):
                if label[idx] > 0:
                    dcg += 1 / np.log2(j + 2)

            ideal_num = min(int(total_relevant), k)
            idcg = sum(1 / np.log2(j + 2) for j in range(ideal_num))
            ndcg_list[k_idx] += dcg / idcg if idcg > 0 else 0

            ap = 0
            relevant_count = 0
            for j, idx in enumerate(top_k_idx):
                if label[idx] > 0:
                    relevant_count += 1
                    ap += relevant_count / (j + 1)
            ap_list[k_idx] += ap / min(total_relevant, k) if total_relevant > 0 else 0

    return (ndcg_list / batch_size, recall_list / batch_size,
            ap_list / batch_size, precision_list / batch_size)
