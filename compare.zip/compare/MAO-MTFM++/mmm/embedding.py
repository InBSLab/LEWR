import os
import sys
import time
from tenacity import (
    retry,
    stop_after_attempt,
    wait_random_exponential,
    wait_fixed
)
from utils import log_and_print_online
sys.path.append(os.path.join(os.getcwd(), "mmm"))


# embedding class should have functions: get_text_embedding() and get_code_embedding()
class OpenAIEmbedding:
    """
    原版 MAO(2) 用的方案：调用 OpenAI text-embedding-ada-002。
    【保留但改为按需导入 openai】——这样即使不装 openai 包、不配 OpenAI key，
    只要 config.yaml 里 embedding_method 选的是 "Local"，这个类就完全不会被
    实例化、不会因为 import 失败而拖垮整个 mmm.embedding 模块。
    如果确实想切回OpenAI方案，把 config.yaml 的 embedding_method 改回 "OpenAI"，
    并且 pip install openai、设置 OPENAI_EMBEDDING_API_KEY 环境变量即可。
    """

    def __init__(self, **params):
        from openai import OpenAI
        self._client = OpenAI(api_key=os.getenv("OPENAI_EMBEDDING_API_KEY", ""))

        self.code_prompt_tokens = 0
        self.text_prompt_tokens = 0
        self.code_total_tokens = 0
        self.text_total_tokens = 0

        self.prompt_tokens = 0
        self.total_tokens = 0

    @retry(wait=wait_random_exponential(min=2, max=5), stop=stop_after_attempt(10))
    def get_text_embedding(self, text: str):
        if len(text) > 8191:
            text = text[:8190]
        response = self._client.embeddings.create(input=text, model="text-embedding-ada-002")
        # 新版 openai>=1.0 SDK 返回对象，用属性访问 (.data[0].embedding)，
        # 不能再用旧版 openai==0.27.8 的字典下标写法 (原版代码这里其实是错的)。
        embedding = response.data[0].embedding
        log_and_print_online(
            "Get text embedding from {}:\n**[OpenAI_Usage_Info Receive]**\nprompt_tokens: {}\ntotal_tokens: {}\n".format(
                response.model, response.usage.prompt_tokens, response.usage.total_tokens))
        self.text_prompt_tokens += response.usage.prompt_tokens
        self.text_total_tokens += response.usage.total_tokens
        self.prompt_tokens += response.usage.prompt_tokens
        self.total_tokens += response.usage.total_tokens
        return embedding

    @retry(wait=wait_random_exponential(min=10, max=60), stop=stop_after_attempt(10))
    def get_code_embedding(self, code: str):
        if len(code) == 0:
            code = "#"
        elif len(code) > 8191:
            code = code[:8190]
        response = self._client.embeddings.create(input=code, model="text-embedding-ada-002")
        embedding = response.data[0].embedding
        log_and_print_online(
            "Get code embedding from {}:\n**[OpenAI_Usage_Info Receive]**\nprompt_tokens: {}\ntotal_tokens: {}\n".format(
                response.model, response.usage.prompt_tokens, response.usage.total_tokens))
        self.code_prompt_tokens += response.usage.prompt_tokens
        self.code_total_tokens += response.usage.total_tokens
        self.prompt_tokens += response.usage.prompt_tokens
        self.total_tokens += response.usage.total_tokens
        return embedding


# ============================================================================
# 本地开源embedding方案（默认使用，不依赖OpenAI，不引入DeepSeek之外的第二个商业API）
# ============================================================================
class LocalEmbedding:
    """
    用本地的 sentence-transformers 模型做文本/代码向量化，接口跟 OpenAIEmbedding
    保持一致 (get_text_embedding / get_code_embedding)，这样 memory.py 里
    MemoryBase.__init__ 只需要按配置切换实例化哪个类，其余检索逻辑
    （cosine_similarity、FAISS建索引、top_k筛选）完全不用改。

    默认模型 all-MiniLM-L6-v2：体积小(约80MB)、CPU上跑得动、检索质量对这种
    "找相似历史任务/代码"的场景够用。第一次运行会自动从HuggingFace下载模型，
    之后会有本地缓存，不需要每次都联网下载。
    """

    def __init__(self, model_name: str = None, **params):
        model_name = model_name or os.getenv("LOCAL_EMBEDDING_MODEL", "all-MiniLM-L6-v2")

        # 【修复】huggingface.co 在国内直连经常超时(你日志里那个
        # ConnectTimeoutError 就是这个)。sentence-transformers/huggingface_hub
        # 支持通过 HF_ENDPOINT 环境变量换成镜像站，这里如果你没有自己设置过
        # HF_ENDPOINT，就默认帮你指向 hf-mirror.com（国内可访问的镜像）。
        # 如果你所在网络环境反而是 hf-mirror.com 连不上、huggingface.co 能连，
        # 可以自己提前 os.environ["HF_ENDPOINT"] = "https://huggingface.co" 覆盖掉。
        os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")

        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as e:
            raise ImportError(
                "使用本地embedding方案需要先安装 sentence-transformers：\n"
                "    pip install sentence-transformers\n"
                f"原始错误: {e}"
            )
        try:
            self._model = SentenceTransformer(model_name)
        except Exception as e:
            raise RuntimeError(
                f"加载本地embedding模型 '{model_name}' 失败: {e}\n"
                "如果是网络超时/连不上 huggingface.co 或 hf-mirror.com："
                "可以在能联网的机器上先手动下载模型到本地目录，"
                "然后设置环境变量 LOCAL_EMBEDDING_MODEL 指向那个本地目录路径"
                "（sentence-transformers支持直接传本地路径），"
                "或者设置 HF_ENDPOINT 指向你能访问的镜像站。"
            )

        # 保留跟 OpenAIEmbedding 一样的计数器字段，纯粹是为了兼容
        # memory.py 里最后打印 [Conclusion] 汇总日志那几行代码，不报错。
        # 本地模型没有"计费token"这个概念，这几个值恒为0。
        self.code_prompt_tokens = 0
        self.text_prompt_tokens = 0
        self.code_total_tokens = 0
        self.text_total_tokens = 0
        self.prompt_tokens = 0
        self.total_tokens = 0

    def get_text_embedding(self, text: str):
        if len(text) > 8191:
            text = text[:8190]
        embedding = self._model.encode(text, show_progress_bar=False).tolist()
        log_and_print_online(
            "Get text embedding from local model, text length: {}\n".format(len(text)))
        return embedding

    def get_code_embedding(self, code: str):
        if len(code) == 0:
            code = "#"
        elif len(code) > 8191:
            code = code[:8190]
        embedding = self._model.encode(code, show_progress_bar=False).tolist()
        log_and_print_online(
            "Get code embedding from local model, code length: {}\n".format(len(code)))
        return embedding
