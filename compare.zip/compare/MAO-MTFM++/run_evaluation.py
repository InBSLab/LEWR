import os
import sys
import re
import json
import time
import logging
import traceback
import numpy as np
import torch
import torch.nn as nn
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

SCRIPT_DIR = Path(__file__).parent.absolute()
PROJECT_ROOT = SCRIPT_DIR.parent.parent
EVAL_ROOT = SCRIPT_DIR.parent

POSSIBLE_MODEL_PATHS = [
    PROJECT_ROOT / "models" / "MAO" / "MAO_MTFMPP" / "BPMN_MAO_MLP",
    PROJECT_ROOT / "MAO_MTFMPP1" / "BPMN_MAO_MLP",
    PROJECT_ROOT.parent / "MAO_MTFMPP1" / "BPMN_MAO_MLP",
    SCRIPT_DIR / "BPMN_MAO_MLP",
    SCRIPT_DIR,
]


def find_model_root():

    for path in POSSIBLE_MODEL_PATHS:
        checkpoint_path = path / "checkpoints" / "mtfmpp_best.pth"
        if checkpoint_path.exists():
            print(f"  找到模型目录: {path}")
            return path
        data_path = path / "data" / "api_name.json"
        if data_path.exists():
            print(f"  找到数据目录: {path}")
            return path
        mao_path = path / "MAO" / "chat_chain.py"
        if mao_path.exists():
            print(f"  找到MAO多智能体框架目录: {path}")
            return path
    return POSSIBLE_MODEL_PATHS[0]


MODEL_ROOT = find_model_root()

sys.path.insert(0, str(EVAL_ROOT / "common"))
sys.path.insert(0, str(MODEL_ROOT))

from scenarios import BPMN_TEST_SCENARIOS, UnifiedOutput, save_results

DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "")
os.environ.setdefault("DEEPSEEK_API_KEY", DEEPSEEK_API_KEY)

os.environ.setdefault("OPENAI_API_KEY", DEEPSEEK_API_KEY)

try:
    from camel.typing import ModelType
    from MAO.chat_chain import ChatChain
    _MAO_IMPORT_ERROR = None
except Exception as _e:
    ChatChain = None
    ModelType = None
    _MAO_IMPORT_ERROR = _e


class MTFMPPLite(nn.Module):


    def __init__(self, num_api, num_category, embed_dim=768, feature_dim=32,
                 api_tag_embed=None, dropout=0.2):
        super(MTFMPPLite, self).__init__()

        if api_tag_embed is not None:
            self.api_tag_embed = nn.Embedding.from_pretrained(api_tag_embed, freeze=True)
        else:
            self.api_tag_embed = nn.Embedding(num_api, num_category)

        self.api_tag_layer = nn.Sequential(
            nn.Linear(num_category, feature_dim),
            nn.Tanh()
        )

        self.mashup_encoder = nn.Sequential(
            nn.Linear(embed_dim, 256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, 128),
            nn.ReLU()
        )

        self.sc_output = nn.Linear(128, num_api)

        self.fic_input = nn.Sequential(
            nn.Linear(128, feature_dim),
            nn.Tanh()
        )

        self.fusion_layer = nn.Linear(num_api * 2, num_api)

        self.api_output = nn.Linear(num_api, num_api)
        self.cat_output = nn.Linear(num_api, num_category)

        self.dropout = nn.Dropout(dropout)
        self.sigmoid = nn.Sigmoid()
        self.tanh = nn.Tanh()

    def forward(self, x):
        api_tag = self.api_tag_layer(self.api_tag_embed.weight).t()
        h = self.mashup_encoder(x)
        u_sc = self.sc_output(h)
        u_fic = self.tanh(torch.matmul(self.fic_input(h), api_tag))
        u = self.fusion_layer(torch.cat([u_sc, u_fic], dim=1))
        u = self.dropout(u)
        return self.sigmoid(self.api_output(u)), self.sigmoid(self.cat_output(u))


MTFMPPModel = MTFMPPLite


class MAOGenerator:


    def __init__(self, config_name: str = "Default", org_name: str = "MAO_MTFMPP_Eval",
                 model_type=None):
        if ChatChain is None:
            raise ImportError(
                f"无法导入压缩包中的MAO多智能体模块 (MAO.chat_chain.ChatChain)。\n"
                f"原始错误: {_MAO_IMPORT_ERROR}\n"
                f"请确认 MODEL_ROOT ({MODEL_ROOT}) 下存在 MAO/、camel/、CompanyConfig/ 目录，"
                f"并且 camel/MAO 所需的第三方依赖包已安装。"
            )
        self.config_name = config_name
        self.org_name = org_name
        self.model_type = model_type if model_type is not None else ModelType.GPT_4
        self._call_count = 0

    def _get_config_paths(self) -> Tuple[str, str, str]:

        config_dir = MODEL_ROOT / "CompanyConfig" / self.config_name
        default_config_dir = MODEL_ROOT / "CompanyConfig" / "Default"

        paths = []
        for fname in ["ChatChainConfig.json", "PhaseConfig.json", "RoleConfig.json"]:
            company_path = config_dir / fname
            default_path = default_config_dir / fname
            paths.append(str(company_path if company_path.exists() else default_path))
        return tuple(paths)

    @staticmethod
    def _sanitize_name(name: str) -> str:

        safe = re.sub(r'[^\w\-]+', '_', str(name)).strip('_')
        return safe or "Scenario"

    def generate(self, task: str, scenario_name: str = "Scenario") -> str:

        self._call_count += 1
        project_name = f"{self._sanitize_name(scenario_name)}_{self._call_count}"

        config_path, config_phase_path, config_role_path = self._get_config_paths()

        print("\n[MAO] 调用真实多智能体框架 (MAO.chat_chain.ChatChain)")
        print(f"  config_path       : {config_path}")
        print(f"  config_phase_path : {config_phase_path}")
        print(f"  config_role_path  : {config_role_path}")
        print(f"  project_name      : {project_name}")

        chat_chain = ChatChain(
            config_path=config_path,
            config_phase_path=config_phase_path,
            config_role_path=config_role_path,
            task_prompt=task,
            project_name=project_name,
            org_name=self.org_name,
            model_type=self.model_type,
        )

        log_dir = os.path.dirname(chat_chain.log_filepath)
        if log_dir and not os.path.exists(log_dir):
            os.makedirs(log_dir, exist_ok=True)

        logging.basicConfig(
            filename=chat_chain.log_filepath,
            level=logging.INFO,
            format='[%(asctime)s %(levelname)s] %(message)s',
            datefmt='%Y-%d-%m %H:%M:%S',
            encoding="utf-8",
            force=True,
        )

        try:
            print("  [1/4] 预处理 (pre_processing)...")
            chat_chain.pre_processing()

            print("  [2/4] 招募人员 (make_recruitment)...")
            chat_chain.make_recruitment()

            print("  [3/4] 执行处理链 (execute_chain): "
                  "ProcessGeneration -> ActivityRefinement -> Review -> Test ...")
            chat_chain.execute_chain()

            print("  [4/4] 后处理 (post_processing)...")
            chat_chain.post_processing()

        except KeyboardInterrupt:
            raise
        except Exception as e:
            print(f"  ✗ MAO ChatChain 执行失败: {e}")
            traceback.print_exc()
            env_dict = chat_chain.chat_env.env_dict
            partial = (env_dict.get('reviewed_process_text', '')
                       or env_dict.get('refinement_process_text', '')
                       or env_dict.get('initial_process_text', ''))
            return partial if partial else "<process></process>"

        process_text = chat_chain.chat_env.env_dict.get('reviewed_process_text', '')
        print("  ✓ MAO完成!")
        return process_text if process_text else "<process></process>"

    def extract_activities(self, process: str) -> List[Dict]:

        activities = []
        pattern = r'<activity[^>]*role=[\'"]([^\'"]*)[\'"][^>]*action=[\'"]([^\'"]*)[\'"][^>]*objects=[\'"]([^\'"]*)[\'"][^>]*id=[\'"]([^\'"]*)[\'"][^>]*/>'

        for match in re.finditer(pattern, process):
            activities.append({
                'id': match.group(4),
                'role': match.group(1),
                'action': match.group(2),
                'objects': match.group(3)
            })

        if not activities:
            pattern2 = r'<activity[^>]*id=[\'"]([^\'"]*)[\'"][^>]*>'
            for i, match in enumerate(re.finditer(pattern2, process)):
                activities.append({
                    'id': match.group(1),
                    'role': '',
                    'action': f'Activity {i+1}',
                    'objects': ''
                })

        return activities

    def extract_gateways(self, process: str) -> List[Dict]:

        gateways = []

        for gw_type in ['exclusiveGateway', 'parallelGateway', 'inclusiveGateway']:
            pattern = f'<{gw_type}[^>]*id=[\'"]([^\'"]*)[\'"][^>]*>'
            for match in re.finditer(pattern, process):
                gateways.append({
                    'id': match.group(1),
                    'type': gw_type.replace('Gateway', '').lower(),
                    'name': gw_type
                })

        return gateways


class MAOMTFMPPSystem:


    def __init__(self, data_path: str = None, embedding_path: str = None, model_path: str = None,
                 mao_config_name: str = "Default", mao_org_name: str = "MAO_MTFMPP_Eval"):

        print("\n" + "=" * 60)
        print("初始化 MAO + MTFM++")
        print("=" * 60)
        print("  阶段1: MAO (真实四阶段多智能体BPMN生成)")
        print("  阶段2: MTFM++ (SC + FIC + 双任务推荐，真实模型推理)")

        self.data_path = Path(data_path) if data_path else SCRIPT_DIR / "data"
        self.embedding_path = Path(embedding_path) if embedding_path else SCRIPT_DIR / "embedding"

        print("\n[1/4] 初始化MAO生成器...")
        self.mao = MAOGenerator(config_name=mao_config_name, org_name=mao_org_name)
        print("  ✓ MAO (真实四阶段多智能体) 初始化完成")

        print("\n[2/4] 加载API数据...")
        self.api_names = self._load_api_names()
        self.category_list = self._load_categories()
        print(f"  ✓ API数量: {len(self.api_names)}")
        print(f"  ✓ 类别数量: {len(self.category_list)}")

        print("\n[3/4] 初始化MTFM++模型...")
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.mtfmpp_model = self._init_mtfmpp_model(model_path)

        print("\n[4/4] 加载Mashup嵌入特征（用于MTFM++真实推理）...")
        self.mashup_features, self.mashup_descriptions = self._load_mashup_embeddings()

        self._build_keyword_index()

        print("\n" + "=" * 60)
        print("系统初始化完成!")
        print("=" * 60)

    def _load_api_names(self) -> List[str]:

        api_name_file = self.data_path / "api_name.json"
        if api_name_file.exists():
            with open(api_name_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return []

    def _load_categories(self) -> List[str]:

        config_file = MODEL_ROOT / "checkpoints" / "mtfmpp_config.json"
        if config_file.exists():
            with open(config_file, 'r', encoding='utf-8') as f:
                config = json.load(f)
                return config.get('category_list', [])
        return []

    def _init_mtfmpp_model(self, model_path: str = None) -> Optional[MTFMPPModel]:

        if not self.api_names:
            print("  ⚠ 无API数据，MTFM++模型未初始化")
            self.mtfmpp_trained = False
            return None

        if model_path is None:
            model_path = MODEL_ROOT / "checkpoints" / "mtfmpp_best.pth"

        model_path = Path(model_path)

        if model_path.exists():
            try:
                checkpoint = torch.load(model_path, map_location=self.device, weights_only=False)

                if 'api_tag_embed.weight' in checkpoint:
                    num_api = checkpoint['api_tag_embed.weight'].shape[0]
                    num_category = checkpoint['api_tag_embed.weight'].shape[1]
                else:
                    num_api = len(self.api_names)
                    num_category = max(len(self.category_list), 20)

                if 'mashup_encoder.0.weight' in checkpoint:
                    embed_dim = checkpoint['mashup_encoder.0.weight'].shape[1]
                else:
                    embed_dim = 768

                if 'fic_input.0.weight' in checkpoint:
                    feature_dim = checkpoint['fic_input.0.weight'].shape[0]
                else:
                    feature_dim = 32

                print(f"  从checkpoint推断参数:")
                print(f"    - num_api: {num_api}")
                print(f"    - num_category: {num_category}")
                print(f"    - embed_dim: {embed_dim}")
                print(f"    - feature_dim: {feature_dim}")

                api_tag_embed = None
                tag_file = MODEL_ROOT / "checkpoints" / "api_tag_embed.npy"
                if tag_file.exists():
                    api_tag_embed = torch.FloatTensor(np.load(str(tag_file)))

                model = MTFMPPModel(
                    num_api=num_api,
                    num_category=num_category,
                    embed_dim=embed_dim,
                    feature_dim=feature_dim,
                    api_tag_embed=api_tag_embed
                )

                model.load_state_dict(checkpoint)
                model.to(self.device)
                model.eval()

                print(f"  ✓ MTFM++模型已加载: {model_path}")
                self.mtfmpp_trained = True

                return model

            except Exception as e:
                print(f"  ⚠ 加载模型失败: {e}")
                traceback.print_exc()
                self.mtfmpp_trained = False
        else:
            print(f"  ⚠ 模型文件不存在: {model_path}")
            print(f"    将使用关键词匹配作为回退方案")
            self.mtfmpp_trained = False

        return None

    def _load_mashup_embeddings(self) -> Tuple[Optional[np.ndarray], List[Any]]:

        features = None
        descriptions: List[Any] = []

        feat_file = self.embedding_path / "mashup_features_roberta.npy"
        if feat_file.exists():
            try:
                features = np.load(str(feat_file))
                print(f"  ✓ Mashup特征已加载: {features.shape}")
            except Exception as e:
                print(f"  ⚠ Mashup特征加载失败: {e}")
                features = None
        else:
            print(f"  ⚠ 未找到Mashup特征文件: {feat_file}")
            print(f"    MTFM++模型将无法进行真实推理，Stage2会自动回退到关键词匹配")

        desc_file = self.data_path / "mashup_description.json"
        if desc_file.exists():
            try:
                with open(desc_file, 'r', encoding='utf-8') as f:
                    descriptions = json.load(f)
                print(f"  ✓ Mashup描述已加载: {len(descriptions)} 条")
            except Exception as e:
                print(f"  ⚠ Mashup描述加载失败: {e}")
                descriptions = []
        else:
            print(f"  ⚠ 未找到Mashup描述文件: {desc_file}")

        return features, descriptions

    def _find_similar_mashups(self, query: str, top_n: int = 10) -> Tuple[np.ndarray, np.ndarray]:

        if not self.mashup_descriptions:
            return np.array([]), np.array([])

        query_words = set(query.lower().replace('-', ' ').replace('_', ' ').split())

        scores = []
        for desc in self.mashup_descriptions:
            if isinstance(desc, list):
                desc_words = set(str(w).lower() for w in desc)
            else:
                desc_words = set(str(desc).lower().split())

            overlap = len(query_words & desc_words)
            scores.append(overlap / max(len(query_words), 1))

        scores = np.array(scores)
        top_idx = np.argsort(scores)[::-1][:top_n]
        top_scores = scores[top_idx]

        mask = top_scores > 0
        return top_idx[mask], top_scores[mask]

    def _build_keyword_index(self):

        self.keyword_mapping = {
            'ship': ['shipping', 'logistics', 'fedex', 'ups', 'delivery', 'freight', 'post'],
            'shipping': ['shipping', 'logistics', 'fedex', 'ups', 'delivery', 'freight'],
            'logistic': ['logistics', 'shipping', 'fedex', 'ups', 'delivery', 'freight'],
            'payment': ['payment', 'paypal', 'stripe', 'pay'],
            'map': ['google-maps', 'mapbox', 'mapping', 'location', 'geo'],
            'email': ['email', 'sendgrid', 'mailchimp', 'mail'],
            'send': ['sendgrid', 'email', 'mail', 'notification'],
            'package': ['package', 'parcel', 'shipping'],
            'label': ['label', 'print', 'barcode'],
            'insurance': ['insurance', 'policy', 'coverage'],
            'offer': ['offer', 'quote', 'pricing', 'bid'],
            'select': ['select', 'choose', 'pick', 'compare'],
            'warehouse': ['warehouse', 'storage', 'inventory'],
            'order': ['order', 'purchase', 'buy'],
            'clarify': ['clarify', 'check', 'verify', 'determine'],
            'invite': ['invite', 'request', 'ask'],
            'write': ['write', 'create', 'generate'],
            'prepare': ['prepare', 'ready', 'arrange'],
        }

    def _text_relevance(self, query: str) -> np.ndarray:

        scores = np.zeros(len(self.api_names), dtype=np.float32)
        words = set(query.lower().replace('-', ' ').replace('_', ' ').split())

        terms = set()
        for w in words:
            if w in self.keyword_mapping:
                terms.update(self.keyword_mapping[w])
            for key in self.keyword_mapping:
                if key in w or w in key:
                    terms.update(self.keyword_mapping[key])

        for i, api in enumerate(self.api_names):
            api_lower = api.lower().replace('-', ' ').replace('_', ' ')
            api_words = set(api_lower.split())

            for t in terms:
                if t in api_lower:
                    scores[i] += 0.5
                if t in api_words:
                    scores[i] += 0.3

            for w in words:
                if len(w) > 3 and w in api_lower:
                    scores[i] += 0.4

        if scores.max() > 0:
            scores /= scores.max()

        return scores

    def recommend_api(self, action: str, role: str = "", objects: str = "", top_k: int = 5) -> List[Dict]:

        if not self.api_names:
            return [{"api_name": "manual-task", "score": 0.5}]

        query = f"{role} {action} {objects}"

        text_scores = self._text_relevance(query)

        combined = text_scores
        method = "keyword"

        if self.mtfmpp_trained and self.mtfmpp_model is not None and self.mashup_features is not None:
            try:
                idx, sims = self._find_similar_mashups(query)
                if len(idx) > 0:
                    feature_vec = np.average(self.mashup_features[idx], axis=0, weights=sims)
                else:
                    feature_vec = self.mashup_features.mean(axis=0)

                x = torch.FloatTensor(feature_vec).unsqueeze(0).to(self.device)
                with torch.no_grad():
                    api_scores, _cat_scores = self.mtfmpp_model(x)
                    api_scores = api_scores.cpu().numpy()[0]

                combined = 0.6 * api_scores + 0.4 * text_scores
                method = "mtfmpp"
            except Exception as e:
                print(f"  ⚠ MTFM++模型推理失败，本次回退为关键词匹配: {e}")
                combined = text_scores
                method = "keyword"

        top_indices = np.argsort(combined)[::-1][:top_k]

        return [
            {
                "api_name": self.api_names[idx],
                "score": float(combined[idx]),
                "method": method
            }
            for idx in top_indices if combined[idx] > 0
        ]

    def run(self, user_request: str, scenario_name: str) -> UnifiedOutput:

        print(f"\n{'='*60}")
        print(f"MAO_MTFMPP 处理场景: {scenario_name}")
        print(f"{'='*60}")

        start_time = time.time()

        print("\n[Stage 1] MAO - 真实四阶段多智能体BPMN生成")
        bpmn_xml = self.mao.generate(user_request, scenario_name)

        activities = self.mao.extract_activities(bpmn_xml)
        gateways_raw = self.mao.extract_gateways(bpmn_xml)

        print(f"\n  提取到 {len(activities)} 个活动, {len(gateways_raw)} 个网关")
        for act in activities[:5]:
            print(f"    [{act['id']}] {act['role']}: {act['action']} {act['objects']}")
        if len(activities) > 5:
            print(f"    ... 还有 {len(activities) - 5} 个活动")

        print("\n[Stage 2] MTFM++ - API推荐")
        print("-" * 50)

        api_bindings = {}
        for act in activities:
            recommendations = self.recommend_api(
                action=act.get('action', ''),
                role=act.get('role', ''),
                objects=act.get('objects', ''),
                top_k=5
            )

            if recommendations:
                top_api = recommendations[0]
                api_bindings[act['id']] = {
                    "task_name": f"{act.get('role', '')} {act.get('action', '')} {act.get('objects', '')}".strip(),
                    "api_name": top_api['api_name'],
                    "confidence": top_api['score'],
                    "method": top_api.get('method', 'unknown'),
                    "top5_recommendations": [
                        {
                            "rank": idx + 1,
                            "api_name": rec['api_name'],
                            "score": round(rec['score'], 4),
                            "method": rec.get('method', 'unknown')
                        }
                        for idx, rec in enumerate(recommendations)
                    ]
                }
                action_label = act.get('action', '')[:22]
                print(f"  [{act['id']}] {action_label}")
                for idx, rec in enumerate(recommendations):
                    prefix = "    ★ 1." if idx == 0 else f"      {idx+1}."
                    print(f"  {prefix} {rec['api_name']} ({rec['score']:.3f}) [{rec.get('method')}]")

        execution_time = time.time() - start_time

        formatted_tasks = []
        for act in activities:
            formatted_tasks.append({
                "id": act['id'],
                "name": f"{act.get('action', '')} {act.get('objects', '')}".strip(),
                "type": "userTask"
            })

        roles = list(set(act.get('role', '') for act in activities if act.get('role')))

        return UnifiedOutput(
            method="MAO_MTFMPP",
            scenario_name=scenario_name,
            user_request=user_request,
            tasks=formatted_tasks,
            dependencies=[],
            gateways=gateways_raw,
            api_bindings=api_bindings,
            roles=roles,
            execution_time=execution_time,
            extra_info={
                "workflow_generator": "MAO (真实多智能体, 4-Phase: Generation→Refinement→Reviewing→Modifying)",
                "api_recommender": "MTFM++ (SC + FIC + 双任务, 真实模型推理)",
                "mtfmpp_trained": getattr(self, 'mtfmpp_trained', False),
                "bpmn_xml": bpmn_xml[:800] if bpmn_xml else ""
            }
        )


def main():

    print("\n")
    print("╔" + "═" * 58 + "╗")
    print("║" + " " * 6 + "MAO_MTFMPP 评估运行脚本 (修复版 v2)" + " " * 6 + "║")
    print("║" + " " * 4 + "真实MAO四阶段多智能体 + 真实MTFM++双任务推荐" + " " * 3 + "║")
    print("╚" + "═" * 58 + "╝")

    data_path = SCRIPT_DIR / "data"
    embedding_path = SCRIPT_DIR / "embedding"

    if not data_path.exists():
        data_path = MODEL_ROOT / "data"
    if not embedding_path.exists():
        embedding_path = MODEL_ROOT / "embedding"

    system = MAOMTFMPPSystem(
        data_path=str(data_path),
        embedding_path=str(embedding_path)
    )

    print("\n" + "=" * 60)
    print("开始评估测试场景")
    print("=" * 60)

    results = []
    for i, scenario in enumerate(BPMN_TEST_SCENARIOS):
        print(f"\n>>> 场景 [{i+1}/{len(BPMN_TEST_SCENARIOS)}]: {scenario.name}")
        try:
            result = system.run(scenario.requirement, scenario.name)
            results.append(result)

            print(f"\n结果摘要:")
            print(f"  - 任务数: {len(result.tasks)}")
            print(f"  - 网关数: {len(result.gateways)}")
            print(f"  - API绑定数: {len(result.api_bindings)}")
            print(f"  - 角色数: {len(result.roles)}")
            print(f"  - 执行时间: {result.execution_time:.2f}s")
        except KeyboardInterrupt:
            print(f"\n  ⚠ 用户中断，跳过场景 {scenario.name}")
            print(f"    (再次按Ctrl+C退出整个程序)")
            try:
                time.sleep(2)
            except KeyboardInterrupt:
                print(f"\n程序被用户终止")
                break
            continue
        except Exception as e:
            print(f"  ✗ 场景 {scenario.name} 处理失败: {e}")
            traceback.print_exc()
            continue

    output_dir = EVAL_ROOT / "results"
    save_results(results, str(output_dir), "mao_mtfmpp_raw")

    print("\n" + "=" * 60)
    print("MAO_MTFMPP 评估完成!")
    print("=" * 60)


if __name__ == "__main__":
    main()
