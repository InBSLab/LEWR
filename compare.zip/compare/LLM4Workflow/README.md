# LLM4Workflow

This repository has two independent parts:

1. **The original LLM4Workflow application** (`backend/` + `frontend/`) — a
   full-stack tool for LLM-based workflow model generation (LangChain backend +
   React/TypeScript frontend). This is upstream third-party code, included here
   for reference.
2. **A standalone Python re-implementation + evaluation** (`main_LLM4Workflow.py`,
   `tools/`, `evaluate_e2e.py`, `run_evaluation.py`) — reproduces the
   LLM4Workflow method (query rewriting → task planning → API retrieval → DAG
   generation) in pure Python for benchmarking. **This part does not import or
   depend on `backend/` / `frontend/`** — it has its own prompts and its own
   ProgrammableWeb API retrieval.

```
LLM4Workflow/
├── backend/               # original LLM4Workflow backend (LangChain) — third-party
├── frontend/              # original LLM4Workflow frontend (React/Vite/TS) — third-party
├── main_LLM4Workflow.py   # standalone pipeline: LLMClient + LLM4Workflow (4-step method)
├── tools/__init__.py      # APIDatabase — ProgrammableWeb API retrieval (keyword + RoBERTa)
├── evaluate_e2e.py        # end-to-end evaluation metrics
├── run_evaluation.py      # batch evaluation over BPMN test scenarios
├── requirements.txt
├── .env.example
└── .gitignore
```

## The standalone Python pipeline

### Requirements
- Python 3.9+, `requests`, `numpy` (see `requirements.txt`)

### Configuration
LLM calls read `DEEPSEEK_API_KEY` from the environment — **no key is hard-coded**.

```bash
export DEEPSEEK_API_KEY="your-api-key-here"
```

### Data (not included)
`APIDatabase` loads the **ProgrammableWeb** API data from a `data/` directory:
`api_name.json` (required), `api_description.json` (optional), `category_list.json`
(required), and optional `embedding/api_features_roberta.npy` for RoBERTa
similarity. Point the scripts at your own `data/` / `embedding/`.

### External modules (not included)
- `run_evaluation.py` imports `BPMN_TEST_SCENARIOS`, `UnifiedOutput`, `save_results`
  from a `scenarios` module (separate evaluation harness).
- `evaluate_e2e.py` imports `Config` from a `config` module (`Config.DEEPSEEK_API_KEY`).

### Run
```bash
python main_LLM4Workflow.py    # run the pipeline on the built-in example
python run_evaluation.py       # batch evaluation (needs the scenarios module)
python evaluate_e2e.py         # end-to-end metrics (needs a config module)
```

## The original LLM4Workflow app (`backend/` + `frontend/`)

See `backend/README.md` and `frontend/README.md` for its own setup (LangChain CLI,
Postgres via `docker-compose`, Vite dev server). The backend reads its own
`backend/.env` (`OPENAI_API_KEY`, LangSmith). Notes:

- The `docker-compose` / server use a **local dev Postgres password `123456`** —
  change it for anything beyond local use.
- **`backend/app/utils.py` has a pre-existing syntax issue** (an invalid `\u`
  escape in its opening docstring) inherited from upstream — fix or ignore
  depending on whether you use that module.

## Licensing (please read before publishing)

`backend/` and `frontend/` are the **original LLM4Workflow project** (third-party).
**No `LICENSE` file was present in the source.** Before publishing, confirm the
upstream project's license, add its `LICENSE` (and `NOTICE` if any) at the repo
root, keep upstream attribution, and note your modifications. The standalone
Python re-implementation is your own work.

## Acknowledgements

Based on the **LLM4Workflow** approach and its reference implementation. The
recommender uses the ProgrammableWeb API dataset.
