import os
import sys
import json
import time
import re
import requests
import traceback
import numpy as np
from pathlib import Path
from typing import List, Dict, Any

SCRIPT_DIR = Path(__file__).parent.absolute()
PROJECT_ROOT = SCRIPT_DIR.parent.parent
EVAL_ROOT = SCRIPT_DIR.parent

POSSIBLE_MODEL_PATHS = [
    PROJECT_ROOT / "models" / "LLM4Workflow" / "LLM4Workflow" / "LLM4Workflow-main",
    PROJECT_ROOT / "LLM4Workflow1" / "LLM4Workflow-main",
    PROJECT_ROOT.parent / "LLM4Workflow1" / "LLM4Workflow-main",
    SCRIPT_DIR / "LLM4Workflow-main",
    SCRIPT_DIR,
]

def find_model_root():

    for path in POSSIBLE_MODEL_PATHS:
        data_path = path / "data" / "api_name.json"
        if data_path.exists():
            print(f"  找到数据目录: {path}")
            return path
    return POSSIBLE_MODEL_PATHS[0]

MODEL_ROOT = find_model_root()

sys.path.insert(0, str(EVAL_ROOT / "common"))

from scenarios import BPMN_TEST_SCENARIOS, UnifiedOutput, save_results


def normalize_description(desc) -> str:

    if desc is None:
        return ""
    if isinstance(desc, str):
        return desc
    if isinstance(desc, list):
        return " ".join(str(item) for item in desc if item)
    if isinstance(desc, dict):
        return " ".join(str(v) for v in desc.values() if v)
    return str(desc)


class LLM4WorkflowModel:


    def __init__(self, data_path: str = None, embedding_path: str = None):

        print("\n" + "=" * 60)
        print("初始化 LLM4Workflow")
        print("=" * 60)
        print("  特点: 纯LLM驱动，四步流程")
        print("  1. Query Rewriting")
        print("  2. Task Planning")
        print("  3. API Retrieval")
        print("  4. DAG Generation")

        self.llm = self._create_llm_client()

        self.data_path = Path(data_path) if data_path else SCRIPT_DIR / "data"
        self.embedding_path = Path(embedding_path) if embedding_path else SCRIPT_DIR / "embedding"

        self.api_database = self._load_api_database()
        self.api_embeddings = self._load_api_embeddings()

        print(f"\n  ✓ API数据库: {len(self.api_database)} 个API")
        print(f"  ✓ API向量: {'已加载' if self.api_embeddings is not None else '未加载'}")

    def _create_llm_client(self):

        class LLMClient:
            def __init__(self):
                self.api_key = os.getenv("DEEPSEEK_API_KEY", "")
                self.base_url = "https://api.deepseek.com/v1"
                self.model = "deepseek-chat"

            def chat(self, prompt: str, system: str = None, temperature: float = 1, max_retries: int = 3) -> str:
                messages = []
                if system:
                    messages.append({"role": "system", "content": system})
                messages.append({"role": "user", "content": prompt})

                for attempt in range(max_retries):
                    try:
                        print(f"    正在调用DeepSeek API... (尝试 {attempt + 1}/{max_retries})")
                        response = requests.post(
                            f"{self.base_url}/chat/completions",
                            headers={
                                "Authorization": f"Bearer {self.api_key}",
                                "Content-Type": "application/json"
                            },
                            json={
                                "model": self.model,
                                "messages": messages,
                                "max_tokens": 2500,
                                "temperature": temperature
                            },
                            timeout=180
                        )
                        if response.status_code == 200:
                            print(f"    ✓ API调用成功")
                            return response.json()["choices"][0]["message"]["content"]
                        else:
                            print(f"    API Error: {response.status_code}")
                    except requests.exceptions.Timeout:
                        print(f"    ⚠ LLM Timeout (attempt {attempt + 1}/{max_retries})")
                        if attempt < max_retries - 1:
                            print(f"      等待10秒后重试...")
                            time.sleep(10)
                    except requests.exceptions.ConnectionError as e:
                        print(f"    ⚠ 网络连接错误")
                        if attempt < max_retries - 1:
                            print(f"      等待15秒后重试...")
                            time.sleep(15)
                    except KeyboardInterrupt:
                        raise
                    except Exception as e:
                        print(f"    LLM Error: {e}")
                        if attempt < max_retries - 1:
                            time.sleep(5)

                return "{}"

        return LLMClient()

    def _load_api_database(self) -> List[Dict]:

        api_name_file = self.data_path / "api_name.json"
        api_desc_file = self.data_path / "api_description.json"

        apis = []

        if api_name_file.exists():
            with open(api_name_file, 'r', encoding='utf-8') as f:
                api_names = json.load(f)

            api_descs = []
            if api_desc_file.exists():
                with open(api_desc_file, 'r', encoding='utf-8') as f:
                    api_descs = json.load(f)

            for i, name in enumerate(api_names):
                desc = api_descs[i] if i < len(api_descs) else ""
                desc = normalize_description(desc)

                apis.append({
                    "id": i,
                    "name": name,
                    "description": desc
                })

        return apis

    def _load_api_embeddings(self) -> np.ndarray:

        embed_file = self.embedding_path / "api_features_roberta.npy"
        if embed_file.exists():
            return np.load(str(embed_file))
        return None

    def rewrite_query(self, user_input: str, k: int = 5) -> List[str]:

        print("\n[Step 1] Query Rewriting (查询重写)...")
        start_time = time.time()

        prompt = f"""You are a query rewriting expert for API search. Given a user's process description,
generate {k} specific search queries to find relevant web APIs from ProgrammableWeb.

User's process description:
{user_input}

Generate {k} specific, concise search queries that would help find relevant APIs.
Each query should focus on a different aspect of the process (e.g., shipping API, email notification API, etc.)
Make queries specific and actionable.

Output as JSON array of strings only, no other text.
Example: ["shipping tracking API", "email notification API", "payment processing API"]"""

        try:
            response = self.llm.chat(prompt)
            match = re.search(r'\[.*\]', response, re.DOTALL)
            if match:
                queries = json.loads(match.group())
                print(f"  ✓ 生成了 {len(queries)} 个查询 ({time.time()-start_time:.2f}s)")
                for i, q in enumerate(queries, 1):
                    print(f"    {i}. {q}")
                return queries
        except Exception as e:
            print(f"  ✗ Query rewriting失败: {e}")

        fallback = self._extract_keywords_as_queries(user_input)
        print(f"  ⚠ 使用回退查询: {fallback}")
        return fallback

    def _extract_keywords_as_queries(self, text: str) -> List[str]:

        keywords = ['shipping', 'logistics', 'package', 'label', 'insurance',
                   'delivery', 'tracking', 'notification', 'email', 'payment',
                   'credit', 'identity', 'verification', 'order', 'inventory']
        text_lower = text.lower()
        queries = []
        for kw in keywords:
            if kw in text_lower:
                queries.append(f"{kw} API")
        return queries if queries else ["workflow API", "business process API"]

    def plan_tasks(self, user_input: str) -> List[Dict]:

        print("\n[Step 2] Task Planning (任务规划)...")
        start_time = time.time()

        prompt = f"""You are a workflow planning expert. Given a process description, decompose it into a list of executable tasks.

Process description:
{user_input}

For each task, provide:
- task_id: t1, t2, t3, etc.
- name: Short task name (in English, 3-6 words)
- description: Brief description of what this task does
- dependencies: List of task_ids this task depends on (empty list if none)

Important:
- Identify both sequential and parallel relationships
- Mark conditional branches clearly
- Keep task granularity appropriate (not too fine, not too coarse)

Output as JSON array only, no other text.
Example:
[
    {{"task_id": "t1", "name": "Clarify shipping method", "description": "Determine shipping approach", "dependencies": []}},
    {{"task_id": "t2", "name": "Select logistics company", "description": "Choose shipping provider", "dependencies": ["t1"]}}
]"""

        try:
            response = self.llm.chat(prompt)
            match = re.search(r'\[.*\]', response, re.DOTALL)
            if match:
                tasks = json.loads(match.group())
                print(f"  ✓ 规划了 {len(tasks)} 个任务 ({time.time()-start_time:.2f}s)")
                for t in tasks:
                    deps = t.get('dependencies', [])
                    dep_str = f" → 依赖: {deps}" if deps else ""
                    print(f"    [{t.get('task_id', '?')}] {t.get('name', '?')}{dep_str}")
                return tasks
        except Exception as e:
            print(f"  ✗ Task planning失败: {e}")

        return []

    def _encode_query_tfidf(self, query: str) -> np.ndarray:

        dim = self.api_embeddings.shape[1] if self.api_embeddings is not None else 768
        vec = np.zeros(dim, dtype=np.float32)
        words = re.findall(r'[a-z]+', query.lower())
        for word in words:
            for i, ch in enumerate(word):
                idx = (hash(word + str(i)) % dim + dim) % dim
                vec[idx] += 1.0
        norm = np.linalg.norm(vec)
        return vec / norm if norm > 0 else vec

    def retrieve_apis(self, queries: List[str], top_k: int = 20) -> List[Dict]:

        print("\n[Step 3] API Retrieval (API检索 - 语义向量优先)...")
        start_time = time.time()

        if not self.api_database:
            print("  ⚠ API数据库为空，使用LLM生成API建议")
            return self._llm_suggest_apis(queries)

        if self.api_embeddings is not None:
            print(f"  使用RoBERTa语义向量检索 (embedding shape: {self.api_embeddings.shape})")
            query_vecs = []
            for q in queries:
                qv = self._encode_query_tfidf(q)
                query_vecs.append(qv)
            query_vec = np.mean(query_vecs, axis=0).astype(np.float32)
            qnorm = np.linalg.norm(query_vec)
            if qnorm > 0:
                query_vec /= qnorm

            emb = self.api_embeddings.astype(np.float32)
            norms = np.linalg.norm(emb, axis=1, keepdims=True)
            norms = np.where(norms == 0, 1e-9, norms)
            emb_normed = emb / norms

            sims = emb_normed.dot(query_vec)

            keyword_scores = np.zeros(len(self.api_database), dtype=np.float32)
            all_query_words = set()
            for q in queries:
                all_query_words.update(w for w in re.findall(r'[a-z]+', q.lower()) if len(w) > 2)
            for idx, api in enumerate(self.api_database):
                api_name = api['name'].lower()
                api_desc = normalize_description(api.get('description', '')).lower()
                for word in all_query_words:
                    if word in api_name:
                        keyword_scores[idx] += 0.10
                    if word in api_desc:
                        keyword_scores[idx] += 0.03

            combined = sims + keyword_scores
            top_indices = np.argsort(-combined)[:top_k]

            top_apis = []
            for idx in top_indices:
                api = self.api_database[idx]
                top_apis.append({
                    'name': api['name'],
                    'description': api.get('description', ''),
                    'score': float(combined[idx])
                })

            print(f"  ✓ 语义检索到 {len(top_apis)} 个相关API ({time.time()-start_time:.2f}s)")
            for i, api in enumerate(top_apis[:10], 1):
                print(f"    {i}. {api['name']} (score: {api['score']:.4f})")
            if len(top_apis) > 10:
                print(f"    ... 还有 {len(top_apis)-10} 个API")
            return top_apis

        print("  ⚠ 未找到RoBERTa向量，回退到关键词匹配")
        all_apis = {}
        for query in queries:
            query_words = set(w for w in re.findall(r'[a-z]+', query.lower()) if len(w) > 2)
            for api in self.api_database:
                api_name = api['name'].lower()
                api_desc = normalize_description(api.get('description', '')).lower()
                score = 0
                for word in query_words:
                    if word in api_name:
                        score += 2
                    if word in api_desc:
                        score += 1
                if score > 0:
                    key = api['name']
                    if key not in all_apis:
                        all_apis[key] = {'name': api['name'], 'description': api.get('description', ''), 'score': score}
                    else:
                        all_apis[key]['score'] += score

        sorted_apis = sorted(all_apis.values(), key=lambda x: x['score'], reverse=True)
        top_apis = sorted_apis[:top_k]
        print(f"  ✓ 关键词检索到 {len(top_apis)} 个相关API ({time.time()-start_time:.2f}s)")
        for i, api in enumerate(top_apis[:10], 1):
            print(f"    {i}. {api['name']} (score: {api['score']:.1f})")
        return top_apis

    def _score_api_for_task(self, task_text: str, api: Dict) -> float:

        words = set(w for w in re.findall(r'[a-z]+', task_text.lower()) if len(w) > 2)
        name = api.get('name', '').lower()
        desc = normalize_description(api.get('description', '')).lower()
        score = float(api.get('score', 0.0)) * 0.01
        for w in words:
            if w in name:
                score += 2.0
            if w in desc:
                score += 0.5
        return score

    def _rank_apis_for_task(self, task_text: str, apis: List[Dict], k: int = 5) -> List[str]:

        if not apis:
            return ["manual-task"]
        scored = sorted(apis, key=lambda a: self._score_api_for_task(task_text, a), reverse=True)
        names = [a['name'] for a in scored[:k] if a.get('name')]
        return names if names else ["manual-task"]

    def _llm_suggest_apis(self, queries: List[str]) -> List[Dict]:

        prompt = f"""Based on these search queries, suggest relevant real-world APIs that could be found on ProgrammableWeb:

Queries: {queries}

For each query, suggest 2-3 relevant APIs with their names and brief descriptions.
Output as JSON array:
[
    {{"name": "API Name", "description": "Brief description", "score": 0.9}},
    ...
]

Only output the JSON array, no other text."""

        try:
            response = self.llm.chat(prompt)
            match = re.search(r'\[.*\]', response, re.DOTALL)
            if match:
                apis = json.loads(match.group())
                print(f"  ✓ LLM建议了 {len(apis)} 个API")
                return apis
        except Exception as e:
            print(f"  ✗ API建议失败: {e}")

        return []

    def generate_dag(self, tasks: List[Dict], retrieved_apis: List[Dict]) -> Dict:

        print("\n[Step 4] DAG Generation (DAG生成 - 编号约束版)...")
        start_time = time.time()

        capped_apis = retrieved_apis[:20]
        api_index_lines = "\n".join(
            [f"[{i}] {api['name']}" for i, api in enumerate(capped_apis)]
        )
        api_by_index = {i: api['name'] for i, api in enumerate(capped_apis)}
        api_names_set = {api['name'].lower(): api['name'] for api in capped_apis}

        task_list = "\n".join([
            f"- {t['task_id']}: {t['name']} (deps: {t.get('dependencies', [])})"
            for t in tasks
        ])

        tasks_by_id = {t.get('task_id', ''): t for t in tasks}

        prompt = f"""You are a workflow expert. Given a list of tasks and a numbered API list, \
generate a complete workflow DAG with API bindings.

Tasks:
{task_list}

Available APIs (select by INDEX number only):
{api_index_lines}

For each task, choose the TOP 5 most suitable API indices (integers), ranked by relevance (best match first).
Also identify parallel execution opportunities and decision gateways.

Output as JSON using "api_indices" (list of 5 integers) NOT api names:
{{
    "tasks": [
        {{
            "id": "t1",
            "name": "Task name",
            "api_indices": [3, 7, 1, 12, 5],
            "type": "userTask"
        }}
    ],
    "gateways": [
        {{
            "id": "g1",
            "type": "exclusive",
            "name": "Gateway description"
        }}
    ],
    "flows": [
        {{"from": "t1", "to": "t2", "condition": null}}
    ]
}}

CRITICAL RULES:
- "api_indices" must be a list of exactly 5 integers, each in range 0-{len(capped_apis)-1}.
- Do NOT write API names in "api_indices", only integer indices.
- Only output the JSON object, no other text."""

        try:
            response = self.llm.chat(prompt)
            match = re.search(r'\{.*\}', response, re.DOTALL)
            if match:
                dag = json.loads(match.group())

                for task_node in dag.get('tasks', []):
                    indices = task_node.pop('api_indices', None)
                    existing_apis = task_node.get('apis', [])

                    resolved = []
                    if isinstance(indices, list):
                        for idx in indices:
                            if isinstance(idx, int) and idx in api_by_index:
                                resolved.append(api_by_index[idx])
                            elif isinstance(idx, str):
                                try:
                                    resolved.append(api_by_index[int(idx)])
                                except (ValueError, KeyError):
                                    matched = api_names_set.get(str(idx).strip().lower())
                                    if matched:
                                        resolved.append(matched)

                    if not resolved and existing_apis:
                        for name in existing_apis:
                            matched = api_names_set.get(str(name).strip().lower())
                            resolved.append(matched if matched else str(name))

                    if not resolved:
                        orig_task = tasks_by_id.get(task_node.get('id', ''), {})
                        task_text = f"{task_node.get('name', '')} {orig_task.get('description', '')}"
                        resolved = self._rank_apis_for_task(task_text, capped_apis, k=5)

                    task_node['apis'] = resolved[:5]

                dag_tasks = dag.get('tasks', [])
                dag_gateways = dag.get('gateways', [])
                dag_flows = dag.get('flows', [])

                print(f"  ✓ 生成DAG ({time.time()-start_time:.2f}s)")
                print(f"    - 任务: {len(dag_tasks)}")
                print(f"    - 网关: {len(dag_gateways)}")
                print(f"    - 流程: {len(dag_flows)}")
                for t in dag_tasks:
                    print(f"    [{t.get('id','')}] {t.get('name','')} → TOP-5 APIs: {t.get('apis', [])}")

                return dag
        except Exception as e:
            print(f"  ✗ DAG生成失败: {e}")

        return self._simple_dag(tasks, retrieved_apis)

    def _simple_dag(self, tasks: List[Dict], apis: List[Dict]) -> Dict:

        dag_tasks = []

        for i, t in enumerate(tasks):
            task_text = f"{t.get('name', f'Task {i+1}')} {t.get('description', '')}"
            top5 = self._rank_apis_for_task(task_text, apis, k=5)
            dag_tasks.append({
                "id": t.get('task_id', f't{i+1}'),
                "name": t.get('name', f'Task {i+1}'),
                "apis": top5,
                "type": "userTask"
            })

        flows = []
        for i in range(len(dag_tasks) - 1):
            flows.append({
                "from": dag_tasks[i]['id'],
                "to": dag_tasks[i+1]['id'],
                "condition": None
            })

        return {
            "tasks": dag_tasks,
            "gateways": [],
            "flows": flows
        }

    def run(self, user_input: str, scenario_name: str) -> UnifiedOutput:

        print(f"\n{'='*60}")
        print(f"LLM4Workflow 处理场景: {scenario_name}")
        print(f"{'='*60}")

        start_time = time.time()

        queries = self.rewrite_query(user_input)

        tasks = self.plan_tasks(user_input)

        apis = self.retrieve_apis(queries)

        dag = self.generate_dag(tasks, apis)

        execution_time = time.time() - start_time

        formatted_tasks = []
        api_bindings = {}

        for task in dag.get('tasks', []):
            task_id = task.get('id', '')
            formatted_tasks.append({
                "id": task_id,
                "name": task.get('name', ''),
                "type": task.get('type', 'userTask')
            })
            raw_apis = task.get('apis', None)
            if raw_apis is None:
                single = task.get('api', 'manual-task')
                raw_apis = [single] if single else ['manual-task']
            top5_apis = raw_apis[:5] if isinstance(raw_apis, list) else [raw_apis]
            api_bindings[task_id] = {
                "task_name": task.get('name', ''),
                "api_name": top5_apis[0] if top5_apis else 'manual-task',
                "top5_apis": top5_apis,
                "confidence": 1.0,
                "method": "llm4workflow"
            }

        dependencies = []
        for flow in dag.get('flows', []):
            dependencies.append({
                "from": flow.get('from', ''),
                "to": flow.get('to', ''),
                "condition": flow.get('condition', '')
            })

        gateways = []
        for gw in dag.get('gateways', []):
            gateways.append({
                "id": gw.get('id', ''),
                "type": gw.get('type', 'exclusive'),
                "name": gw.get('name', '')
            })

        return UnifiedOutput(
            method="LLM4Workflow",
            scenario_name=scenario_name,
            user_request=user_input,
            tasks=formatted_tasks,
            dependencies=dependencies,
            gateways=gateways,
            api_bindings=api_bindings,
            roles=[],
            execution_time=execution_time,
            extra_info={
                "queries": queries,
                "retrieved_apis": [a['name'] for a in apis[:20]],
                "num_planned_tasks": len(tasks),
                "top5_per_node": {tid: v["top5_apis"] for tid, v in api_bindings.items()}
            }
        )


def main():

    print("\n")
    print("╔" + "═" * 58 + "╗")
    print("║" + " " * 10 + "LLM4Workflow 评估运行脚本 (修复版)" + " " * 4 + "║")
    print("║" + " " * 6 + "纯LLM驱动的工作流生成方法" + " " * 15 + "║")
    print("╚" + "═" * 58 + "╝")

    data_path = SCRIPT_DIR / "data"
    embedding_path = SCRIPT_DIR / "embedding"

    if not data_path.exists():
        data_path = MODEL_ROOT / "data"
    if not embedding_path.exists():
        embedding_path = MODEL_ROOT / "embedding"

    model = LLM4WorkflowModel(
        data_path=str(data_path),
        embedding_path=str(embedding_path)
    )

    print("\n" + "=" * 60)
    print("开始评估测试场景")
    print("=" * 60)

    results = []
    for i, scenario in enumerate(BPMN_TEST_SCENARIOS):
        print(f"\n>>> 场景 [{i+1}/{len(BPMN_TEST_SCENARIOS)}]: {scenario.name}")
        try:
            result = model.run(scenario.requirement, scenario.name)
            results.append(result)

            print(f"\n结果摘要:")
            print(f"  - 任务数: {len(result.tasks)}")
            print(f"  - 依赖数: {len(result.dependencies)}")
            print(f"  - 网关数: {len(result.gateways)}")
            print(f"  - API绑定数: {len(result.api_bindings)}")
            print(f"  - 执行时间: {result.execution_time:.2f}s")
            print(f"  - 每节点Top-5 API:")
            for tid, v in result.api_bindings.items():
                print(f"      [{tid}] {v['task_name']}: {v.get('top5_apis', [v['api_name']])}")
        except KeyboardInterrupt:
            print(f"\n  ⚠ 用户中断，跳过场景 {scenario.name}")
            print(f"    (再次按Ctrl+C退出整个程序)")
            try:
                time.sleep(2)
            except KeyboardInterrupt:
                print(f"\n程序被用户终止")
                break
            continue
        except Exception as e:
            print(f"  ✗ 场景 {scenario.name} 处理失败: {e}")
            traceback.print_exc()
            continue

    output_dir = EVAL_ROOT / "results"
    save_results(results, str(output_dir), "llm4workflow_raw")

    print("\n" + "=" * 60)
    print("LLM4Workflow 评估完成!")
    print("=" * 60)


if __name__ == "__main__":
    main()
