import os
import sys
import json
import numpy as np
import re
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, field
from collections import defaultdict
import time

PROJECT_ROOT = Path(__file__).parent.absolute()
sys.path.insert(0, str(PROJECT_ROOT))

from config import Config


class ProgrammableWebData:


    def __init__(self):
        print("=" * 60)
        print("加载ProgrammableWeb数据集")
        print("=" * 60)

        self.api_names: List[str] = []
        self.api_descriptions: Dict[str, str] = {}
        self.api_categories: Dict[str, str] = {}
        self.api_embeddings: Optional[np.ndarray] = None

        self.mashup_names: List[str] = []
        self.mashup_descriptions: Dict[str, str] = {}
        self.mashup_used_apis: Dict[str, List[str]] = {}
        self.mashup_embeddings: Optional[np.ndarray] = None

        self._load_data()

    def _load_data(self):


        if Config.API_NAME_FILE.exists():
            with open(Config.API_NAME_FILE, 'r', encoding='utf-8') as f:
                self.api_names = json.load(f)
            print(f"  ✓ API名称: {len(self.api_names)} 个")
        elif Config.API_IDS_FILE.exists():
            with open(Config.API_IDS_FILE, 'r', encoding='utf-8') as f:
                self.api_names = json.load(f)
            print(f"  ✓ API名称: {len(self.api_names)} 个")
        else:
            print("  ✗ API名称文件不存在")

        if Config.API_DESCRIPTION_FILE.exists():
            with open(Config.API_DESCRIPTION_FILE, 'r', encoding='utf-8') as f:
                desc_data = json.load(f)

            if isinstance(desc_data, dict):
                self.api_descriptions = desc_data
            elif isinstance(desc_data, list):
                self.api_descriptions = {
                    self.api_names[i]: desc_data[i]
                    for i in range(min(len(self.api_names), len(desc_data)))
                }
            print(f"  ✓ API描述: {len(self.api_descriptions)} 个")
        else:
            print("  ✗ API描述文件不存在")

        if Config.API_CATEGORY_FILE.exists():
            with open(Config.API_CATEGORY_FILE, 'r', encoding='utf-8') as f:
                cat_data = json.load(f)

            if isinstance(cat_data, dict):
                self.api_categories = cat_data
            elif isinstance(cat_data, list):
                self.api_categories = {
                    self.api_names[i]: cat_data[i]
                    for i in range(min(len(self.api_names), len(cat_data)))
                }
            print(f"  ✓ API类别: {len(self.api_categories)} 个")

        if Config.API_EMBEDDINGS_FILE.exists():
            self.api_embeddings = np.load(Config.API_EMBEDDINGS_FILE)
            print(f"  ✓ API向量: {self.api_embeddings.shape}")
        else:
            print("  ✗ API向量文件不存在")

        if Config.MASHUP_NAME_FILE.exists():
            with open(Config.MASHUP_NAME_FILE, 'r', encoding='utf-8') as f:
                self.mashup_names = json.load(f)
            print(f"  ✓ Mashup名称: {len(self.mashup_names)} 个")

        if Config.MASHUP_DESCRIPTION_FILE.exists():
            with open(Config.MASHUP_DESCRIPTION_FILE, 'r', encoding='utf-8') as f:
                desc_data = json.load(f)

            if isinstance(desc_data, dict):
                self.mashup_descriptions = desc_data
            elif isinstance(desc_data, list):
                self.mashup_descriptions = {
                    self.mashup_names[i]: desc_data[i]
                    for i in range(min(len(self.mashup_names), len(desc_data)))
                }
            print(f"  ✓ Mashup描述: {len(self.mashup_descriptions)} 个")

        if Config.MASHUP_USED_API_FILE.exists():
            with open(Config.MASHUP_USED_API_FILE, 'r', encoding='utf-8') as f:
                used_api_data = json.load(f)

            if isinstance(used_api_data, dict):
                self.mashup_used_apis = used_api_data
            elif isinstance(used_api_data, list):
                self.mashup_used_apis = {
                    self.mashup_names[i]: used_api_data[i]
                    for i in range(min(len(self.mashup_names), len(used_api_data)))
                }
            print(f"  ✓ Mashup API映射: {len(self.mashup_used_apis)} 个")

        if Config.MASHUP_EMBEDDINGS_FILE.exists():
            self.mashup_embeddings = np.load(Config.MASHUP_EMBEDDINGS_FILE)
            print(f"  ✓ Mashup向量: {self.mashup_embeddings.shape}")

        print("=" * 60)

    def get_api_database(self) -> Dict[str, str]:

        return self.api_descriptions

    def get_api_list(self) -> List[str]:

        return self.api_names


_pw_data: Optional[ProgrammableWebData] = None

def get_pw_data() -> ProgrammableWebData:
    global _pw_data
    if _pw_data is None:
        _pw_data = ProgrammableWebData()
    return _pw_data


BPMN_TEST_SCENARIOS = [
    {
        "name": "Dispatch-of-goods",
        "requirement": """If goods shall be shipped, the secretary clarifies who will do the shipping.
If you have large amounts, special shipping will be necessary. In these cases the secretary
invites three logistic companies to make offers and she selects one of them. In case of small
amounts, normal post shipment is used. Therefore a package label is written by the secretary
and a parcel insurance taken by the logistics department head if necessary. In the meantime
the goods can be already packaged by the warehousemen. If everything is ready, the packaged
goods are prepared for being picked up by the logistic company.""",
        "ground_truth_tasks": [
            "Clarify shipment method",
            "Get 3 offers from logistic companies",
            "Select logistic company and place order",
            "Write package label",
            "Insure parcel",
            "Package goods",
            "Prepare for picking up goods"
        ],
        "ground_truth_gateways": {"parallel": 1, "exclusive": 3, "inclusive": 2}
    },
    {
        "name": "Recourse",
        "requirement": """A customer brings in a defective computer and the retailer sends it to the
manufacturer for repair. The manufacturer checks if the defect is covered by warranty.
If yes, they repair it for free; if not, they provide a cost estimate. The customer decides
whether to proceed with paid repair or take back the unrepaired item. After repair or return,
the retailer contacts the customer for pickup.""",
        "ground_truth_tasks": [
            "Receive defective item",
            "Send to manufacturer",
            "Check warranty",
            "Repair under warranty",
            "Provide cost estimate",
            "Customer decision",
            "Paid repair",
            "Return unrepaired",
            "Contact customer"
        ],
        "ground_truth_gateways": {"parallel": 0, "exclusive": 3, "inclusive": 0}
    },
    {
        "name": "Credit-scoring",
        "requirement": """When a bank receives a credit request, they first check the customer's
identity. Then two parallel checks are performed: checking the credit history with the
credit bureau and checking the customer's employment status. After both checks complete,
the results are combined to calculate a credit score. Based on the score, the bank either
approves or rejects the credit application.""",
        "ground_truth_tasks": [
            "Check identity",
            "Check credit history",
            "Check employment",
            "Calculate credit score",
            "Approve application",
            "Reject application"
        ],
        "ground_truth_gateways": {"parallel": 2, "exclusive": 1, "inclusive": 0}
    },
    {
        "name": "Self-service-restaurant",
        "requirement": """In a self-service restaurant, the guest first takes a tray. Then they can
optionally take a starter, a main dish, and a dessert - these can be done in any order and
each is optional. After selecting food, the guest pays at the cashier. Finally, the guest
finds a table and eats the meal.""",
        "ground_truth_tasks": [
            "Take tray",
            "Take starter",
            "Take main dish",
            "Take dessert",
            "Pay at cashier",
            "Eat meal"
        ],
        "ground_truth_gateways": {"parallel": 0, "exclusive": 0, "inclusive": 2}
    }
]


class SemanticSimilarity:


    def __init__(self):
        self.encoder = None
        self._initialized = False

    def _init_encoder(self):
        if self._initialized:
            return

        try:
            sys.path.insert(0, str(PROJECT_ROOT / "3.1files"))
            from simcse_encoder import SimCSEEncoder
            self.encoder = SimCSEEncoder()
            self._initialized = True
            print("[SemanticSimilarity] SimCSE编码器初始化成功")
        except Exception as e:
            print(f"[SemanticSimilarity] 初始化失败: {e}, 使用Jaccard降级")
            self._initialized = False

    def compute_similarity(self, text1: str, text2: str) -> float:

        self._init_encoder()

        if self._initialized and self.encoder:
            try:
                emb1 = self.encoder.encode(text1)
                emb2 = self.encoder.encode(text2)
                similarity = np.dot(emb1, emb2) / (np.linalg.norm(emb1) * np.linalg.norm(emb2) + 1e-8)
                return float(similarity)
            except:
                pass

        return self._jaccard_similarity(text1, text2)

    def _jaccard_similarity(self, text1: str, text2: str) -> float:

        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        if not words1 or not words2:
            return 0.0
        intersection = len(words1 & words2)
        union = len(words1 | words2)
        return intersection / union if union > 0 else 0.0

    def compute_batch_similarity(self, texts1: List[str], texts2: List[str]) -> np.ndarray:

        n, m = len(texts1), len(texts2)
        sim_matrix = np.zeros((n, m))

        for i, t1 in enumerate(texts1):
            for j, t2 in enumerate(texts2):
                sim_matrix[i, j] = self.compute_similarity(t1, t2)

        return sim_matrix


_sim_calculator: Optional[SemanticSimilarity] = None

def get_sim_calculator() -> SemanticSimilarity:
    global _sim_calculator
    if _sim_calculator is None:
        _sim_calculator = SemanticSimilarity()
    return _sim_calculator


class EndToEndMetrics:


    def __init__(self, api_descriptions: Dict[str, str] = None):
        self.api_descriptions = api_descriptions or {}
        self.sim_calculator = get_sim_calculator()

    def executable_composition_rate(self, results: List[dict]) -> float:

        if not results:
            return 0.0

        success = 0
        for r in results:
            cond1 = r.get('workflow_valid', False)

            api_bindings = r.get('api_bindings', {})
            tasks = r.get('tasks', [])

            if tasks and api_bindings:
                bound_count = sum(1 for t in tasks
                                  if t.get('task_id', '') in api_bindings
                                  and api_bindings[t['task_id']].get('api_name'))
                cond2 = bound_count >= len(tasks) * 0.8
            else:
                cond2 = False

            cond3 = r.get('constraint_passed', True)

            if cond1 and cond2 and cond3:
                success += 1

        return success / len(results)

    def task_api_semantic_consistency(self, results: List[dict]) -> float:

        all_scores = []

        for r in results:
            tasks = r.get('tasks', [])
            api_bindings = r.get('api_bindings', {})

            for task in tasks:
                task_id = task.get('task_id', '')
                task_text = f"{task.get('name', '')} {task.get('description', '')}"

                if task_id in api_bindings:
                    api_name = api_bindings[task_id].get('api_name', '')
                    api_desc = self.api_descriptions.get(api_name, api_name)

                    if api_desc and task_text.strip():
                        sim = self.sim_calculator.compute_similarity(task_text, api_desc)
                        all_scores.append(sim)

        return np.mean(all_scores) if all_scores else 0.0

    def requirement_coverage(self, results: List[dict],
                              gt_tasks: Dict[str, List[str]],
                              threshold: float = 0.5) -> float:

        all_coverage = []

        for r in results:
            scenario = r.get('scenario_name', '')
            gt = gt_tasks.get(scenario, [])

            if not gt:
                continue

            pred_tasks = [t.get('name', '') for t in r.get('tasks', [])]

            if not pred_tasks:
                all_coverage.append(0.0)
                continue

            sim_matrix = self.sim_calculator.compute_batch_similarity(gt, pred_tasks)

            covered = sum(1 for i in range(len(gt)) if np.max(sim_matrix[i, :]) >= threshold)
            all_coverage.append(covered / len(gt))

        return np.mean(all_coverage) if all_coverage else 0.0


class LLM4Workflow:


    def __init__(self, api_database: Dict[str, str],
                 api_embeddings: np.ndarray = None,
                 api_names: List[str] = None):
        self.name = "LLM4Workflow"
        self.api_database = api_database
        self.api_embeddings = api_embeddings
        self.api_names = api_names or list(api_database.keys())

        self.llm = self._init_llm()

        self.encoder = None
        self._init_encoder()

        print(f"[{self.name}] 初始化完成，API数据库: {len(self.api_database)} 个")

    def _init_llm(self):

        try:
            from openai import OpenAI
            return OpenAI(
                api_key=Config.DEEPSEEK_API_KEY,
                base_url="https://api.deepseek.com"
            )
        except Exception as e:
            print(f"[{self.name}] LLM初始化失败: {e}")
            return None

    def _init_encoder(self):

        try:
            sys.path.insert(0, str(PROJECT_ROOT / "3.1files"))
            from simcse_encoder import SimCSEEncoder
            self.encoder = SimCSEEncoder()
        except Exception as e:
            print(f"[{self.name}] SimCSE初始化失败: {e}")

    def _call_llm(self, prompt: str) -> str:

        if not self.llm:
            return ""

        try:
            response = self.llm.chat.completions.create(
                model="deepseek-chat",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=2500
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"[{self.name}] LLM调用失败: {e}")
            return ""

    def rewrite_query(self, user_input: str) -> List[str]:

        prompt = f"""You are a query rewriting expert. Given a user request, generate 3-5 search queries to find relevant APIs.

User request: {user_input}

Generate specific search queries that would help find APIs for this workflow.
Output as JSON array of strings only, no other text.

Example: ["shipping API", "logistics tracking", "parcel insurance API"]"""

        response = self._call_llm(prompt)

        try:
            json_match = re.search(r'\[.*\]', response, re.DOTALL)
            if json_match:
                queries = json.loads(json_match.group())
                return queries if isinstance(queries, list) else [user_input]
        except:
            pass

        words = user_input.lower().split()
        keywords = [w for w in words if len(w) > 4 and w.isalpha()][:5]
        return keywords if keywords else [user_input[:100]]

    def plan_tasks(self, user_input: str) -> List[dict]:

        prompt = f"""You are a workflow planning expert. Decompose this requirement into tasks.

Requirement: {user_input}

For each task provide:
- task_id: t1, t2, t3...
- name: Short task name
- description: Brief description
- dependencies: List of task_ids this depends on

Output as JSON array only.

Example:
[{{"task_id": "t1", "name": "Check order", "description": "Verify order details", "dependencies": []}}]"""

        response = self._call_llm(prompt)

        try:
            json_match = re.search(r'\[.*\]', response, re.DOTALL)
            if json_match:
                tasks = json.loads(json_match.group())
                return tasks if isinstance(tasks, list) else []
        except:
            pass

        return []

    def retrieve_apis(self, queries: List[str], top_k: int = 10) -> List[dict]:

        api_scores = defaultdict(float)

        for query in queries:
            bm25_results = self._bm25_retrieve(query, top_k=5)
            for api_name, score in bm25_results:
                api_scores[api_name] += 0.4 * score

            if self.encoder and self.api_embeddings is not None:
                vector_results = self._vector_retrieve(query, top_k=5)
                for api_name, score in vector_results:
                    api_scores[api_name] += 0.6 * score

        sorted_apis = sorted(api_scores.items(), key=lambda x: x[1], reverse=True)[:top_k]

        return [
            {"name": api_name, "description": self.api_database.get(api_name, ""), "score": score}
            for api_name, score in sorted_apis
        ]

    def _bm25_retrieve(self, query: str, top_k: int = 5) -> List[Tuple[str, float]]:

        query_words = set(query.lower().split())
        results = []

        for api_name, api_desc in self.api_database.items():
            api_text = f"{api_name} {api_desc}".lower()
            api_words = set(api_text.split())

            overlap = len(query_words & api_words)
            if overlap > 0:
                score = overlap / (len(query_words) + 1)
                results.append((api_name, score))

        results.sort(key=lambda x: x[1], reverse=True)
        return results[:top_k]

    def _vector_retrieve(self, query: str, top_k: int = 5) -> List[Tuple[str, float]]:

        if self.encoder is None or self.api_embeddings is None:
            return []

        try:
            query_emb = self.encoder.encode(query)

            similarities = np.dot(self.api_embeddings, query_emb) / (
                np.linalg.norm(self.api_embeddings, axis=1) * np.linalg.norm(query_emb) + 1e-8
            )

            top_indices = np.argsort(similarities)[::-1][:top_k]

            results = []
            for idx in top_indices:
                if idx < len(self.api_names):
                    results.append((self.api_names[idx], float(similarities[idx])))

            return results
        except Exception as e:
            return []

    def generate_dag(self, tasks: List[dict], apis: List[dict]) -> dict:

        if not tasks:
            return {"task_list": [], "task_dependencies": {}, "api_bindings": {}}

        api_names = [api['name'] for api in apis]

        prompt = f"""You are a workflow expert. Bind each task to the most suitable API.

Tasks:
{json.dumps(tasks, indent=2)}

Available APIs:
{json.dumps(api_names[:20], indent=2)}

For each task, select the most relevant API.
Output JSON:
{{
    "task_api_bindings": {{
        "t1": "api-name",
        "t2": "api-name"
    }}
}}

Output only JSON."""

        response = self._call_llm(prompt)

        api_bindings = {}

        try:
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                result = json.loads(json_match.group())
                bindings = result.get('task_api_bindings', {})

                for task_id, api_name in bindings.items():
                    api_bindings[task_id] = {
                        "api_name": api_name,
                        "confidence": 0.6,
                        "task_name": next((t['name'] for t in tasks if t.get('task_id') == task_id), "")
                    }
        except:
            for i, task in enumerate(tasks):
                task_id = task.get('task_id', f't{i+1}')
                api_bindings[task_id] = {
                    "api_name": api_names[i % len(api_names)] if api_names else "unknown",
                    "confidence": 0.5,
                    "task_name": task.get('name', '')
                }

        dependencies = []
        for task in tasks:
            task_id = task.get('task_id', '')
            for dep in task.get('dependencies', []):
                dependencies.append({"from": dep, "to": task_id})

        return {
            "tasks": tasks,
            "dependencies": dependencies,
            "api_bindings": api_bindings
        }

    def run(self, requirement: str) -> dict:

        print(f"\n[{self.name}] 处理需求...")

        queries = self.rewrite_query(requirement)
        print(f"  [1] Query Rewriting: {len(queries)} 个查询")

        tasks = self.plan_tasks(requirement)
        print(f"  [2] Task Planning: {len(tasks)} 个任务")

        apis = self.retrieve_apis(queries, top_k=15)
        print(f"  [3] API Retrieval: {len(apis)} 个API")

        dag_result = self.generate_dag(tasks, apis)
        print(f"  [4] DAG Generation: {len(dag_result.get('api_bindings', {}))} 个绑定")

        return {
            "workflow_valid": len(tasks) > 0,
            "tasks": dag_result.get('tasks', tasks),
            "dependencies": dag_result.get('dependencies', []),
            "api_bindings": dag_result.get('api_bindings', {}),
            "constraint_passed": True
        }


class MAO_SEFR_Pipeline:


    def __init__(self, api_database: Dict[str, str],
                 api_embeddings: np.ndarray = None,
                 api_names: List[str] = None):
        self.name = "MAO+SEFR"
        self.api_database = api_database
        self.api_embeddings = api_embeddings
        self.api_names = api_names or list(api_database.keys())

        self.llm = self._init_llm()
        self.encoder = None
        self._init_encoder()

        print(f"[{self.name}] 初始化完成")

    def _init_llm(self):
        try:
            from openai import OpenAI
            return OpenAI(api_key=Config.DEEPSEEK_API_KEY, base_url="https://api.deepseek.com")
        except:
            return None

    def _init_encoder(self):
        try:
            sys.path.insert(0, str(PROJECT_ROOT / "3.1files"))
            from simcse_encoder import SimCSEEncoder
            self.encoder = SimCSEEncoder()
        except:
            pass

    def run(self, requirement: str) -> dict:

        print(f"\n[{self.name}] 处理需求...")

        tasks = self._mao_generate(requirement)
        print(f"  [MAO] 生成 {len(tasks)} 个任务")

        api_bindings = {}
        for task in tasks:
            task_id = task['task_id']
            query = task['name']
            api_name, confidence = self._sefr_recommend(query)
            api_bindings[task_id] = {
                "api_name": api_name,
                "confidence": confidence,
                "task_name": task['name']
            }

        print(f"  [SEFR] 绑定 {len(api_bindings)} 个API")

        return {
            "workflow_valid": len(tasks) > 0,
            "tasks": tasks,
            "dependencies": [],
            "api_bindings": api_bindings,
            "constraint_passed": True
        }

    def _mao_generate(self, requirement: str) -> List[dict]:

        if not self.llm:
            return self._rule_based_extract(requirement)

        prompt = f"""Extract main tasks from this workflow description.
Output JSON array with task_id and name only.

Description: {requirement}

Example: [{{"task_id": "t1", "name": "Check order"}}]
Output only JSON array."""

        try:
            response = self.llm.chat.completions.create(
                model="deepseek-chat",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=2500
            )
            content = response.choices[0].message.content

            json_match = re.search(r'\[.*\]', content, re.DOTALL)
            if json_match:
                tasks = json.loads(json_match.group())
                return [{"task_id": t.get('task_id', f't{i+1}'), "name": t.get('name', ''), "description": ""}
                        for i, t in enumerate(tasks)]
        except:
            pass

        return self._rule_based_extract(requirement)

    def _rule_based_extract(self, requirement: str) -> List[dict]:

        keywords = [
            ('ship', 'Ship goods'), ('label', 'Write label'), ('insurance', 'Take insurance'),
            ('package', 'Package items'), ('offer', 'Get offers'), ('select', 'Select option'),
            ('check', 'Check status'), ('pay', 'Process payment'), ('repair', 'Repair item')
        ]

        tasks = []
        req_lower = requirement.lower()
        for i, (kw, name) in enumerate(keywords):
            if kw in req_lower:
                tasks.append({"task_id": f"t{len(tasks)+1}", "name": name, "description": ""})

        return tasks if tasks else [{"task_id": "t1", "name": "Process request", "description": ""}]

    def _sefr_recommend(self, query: str) -> Tuple[str, float]:

        if self.encoder and self.api_embeddings is not None:
            try:
                query_emb = self.encoder.encode(query)
                similarities = np.dot(self.api_embeddings, query_emb) / (
                    np.linalg.norm(self.api_embeddings, axis=1) * np.linalg.norm(query_emb) + 1e-8
                )
                best_idx = np.argmax(similarities)
                return self.api_names[best_idx], float(similarities[best_idx])
            except:
                pass

        query_words = set(query.lower().split())
        best_api, best_score = self.api_names[0] if self.api_names else "unknown", 0.0

        for api_name in self.api_names[:1000]:
            api_words = set(api_name.lower().replace('-', ' ').split())
            overlap = len(query_words & api_words)
            if overlap > best_score:
                best_score = overlap
                best_api = api_name

        return best_api, min(best_score / 3, 1.0)


class MAO_BM25_Pipeline:


    def __init__(self, api_database: Dict[str, str], api_names: List[str] = None):
        self.name = "MAO+BM25"
        self.api_database = api_database
        self.api_names = api_names or list(api_database.keys())
        self.mao_sefr = MAO_SEFR_Pipeline(api_database, None, api_names)
        print(f"[{self.name}] 初始化完成")

    def run(self, requirement: str) -> dict:
        print(f"\n[{self.name}] 处理需求...")

        tasks = self.mao_sefr._mao_generate(requirement)
        print(f"  [MAO] 生成 {len(tasks)} 个任务")

        api_bindings = {}
        for task in tasks:
            task_id = task['task_id']
            query = task['name']
            api_name = self._bm25_recommend(query)
            api_bindings[task_id] = {
                "api_name": api_name,
                "confidence": 0.5,
                "task_name": task['name']
            }

        print(f"  [BM25] 绑定 {len(api_bindings)} 个API")

        return {
            "workflow_valid": len(tasks) > 0,
            "tasks": tasks,
            "dependencies": [],
            "api_bindings": api_bindings,
            "constraint_passed": True
        }

    def _bm25_recommend(self, query: str) -> str:
        query_words = set(query.lower().split())
        best_api, best_score = self.api_names[0] if self.api_names else "unknown", 0

        for api_name, api_desc in list(self.api_database.items())[:2000]:
            api_text = f"{api_name} {api_desc}".lower()
            api_words = set(api_text.split())
            overlap = len(query_words & api_words)
            if overlap > best_score:
                best_score = overlap
                best_api = api_name

        return best_api


class GPT4Direct:


    def __init__(self, api_names: List[str] = None):
        self.name = "GPT-4 Direct"
        self.api_names = api_names or []
        self.llm = self._init_llm()
        print(f"[{self.name}] 初始化完成")

    def _init_llm(self):
        try:
            from openai import OpenAI
            return OpenAI(api_key=Config.DEEPSEEK_API_KEY, base_url="https://api.deepseek.com")
        except:
            return None

    def run(self, requirement: str) -> dict:
        print(f"\n[{self.name}] 处理需求...")

        api_sample = self.api_names[:30] if self.api_names else ["api-1", "api-2"]

        prompt = f"""Generate a workflow with API bindings for this requirement.

Requirement: {requirement}

Available APIs (sample): {json.dumps(api_sample)}

Output JSON:
{{
    "tasks": [{{"task_id": "t1", "name": "...", "description": "..."}}],
    "api_bindings": {{"t1": {{"api_name": "...", "confidence": 0.7}}}}
}}

Output only JSON."""

        if self.llm:
            try:
                response = self.llm.chat.completions.create(
                    model="deepseek-chat",
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.7,
                    max_tokens=2500
                )
                content = response.choices[0].message.content

                json_match = re.search(r'\{.*\}', content, re.DOTALL)
                if json_match:
                    result = json.loads(json_match.group())
                    tasks = result.get('tasks', [])
                    api_bindings = result.get('api_bindings', {})

                    print(f"  生成 {len(tasks)} 个任务, {len(api_bindings)} 个绑定")

                    return {
                        "workflow_valid": len(tasks) > 0,
                        "tasks": tasks,
                        "dependencies": [],
                        "api_bindings": api_bindings,
                        "constraint_passed": True
                    }
            except Exception as e:
                print(f"  错误: {e}")

        return {
            "workflow_valid": False,
            "tasks": [],
            "dependencies": [],
            "api_bindings": {},
            "constraint_passed": False
        }


class YourModel:


    def __init__(self):
        self.name = "Ours"
        print(f"[{self.name}] 初始化...")

    def run(self, requirement: str) -> dict:

        print(f"\n[{self.name}] 处理需求...")

        try:
            from main import (
                run_agent1_workflow_generator,
                run_checker_hallucination_detector,
                run_agent2_api_recommender,
                run_validator
            )

            workflow_result = run_agent1_workflow_generator(requirement)
            print(f"  [Agent1] 工作流生成完成")

            checker_result = run_checker_hallucination_detector(workflow_result, requirement)
            print(f"  [Checker] 幻觉检测完成")

            api_result = run_agent2_api_recommender(workflow_result, requirement)
            print(f"  [Agent2] API推荐完成")

            try:
                validation_result = run_validator(api_result.get('api_bindings', {}), requirement)
            except:
                validation_result = {'is_valid': True}

            return {
                "workflow_valid": checker_result.get('is_valid', True),
                "tasks": workflow_result.get('tasks', []),
                "dependencies": workflow_result.get('dependencies', {}),
                "api_bindings": api_result.get('api_bindings', {}),
                "constraint_passed": validation_result.get('is_valid', True)
            }

        except Exception as e:
            print(f"  [错误] {e}")
            import traceback
            traceback.print_exc()
            return {
                "workflow_valid": False,
                "tasks": [],
                "dependencies": {},
                "api_bindings": {},
                "constraint_passed": False
            }


class EndToEndEvaluator:


    def __init__(self):
        print("\n" + "=" * 70)
        print("             端到端评价系统 (End-to-End Evaluation)")
        print("=" * 70)

        self.pw_data = get_pw_data()

        self.metrics = EndToEndMetrics(api_descriptions=self.pw_data.api_descriptions)

        self.gt_tasks = {s['name']: s['ground_truth_tasks'] for s in BPMN_TEST_SCENARIOS}

    def evaluate_method(self, method, scenarios: List[dict] = None) -> dict:

        scenarios = scenarios or BPMN_TEST_SCENARIOS
        method_name = getattr(method, 'name', type(method).__name__)

        print(f"\n{'='*60}")
        print(f"评价: {method_name}")
        print(f"{'='*60}")

        results = []

        for scenario in scenarios:
            print(f"\n[场景] {scenario['name']}")

            start_time = time.time()
            output = method.run(scenario['requirement'])
            elapsed = time.time() - start_time

            output['scenario_name'] = scenario['name']
            output['method_name'] = method_name
            output['time'] = elapsed

            results.append(output)

            n_tasks = len(output.get('tasks', []))
            n_apis = len(output.get('api_bindings', {}))
            print(f"  任务: {n_tasks}, API绑定: {n_apis}, 耗时: {elapsed:.2f}s")

        ecr = self.metrics.executable_composition_rate(results)
        consistency = self.metrics.task_api_semantic_consistency(results)
        coverage = self.metrics.requirement_coverage(results, self.gt_tasks)

        print(f"\n[{method_name} 结果]")
        print(f"  ECR: {ecr:.4f}")
        print(f"  Task-API一致性: {consistency:.4f}")
        print(f"  需求覆盖率: {coverage:.4f}")

        return {
            'method': method_name,
            'ecr': ecr,
            'task_api_consistency': consistency,
            'requirement_coverage': coverage,
            'num_scenarios': len(results),
            'details': results
        }

    def run_all_baselines(self) -> Dict[str, dict]:

        print("\n" + "=" * 70)
        print("                    运行所有对比方法")
        print("=" * 70)

        all_results = {}

        api_db = self.pw_data.get_api_database()
        api_names = self.pw_data.get_api_list()
        api_emb = self.pw_data.api_embeddings

        print("\n" + "-" * 40)
        llm4wf = LLM4Workflow(api_db, api_emb, api_names)
        all_results['LLM4Workflow'] = self.evaluate_method(llm4wf)

        print("\n" + "-" * 40)
        mao_sefr = MAO_SEFR_Pipeline(api_db, api_emb, api_names)
        all_results['MAO+SEFR'] = self.evaluate_method(mao_sefr)

        print("\n" + "-" * 40)
        mao_bm25 = MAO_BM25_Pipeline(api_db, api_names)
        all_results['MAO+BM25'] = self.evaluate_method(mao_bm25)

        print("\n" + "-" * 40)
        gpt4 = GPT4Direct(api_names)
        all_results['GPT-4 Direct'] = self.evaluate_method(gpt4)

        print("\n" + "-" * 40)
        try:
            ours = YourModel()
            all_results['Ours'] = self.evaluate_method(ours)
        except Exception as e:
            print(f"\n[警告] 您的模型运行出错: {e}")
            print("请确保main.py中的函数可以正常导入")

        return all_results

    def print_comparison_table(self, results: Dict[str, dict]):

        print("\n" + "=" * 70)
        print("                    端到端评价结果对比")
        print("=" * 70)

        print(f"\n{'Method':<20} {'ECR':>10} {'T-A Cons.':>12} {'Req. Cov.':>12}")
        print("-" * 56)

        for method, result in results.items():
            ecr = result.get('ecr', 0)
            cons = result.get('task_api_consistency', 0)
            cov = result.get('requirement_coverage', 0)
            print(f"{method:<20} {ecr:>10.4f} {cons:>12.4f} {cov:>12.4f}")

        print("-" * 56)

        if 'Ours' in results:
            ours = results['Ours']
            baselines = {k: v for k, v in results.items() if k != 'Ours'}

            if baselines:
                best_ecr = max(r['ecr'] for r in baselines.values())
                best_cons = max(r['task_api_consistency'] for r in baselines.values())
                best_cov = max(r['requirement_coverage'] for r in baselines.values())

                print("\n相对于最佳Baseline的提升:")
                if best_ecr > 0:
                    print(f"  ECR: {(ours['ecr'] - best_ecr) / best_ecr * 100:+.1f}%")
                if best_cons > 0:
                    print(f"  Task-API一致性: {(ours['task_api_consistency'] - best_cons) / best_cons * 100:+.1f}%")
                if best_cov > 0:
                    print(f"  需求覆盖率: {(ours['requirement_coverage'] - best_cov) / best_cov * 100:+.1f}%")

    def save_results(self, results: Dict[str, dict], output_path: str = None):

        output_path = output_path or str(PROJECT_ROOT / "evaluation1_results.json")

        serializable = {}
        for method, result in results.items():
            serializable[method] = {
                'method': result['method'],
                'ecr': float(result['ecr']),
                'task_api_consistency': float(result['task_api_consistency']),
                'requirement_coverage': float(result['requirement_coverage']),
                'num_scenarios': result['num_scenarios']
            }

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(serializable, f, indent=2, ensure_ascii=False)

        print(f"\n✓ 结果已保存: {output_path}")


def main():
    print("\n")
    print("╔" + "═" * 68 + "╗")
    print("║" + " " * 18 + "评价1：端到端评价" + " " * 19 + "║")
    print("║" + " " * 10 + "End-to-End Evaluation System v2.0" + " " * 11 + "║")
    print("║" + " " * 68 + "║")
    print("║  对比方法:                                                         ║")
    print("║    1. LLM4Workflow (RAG + LLM)                                     ║")
    print("║    2. MAO + SEFR (工作流生成 + SimCSE推荐)                          ║")
    print("║    3. MAO + BM25 (工作流生成 + 关键词匹配)                          ║")
    print("║    4. GPT-4 Direct (直接生成)                                      ║")
    print("║    5. Ours (Agent1 + Checker + Agent2 + Validator)                ║")
    print("╚" + "═" * 68 + "╝")

    evaluator = EndToEndEvaluator()

    results = evaluator.run_all_baselines()

    evaluator.print_comparison_table(results)

    evaluator.save_results(results)

    print("\n" + "=" * 70)
    print("评价完成!")
    print("=" * 70)

    return results


if __name__ == "__main__":
    main()
