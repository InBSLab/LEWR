# -*- coding: utf-8 -*-

import os
import sys
import json
import time
import re
import requests
import traceback
import numpy as np
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

SCRIPT_DIR = Path(__file__).parent.absolute()
PROJECT_ROOT = SCRIPT_DIR.parent.parent  # evaluation_framework_complete/
EVAL_ROOT = SCRIPT_DIR.parent  # evaluation_framework_complete/evaluation/

POSSIBLE_MODEL_PATHS = [
    PROJECT_ROOT / "models" / "LLM4Workflow" / "LLM4Workflow" / "LLM4Workflow-main",
    PROJECT_ROOT / "LLM4Workflow1" / "LLM4Workflow-main",
    PROJECT_ROOT.parent / "LLM4Workflow1" / "LLM4Workflow-main",
    SCRIPT_DIR / "LLM4Workflow-main",
    SCRIPT_DIR,
]


def find_model_root():
    for path in POSSIBLE_MODEL_PATHS:
        data_path = path / "data" / "api_name.json"
        if data_path.exists():
            print(f"  找到数据目录: {path}")
            return path
    return POSSIBLE_MODEL_PATHS[0]


MODEL_ROOT = find_model_root()

sys.path.insert(0, str(EVAL_ROOT / "common"))

from scenarios import BPMN_TEST_SCENARIOS, UnifiedOutput, save_results


LLM_BASE_URL = os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com/v1")
LLM_MODEL = os.getenv("LLM4WF_LLM_MODEL", "deepseek-chat")
LLM_TEMPERATURE = 0.3
LLM_MAX_TOKENS = 2500

EMBED_MODEL_NAME = os.getenv("LLM4WF_EMBED_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
TOP_K_OUTPUT = int(os.getenv("LLM4WF_TOP_K_OUTPUT", "5"))

RETRIEVE_K_PER_QUERY = 3
MMR_FETCH_K = 20
MMR_LAMBDA = 0.5


# --- create_game.py ---
DEMONSTRATION = """Human: The Lotka-Volterra workflow solves the classic Lotka-Volterra predator prey dynamics model, which describes the relative populations of a predator and its prey over time using two coupled differential equations: one that describes how predator population changes (dn2/dt = -d*n2 + b*n1*n2); and one that describes how prey population changes (dn1/dt = r*n1 - a*n1*n2). The results are plotted as they are calculated, showing the two populations versus time (using the TimedPlotter) and versus each other (using the XYPlotter).
AI:
Define the differential equation describing the change in predator population: (dn2/dt = -d*n2 + b*n1*n2)
Define the differential equation describing the change in prey population: (dn1/dt = r*n1 - a*n1*n2)
Calculate the solution for equation 1.
Calculate the solution for equation 2.
Present the results showing the evolution of both populations over time.
Present the results illustrating the relationship between the two populations.
"""

CREATE_GAME_PROMPT = """We're going to play a game called 'workflow'. In this game, I will give you a text description, and you need to provide the task extraction separated by newlines.
Ensure that extracted tasks are only one level deep, without nesting and ensure that tasks are broken down into atomic tasks, with each task containing only a single action.
Here is a example for your reference: {Demonstration}  
When I say 'workflow: {{}}', we'll start the game. Do you know how to play this game? If you do, please reply with 'OK' only.
"""

# --- rag.py ---
REWRITE_QUERY_PROMPT = """You are an AI language model assistant. Your task is to generate {k} alternative queries to retrieve relevant 
APIs (to execute tasks in scientific workflows) from a vector database. 
By generating better queries based on the user's task list, your goal is to help the user overcome some of the limitations of distance-based similarity search. 
Provide these alternative queries separated by newlines. 
Original user task list: {text}
"""

# --- write_dag.py ---
WRITE_DAG_PROMPT = """You're a scientific workflow expert, and your role involves: 
1. Analyzing the following workflow task descriptions and the associated API list for task execution, but you don't need to return them to me.
2. Choosing the suitable API from the following api list for each task execution and assessing the interdependencies among task executions, but you don't need to return them to me.
3. Ultimately, presenting the workflow task list and their dependencies in the following json markdown format:
```json {{
"task_list": [{{id: task id, task name: task name, task description: task description, api: api name}}]
"task_dependencies": {{id: [task ids required to execute before the current task]}}
}}```

Don't output anything for step 1 and 2, only the answer in step 3. Let's work this out in a step by step way to be sure we have the right answer.

workflow task descriptions: {task_list}
api list: {api_list}
Answer:
"""

if TOP_K_OUTPUT > 1:
    WRITE_DAG_PROMPT = WRITE_DAG_PROMPT.replace(
        "api: api name",
        f"apis: [up to {TOP_K_OUTPUT} api names from the api list, best match first]"
    )


def normalize_description(desc) -> str:
    if desc is None:
        return ""
    if isinstance(desc, str):
        return desc
    if isinstance(desc, list):
        return " ".join(str(item) for item in desc if item)
    if isinstance(desc, dict):
        return " ".join(str(v) for v in desc.values() if v)
    return str(desc)


def parse_json_object(text: str) -> Dict:
    text = text.strip()
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1 or end <= start:
        raise ValueError("LLM输出中没有找到JSON对象")
    body = text[start:end + 1]
    try:
        return json.loads(body)
    except json.JSONDecodeError:
        body = re.sub(r",\s*([}\]])", r"\1", body)
        return json.loads(body)


def mmr_select(query_vec: np.ndarray, doc_vecs: np.ndarray, k: int,
               fetch_k: int, lambda_mult: float) -> List[int]:
    sims = doc_vecs @ query_vec
    fetch_k = min(fetch_k, len(sims))
    cand = np.argsort(-sims)[:fetch_k].tolist()
    if not cand:
        return []
    selected = [cand[0]]
    cand = cand[1:]
    while cand and len(selected) < k:
        best_idx, best_score = None, -1e9
        for c in cand:
            redundancy = max(float(doc_vecs[c] @ doc_vecs[s]) for s in selected)
            score = lambda_mult * float(sims[c]) - (1 - lambda_mult) * redundancy
            if score > best_score:
                best_idx, best_score = c, score
        selected.append(best_idx)
        cand.remove(best_idx)
    return selected


REPAIR_MAX_ATTEMPTS = int(os.getenv("LLM4WF_REPAIR_MAX_ATTEMPTS", "3"))       # LEWR: for attempt in range(3)
REPAIR_PARSE_RETRIES = 3                                                        # LEWR: generate(max_retries=3)
REPAIR_ADD_BOUNDARY = os.getenv("LLM4WF_REPAIR_ADD_BOUNDARY", "1") != "0"
REPAIR_USE_FALLBACK = os.getenv("LLM4WF_REPAIR_FALLBACK", "1") != "0"

def _estimate_task_range(description: str) -> Tuple[int, int]:
    desc_lower = description.lower()

    branch_markers = [
        'if ', 'otherwise', 'in case', 'depending on', 'either', 'or else',
        'unless', 'when ', 'whenever'
    ]
    sequence_markers = [
        'then', 'after', 'afterwards', 'meanwhile', 'in the meantime',
        'once', 'subsequently', 'next,'
    ]

    branch_count = sum(desc_lower.count(m) for m in branch_markers)
    sequence_count = sum(desc_lower.count(m) for m in sequence_markers)

    sentence_count = max(1, len(re.findall(r'[.!?](?:\s|$)', description)))

    base = sentence_count
    expansion = branch_count * 2 + sequence_count

    min_tasks = max(4, int(base * 0.8))
    max_tasks = max(min_tasks + 4, int((base + expansion) * 1.3))

    max_tasks = min(max_tasks, 30)

    return min_tasks, max_tasks


def repair_target_score(count: int, min_tasks: int, max_tasks: int) -> int:
    if min_tasks <= count <= max_tasks:
        return 100 - abs(count - (min_tasks + max_tasks) // 2)
    elif count < min_tasks:
        return count - min_tasks
    else:
        return max_tasks - count


def build_retry_description(process_description: str, min_tasks: int, max_tasks: int,
                            level: str) -> str:
    if level == "strong":
        suffix = f"""

[GENERATION REQUIREMENT]
Based on the structure of the process description above (conditions, parallel
activities, sequential steps), extract a workflow with approximately
{min_tasks}-{max_tasks} tasks. Split each distinct activity mentioned in the
text into its own task; do not merge multiple described actions into one task,
and do not invent activities that are not implied by the text.
"""
    else:  # maximum
        suffix = f"""

[GENERATION REQUIREMENT - STRICT]
Re-read the process description carefully. Extract a workflow with
{min_tasks}-{max_tasks} tasks total:
- Do not add steps, roles, or checks that are not stated or clearly implied
  by the text. Do not omit a step that is explicitly stated.
Stay within the {min_tasks}-{max_tasks} task range.
"""
    return process_description + suffix


FALLBACK_TASKS = [
    ("task1", "Process request", "userTask"),
    ("task2", "Execute action", "serviceTask"),
    ("task3", "Complete process", "userTask"),
]


_ID_PREFIX_RE = re.compile(r"^(?:task|step|t)[\s_\-]*", re.I)


def _id_aliases(rid: str) -> List[str]:
    s = rid.strip()
    low = s.lower()
    core = _ID_PREFIX_RE.sub("", low)
    aliases = [s, low]
    if core:
        aliases.append(core)
        if core.isdigit():
            aliases += [f"t{core}", f"task{core}", f"task_{core}", f"step{core}"]
    return aliases


def _extract_dep_pairs(deps) -> Tuple[List[Tuple[Any, Any]], str]:
    pairs: List[Tuple[Any, Any]] = []
    if isinstance(deps, dict):
        for to_raw, prereqs in deps.items():
            if prereqs is None:
                continue
            if not isinstance(prereqs, (list, tuple, set)):
                prereqs = [prereqs]
            for p in prereqs:
                if isinstance(p, dict):
                    p = p.get("id", p.get("task_id"))
                if p is None or (isinstance(p, str) and p.strip().lower() in ("", "none", "null")):
                    continue
                pairs.append((p, to_raw))
        return pairs, "dict"
    if isinstance(deps, list):
        for it in deps:
            if isinstance(it, dict):
                f = it.get("from", it.get("source"))
                t = it.get("to", it.get("target"))
                if f is not None and t is not None:
                    pairs.append((f, t))
            elif isinstance(it, (list, tuple)) and len(it) == 2:
                pairs.append((it[0], it[1]))
        return pairs, "list"
    return pairs, "other"


def normalize_dag(dag: Dict) -> Tuple[Dict, Dict]:
    log = {"dup_ids_renamed": 0, "missing_ids_filled": 0, "non_dict_tasks_dropped": 0,
           "refs_resolved_by_alias": 0, "refs_unresolvable_dropped": 0, "deps_shape": "dict"}
    items = dag.get("task_list", []) if isinstance(dag, dict) else []
    if not isinstance(items, list):
        items = []

    out_items, seen, dup_counter = [], set(), 0
    for i, item in enumerate(items):
        if not isinstance(item, dict):
            log["non_dict_tasks_dropped"] += 1
            continue
        item = dict(item)
        rid = item.get("id")
        if rid is None or str(rid).strip() == "":
            rid = i + 1
            log["missing_ids_filled"] += 1
        rid_s = str(rid).strip()
        if rid_s in seen:
            dup_counter += 1
            rid_s = f"{rid_s}_dup{dup_counter}"
            log["dup_ids_renamed"] += 1
        seen.add(rid_s)
        item["id"] = rid_s
        out_items.append(item)

    exact = {item["id"]: item["id"] for item in out_items}
    alias_map: Dict[str, str] = {}
    for item in out_items:
        for a in _id_aliases(item["id"]):
            if a not in exact and a not in alias_map:
                alias_map[a] = item["id"]

    def resolve(ref) -> Tuple[Optional[str], bool]:
        s = str(ref).strip()
        if s in exact:
            return s, True
        if s in alias_map:
            return alias_map[s], False
        if s.lower() in alias_map:
            return alias_map[s.lower()], False
        return None, False

    pairs, shape = _extract_dep_pairs(dag.get("task_dependencies", {}) if isinstance(dag, dict) else {})
    log["deps_shape"] = shape
    new_deps: Dict[str, List[str]] = {}
    for f_raw, t_raw in pairs:
        f, f_exact = resolve(f_raw)
        t, t_exact = resolve(t_raw)
        if f is None or t is None:
            log["refs_unresolvable_dropped"] += 1
            continue
        if not (f_exact and t_exact):
            log["refs_resolved_by_alias"] += 1
        if f not in new_deps.setdefault(t, []):
            new_deps[t].append(f)

    return {"task_list": out_items, "task_dependencies": new_deps}, log


def repair_graph(task_ids: List[str], deps: List[Dict], add_boundary: bool = True) -> Tuple[List[Dict], Dict]:
    log = {"self_loops_removed": 0, "duplicate_edges_removed": 0, "dangling_edges_removed": 0,
           "cycle_edges_removed": 0, "boundary_edges_added": 0, "start_id": None, "end_id": None}
    known = set(task_ids)
    edges, seen = [], set()
    for d in deps:
        f, t = d.get("from"), d.get("to")
        if f not in known or t not in known:
            log["dangling_edges_removed"] += 1
            continue
        if f == t:
            log["self_loops_removed"] += 1
            continue
        if (f, t) in seen:
            log["duplicate_edges_removed"] += 1
            continue
        seen.add((f, t))
        edges.append((f, t))

    adj: Dict[str, List[str]] = {n: [] for n in task_ids}
    indeg: Dict[str, int] = {n: 0 for n in task_ids}
    for f, t in edges:
        adj[f].append(t)
        indeg[t] += 1
    roots = [n for n in task_ids if indeg[n] == 0] + [n for n in task_ids if indeg[n] > 0]
    WHITE, GRAY, BLACK = 0, 1, 2
    color = {n: WHITE for n in task_ids}
    back_edges = set()
    for root in roots:
        if color[root] != WHITE:
            continue
        color[root] = GRAY
        stack = [(root, iter(adj[root]))]
        while stack:
            node, it = stack[-1]
            descended = False
            for nxt in it:
                if color[nxt] == GRAY:
                    back_edges.add((node, nxt))
                elif color[nxt] == WHITE:
                    color[nxt] = GRAY
                    stack.append((nxt, iter(adj[nxt])))
                    descended = True
                    break
            if not descended:
                color[node] = BLACK
                stack.pop()
    if back_edges:
        log["cycle_edges_removed"] = len(back_edges)
        edges = [e for e in edges if e not in back_edges]

    if add_boundary and task_ids:
        indeg = {n: 0 for n in task_ids}
        outdeg = {n: 0 for n in task_ids}
        for f, t in edges:
            outdeg[f] += 1
            indeg[t] += 1

        def unique_id(base: str) -> str:
            cand = base
            while cand in known:
                cand = f"_{cand}_"
            return cand

        start_id, end_id = unique_id("start"), unique_id("end")
        log["start_id"], log["end_id"] = start_id, end_id
        for n in task_ids:
            if indeg[n] == 0:
                edges.append((start_id, n))
                log["boundary_edges_added"] += 1
        for n in task_ids:
            if outdeg[n] == 0:
                edges.append((n, end_id))
                log["boundary_edges_added"] += 1

    return [{"from": f, "to": t, "condition": None} for f, t in edges], log


def diagnose_graph(task_ids: List[str], deps: List[Dict]) -> Dict:
    edges = [(d.get("from"), d.get("to")) for d in deps]
    nodes = list(dict.fromkeys(list(task_ids) + [x for e in edges for x in e if x is not None]))
    if not task_ids:
        return {"n_tasks": 0, "n_edges": 0, "n_sources": 0, "n_sinks": 0, "n_isolated_tasks": 0,
                "n_components": 0, "has_cycle": False, "self_loops": 0, "duplicate_edges": 0,
                "path_coverage": 0.0}
    self_loops = sum(1 for f, t in edges if f == t)
    uniq, dup = set(), 0
    for e in edges:
        dup += e in uniq
        uniq.add(e)
    adj = {n: [] for n in nodes}
    radj = {n: [] for n in nodes}
    for f, t in uniq:
        if f != t:
            adj[f].append(t)
            radj[t].append(f)
    indeg = {n: len(radj[n]) for n in nodes}
    outdeg = {n: len(adj[n]) for n in nodes}
    sources = [n for n in nodes if indeg[n] == 0]
    sinks = [n for n in nodes if outdeg[n] == 0]
    isolated = [n for n in task_ids if indeg[n] == 0 and outdeg[n] == 0]

    deg = dict(indeg)
    queue = [n for n in nodes if deg[n] == 0]
    visited = 0
    while queue:
        n = queue.pop()
        visited += 1
        for m in adj[n]:
            deg[m] -= 1
            if deg[m] == 0:
                queue.append(m)
    has_cycle = self_loops > 0 or visited < len(nodes)

    parent = {n: n for n in nodes}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    for f, t in uniq:
        parent[find(f)] = find(t)
    n_components = len({find(n) for n in nodes})

    def reach(starts, graph):
        seen_, stack_ = set(starts), list(starts)
        while stack_:
            x = stack_.pop()
            for y in graph[x]:
                if y not in seen_:
                    seen_.add(y)
                    stack_.append(y)
        return seen_
    covered = reach(sources, adj) & reach(sinks, radj)
    path_coverage = sum(1 for n in task_ids if n in covered) / len(task_ids)

    return {"n_tasks": len(task_ids), "n_edges": len(uniq), "n_sources": len(sources),
            "n_sinks": len(sinks), "n_isolated_tasks": len(isolated), "n_components": n_components,
            "has_cycle": bool(has_cycle), "self_loops": self_loops, "duplicate_edges": dup,
            "path_coverage": round(path_coverage, 3)}


def _fmt_diag(d: Dict) -> str:
    return (f"任务{d['n_tasks']} 边{d['n_edges']} 入口{d['n_sources']} 出口{d['n_sinks']} "
            f"孤立{d['n_isolated_tasks']} 连通分量{d['n_components']} "
            f"成环={'是' if d['has_cycle'] else '否'} 路径覆盖{d['path_coverage']:.2f}")


class LLMError(RuntimeError):
    pass


class LLMClient:

    def __init__(self):
        self.api_key = os.getenv("DEEPSEEK_API_KEY")
        if not self.api_key:
            raise RuntimeError("请先设置环境变量 DEEPSEEK_API_KEY")
        self.base_url = LLM_BASE_URL
        self.model = LLM_MODEL

    def chat(self, messages: List[Dict[str, str]], temperature: float = LLM_TEMPERATURE,
             max_tokens: int = LLM_MAX_TOKENS, max_retries: int = 3) -> str:
        last_err = None
        for attempt in range(max_retries):
            try:
                print(f"    正在调用LLM... (尝试 {attempt + 1}/{max_retries})")
                resp = requests.post(
                    f"{self.base_url}/chat/completions",
                    headers={"Authorization": f"Bearer {self.api_key}",
                             "Content-Type": "application/json"},
                    json={"model": self.model, "messages": messages,
                          "max_tokens": max_tokens, "temperature": temperature},
                    timeout=180,
                )
                if resp.status_code == 200:
                    return resp.json()["choices"][0]["message"]["content"]
                last_err = f"HTTP {resp.status_code}: {resp.text[:200]}"
                print(f"    API Error: {last_err}")
            except KeyboardInterrupt:
                raise
            except requests.exceptions.Timeout:
                last_err = "timeout"
                print("    ⚠ LLM Timeout")
            except requests.exceptions.ConnectionError:
                last_err = "connection error"
                print("    ⚠ 网络连接错误")
            except Exception as e:
                last_err = str(e)
                print(f"    LLM Error: {e}")
            if attempt < max_retries - 1:
                time.sleep(10)
        raise LLMError(f"LLM调用失败: {last_err}")


class SentenceEmbedder:

    def __init__(self, model_name: str):
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as e:
            raise RuntimeError("需要安装 sentence-transformers: pip install sentence-transformers") from e
        print(f"  加载Embedding模型: {model_name}")
        self.model_name = model_name
        self.model = SentenceTransformer(model_name)

    def encode(self, texts: List[str]) -> np.ndarray:
        vecs = self.model.encode(texts, batch_size=64, normalize_embeddings=True,
                                 show_progress_bar=len(texts) > 200)
        return np.asarray(vecs, dtype=np.float32)


class LLM4WorkflowModel:

    def __init__(self, data_path: str = None, embedding_path: str = None,
                 llm=None, embedder=None):
        print("\n" + "=" * 60)
        print("初始化 LLM4Workflow (忠实复现版)")
        print("=" * 60)
        print("  0. Task Extraction (原 create_game prompt)")
        print("  1. Query Rewriting (原 REWRITE_QUERY_PROMPT)")
        print("  2. API Retrieval   (向量 MMR, k=3/query, 并集去重)")
        print("  3. DAG Generation  (原 WRITE_DAG_PROMPT)")

        self.llm = llm if llm is not None else LLMClient()
        self.data_path = Path(data_path) if data_path else SCRIPT_DIR / "data"
        self.embedding_path = Path(embedding_path) if embedding_path else SCRIPT_DIR / "embedding"

        self.api_database = self._load_api_database()
        if not self.api_database:
            raise RuntimeError(f"API数据库为空, 请检查 {self.data_path}/api_name.json")

        self.embedder = embedder if embedder is not None else SentenceEmbedder(EMBED_MODEL_NAME)
        self.api_embeddings = self._build_api_embeddings()

        print(f"\n  ✓ API数据库: {len(self.api_database)} 个API")
        print(f"  ✓ API向量: shape={self.api_embeddings.shape}, model={self.embedder.model_name}")

    def _load_api_database(self) -> List[Dict]:
        api_name_file = self.data_path / "api_name.json"
        api_desc_file = self.data_path / "api_description.json"
        apis = []
        if api_name_file.exists():
            with open(api_name_file, "r", encoding="utf-8") as f:
                api_names = json.load(f)
            api_descs = []
            if api_desc_file.exists():
                with open(api_desc_file, "r", encoding="utf-8") as f:
                    api_descs = json.load(f)
            for i, name in enumerate(api_names):
                desc = normalize_description(api_descs[i] if i < len(api_descs) else "")
                apis.append({"id": i, "name": name, "description": desc})
        return apis

    @staticmethod
    def _doc_text(api: Dict) -> str:
        return json.dumps({"name": api["name"], "description": api["description"]},
                          ensure_ascii=False)

    def _build_api_embeddings(self) -> np.ndarray:
        tag = re.sub(r"[^A-Za-z0-9]+", "_", self.embedder.model_name).strip("_")
        cache_file = self.embedding_path / f"api_features_{tag}_{len(self.api_database)}.npy"
        if cache_file.exists():
            emb = np.load(str(cache_file))
            if emb.shape[0] == len(self.api_database):
                print(f"  使用缓存向量: {cache_file}")
                return emb.astype(np.float32)
        print(f"  编码 {len(self.api_database)} 个API (首次运行较慢)...")
        emb = self.embedder.encode([self._doc_text(a) for a in self.api_database])
        try:
            self.embedding_path.mkdir(parents=True, exist_ok=True)
            np.save(str(cache_file), emb)
            print(f"  已缓存: {cache_file}")
        except Exception as e:
            print(f"  ⚠ 向量缓存写入失败(不影响结果): {e}")
        return emb

    # ---------------------------------------------------------------- Step 0
    def extract_tasks(self, user_input: str) -> str:
        print("\n[Step 0] Task Extraction (任务提取)...")
        t0 = time.time()
        init_prompt = CREATE_GAME_PROMPT.format(Demonstration=DEMONSTRATION)
        messages = [
            {"role": "user", "content": init_prompt},
            {"role": "assistant", "content": "OK"},
            {"role": "user", "content": f"workflow:{user_input}"},
        ]
        text = self.llm.chat(messages)
        lines = [ln.strip() for ln in text.strip().split("\n") if ln.strip()]
        print(f"  ✓ 提取了 {len(lines)} 个任务 ({time.time() - t0:.2f}s)")
        for ln in lines:
            print(f"    - {ln}")
        return "\n".join(lines)

    # ---------------------------------------------------------------- Step 1
    def rewrite_queries(self, task_list: str, k: int) -> List[str]:
        print("\n[Step 1] Query Rewriting (查询重写)...")
        t0 = time.time()
        prompt = REWRITE_QUERY_PROMPT.format(k=k, text=task_list)
        text = self.llm.chat([{"role": "user", "content": prompt}])
        queries = [q.strip() for q in text.strip().split("\n") if q.strip()]
        print(f"  ✓ 生成了 {len(queries)} 个查询 ({time.time() - t0:.2f}s)")
        for i, q in enumerate(queries, 1):
            print(f"    {i}. {q}")
        return queries

    # ---------------------------------------------------------------- Step 2
    def retrieve_apis(self, queries: List[str]) -> List[Dict]:
        print("\n[Step 2] API Retrieval (向量MMR检索, 多查询并集)...")
        t0 = time.time()
        if not queries:
            return []
        qvecs = self.embedder.encode(queries)
        seen, result = set(), []
        for q, qv in zip(queries, qvecs):
            idxs = mmr_select(qv, self.api_embeddings, RETRIEVE_K_PER_QUERY,
                              MMR_FETCH_K, MMR_LAMBDA)
            for idx in idxs:
                if idx not in seen:
                    seen.add(idx)
                    api = self.api_database[idx]
                    result.append({"name": api["name"], "description": api["description"]})
        print(f"  ✓ 检索到 {len(result)} 个候选API ({time.time() - t0:.2f}s)")
        return result

    # ---------------------------------------------------------------- Step 3
    def write_dag(self, task_list: str, apis: List[Dict],
                  parse_retries: int = 1, require_tasks: bool = False) -> Dict:
        print("\n[Step 3] DAG Generation (DAG生成)...")
        t0 = time.time()
        prompt = WRITE_DAG_PROMPT.format(task_list=task_list,
                                         api_list=json.dumps(apis, ensure_ascii=False))
        last_err = None
        for attempt in range(max(1, parse_retries)):
            text = self.llm.chat([{"role": "user", "content": prompt}])
            try:
                dag = parse_json_object(text)
                if require_tasks and not (isinstance(dag.get("task_list"), list) and dag["task_list"]):
                    raise ValueError("DAG中没有有效的 task_list")
                print(f"  ✓ 生成DAG: {len(dag.get('task_list', []))} 个任务 ({time.time() - t0:.2f}s)")
                return dag
            except ValueError as e:
                last_err = e
                if parse_retries > 1:
                    print(f"    ⚠ DAG解析失败 (第{attempt + 1}/{parse_retries}次): {e}")
        raise last_err

    @staticmethod
    def _norm_id(raw) -> str:
        s = str(raw).strip()
        return f"t{s}" if s.isdigit() else s

    def _to_unified(self, dag: Dict, candidates: List[Dict]):
        cand_map = {a["name"].strip().lower(): a["name"] for a in candidates}
        tasks, api_bindings, id_map = [], {}, {}
        not_in_candidates = 0

        for i, item in enumerate(dag.get("task_list", []) or []):
            if not isinstance(item, dict):
                continue
            raw_id = item.get("id", i + 1)
            tid = self._norm_id(raw_id)
            id_map[str(raw_id).strip()] = tid
            name = item.get("task name") or item.get("task_name") or item.get("name") or ""

            raw_apis = item.get("apis", item.get("api", []))
            if isinstance(raw_apis, str):
                raw_apis = [raw_apis]
            apis_out = []
            for a in raw_apis or []:
                a = str(a).strip()
                if not a:
                    continue
                canon = cand_map.get(a.lower())
                if canon is None:
                    not_in_candidates += 1
                    canon = a
                if canon not in apis_out:
                    apis_out.append(canon)
            apis_out = apis_out[:TOP_K_OUTPUT] or ["manual-task"]

            tasks.append({"id": tid, "name": name, "type": "userTask"})
            api_bindings[tid] = {
                "task_name": name,
                "api_name": apis_out[0],
                "top5_apis": apis_out,
                "confidence": 1.0,
                "method": "llm4workflow",
            }

        dependencies = []
        deps = dag.get("task_dependencies", {}) or {}
        if isinstance(deps, dict):
            for to_raw, prereqs in deps.items():
                to_id = id_map.get(str(to_raw).strip())
                if to_id is None:
                    continue
                if not isinstance(prereqs, list):
                    prereqs = [prereqs]
                for p in prereqs:
                    from_id = id_map.get(str(p).strip())
                    if from_id is not None:
                        dependencies.append({"from": from_id, "to": to_id, "condition": None})
        return tasks, dependencies, api_bindings, not_in_candidates

    def _generate(self, user_input: str, parse_retries: int = 1, require_tasks: bool = False) -> Dict:
        st = {"extracted": "", "queries": [], "apis": [], "dag": {}, "n_extracted": 0,
              "tasks": [], "dependencies": [], "api_bindings": {}, "not_in_cand": 0,
              "error": None, "time": 0.0}
        t0 = time.time()
        try:
            st["extracted"] = self.extract_tasks(user_input)
            st["n_extracted"] = len(st["extracted"].split("\n")) if st["extracted"] else 0
            st["queries"] = self.rewrite_queries(st["extracted"], k=max(st["n_extracted"], 1))
            st["apis"] = self.retrieve_apis(st["queries"])
            st["dag"] = self.write_dag(st["extracted"], st["apis"],
                                       parse_retries=parse_retries, require_tasks=require_tasks)
            (st["tasks"], st["dependencies"],
             st["api_bindings"], st["not_in_cand"]) = self._to_unified(st["dag"], st["apis"])
        except KeyboardInterrupt:
            raise
        except Exception as e:
            st["error"] = f"{type(e).__name__}: {e}"
            print(f"  ✗ 流程失败 (不做兜底, 如实记录为空结果): {st['error']}")
        st["time"] = time.time() - t0
        return st

    def _base_extra(self, st: Dict, api_bindings: Dict, not_in_cand: int, error) -> Dict:
        return {
            "queries": st["queries"],
            "extracted_tasks": st["extracted"],
            "retrieved_apis": [a["name"] for a in st["apis"]],
            "num_planned_tasks": st["n_extracted"],
            "top5_per_node": {tid: v["top5_apis"] for tid, v in api_bindings.items()},
            "num_apis_not_in_candidates": not_in_cand,
            "config": {
                "llm": LLM_MODEL, "temperature": LLM_TEMPERATURE,
                "embed_model": getattr(self.embedder, "model_name", "unknown"),
                "retrieval": f"MMR k={RETRIEVE_K_PER_QUERY} fetch_k={MMR_FETCH_K} lambda={MMR_LAMBDA}",
                "top_k_output": TOP_K_OUTPUT,
            },
            "error": error,
        }

    def _raw_output(self, st: Dict, user_input: str, scenario_name: str) -> UnifiedOutput:
        return UnifiedOutput(
            method="LLM4Workflow",
            scenario_name=scenario_name,
            user_request=user_input,
            tasks=st["tasks"],
            dependencies=st["dependencies"],
            gateways=[],
            api_bindings=st["api_bindings"],
            roles=[],
            execution_time=st["time"],
            extra_info=self._base_extra(st, st["api_bindings"], st["not_in_cand"], st["error"]),
        )

    def run(self, user_input: str, scenario_name: str) -> UnifiedOutput:
        print(f"\n{'=' * 60}")
        print(f"LLM4Workflow 处理场景: {scenario_name}")
        print(f"{'=' * 60}")
        st = self._generate(user_input)
        return self._raw_output(st, user_input, scenario_name)

    def run_both(self, user_input: str, scenario_name: str):
        print(f"\n{'=' * 60}")
        print(f"LLM4Workflow 处理场景: {scenario_name}  (raw + repaired)")
        print(f"{'=' * 60}")
        raw_st = self._generate(user_input)
        raw_out = self._raw_output(raw_st, user_input, scenario_name)
        try:
            rep_out = self._repair(user_input, scenario_name, raw_st)
        except KeyboardInterrupt:
            raise
        except Exception as e:
            print(f"  ✗ 修复阶段异常 (raw 结果仍然保留, 本场景不产出 repaired): {e}")
            traceback.print_exc()
            rep_out = None
        return raw_out, rep_out

    def _convert_repaired(self, st: Dict) -> Optional[Dict]:
        if st["error"] is not None or not isinstance(st["dag"], dict):
            return None
        dag_norm, norm_log = normalize_dag(st["dag"])
        tasks, deps, bindings, not_in_cand = self._to_unified(dag_norm, st["apis"])
        if not tasks:
            return None
        return {"st": st, "tasks": tasks, "dependencies": deps, "api_bindings": bindings,
                "not_in_cand": not_in_cand, "norm_log": norm_log}

    def _repair(self, user_input: str, scenario_name: str, raw_st: Dict) -> UnifiedOutput:
        print("\n[Repair] 对等修复 (与 LEWR 相同的校验 / 重试 / 修复)...")
        t0 = time.time()
        min_t, max_t = _estimate_task_range(user_input)
        print(f"  任务数目标区间 (与 LEWR 同一估计函数): {min_t} ~ {max_t}")

        attempts: List[Dict] = []
        best, best_score = None, -999
        for attempt in range(REPAIR_MAX_ATTEMPTS):
            reused = False
            if attempt == 0:
                raw_dag = raw_st["dag"] if isinstance(raw_st["dag"], dict) else {}
                if raw_st["error"] is None and isinstance(raw_dag.get("task_list"), list) and raw_dag["task_list"]:
                    st, reused = raw_st, True
                else:
                    print("  原始采样不可用 (解析失败/无任务), 重新生成并启用解析重试...")
                    st = self._generate(user_input, parse_retries=REPAIR_PARSE_RETRIES, require_tasks=True)
            else:
                level = "strong" if attempt == 1 else "maximum"
                print(f"\n  第 {attempt + 1}/{REPAIR_MAX_ATTEMPTS} 次生成: 追加任务数要求 (level={level})")
                st = self._generate(build_retry_description(user_input, min_t, max_t, level),
                                    parse_retries=REPAIR_PARSE_RETRIES, require_tasks=True)

            conv = self._convert_repaired(st)
            if conv is None:
                attempts.append({"attempt": attempt + 1, "reused_raw_sample": reused,
                                 "task_count": 0, "error": st["error"] or "no tasks"})
                print(f"  → 第 {attempt + 1} 次没有得到可用结果, 跳过")
                continue

            count = len(conv["tasks"])
            score = repair_target_score(count, min_t, max_t)
            in_range = min_t <= count <= max_t
            attempts.append({"attempt": attempt + 1, "reused_raw_sample": reused,
                             "task_count": count, "in_range": in_range, "score": score})
            print(f"  → 第 {attempt + 1} 次得到 {count} 个任务 (需要 {min_t}~{max_t})")
            if score > best_score:
                best_score, best = score, dict(conv, attempt=attempt + 1)
            if in_range:
                print("  ✓ 任务数在区间内, 采用")
                break

        is_fallback = False
        if best is None:
            if REPAIR_USE_FALLBACK:
                is_fallback = True
                print("  ⚠ 所有尝试均失败, 使用3任务模板兜底 (与 LEWR 的 _generate_fallback 相同)")
                tasks = [{"id": tid, "name": nm, "type": ty} for tid, nm, ty in FALLBACK_TASKS]
                deps = [{"from": FALLBACK_TASKS[i][0], "to": FALLBACK_TASKS[i + 1][0], "condition": None}
                        for i in range(len(FALLBACK_TASKS) - 1)]
                bindings = {tid: {"task_name": nm, "api_name": "manual-task", "top5_apis": ["manual-task"],
                                  "confidence": 1.0, "method": "fallback_template"}
                            for tid, nm, _ in FALLBACK_TASKS}
                best = {"st": raw_st, "tasks": tasks, "dependencies": deps, "api_bindings": bindings,
                        "not_in_cand": 0, "norm_log": {}, "attempt": None}
            else:
                best = {"st": raw_st, "tasks": [], "dependencies": [], "api_bindings": {},
                        "not_in_cand": 0, "norm_log": {}, "attempt": None}

        tasks, deps, bindings = best["tasks"], best["dependencies"], best["api_bindings"]

        trimmed = 0
        if len(tasks) > max_t:
            trimmed = len(tasks) - max_t
            print(f"  ✂ 裁剪任务: {len(tasks)} → {max_t}")
            tasks = tasks[:max_t]
            keep = {t["id"] for t in tasks}
            deps = [d for d in deps if d["from"] in keep and d["to"] in keep]
            bindings = {k: v for k, v in bindings.items() if k in keep}

        task_ids = [t["id"] for t in tasks]
        deps_fixed, graph_log = repair_graph(task_ids, deps, add_boundary=REPAIR_ADD_BOUNDARY)
        diag_raw = diagnose_graph([t["id"] for t in raw_st["tasks"]], raw_st["dependencies"])
        diag_rep = diagnose_graph(task_ids, deps_fixed)

        print(f"  结构自检 raw     : {_fmt_diag(diag_raw)}")
        print(f"  结构自检 repaired: {_fmt_diag(diag_rep)}")
        print(f"  图修复: 去环边 {graph_log['cycle_edges_removed']}, 自环 {graph_log['self_loops_removed']}, "
              f"重复边 {graph_log['duplicate_edges_removed']}, 补 start/end 边 {graph_log['boundary_edges_added']}")

        if is_fallback:
            error = "all generation attempts failed; fallback template used"
        elif not tasks:
            error = raw_st["error"] or "no tasks generated"
        else:
            error = None

        extra = self._base_extra(best["st"], bindings, best["not_in_cand"], error)
        extra["raw_error"] = raw_st["error"]
        extra["raw_execution_time"] = raw_st["time"]
        extra["repair"] = {
            "task_range": [min_t, max_t],
            "attempts": attempts,
            "selected_attempt": best["attempt"],
            "is_fallback": is_fallback,
            "trimmed_tasks": trimmed,
            "normalize": best["norm_log"],
            "graph_repair": graph_log,
            "diag_raw": diag_raw,
            "diag_repaired": diag_rep,
            "settings": {"max_attempts": REPAIR_MAX_ATTEMPTS, "parse_retries": REPAIR_PARSE_RETRIES,
                         "add_boundary": REPAIR_ADD_BOUNDARY, "use_fallback": REPAIR_USE_FALLBACK},
        }

        return UnifiedOutput(
            method="LLM4Workflow_Repaired",
            scenario_name=scenario_name,
            user_request=user_input,
            tasks=tasks,
            dependencies=deps_fixed,
            gateways=[],
            api_bindings=bindings,
            roles=[],
            execution_time=raw_st["time"] + (time.time() - t0),
            extra_info=extra,
        )


def main():
    print("\n")
    print("╔" + "═" * 58 + "╗")
    print("║" + " " * 5 + "LLM4Workflow 评估运行脚本 (忠实复现 + 对等修复)" + " " * 1 + "║")
    print("╚" + "═" * 58 + "╝")

    data_path = SCRIPT_DIR / "data"
    embedding_path = SCRIPT_DIR / "embedding"
    if not data_path.exists():
        data_path = MODEL_ROOT / "data"
    if not embedding_path.exists():
        embedding_path = MODEL_ROOT / "embedding"

    model = LLM4WorkflowModel(data_path=str(data_path), embedding_path=str(embedding_path))

    print("\n" + "=" * 60)
    print("开始评估测试场景 (每个场景产出 raw + repaired)")
    print("=" * 60)

    results_raw, results_rep, reports = [], [], []
    for i, scenario in enumerate(BPMN_TEST_SCENARIOS):
        print(f"\n>>> 场景 [{i + 1}/{len(BPMN_TEST_SCENARIOS)}]: {scenario.name}")
        try:
            raw, rep = model.run_both(scenario.requirement, scenario.name)
            results_raw.append(raw)

            print("\n结果摘要 (raw):")
            print(f"  - 任务数: {len(raw.tasks)}  依赖数: {len(raw.dependencies)}  "
                  f"网关数: {len(raw.gateways)}  API绑定数: {len(raw.api_bindings)}  "
                  f"执行时间: {raw.execution_time:.2f}s")
            if raw.extra_info.get("error"):
                print(f"  - ⚠ 错误: {raw.extra_info['error']}")
            print("  - 每节点Top-5 API:")
            for tid, v in raw.api_bindings.items():
                print(f"      [{tid}] {v['task_name']}: {v.get('top5_apis', [v['api_name']])}")

            if rep is not None:
                results_rep.append(rep)
                print("\n结果摘要 (repaired):")
                print(f"  - 任务数: {len(rep.tasks)}  依赖数: {len(rep.dependencies)}  "
                      f"网关数: {len(rep.gateways)}  API绑定数: {len(rep.api_bindings)}  "
                      f"执行时间: {rep.execution_time:.2f}s (含 raw 生成与全部重试)")
                reports.append({"scenario": scenario.name, **rep.extra_info["repair"],
                                "raw_error": rep.extra_info.get("raw_error")})
        except KeyboardInterrupt:
            print(f"\n  ⚠ 用户中断，跳过场景 {scenario.name}")
            print("    (再次按Ctrl+C退出整个程序)")
            try:
                time.sleep(2)
            except KeyboardInterrupt:
                print("\n程序被用户终止")
                break
            continue
        except Exception as e:
            print(f"  ✗ 场景 {scenario.name} 处理失败: {e}")
            traceback.print_exc()
            continue

    output_dir = EVAL_ROOT / "results"
    save_results(results_raw, str(output_dir), "llm4workflow_raw")
    save_results(results_rep, str(output_dir), "llm4workflow_repaired")
    try:
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        report_file = Path(output_dir) / "llm4workflow_repair_report.json"
        with open(report_file, "w", encoding="utf-8") as f:
            json.dump(reports, f, indent=2, ensure_ascii=False)
        print(f"\n修复日志已保存: {report_file}")
    except Exception as e:
        print(f"\n  ⚠ 修复日志写入失败(不影响结果): {e}")

    if reports:
        print("\n" + "=" * 60)
        print("修复前后结构自检对比 (入度0=start, 出度0=end)")
        print("=" * 60)
        for r in reports:
            print(f"\n[{r['scenario']}]")
            print(f"  raw      : {_fmt_diag(r['diag_raw'])}")
            print(f"  repaired : {_fmt_diag(r['diag_repaired'])}")
            tags = [f"尝试{len(r['attempts'])}次",
                    f"采用第{r['selected_attempt']}次" if r["selected_attempt"] else "无可用尝试"]
            if r["trimmed_tasks"]:
                tags.append(f"裁剪{r['trimmed_tasks']}个任务")
            if r["is_fallback"]:
                tags.append("⚠使用兜底模板")
            print(f"  修复动作 : {', '.join(tags)}")
        n_fb = sum(1 for r in reports if r["is_fallback"])
        if n_fb:
            print(f"\n⚠ 有 {n_fb} 个场景使用了兜底模板, 这些场景的 repaired 结果不代表真实生成能力, 论文中请单独说明。")

    print("\n" + "=" * 60)
    print("LLM4Workflow 评估完成! 已保存: llm4workflow_raw / llm4workflow_repaired")
    print("=" * 60)


if __name__ == "__main__":
    main()
