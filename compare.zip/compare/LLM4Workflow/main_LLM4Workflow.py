import json
import sys
import os
import re
import time
import requests
from pathlib import Path
from typing import List, Dict, Any, Optional

PROJECT_ROOT = Path(__file__).parent.absolute()
sys.path.insert(0, str(PROJECT_ROOT))

from tools import APIDatabase


API_CONFIG = {
    "api_key": os.getenv("DEEPSEEK_API_KEY", ""),
    "base_url": "https://api.deepseek.com/v1",
    "model": "deepseek-chat",
    "temperature": 0.7,
    "max_tokens": 2500,
}


class LLMClient:


    def __init__(self):
        self.api_key = API_CONFIG["api_key"]
        self.base_url = API_CONFIG["base_url"]
        self.model = API_CONFIG["model"]

    def chat(self, prompt: str, system_prompt: str = None) -> str:
        """调用LLM"""
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": self.model,
                    "messages": messages,
                    "temperature": API_CONFIG["temperature"],
                    "max_tokens": API_CONFIG["max_tokens"]
                },
                timeout=60
            )

            if response.status_code == 200:
                result = response.json()
                return result["choices"][0]["message"]["content"]
            else:
                print(f"  API Error: {response.status_code}")
                return ""
        except Exception as e:
            print(f"  LLM Error: {e}")
            return ""


class LLM4Workflow:


    def __init__(self, data_path: str = None, embedding_path: str = None):

        self.llm = LLMClient()

        data_path = Path(data_path) if data_path else PROJECT_ROOT / "data"
        embedding_path = Path(embedding_path) if embedding_path else PROJECT_ROOT / "embedding"

        print("\n[初始化] 加载ProgrammableWeb API数据库...")
        self.api_db = APIDatabase(str(data_path), str(embedding_path))
        print(f"  ✓ 加载了 {self.api_db.num_api} 个API")

    def rewrite_query(self, user_input: str, k: int = 5) -> List[str]:

        print("\n[Step 1] Query Rewriting (查询重写)...")
        start_time = time.time()

        prompt = f"""You are a query rewriting expert for API search. Given a user's process description,
generate {k} specific search queries to find relevant web APIs from ProgrammableWeb.

User's process description:
{user_input}

Generate {k} specific, concise search queries that would help find relevant APIs.
Each query should focus on a different aspect of the process (e.g., shipping API, email notification API, etc.)

Output as JSON array of strings only, no other text.
Example: ["shipping tracking API", "email notification API", "payment processing API"]"""

        try:
            response = self.llm.chat(prompt)

            json_match = re.search(r'\[.*\]', response, re.DOTALL)
            if json_match:
                queries = json.loads(json_match.group())
                print(f"  ✓ 生成了 {len(queries)} 个查询 ({time.time()-start_time:.2f}s)")
                for i, q in enumerate(queries, 1):
                    print(f"    {i}. {q}")
                return queries
        except Exception as e:
            print(f"  ✗ Query rewriting失败: {e}")

        fallback_queries = self._extract_keywords_as_queries(user_input)
        print(f"  ⚠ 使用回退查询: {fallback_queries}")
        return fallback_queries

    def _extract_keywords_as_queries(self, text: str) -> List[str]:

        keywords = ['shipping', 'logistics', 'package', 'label', 'insurance',
                   'delivery', 'tracking', 'notification', 'email', 'payment']
        text_lower = text.lower()
        queries = []
        for kw in keywords:
            if kw in text_lower:
                queries.append(f"{kw} API")
        return queries if queries else ["shipping API", "logistics API"]

    def plan_tasks(self, user_input: str) -> List[Dict]:

        print("\n[Step 2] Task Planning (任务规划)...")
        start_time = time.time()

        prompt = f"""You are a workflow planning expert. Given a process description, decompose it into a list of executable tasks.

Process description:
{user_input}

For each task, provide:
- task_id: t1, t2, t3, etc.
- name: Short task name (in English, 3-6 words)
- description: Brief description of what this task does
- dependencies: List of task_ids this task depends on (empty list if none)

Output as JSON array only, no other text.
Example:
[
    {{"task_id": "t1", "name": "Clarify shipping responsibility", "description": "Determine who handles shipping", "dependencies": []}},
    {{"task_id": "t2", "name": "Select logistics company", "description": "Choose shipping provider", "dependencies": ["t1"]}}
]"""

        try:
            response = self.llm.chat(prompt)

            json_match = re.search(r'\[.*\]', response, re.DOTALL)
            if json_match:
                tasks = json.loads(json_match.group())
                print(f"  ✓ 规划了 {len(tasks)} 个任务 ({time.time()-start_time:.2f}s)")
                for t in tasks:
                    deps = t.get('dependencies', [])
                    dep_str = f" → 依赖: {deps}" if deps else ""
                    print(f"    [{t.get('task_id', '?')}] {t.get('name', '未知')}{dep_str}")
                return tasks
        except Exception as e:
            print(f"  ✗ Task planning失败: {e}")

        return []

    def retrieve_apis(self, queries: List[str], top_k_per_query: int = 5) -> List[Dict]:

        print("\n[Step 3] API Retrieval (API检索)...")
        start_time = time.time()

        all_apis = {}

        for query in queries:
            results = self.api_db.search(query, top_k=top_k_per_query)
            for api in results:
                api_name = api['name']
                if api_name not in all_apis:
                    all_apis[api_name] = api
                else:
                    all_apis[api_name]['score'] += api['score']

        sorted_apis = sorted(all_apis.values(), key=lambda x: x['score'], reverse=True)

        top_apis = sorted_apis[:20]

        print(f"  ✓ 检索到 {len(top_apis)} 个相关API ({time.time()-start_time:.2f}s)")
        for i, api in enumerate(top_apis[:10], 1):
            print(f"    {i}. {api['name']} (score: {api['score']:.2f})")

        if len(top_apis) > 10:
            print(f"    ... 还有 {len(top_apis)-10} 个API")

        return top_apis

    def generate_dag(self, tasks: List[Dict], apis: List[Dict]) -> Dict:

        print("\n[Step 4] DAG Generation (DAG生成与API绑定)...")
        start_time = time.time()

        if not tasks:
            print("  ✗ 没有任务可以生成DAG")
            return {"task_list": [], "task_dependencies": {}}

        api_names = [api['name'] for api in apis]
        api_info = "\n".join([f"- {api['name']}: {api.get('description', '')[:100]}" for api in apis[:15]])

        prompt = f"""You are a workflow expert. Given a list of tasks and available APIs, bind each task to the most suitable API.

Tasks:
{json.dumps(tasks, indent=2)}

Available APIs (from ProgrammableWeb):
{api_info}

For each task, select the most relevant API from the list above.
If no API is suitable, use "manual-task" as the API name.

Output as JSON with this exact format:
{{
    "task_list": [
        {{"id": "t1", "name": "task name", "api": "api-name-from-list"}},
        ...
    ],
    "task_dependencies": {{
        "t2": ["t1"],
        "t3": ["t1", "t2"]
    }},
    "parallel_groups": [],
    "exclusive_groups": []
}}

Output only valid JSON, no other text."""

        try:
            response = self.llm.chat(prompt)

            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                dag = json.loads(json_match.group())

                task_list = dag.get('task_list', [])
                print(f"  ✓ 生成DAG ({time.time()-start_time:.2f}s)")
                print(f"\n  任务-API绑定:")
                for task in task_list:
                    print(f"    [{task.get('id', '?')}] {task.get('name', '?')[:40]}...")
                    print(f"        → {task.get('api', '?')}")

                return dag
        except Exception as e:
            print(f"  ✗ DAG生成失败: {e}")

        return self._fallback_dag(tasks, apis)

    def _fallback_dag(self, tasks: List[Dict], apis: List[Dict]) -> Dict:
        """回退DAG生成"""
        task_list = []
        task_deps = {}

        for i, task in enumerate(tasks):
            task_id = task.get('task_id', f't{i+1}')
            task_name = task.get('name', f'Task {i+1}')

            best_api = "manual-task"
            task_lower = task_name.lower()

            for api in apis:
                api_lower = api['name'].lower()
                for word in task_lower.split():
                    if len(word) > 3 and word in api_lower:
                        best_api = api['name']
                        break
                if best_api != "manual-task":
                    break

            task_list.append({
                "id": task_id,
                "name": task_name,
                "api": best_api
            })

            deps = task.get('dependencies', [])
            if deps:
                task_deps[task_id] = deps

        return {
            "task_list": task_list,
            "task_dependencies": task_deps,
            "parallel_groups": [],
            "exclusive_groups": []
        }

    def run(self, user_input: str) -> Dict:

        print("\n" + "=" * 60)
        print("开始 LLM4Workflow 流程")
        print("=" * 60)

        total_start = time.time()

        queries = self.rewrite_query(user_input)

        tasks = self.plan_tasks(user_input)

        apis = self.retrieve_apis(queries)

        dag = self.generate_dag(tasks, apis)

        total_time = time.time() - total_start
        print(f"\n  总耗时: {total_time:.2f}s")

        return {
            "user_input": user_input,
            "method": "LLM4Workflow",
            "queries": queries,
            "tasks": tasks,
            "retrieved_apis": [api['name'] for api in apis],
            "dag": dag
        }


def convert_to_evaluation_format(result: Dict) -> Dict:
    """将LLM4Workflow输出转换为统一评估格式"""

    dag = result.get('dag', {})
    task_list = dag.get('task_list', [])
    task_deps = dag.get('task_dependencies', {})

    tasks = []
    for task in task_list:
        tasks.append({
            "task_id": task.get('id', ''),
            "name": task.get('name', ''),
            "type": "task"
        })

    if not tasks:
        for task in result.get('tasks', []):
            tasks.append({
                "task_id": task.get('task_id', ''),
                "name": task.get('name', ''),
                "type": "task"
            })

    dependencies = []
    for task_id, deps in task_deps.items():
        for dep in deps:
            dependencies.append({
                "from": dep,
                "to": task_id
            })

    api_bindings = {}
    for task in task_list:
        task_id = task.get('id', '')
        api_name = task.get('api', '')
        if task_id and api_name:
            api_bindings[task_id] = {
                "task_name": task.get('name', ''),
                "api_name": api_name,
                "api_score": 1.0
            }

    return {
        "user_request": result.get('user_input', ''),
        "method": "LLM4Workflow (ProgrammableWeb)",
        "tasks": tasks,
        "dependencies": dependencies,
        "parallel_groups": dag.get('parallel_groups', []),
        "exclusive_groups": dag.get('exclusive_groups', []),
        "api_bindings": api_bindings,
        "queries_used": result.get('queries', []),
        "apis_retrieved": result.get('retrieved_apis', [])
    }


def print_result(result: Dict):
    """打印结果"""
    print("\n" + "=" * 60)
    print("最终结果")
    print("=" * 60)

    print(f"\n任务数量: {len(result['tasks'])}")
    print(f"依赖关系: {len(result['dependencies'])}")
    print(f"API绑定: {len(result['api_bindings'])}")

    print("\n任务列表:")
    for task in result['tasks']:
        print(f"  [{task['task_id']}] {task['name']}")

    print("\nAPI绑定:")
    for task_id, binding in result['api_bindings'].items():
        print(f"  [{task_id}] {binding['task_name'][:40]}...")
        print(f"      → {binding['api_name']}")


def main():
    print("\n")
    print("╔" + "═" * 58 + "╗")
    print("║" + " " * 12 + "LLM4Workflow 对比实验" + " " * 18 + "║")
    print("║" + " " * 8 + "ProgrammableWeb API数据集版本" + " " * 13 + "║")
    print("╚" + "═" * 58 + "╝")

    if len(sys.argv) > 1:
        user_input = " ".join(sys.argv[1:])
    else:
        user_input = """If goods shall be shipped, the secretary clarifies who will do the shipping.
If you have large amounts, special shipping will be necessary. In these cases the secretary
invites three logistic companies to make offers and she selects one of them. In case of small
amounts, normal post shipment is used. Therefore a package label is written by the secretary
and a parcel insurance taken by the logistics department head if necessary. In the meantime
the goods can be already packaged by the warehousemen. If everything is ready, the packaged
goods are prepared for being picked up by the logistic company."""

    print("\n" + "=" * 60)
    print("用户输入")
    print("=" * 60)
    print(f"\n{user_input[:300]}..." if len(user_input) > 300 else f"\n{user_input}")

    workflow = LLM4Workflow()
    result = workflow.run(user_input)

    eval_format = convert_to_evaluation_format(result)

    output_file = PROJECT_ROOT / "output.json"
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(eval_format, f, indent=2, ensure_ascii=False)

    print_result(eval_format)

    print(f"\n✓ 结果已保存到: {output_file}")

    print("\n" + "=" * 60)
    print("LLM4Workflow 特点说明")
    print("=" * 60)
    print("  1. Query Rewriting: LLM生成多个搜索查询")
    print("  2. Task Planning: LLM规划任务和依赖")
    print("  3. API Retrieval: 从ProgrammableWeb检索API")
    print("  4. DAG Generation: LLM绑定任务和API")
    print("  * 纯LLM驱动，无需训练神经网络")
    print("=" * 60)


if __name__ == "__main__":
    main()
