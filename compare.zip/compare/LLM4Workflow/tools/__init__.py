"""
tools模块 - ProgrammableWeb数据加载
====================================
为LLM4Workflow提供API数据支持
"""

import os
import json
import numpy as np
from pathlib import Path
from typing import List, Dict, Tuple


class APIDatabase:
    """
    ProgrammableWeb API数据库

    提供API检索功能，支持：
    1. 关键词匹配
    2. RoBERTa特征相似度（如果可用）
    """

    def __init__(self, data_path: str = None, embedding_path: str = None):
        self.data_path = Path(data_path) if data_path else Path(__file__).parent.parent / "data"
        self.embedding_path = Path(embedding_path) if embedding_path else Path(__file__).parent.parent / "embedding"

        self._load_data()
        self._load_roberta_features()
        self._build_keyword_index()

    def _load_data(self):
        """加载ProgrammableWeb数据"""
        with open(self.data_path / "api_name.json", 'r', encoding='utf-8') as f:
            self.api_names = json.load(f)

        api_desc_path = self.data_path / "api_description.json"
        if api_desc_path.exists():
            with open(api_desc_path, 'r', encoding='utf-8') as f:
                self.api_descriptions = json.load(f)
        else:
            self.api_descriptions = [""] * len(self.api_names)

        with open(self.data_path / "category_list.json", 'r', encoding='utf-8') as f:
            self.categories = json.load(f)

        self.num_api = len(self.api_names)
        self.api_to_idx = {name: i for i, name in enumerate(self.api_names)}

        print(f"[APIDatabase] Loaded {self.num_api} APIs")

    def _load_roberta_features(self):
        """加载RoBERTa特征（可选）"""
        api_feat_path = self.embedding_path / "api_features_roberta.npy"

        if api_feat_path.exists():
            self.api_features = np.load(api_feat_path)
            self.use_roberta = True
            print(f"[APIDatabase] ✓ Loaded API RoBERTa features: {self.api_features.shape}")
        else:
            self.api_features = None
            self.use_roberta = False
            print(f"[APIDatabase] ⚠ RoBERTa features not found, using keyword matching only")

    def _build_keyword_index(self):
        """构建关键词索引"""
        self.keyword_to_apis = {}

        for i, name in enumerate(self.api_names):
            words = name.lower().replace('-', ' ').replace('_', ' ').split()
            for word in words:
                if len(word) > 2:
                    if word not in self.keyword_to_apis:
                        self.keyword_to_apis[word] = []
                    self.keyword_to_apis[word].append(i)

        for i, desc in enumerate(self.api_descriptions):
            if isinstance(desc, list):
                words = [w.lower() for w in desc if len(w) > 3]
            else:
                words = str(desc).lower().split()

            for word in words[:50]:
                word = word.strip('.,!?()[]{}')
                if len(word) > 3 and word.isalpha():
                    if word not in self.keyword_to_apis:
                        self.keyword_to_apis[word] = []
                    if i not in self.keyword_to_apis[word]:
                        self.keyword_to_apis[word].append(i)

    def search(self, query: str, top_k: int = 10) -> List[Dict]:
        """
        搜索相关API

        Args:
            query: 搜索查询
            top_k: 返回数量

        Returns:
            List[Dict]: API列表，每个包含name, description, score
        """
        query_lower = query.lower()
        query_words = set(query_lower.replace('-', ' ').replace('_', ' ').split())

        scores = np.zeros(self.num_api, dtype=np.float32)

        for word in query_words:
            if len(word) > 2:
                if word in self.keyword_to_apis:
                    for api_idx in self.keyword_to_apis[word]:
                        scores[api_idx] += 1.0

                for kw, apis in self.keyword_to_apis.items():
                    if kw.startswith(word) or word.startswith(kw):
                        for api_idx in apis:
                            scores[api_idx] += 0.5

        for i, name in enumerate(self.api_names):
            name_lower = name.lower()
            for word in query_words:
                if len(word) > 3 and word in name_lower:
                    scores[i] += 2.0

        domain_boost = self._get_domain_boost(query_lower)
        scores += domain_boost

        top_indices = np.argsort(scores)[::-1][:top_k]

        results = []
        for idx in top_indices:
            if scores[idx] > 0:
                desc = self.api_descriptions[idx] if idx < len(self.api_descriptions) else ""
                if isinstance(desc, list):
                    desc = " ".join(desc[:20])
                results.append({
                    "name": self.api_names[idx],
                    "description": desc[:200] if desc else "",
                    "score": float(scores[idx])
                })

        return results

    def _get_domain_boost(self, query: str) -> np.ndarray:
        """基于领域关键词增强分数"""
        boost = np.zeros(self.num_api, dtype=np.float32)

        domain_keywords = {
            'shipping': ['shipping', 'ship', 'delivery', 'logistics', 'fedex', 'ups', 'dhl', 'usps', 'post', 'parcel', 'freight', 'carrier', 'express', 'mail'],
            'package': ['package', 'parcel', 'box', 'cargo', 'shipment', 'label', 'tracking', 'track'],
            'insurance': ['insurance', 'insure', 'coverage', 'policy', 'risk', 'claim', 'protection'],
            'company': ['company', 'business', 'enterprise', 'corporate', 'crm', 'database', 'directory'],
            'communication': ['email', 'sms', 'message', 'notification', 'contact', 'send', 'alert'],
            'payment': ['payment', 'pay', 'stripe', 'paypal', 'transaction', 'billing', 'invoice'],
            'location': ['map', 'location', 'geo', 'address', 'route', 'direction', 'place'],
            'weather': ['weather', 'forecast', 'climate', 'temperature'],
            'social': ['social', 'facebook', 'twitter', 'linkedin', 'share'],
            'storage': ['storage', 'file', 'cloud', 'dropbox', 'drive', 'upload', 'download'],
        }

        matched_terms = set()
        for domain, terms in domain_keywords.items():
            for term in terms:
                if term in query:
                    matched_terms.update(terms)

        for i, name in enumerate(self.api_names):
            name_lower = name.lower()
            for term in matched_terms:
                if term in name_lower:
                    boost[i] += 1.5

        return boost

    def get_api_info(self, api_name: str) -> Dict:
        """获取API详细信息"""
        if api_name in self.api_to_idx:
            idx = self.api_to_idx[api_name]
            desc = self.api_descriptions[idx] if idx < len(self.api_descriptions) else ""
            if isinstance(desc, list):
                desc = " ".join(desc)
            return {
                "name": api_name,
                "description": desc,
                "index": idx
            }
        return None

    def get_all_api_names(self) -> List[str]:
        """获取所有API名称"""
        return self.api_names.copy()


def load_api_database(data_path: str = None, embedding_path: str = None) -> APIDatabase:
    """加载API数据库"""
    return APIDatabase(data_path, embedding_path)
