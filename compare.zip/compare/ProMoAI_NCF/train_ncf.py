import os
import sys
import time
import json
import random
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, SubsetRandomSampler
from pathlib import Path
from collections import Counter

PROJECT_ROOT = Path(__file__).parent.absolute()
sys.path.insert(0, str(PROJECT_ROOT))


MIN_API_USAGE = 5
MAX_DOC_LEN = 100
MAX_VOCAB_SIZE = 10000
TRAIN_EPOCHS = 100
BATCH_SIZE = 128
LEARNING_RATE = 1e-3
EMBED_DIM = 128


def preprocess_data(data_path, min_usage=5):

    print(f"[预处理] 保留使用次数>={min_usage}的API...")

    with open(data_path / "api_name.json", 'r', encoding='utf-8') as f:
        all_api_names = json.load(f)
    with open(data_path / "mashup_description.json", 'r', encoding='utf-8') as f:
        mashup_descriptions = json.load(f)
    with open(data_path / "mashup_used_api.json", 'r', encoding='utf-8') as f:
        mashup_used_apis = json.load(f)
    with open(data_path / "mashup_category.json", 'r', encoding='utf-8') as f:
        mashup_categories = json.load(f)
    with open(data_path / "category_list.json", 'r', encoding='utf-8') as f:
        categories = json.load(f)

    api_counter = Counter()
    for apis in mashup_used_apis:
        for api in apis:
            api_counter[api] += 1

    valid_apis = [api for api, count in api_counter.items() if count >= min_usage]
    valid_api_set = set(valid_apis)

    valid_apis = sorted(valid_apis, key=lambda x: -api_counter[x])

    print(f"  原始API数: {len(all_api_names)}")
    print(f"  被使用的API数: {len(api_counter)}")
    print(f"  保留的API数 (>={min_usage}次): {len(valid_apis)}")

    print(f"\n  Top 10 API:")
    for i, api in enumerate(valid_apis[:10]):
        print(f"    {i+1}. {api}: {api_counter[api]}次")

    filtered_indices = [i for i, apis in enumerate(mashup_used_apis)
                        if any(api in valid_api_set for api in apis)]

    print(f"\n  保留的Mashup数: {len(filtered_indices)}")

    key_apis_by_domain = {
        'Weather': ['weather-channel', 'world-weather-online', 'openweathermap', 'weather-underground'],
        'Email': ['mailchimp', 'google-gmail-oauth', 'sendgrid', 'mailgun'],
        'Shipping': ['fedex', 'ups', 'usps', 'dhl'],
        'Storage': ['amazon-s3', 'dropbox', 'google-drive', 'box'],
        'Social': ['twitter', 'facebook', 'instagram', 'linkedin'],
        'Maps': ['google-maps', 'microsoft-bing-maps', 'yahoo-maps', 'mapquest'],
    }

    print(f"\n  领域API保留情况:")
    for domain, apis in key_apis_by_domain.items():
        retained = [api for api in apis if api in valid_api_set]
        print(f"    {domain}: {len(retained)}/{len(apis)} - {retained[:3]}")

    return {
        'api_names': valid_apis,
        'api_usage': {api: api_counter[api] for api in valid_apis},
        'descriptions': [mashup_descriptions[i] for i in filtered_indices],
        'used_apis': [[api for api in mashup_used_apis[i] if api in valid_api_set] for i in filtered_indices],
        'categories': [mashup_categories[i] for i in filtered_indices],
        'category_list': categories
    }


class ImprovedMashupDataset(Dataset):


    def __init__(self, data, max_doc_len=100, max_vocab_size=10000):
        self.max_doc_len = max_doc_len

        self.api_names = data['api_names']
        self.api_to_idx = {name: i for i, name in enumerate(self.api_names)}
        self.num_api = len(self.api_names)

        self.categories = data['category_list']
        self.category_to_idx = {c: i for i, c in enumerate(self.categories)}
        self.num_category = len(self.categories)

        self.descriptions = data['descriptions']
        self.used_apis = data['used_apis']
        self.mashup_categories = data['categories']
        self.num_mashup = len(self.descriptions)

        self._build_vocab(max_vocab_size)
        self._build_text_indices()
        self._build_labels()

        self.embed_dim = EMBED_DIM
        self.vocab_size = len(self.vocab)

    def _build_vocab(self, max_vocab_size):

        word_freq = Counter()
        for desc in self.descriptions:
            if isinstance(desc, list):
                words = [w.lower() for w in desc]
            else:
                words = str(desc).lower().split()
            word_freq.update(words)

        self.vocab = {'<PAD>': 0, '<UNK>': 1}
        for word, _ in word_freq.most_common(max_vocab_size - 2):
            self.vocab[word] = len(self.vocab)

        print(f"  词汇表大小: {len(self.vocab)}")

    def _text_to_indices(self, text):

        if isinstance(text, list):
            words = [w.lower() for w in text]
        else:
            words = str(text).lower().split()

        indices = [self.vocab.get(w, 1) for w in words[:self.max_doc_len]]
        while len(indices) < self.max_doc_len:
            indices.append(0)
        return indices

    def _build_text_indices(self):

        self.text_indices = [self._text_to_indices(desc) for desc in self.descriptions]

    def _build_labels(self):

        self.api_labels = np.zeros((self.num_mashup, self.num_api), dtype=np.float32)
        for i, apis in enumerate(self.used_apis):
            for api in apis:
                if api in self.api_to_idx:
                    self.api_labels[i, self.api_to_idx[api]] = 1.0

        self.category_labels = np.zeros((self.num_mashup, self.num_category), dtype=np.float32)
        for i, cats in enumerate(self.mashup_categories):
            for cat in cats:
                if cat in self.category_to_idx:
                    self.category_labels[i, self.category_to_idx[cat]] = 1.0

    def __len__(self):
        return self.num_mashup

    def __getitem__(self, idx):
        features = torch.LongTensor(self.text_indices[idx])
        category_target = torch.FloatTensor(self.category_labels[idx])
        api_target = torch.FloatTensor(self.api_labels[idx])
        return idx, features, category_target, api_target


class NCF(nn.Module):


    def __init__(self, config):
        super(NCF, self).__init__()

        self.config = config

        self.embedding = nn.Embedding(
            config.vocab_size,
            config.embed_dim,
            padding_idx=0
        )

        self.mlp = nn.Sequential(
            nn.Linear(config.embed_dim, 256),
            nn.ReLU(),
            nn.Dropout(config.dropout),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(config.dropout),
            nn.Linear(128, config.num_api)
        )

    def forward(self, mashup_des):
        embed = self.embedding(mashup_des)
        embed = embed.mean(dim=1)
        output = self.mlp(embed)
        return output


class NCFConfig:

    def __init__(self, dataset):
        self.embed_dim = dataset.embed_dim
        self.max_doc_len = dataset.max_doc_len
        self.dropout = 0.2
        self.num_category = dataset.num_category
        self.num_mashup = dataset.num_mashup
        self.num_api = dataset.num_api
        self.vocab_size = dataset.vocab_size
        self.lr = LEARNING_RATE
        self.batch_size = BATCH_SIZE
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'


class EarlyStopping:
    def __init__(self, patience=7, path='checkpoint.pth', delta=0):
        self.patience = patience
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = np.inf
        self.delta = delta
        self.path = path

    def __call__(self, val_loss, model):
        score = -val_loss

        if self.best_score is None:
            self.best_score = score
            self.save_checkpoint(val_loss, model)
        elif score < self.best_score + self.delta:
            self.counter += 1
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_score = score
            self.save_checkpoint(val_loss, model)
            self.counter = 0

    def save_checkpoint(self, val_loss, model):
        torch.save(model.state_dict(), self.path)
        self.val_loss_min = val_loss


def calculate_metrics(target, prediction, top_k_list=[1, 5, 10, 15, 20]):

    results = {'ndcg': [], 'recall': [], 'precision': []}

    for top_k in top_k_list:
        ndcg_sum, recall_sum, precision_sum = 0.0, 0.0, 0.0
        batch_size = target.shape[0]

        for i in range(batch_size):
            true_labels = target[i].numpy()
            pred_scores = prediction[i].numpy()

            top_k_indices = np.argsort(pred_scores)[::-1][:top_k]
            num_relevant = int(true_labels.sum())

            if num_relevant > 0:
                dcg = sum([1.0/np.log2(j+2) for j, idx in enumerate(top_k_indices) if true_labels[idx] > 0])
                idcg = sum([1.0/np.log2(j+2) for j in range(min(num_relevant, top_k))])
                ndcg_sum += dcg / idcg if idcg > 0 else 0

                hits = sum([1 for idx in top_k_indices if true_labels[idx] > 0])
                recall_sum += hits / num_relevant

                precision_sum += hits / top_k

        results['ndcg'].append(ndcg_sum / batch_size)
        results['recall'].append(recall_sum / batch_size)
        results['precision'].append(precision_sum / batch_size)

    return results


def train():
    print("=" * 60)
    print("NCF 改进版训练")
    print("=" * 60)
    print(f"改进点: 保留使用次数>={MIN_API_USAGE}的API")
    print("模型结构: 保持原始NCF不变")
    print("=" * 60)

    random.seed(42)
    np.random.seed(42)
    torch.manual_seed(42)

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"\n[Device] {device}")

    print("\n[1] 加载数据...")
    data = preprocess_data(PROJECT_ROOT / "data", min_usage=MIN_API_USAGE)
    dataset = ImprovedMashupDataset(data, max_doc_len=MAX_DOC_LEN, max_vocab_size=MAX_VOCAB_SIZE)

    print(f"\n  数据集统计:")
    print(f"    - APIs: {dataset.num_api}")
    print(f"    - Mashups: {dataset.num_mashup}")
    print(f"    - Categories: {dataset.num_category}")
    print(f"    - Vocab: {dataset.vocab_size}")

    print("\n[2] 划分数据集...")
    n = len(dataset)
    indices = list(range(n))
    random.shuffle(indices)

    train_size = int(n * 0.8)
    val_size = int(n * 0.1)

    train_idx = indices[:train_size]
    val_idx = indices[train_size:train_size + val_size]
    test_idx = indices[train_size + val_size:]

    print(f"  Train: {len(train_idx)}, Val: {len(val_idx)}, Test: {len(test_idx)}")

    config = NCFConfig(dataset)

    train_loader = DataLoader(dataset, batch_size=config.batch_size, sampler=SubsetRandomSampler(train_idx))
    val_loader = DataLoader(dataset, batch_size=len(val_idx), sampler=SubsetRandomSampler(val_idx))
    test_loader = DataLoader(dataset, batch_size=len(test_idx), sampler=SubsetRandomSampler(test_idx))

    print("\n[3] 创建NCF模型...")
    model = NCF(config).to(device)

    param_count = sum(p.numel() for p in model.parameters())
    print(f"  模型参数: {param_count:,}")
    print(f"  Embedding: {config.vocab_size} × {config.embed_dim}")
    print(f"  Output: {config.num_api} APIs")

    print(f"\n[4] 开始训练 ({TRAIN_EPOCHS} epochs)...")

    criterion = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=config.lr)

    model_path = PROJECT_ROOT / "checkpoints" / "ncf_improved.pth"
    model_path.parent.mkdir(exist_ok=True)
    early_stopping = EarlyStopping(patience=10, path=str(model_path))

    log_path = PROJECT_ROOT / "logs" / f"ncf_improved_{time.strftime('%Y%m%d_%H%M%S')}.log"
    log_path.parent.mkdir(exist_ok=True)
    log_file = open(log_path, 'w', encoding='utf-8')

    for epoch in range(TRAIN_EPOCHS):
        model.train()
        train_loss = []

        for batch_idx, (_, features, _, api_target) in enumerate(train_loader):
            features = features.to(device)
            api_target = api_target.to(device)

            optimizer.zero_grad()
            prediction = model(features)
            loss = criterion(prediction, api_target)
            loss.backward()
            optimizer.step()

            train_loss.append(loss.item())

        train_loss = np.mean(train_loss)

        model.eval()
        with torch.no_grad():
            for _, features, _, api_target in val_loader:
                features = features.to(device)
                api_target = api_target.to(device)
                prediction = model(features)
                val_loss = criterion(prediction, api_target).item()

        log_msg = f"[Epoch {epoch+1}/{TRAIN_EPOCHS}] Train_Loss: {train_loss:.6f}, Val_Loss: {val_loss:.6f}"
        print(log_msg)
        log_file.write(log_msg + '\n')
        log_file.flush()

        early_stopping(val_loss, model)
        if early_stopping.early_stop:
            print("Early stopping triggered!")
            break

    print("\n[5] 测试...")
    model.load_state_dict(torch.load(model_path, map_location=device, weights_only=True))
    model.eval()

    with torch.no_grad():
        for _, features, _, api_target in test_loader:
            features = features.to(device)
            api_target = api_target.to(device)
            prediction = model(features)
            test_loss = criterion(prediction, api_target).item()

            metrics = calculate_metrics(api_target.cpu(), prediction.cpu())

    print(f"\n{'=' * 60}")
    print(f"[Test] Loss: {test_loss:.6f}")
    print(f"{'=' * 60}")
    print(f"Top-K:     [1, 5, 10, 15, 20]")
    print(f"NDCG:      {[f'{v:.4f}' for v in metrics['ndcg']]}")
    print(f"Recall:    {[f'{v:.4f}' for v in metrics['recall']]}")
    print(f"Precision: {[f'{v:.4f}' for v in metrics['precision']]}")
    print(f"{'=' * 60}")

    log_file.write(f"\n[Test] Loss: {test_loss:.6f}\n")
    log_file.write(f"NDCG: {metrics['ndcg']}\n")
    log_file.write(f"Recall: {metrics['recall']}\n")
    log_file.close()

    config_info = {
        'min_api_usage': MIN_API_USAGE,
        'num_api': dataset.num_api,
        'num_category': dataset.num_category,
        'vocab_size': dataset.vocab_size,
        'max_doc_len': MAX_DOC_LEN,
        'embed_dim': EMBED_DIM,
        'api_names': dataset.api_names,
        'vocab': dataset.vocab
    }

    config_path = PROJECT_ROOT / "checkpoints" / "ncf_improved_config.json"
    with open(config_path, 'w', encoding='utf-8') as f:
        json.dump(config_info, f, indent=2, ensure_ascii=False)

    print(f"\n✓ 训练完成!")
    print(f"✓ 模型: {model_path}")
    print(f"✓ 配置: {config_path}")
    print(f"✓ 日志: {log_path}")


if __name__ == '__main__':
    train()
