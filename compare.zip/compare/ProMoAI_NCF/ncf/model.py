import torch
import torch.nn as nn
import numpy as np
from typing import Optional


class NCFConfig:


    def __init__(self, ds_config):

        self.model_name = 'NCF_Model'
        self.embed_dim = ds_config.embed_dim
        self.max_doc_len = ds_config.max_doc_len
        self.dropout = 0.2
        self.num_category = ds_config.num_category
        self.feature_dim = 8
        self.num_mashup = ds_config.num_mashup
        self.num_api = ds_config.num_api
        self.vocab_size = ds_config.vocab_size
        self.embed = ds_config.embed
        self.lr = 1e-3
        self.batch_size = 128
        self.device = ('cuda' if torch.cuda.is_available() else 'cpu')


class NCF(nn.Module):


    def __init__(self, config: NCFConfig):
        super(NCF, self).__init__()

        self.config = config

        if config.embed is not None:
            self.embedding = nn.Embedding.from_pretrained(config.embed, freeze=False)
        else:
            self.embedding = nn.Embedding(
                config.vocab_size,
                config.embed_dim,
                padding_idx=0
            )

        self.mlp = nn.Sequential(
            nn.Linear(config.embed_dim, 256),
            nn.ReLU(),
            nn.Dropout(config.dropout),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(config.dropout),
            nn.Linear(128, config.num_api)
        )

    def forward(self, mashup_des: torch.Tensor) -> torch.Tensor:

        embed = self.embedding(mashup_des)

        embed = embed.mean(dim=1)

        output = self.mlp(embed)

        return output

    def predict_apis(self, text_indices: torch.Tensor, top_k: int = 5) -> torch.Tensor:

        self.eval()
        with torch.no_grad():
            logits = self.forward(text_indices)
            probs = torch.sigmoid(logits)
            _, top_indices = torch.topk(probs, top_k, dim=1)
        return top_indices


class EarlyStopping:


    def __init__(self, patience: int = 7, path: str = 'checkpoint.pth', delta: float = 0):

        self.patience = patience
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = np.inf
        self.delta = delta
        self.path = path

    def __call__(self, val_loss: float, model: nn.Module):
        score = -val_loss

        if self.best_score is None:
            self.best_score = score
            self.save_checkpoint(val_loss, model)
        elif score < self.best_score + self.delta:
            self.counter += 1
            print(f'EarlyStopping counter: {self.counter}/{self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_score = score
            self.save_checkpoint(val_loss, model)
            self.counter = 0

    def save_checkpoint(self, val_loss: float, model: nn.Module):

        torch.save(model.state_dict(), self.path)
        self.val_loss_min = val_loss


def metric(target: torch.Tensor, prediction: torch.Tensor, top_k_list: list = [1, 5, 10, 15, 20, 25, 30]):

    ndcg_list = []
    recall_list = []
    ap_list = []
    precision_list = []

    for top_k in top_k_list:
        ndcg = calculate_ndcg(target, prediction, top_k)
        recall = calculate_recall(target, prediction, top_k)
        ap = calculate_ap(target, prediction, top_k)
        precision = calculate_precision(target, prediction, top_k)

        ndcg_list.append(ndcg)
        recall_list.append(recall)
        ap_list.append(ap)
        precision_list.append(precision)

    return np.array(ndcg_list), np.array(recall_list), np.array(ap_list), np.array(precision_list)


def calculate_ndcg(target: torch.Tensor, prediction: torch.Tensor, top_k: int) -> float:

    batch_size = target.shape[0]
    ndcg_sum = 0.0

    for i in range(batch_size):
        true_labels = target[i].numpy()
        pred_scores = prediction[i].numpy()

        top_k_indices = np.argsort(pred_scores)[::-1][:top_k]

        dcg = 0.0
        for j, idx in enumerate(top_k_indices):
            if true_labels[idx] > 0:
                dcg += 1.0 / np.log2(j + 2)

        num_relevant = int(true_labels.sum())
        idcg = sum([1.0 / np.log2(j + 2) for j in range(min(num_relevant, top_k))])

        if idcg > 0:
            ndcg_sum += dcg / idcg

    return ndcg_sum / batch_size


def calculate_recall(target: torch.Tensor, prediction: torch.Tensor, top_k: int) -> float:

    batch_size = target.shape[0]
    recall_sum = 0.0

    for i in range(batch_size):
        true_labels = target[i].numpy()
        pred_scores = prediction[i].numpy()

        top_k_indices = np.argsort(pred_scores)[::-1][:top_k]

        num_relevant = int(true_labels.sum())
        if num_relevant > 0:
            hits = sum([1 for idx in top_k_indices if true_labels[idx] > 0])
            recall_sum += hits / num_relevant

    return recall_sum / batch_size


def calculate_ap(target: torch.Tensor, prediction: torch.Tensor, top_k: int) -> float:

    batch_size = target.shape[0]
    ap_sum = 0.0

    for i in range(batch_size):
        true_labels = target[i].numpy()
        pred_scores = prediction[i].numpy()

        top_k_indices = np.argsort(pred_scores)[::-1][:top_k]

        hits = 0
        precision_sum = 0.0
        for j, idx in enumerate(top_k_indices):
            if true_labels[idx] > 0:
                hits += 1
                precision_sum += hits / (j + 1)

        num_relevant = int(true_labels.sum())
        if num_relevant > 0:
            ap_sum += precision_sum / min(num_relevant, top_k)

    return ap_sum / batch_size


def calculate_precision(target: torch.Tensor, prediction: torch.Tensor, top_k: int) -> float:

    batch_size = target.shape[0]
    precision_sum = 0.0

    for i in range(batch_size):
        true_labels = target[i].numpy()
        pred_scores = prediction[i].numpy()

        top_k_indices = np.argsort(pred_scores)[::-1][:top_k]

        hits = sum([1 for idx in top_k_indices if true_labels[idx] > 0])
        precision_sum += hits / top_k

    return precision_sum / batch_size


__all__ = ['NCF', 'NCFConfig', 'EarlyStopping', 'metric']


if __name__ == '__main__':
    print("Testing NCF model structure...")

    class MockConfig:
        embed_dim = 128
        max_doc_len = 100
        dropout = 0.2
        num_category = 20
        feature_dim = 8
        num_mashup = 1000
        num_api = 500
        vocab_size = 10000
        embed = None
        lr = 1e-3
        batch_size = 128
        device = 'cpu'

    config = MockConfig()
    model = NCF(config)

    batch_size = 4
    x = torch.randint(0, config.vocab_size, (batch_size, config.max_doc_len))
    output = model(x)

    print(f"Input shape: {x.shape}")
    print(f"Output shape: {output.shape}")
    print(f"Expected output shape: [{batch_size}, {config.num_api}]")
    print("NCF model test passed!")
