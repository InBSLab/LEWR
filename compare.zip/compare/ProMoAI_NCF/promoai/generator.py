import os
import re
import json
import requests
import logging
from typing import List, Dict, Any, Optional, Tuple
from pathlib import Path

from .prompts import create_full_prompt, create_error_handling_prompt, create_feedback_prompt

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class ModelGenerator:


    def __init__(self):
        self.activity_counter = 0
        self._consumed_ids = set()

    def _consume(self, node, context: str):

        if node is None:
            return
        node_id = id(node)
        if node_id in self._consumed_ids:
            label = node.get("label", node.get("type", "unknown")) if isinstance(node, dict) else str(node)
            raise ValueError(
                f"Ensure that each submodel is used uniquely! The node '{label}' was already used as a "
                f"submodel elsewhere, but is being reused inside {context}. If you need repeated execution, "
                f"model it with self_loop/decision_graph; if you need a second independent instance, "
                f"call copy(node) instead of reusing the same object."
            )
        self._consumed_ids.add(node_id)

    def activity(self, label: str) -> Dict:

        self.activity_counter += 1
        return {
            "id": f"activity_{self.activity_counter}",
            "type": "activity",
            "label": label,
        }

    def partial_order(self, dependencies: List[Tuple]) -> Dict:

        seen_ids = set()
        unique_nodes = []
        edges = []

        for dep in dependencies:
            if not isinstance(dep, tuple):
                raise ValueError(
                    "partial_order expects a list of tuples of submodels, "
                    f"got an element of type {type(dep)} instead!"
                )
            for n in dep:
                if id(n) not in seen_ids:
                    seen_ids.add(id(n))
                    unique_nodes.append(n)
            for i in range(len(dep) - 1):
                edges.append({"from": dep[i], "to": dep[i + 1]})

        if len(unique_nodes) == 0:
            raise ValueError("Cannot create a partial order over 0 submodels!")
        if len(unique_nodes) == 1:
            return unique_nodes[0]

        for n in unique_nodes:
            self._consume(n, context="partial_order")

        return {
            "type": "partial_order",
            "nodes": unique_nodes,
            "edges": edges,
        }

    def decision_graph(self, dependencies: List[Tuple]) -> Dict:

        nodes_order = []
        seen_ids = set()
        edges = []
        start_nodes, end_nodes = [], []
        empty_path = False

        for dep in dependencies:
            if not isinstance(dep, tuple) or len(dep) != 2:
                raise ValueError(
                    "Each dependency in decision_graph must be a 2-tuple (source, target); "
                    "use None as source/target to mark start/end nodes, e.g. (None, A) or (B, None)."
                )
            source, target = dep
            if source is None and target is None:
                empty_path = True
                continue
            if source is None:
                start_nodes.append(target)
            elif target is None:
                end_nodes.append(source)
            else:
                edges.append((source, target))

            for n in (source, target):
                if n is not None and id(n) not in seen_ids:
                    seen_ids.add(id(n))
                    nodes_order.append(n)

        if len(nodes_order) == 0 and not empty_path:
            raise ValueError("A decision graph must contain at least one node!")

        adjacency, reverse_adjacency = {}, {}
        for n in nodes_order:
            adjacency[id(n)] = []
            reverse_adjacency[id(n)] = []
        for s, t in edges:
            adjacency[id(s)].append(id(t))
            reverse_adjacency[id(t)].append(id(s))

        def _bfs(start_ids, graph):
            visited = set(start_ids)
            queue = list(start_ids)
            while queue:
                cur = queue.pop()
                for nxt in graph.get(cur, []):
                    if nxt not in visited:
                        visited.add(nxt)
                        queue.append(nxt)
            return visited

        forward_reachable = _bfs({id(n) for n in start_nodes}, adjacency)
        backward_reachable = _bfs({id(n) for n in end_nodes}, reverse_adjacency)

        for n in nodes_order:
            if id(n) not in forward_reachable or id(n) not in backward_reachable:
                label = n.get("label", n.get("type", "unknown")) if isinstance(n, dict) else str(n)
                raise ValueError(
                    f"All nodes in a decision graph must be on a path from a start node to an end node "
                    f"— '{label}' isn't! Check the (None, X) / (X, None) start/end declarations."
                )

        for n in nodes_order:
            self._consume(n, context="decision_graph")

        return {
            "type": "decision_graph",
            "nodes": nodes_order,
            "edges": [{"from": s, "to": t} for s, t in edges],
            "start_nodes": start_nodes,
            "end_nodes": end_nodes,
            "empty_path": empty_path,
        }

    def skip(self, submodel: Dict) -> Dict:

        if submodel is None:
            raise ValueError("Cannot create a skip over an empty model!")
        self._consume(submodel, context="skip")
        return {
            "type": "skip",
            "submodel": submodel,
            "optional": True,
        }

    def self_loop(self, submodel: Dict) -> Dict:

        if submodel is None:
            raise ValueError("Cannot create a self-loop over an empty model!")
        self._consume(submodel, context="self_loop")
        return {
            "type": "self_loop",
            "submodel": submodel,
            "repeatable": True,
        }

    def copy(self, model: Dict) -> Dict:

        import copy as copy_module
        copied = copy_module.deepcopy(model)
        if isinstance(copied, dict) and "id" in copied:
            copied["id"] = copied["id"] + "_copy"
        return copied


def extract_python_code(response: str) -> str:

    pattern = r'```python(.*?)```'
    matches = re.findall(pattern, response, re.DOTALL)

    if matches:
        code = matches[-1].strip()
        return code
    else:
        raise ValueError("No Python code block found in response")


def preprocess_code(code: str) -> str:

    lines = code.split('\n')
    processed_lines = []

    for line in lines:
        stripped = line.strip()
        if stripped.startswith('from promoai') or stripped.startswith('import promoai'):
            continue
        if stripped.startswith('from ') and 'ModelGenerator' in stripped:
            continue
        if stripped.startswith('import ') and 'ModelGenerator' in stripped:
            continue
        processed_lines.append(line)

    return '\n'.join(processed_lines)


def execute_code_safely(code: str) -> Dict:

    processed_code = preprocess_code(code)

    gen = ModelGenerator()

    local_vars = {
        'ModelGenerator': ModelGenerator,
        'gen': gen
    }

    global_vars = {
        'ModelGenerator': ModelGenerator,
        '__builtins__': __builtins__
    }

    try:
        exec(processed_code, global_vars, local_vars)

        if 'final_model' in local_vars:
            return local_vars['final_model']
        else:
            raise ValueError("Variable 'final_model' not found in generated code")

    except Exception as e:
        raise RuntimeError(f"Code execution error: {str(e)}")


class ProMoAIGenerator:


    def __init__(self,
                 api_key: str = None,
                 base_url: str = None,
                 model_name: str = "deepseek-chat"):

        self.api_key = api_key or os.getenv("DEEPSEEK_API_KEY", "")
        self.base_url = base_url or "https://api.deepseek.com/v1"
        self.model_name = model_name

        self.conversation_history = []

        logger.info(f"[ProMoAI] Initialized with model: {self.model_name}")

    def _call_llm(self, messages: List[Dict], temperature: float = 0.3, max_tokens: int = 2500) -> str:

        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": self.model_name,
                    "messages": messages,
                    "max_tokens": max_tokens,
                    "temperature": temperature
                },
                timeout=120
            )

            if response.status_code == 200:
                return response.json()["choices"][0]["message"]["content"]
            else:
                raise RuntimeError(f"API error: {response.status_code} - {response.text}")

        except requests.exceptions.Timeout:
            raise RuntimeError("API timeout (120s)")
        except Exception as e:
            raise RuntimeError(f"LLM call failed: {str(e)}")

    def generate(self, process_description: str, max_retries: int = 3) -> Tuple[Dict, str]:

        prompt = create_full_prompt(process_description)

        self.conversation_history = [
            {"role": "system", "content": "You are an expert in process modeling using POWL (Partially Ordered Workflow Language). Generate Python code to create POWL models."},
            {"role": "user", "content": prompt}
        ]

        last_error = None
        generated_code = None

        for attempt in range(max_retries):
            try:
                logger.info(f"[ProMoAI] Generation attempt {attempt + 1}/{max_retries}")

                response = self._call_llm(self.conversation_history)

                self.conversation_history.append({"role": "assistant", "content": response})

                generated_code = extract_python_code(response)
                logger.info(f"[ProMoAI] Extracted code ({len(generated_code)} chars)")

                workflow_model = execute_code_safely(generated_code)
                logger.info(f"[ProMoAI] Successfully generated workflow model")

                activities = self._extract_activities(workflow_model)

                return {
                    'model': workflow_model,
                    'activities': activities,
                    'code': generated_code,
                    'method': 'ProMoAI (POWL + LLM)'
                }, generated_code

            except Exception as e:
                last_error = str(e)
                logger.warning(f"[ProMoAI] Attempt {attempt + 1} failed: {last_error}")

                if attempt < max_retries - 1:
                    error_prompt = create_error_handling_prompt(last_error)
                    self.conversation_history.append({"role": "user", "content": error_prompt})

        logger.error(f"[ProMoAI] All {max_retries} attempts failed. Last error: {last_error}")
        raise RuntimeError(
            f"ProMoAI failed to generate a valid workflow after {max_retries} attempts. "
            f"Last error: {last_error}"
        )

    def refine_with_feedback(self, feedback: str) -> Tuple[Dict, str]:

        if not self.conversation_history:
            raise RuntimeError("No previous generation to refine. Call generate() first.")

        feedback_prompt = create_feedback_prompt(feedback)
        self.conversation_history.append({"role": "user", "content": feedback_prompt})

        try:
            response = self._call_llm(self.conversation_history)
            self.conversation_history.append({"role": "assistant", "content": response})

            generated_code = extract_python_code(response)
            workflow_model = execute_code_safely(generated_code)

            activities = self._extract_activities(workflow_model)

            return {
                'model': workflow_model,
                'activities': activities,
                'code': generated_code,
                'method': 'ProMoAI (POWL + LLM + Feedback)'
            }, generated_code

        except Exception as e:
            logger.error(f"[ProMoAI] Feedback refinement failed: {e}")
            raise

    def _extract_activities(self, model: Any, depth: int = 0) -> List[Dict]:

        activities = []

        if isinstance(model, dict):
            model_type = model.get('type', '')

            if model_type == 'activity':
                activities.append({
                    'id': model.get('id', f'activity_{depth}'),
                    'label': model.get('label', 'Unknown'),
                    'type': 'activity'
                })

            elif model_type in ['partial_order', 'decision_graph']:
                for node in model.get('nodes', []):
                    activities.extend(self._extract_activities(node, depth + 1))
                for node in model.get('start_nodes', []):
                    if node is not None:
                        activities.extend(self._extract_activities(node, depth + 1))
                for node in model.get('end_nodes', []):
                    if node is not None:
                        activities.extend(self._extract_activities(node, depth + 1))

            elif model_type in ['skip', 'self_loop']:
                submodel = model.get('submodel')
                if submodel:
                    activities.extend(self._extract_activities(submodel, depth + 1))

            for key in ['submodel', 'nodes', 'children']:
                if key in model and key != 'nodes':
                    value = model[key]
                    if isinstance(value, list):
                        for item in value:
                            activities.extend(self._extract_activities(item, depth + 1))
                    elif isinstance(value, dict):
                        activities.extend(self._extract_activities(value, depth + 1))

        seen_ids = set()
        unique_activities = []
        for act in activities:
            act_id = act.get('id', '')
            if act_id not in seen_ids:
                seen_ids.add(act_id)
                unique_activities.append(act)

        return unique_activities

    def _generate_template(self, process_description: str) -> Dict:

        keywords = {
            'submit': 'Submit request',
            'review': 'Review request',
            'approve': 'Approve',
            'reject': 'Reject',
            'process': 'Process request',
            'send': 'Send notification',
            'receive': 'Receive input',
            'check': 'Check status',
            'verify': 'Verify information',
            'create': 'Create item',
            'update': 'Update item',
            'delete': 'Delete item',
            'search': 'Search',
            'select': 'Select option',
            'ship': 'Ship goods',
            'package': 'Package items',
            'pay': 'Process payment',
            'order': 'Place order',
            'deliver': 'Deliver items',
            'notify': 'Send notification',
            'invite': 'Invite',
            'prepare': 'Prepare',
            'clarify': 'Clarify requirements',
            'write': 'Write document',
            'take': 'Take action'
        }

        gen = ModelGenerator()
        activities = []

        desc_lower = process_description.lower()
        words = desc_lower.split()

        for word in words:
            for keyword, label in keywords.items():
                if keyword in word and label not in [a.get('label') for a in activities]:
                    activities.append(gen.activity(label))
                    break

        if not activities:
            activities = [
                gen.activity("Receive request"),
                gen.activity("Process request"),
                gen.activity("Complete request")
            ]

        if len(activities) > 1:
            deps = [(activities[i], activities[i+1]) for i in range(len(activities)-1)]
            model = gen.partial_order(dependencies=deps)
        else:
            model = activities[0]

        return {
            'model': model,
            'activities': [{'id': a.get('id'), 'label': a.get('label'), 'type': 'activity'} for a in activities],
            'code': None,
            'method': 'ProMoAI (Template Fallback)'
        }

    def get_tasks(self, workflow: Dict) -> List[Dict]:

        activities = workflow.get('activities', [])

        tasks = []
        for i, activity in enumerate(activities):
            tasks.append({
                'id': activity.get('id', f'task_{i+1}'),
                'name': activity.get('label', 'Unknown Task'),
                'type': 'activity',
                'index': i
            })

        return tasks


__all__ = ['ProMoAIGenerator', 'ModelGenerator', 'extract_python_code', 'execute_code_safely']


if __name__ == '__main__':
    generator = ProMoAIGenerator()

    test_desc = """
    If goods shall be shipped, the secretary clarifies who will do the shipping.
    If you have large amounts, special shipping will be necessary. In these cases
    the secretary invites three logistic companies to make offers and she selects
    one of them. In case of small amounts, normal post shipment is used.
    """

    print("Testing ProMoAI Generator...")
    workflow, code = generator.generate(test_desc)

    print(f"\nGenerated workflow:")
    print(json.dumps(workflow, indent=2, default=str))

    if code:
        print(f"\nGenerated code:\n{code}")
