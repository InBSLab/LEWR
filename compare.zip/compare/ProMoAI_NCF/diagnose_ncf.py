import json
from pathlib import Path
from collections import Counter

PROJECT_ROOT = Path(__file__).parent.absolute()


def diagnose():
    print("=" * 60)
    print("NCF 模型诊断")
    print("=" * 60)

    config_path = PROJECT_ROOT / "checkpoints" / "ncf_improved_config.json"

    if not config_path.exists():
        print(f"❌ 配置文件不存在: {config_path}")
        print("请先运行 train_ncf_improved.py")
        return

    with open(config_path, 'r', encoding='utf-8') as f:
        config = json.load(f)

    vocab = config['vocab']
    api_names = config['api_names']

    print(f"\n[1] 基本信息")
    print(f"  - 词汇表大小: {len(vocab)}")
    print(f"  - API数量: {len(api_names)}")

    print(f"\n[2] 关键词覆盖检查")

    keyword_groups = {
        '物流/运输': ['shipping', 'ship', 'delivery', 'deliver', 'logistics', 'freight',
                    'carrier', 'package', 'parcel', 'courier', 'transport', 'tracking',
                    'fedex', 'ups', 'dhl', 'usps', 'postal', 'warehouse', 'fulfillment'],
        '支付': ['payment', 'pay', 'transaction', 'checkout', 'billing', 'invoice',
                'credit', 'paypal', 'stripe'],
        '邮件': ['email', 'mail', 'message', 'notification', 'send', 'sendgrid', 'mailchimp'],
        '存储': ['storage', 'file', 'cloud', 'upload', 'download', 'dropbox', 's3', 'drive'],
        '地图': ['map', 'location', 'geocoding', 'direction', 'navigation', 'address', 'route'],
        '标签/打印': ['label', 'print', 'barcode', 'address', 'postage'],
        '保险': ['insurance', 'insure', 'coverage', 'protection', 'claim', 'policy'],
        '动作词': ['invite', 'select', 'choose', 'compare', 'prepare', 'write', 'take', 'package'],
    }

    for group_name, keywords in keyword_groups.items():
        found = [kw for kw in keywords if kw in vocab]
        missing = [kw for kw in keywords if kw not in vocab]
        coverage = len(found) / len(keywords) * 100

        print(f"\n  {group_name}: {len(found)}/{len(keywords)} ({coverage:.0f}%)")
        if missing:
            print(f"    缺失: {missing[:10]}{'...' if len(missing) > 10 else ''}")

    print(f"\n[3] API领域分布")

    api_domains = {
        '物流': [],
        '电商': [],
        '地图': [],
        '支付': [],
        '邮件': [],
        '社交': [],
        '存储': [],
        '其他': []
    }

    for api in api_names:
        api_lower = api.lower()
        categorized = False

        if any(kw in api_lower for kw in ['ship', 'fedex', 'ups', 'dhl', 'usps', 'postal', 'delivery']):
            api_domains['物流'].append(api)
            categorized = True
        elif any(kw in api_lower for kw in ['ebay', 'amazon', 'shop', 'store', 'commerce']):
            api_domains['电商'].append(api)
            categorized = True
        elif any(kw in api_lower for kw in ['map', 'geo', 'location', 'place']):
            api_domains['地图'].append(api)
            categorized = True
        elif any(kw in api_lower for kw in ['pay', 'stripe', 'square']):
            api_domains['支付'].append(api)
            categorized = True
        elif any(kw in api_lower for kw in ['mail', 'sendgrid', 'mailgun']):
            api_domains['邮件'].append(api)
            categorized = True
        elif any(kw in api_lower for kw in ['twitter', 'facebook', 'linkedin', 'social']):
            api_domains['社交'].append(api)
            categorized = True
        elif any(kw in api_lower for kw in ['s3', 'dropbox', 'drive', 'storage', 'box']):
            api_domains['存储'].append(api)
            categorized = True

        if not categorized:
            api_domains['其他'].append(api)

    for domain, apis in api_domains.items():
        print(f"  {domain}: {len(apis)} 个API")
        if apis and domain != '其他':
            print(f"    示例: {apis[:5]}")

    print(f"\n[4] 物流相关API详细")
    shipping_apis = api_domains['物流']
    if shipping_apis:
        for api in shipping_apis:
            print(f"  - {api}")
    else:
        print("  ⚠️ 没有物流相关API!")
        print("  这可能是因为物流API使用次数<5被过滤掉了")

    print(f"\n[5] 测试句子词汇覆盖率")

    test_sentences = [
        "invite three logistic companies",
        "select one logistic company",
        "write package label",
        "take parcel insurance",
        "package goods",
        "prepare packaged goods for pickup",
        "shipping delivery tracking package carrier logistics service",
        "web application integrates fedex ups tracking service delivery"
    ]

    for sentence in test_sentences:
        words = sentence.lower().split()
        known = [w for w in words if w in vocab]
        coverage = len(known) / len(words) * 100 if words else 0

        print(f"\n  \"{sentence[:50]}...\"" if len(sentence) > 50 else f"\n  \"{sentence}\"")
        print(f"    覆盖率: {len(known)}/{len(words)} ({coverage:.0f}%)")
        unknown = [w for w in words if w not in vocab]
        if unknown:
            print(f"    未知词: {unknown}")

    print(f"\n" + "=" * 60)
    print("诊断建议")
    print("=" * 60)

    if len(api_domains['物流']) < 3:
        print("\n⚠️ 物流API太少!")
        print("   原因: MIN_API_USAGE=5 过滤掉了低频API")
        print("   建议: 在 train_ncf_improved.py 中设置 MIN_API_USAGE=3 或更低")

    shipping_keywords = ['shipping', 'logistics', 'freight', 'carrier']
    missing_shipping = [kw for kw in shipping_keywords if kw not in vocab]
    if missing_shipping:
        print(f"\n⚠️ 关键物流词汇缺失: {missing_shipping}")
        print("   原因: 这些词在Mashup描述中出现次数不够")
        print("   建议: 使用领域匹配作为主要推荐方式")

    print("\n✓ 诊断完成")


if __name__ == '__main__':
    diagnose()
