import os
import sys
import json
import time
import re
import requests
import traceback
import numpy as np
import torch
import torch.nn as nn
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

SCRIPT_DIR = Path(__file__).parent.absolute()
PROJECT_ROOT = SCRIPT_DIR.parent.parent
EVAL_ROOT    = SCRIPT_DIR.parent

POSSIBLE_MODEL_PATHS = [
    PROJECT_ROOT / "models" / "ProMoAI" / "ProMoAI_NCF_System" / "ProMoAI_NCF_System",
    PROJECT_ROOT / "ProMoAI_NCF_System1"  / "ProMoAI_NCF_System",
    PROJECT_ROOT.parent / "ProMoAI_NCF_System1" / "ProMoAI_NCF_System",
    SCRIPT_DIR / "ProMoAI_NCF_System",
    SCRIPT_DIR,
]


def find_model_root() -> Path:

    for path in POSSIBLE_MODEL_PATHS:
        if (path / "checkpoints" / "ncf_improved.pth").exists():
            print(f"  找到改进模型目录: {path}")
            return path
        if (path / "checkpoints" / "ncf_best.pth").exists():
            print(f"  找到模型目录: {path}")
            return path
        if (path / "data" / "api_name.json").exists():
            print(f"  找到数据目录: {path}")
            return path
    return POSSIBLE_MODEL_PATHS[0]


MODEL_ROOT = find_model_root()

sys.path.insert(0, str(EVAL_ROOT / "common"))
sys.path.insert(0, str(MODEL_ROOT))

from scenarios import BPMN_TEST_SCENARIOS, UnifiedOutput, save_results

_PROMOAI_IMPORTED = False
_NCF_PKG_IMPORTED  = False

try:
    from promoai import ProMoAIGenerator as _PkgProMoAIGenerator, ModelGenerator
    from promoai.prompts import create_full_prompt, create_error_handling_prompt
    _PROMOAI_IMPORTED = True
    print("[✓] 已导入 promoai 包 (promoai/generator.py, promoai/prompts.py)")
except ImportError as e:
    print(f"[⚠] 无法导入 promoai 包: {e}，将使用本地实现")

try:
    from ncf import NCF as _PkgNCF
    _NCF_PKG_IMPORTED = True
    print("[✓] 已导入 ncf 包 (ncf/model.py)")
except ImportError as e:
    print(f"[⚠] 无法导入 ncf 包: {e}，将使用本地实现")


if not _PROMOAI_IMPORTED:

    class ModelGenerator:


        def __init__(self):
            self.activities = []
            self.activity_counter = 0

        def activity(self, label: str) -> Dict:
            self.activity_counter += 1
            act = {
                "id": f"activity_{self.activity_counter}",
                "type": "activity",
                "label": label,
            }
            self.activities.append(act)
            return act

        def partial_order(self, dependencies: List) -> Dict:
            nodes, edges = [], []
            for dep in dependencies:
                if len(dep) == 1:
                    nodes.append(dep[0])
                elif len(dep) == 2:
                    nodes.extend([dep[0], dep[1]])
                    edges.append({"from": dep[0], "to": dep[1]})
            unique = []
            for n in nodes:
                if n not in unique:
                    unique.append(n)
            return {"type": "partial_order", "nodes": unique, "edges": edges}

        def decision_graph(self, dependencies: List) -> Dict:
            nodes, edges, start_nodes, end_nodes = [], [], [], []
            for dep in dependencies:
                if len(dep) == 2:
                    src, tgt = dep
                    if src is None:
                        start_nodes.append(tgt)
                        nodes.append(tgt)
                    elif tgt is None:
                        end_nodes.append(src)
                        nodes.append(src)
                    else:
                        nodes.extend([src, tgt])
                        edges.append({"from": src, "to": tgt})
            unique = []
            for n in nodes:
                if n not in unique and n is not None:
                    unique.append(n)
            return {
                "type": "decision_graph",
                "nodes": unique,
                "edges": edges,
                "start_nodes": start_nodes,
                "end_nodes": end_nodes,
            }

        def skip(self, submodel: Dict) -> Dict:
            return {"type": "skip", "submodel": submodel, "optional": True}

        def self_loop(self, submodel: Dict) -> Dict:
            return {"type": "self_loop", "submodel": submodel, "repeatable": True}

        def copy(self, model: Dict) -> Dict:
            import copy as _copy
            copied = _copy.deepcopy(model)
            if "id" in copied:
                copied["id"] = copied["id"] + "_copy"
            return copied

    def create_full_prompt(process_description: str) -> str:

        return (
            "Your role: you are an expert in process modeling using POWL.\n\n"
            "Use ModelGenerator to create the model:\n"
            "- activity(label), partial_order(dependencies), decision_graph(dependencies),\n"
            "  skip(submodel), self_loop(submodel)\n\n"
            "Save the final model in 'final_model'.\n\n"
            f"Process:\n{process_description}\n"
        )

    def create_error_handling_prompt(error_message: str) -> str:
        return (
            f"The previous code resulted in an error:\n{error_message}\n\n"
            "Please fix the code and save the corrected model in 'final_model'."
        )


class NCFModel(nn.Module):


    def __init__(self, vocab_size: int, embed_dim: int, num_api: int, dropout: float = 0.2):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        self.mlp = nn.Sequential(
            nn.Linear(embed_dim, 256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(128, num_api),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        embed = self.embedding(x)
        embed = embed.mean(dim=1)
        return self.mlp(embed)


def _build_ncf_model(vocab_size: int, embed_dim: int, num_api: int) -> nn.Module:

    return NCFModel(vocab_size, embed_dim, num_api)


class SemanticBridge:


    def __init__(self, api_key: str = None, base_url: str = "https://api.deepseek.com/v1"):
        self.api_key  = api_key or os.getenv("DEEPSEEK_API_KEY", "")
        self.base_url = base_url
        self._cache: Dict[str, str] = {}

    def bridge(self, task_description: str) -> str:

        if not task_description:
            return task_description
        if task_description in self._cache:
            return self._cache[task_description]
        if not self.api_key:
            return task_description

        prompt = f"""Convert this task into a web application description (mashup style).

Task: "{task_description}"

Requirements:
1. Describe what the application does functionally
2. Use common web/software terminology
3. Do NOT mention any specific API names (like fedex, google, etc.)
4. Write 15-25 words

Example:
Task: "write package label"
Output: "web application creates shipping labels with address information barcode generation tracking number assignment delivery service integration"

Task: "take parcel insurance"
Output: "application provides insurance coverage for packages calculates rates based on value handles claims processing delivery protection"

Now convert (output only the description, no quotes):
Task: "{task_description}"
Output:"""

        try:
            resp = requests.post(
                f"{self.base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": "deepseek-chat",
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": 2500,
                    "temperature": 0.3,
                },
                timeout=30,
            )
            result  = resp.json()
            bridged = result["choices"][0]["message"]["content"].strip().lower()
            bridged = "".join(c if c.isalnum() or c.isspace() else " " for c in bridged)
            bridged = " ".join(bridged.split())
            if not bridged:
                return task_description
            self._cache[task_description] = bridged
            return bridged
        except Exception as exc:
            print(f"      [语义桥接失败，使用原始任务名] {exc}")
            return task_description


class ProMoAIGenerator:


    def __init__(self, api_key: str = None):
        self.api_key  = api_key or os.getenv("DEEPSEEK_API_KEY", "")
        self.base_url = "https://api.deepseek.com/v1"
        self._pkg_gen = _PkgProMoAIGenerator(api_key=self.api_key) if _PROMOAI_IMPORTED else None

    def _call_llm(self, messages: List[Dict], temperature: float = 0.3,
                  max_retries: int = 3) -> str:
        for attempt in range(max_retries):
            try:
                print(f"    正在调用 DeepSeek API... (尝试 {attempt + 1}/{max_retries})")
                resp = requests.post(
                    f"{self.base_url}/chat/completions",
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "model": "deepseek-chat",
                        "messages": messages,
                        "max_tokens": 2500,
                        "temperature": temperature,
                    },
                    timeout=180,
                )
                if resp.status_code == 200:
                    print("    ✓ API 调用成功")
                    return resp.json()["choices"][0]["message"]["content"]
                print(f"    API Error: HTTP {resp.status_code}")
            except requests.exceptions.Timeout:
                print(f"    ⚠ 超时 (attempt {attempt + 1}/{max_retries})")
                if attempt < max_retries - 1:
                    time.sleep(10)
            except requests.exceptions.ConnectionError:
                print("    ⚠ 网络连接错误")
                if attempt < max_retries - 1:
                    time.sleep(15)
            except KeyboardInterrupt:
                raise
            except Exception as exc:
                print(f"    LLM Error: {exc}")
                if attempt < max_retries - 1:
                    time.sleep(5)
        print("    ✗ 已达最大重试次数")
        return ""

    def generate(self, user_request: str) -> Tuple[Dict, str]:

        print("\n[ProMoAI] 生成 POWL 工作流...")

        if self._pkg_gen is not None:
            try:
                workflow, generated_code = self._pkg_gen.generate(user_request)
                print("  ✓ POWL 模型生成成功（使用 promoai 包）")
                return workflow, generated_code
            except Exception as exc:
                print(f"  ⚠ promoai 包生成失败: {exc}，降级到本地实现")

        system_msg = (
            "You are an expert in process modeling using POWL (Partially Ordered Workflow Language). "
            "Generate Python code to create POWL models using ModelGenerator."
        )
        prompt = create_full_prompt(user_request)
        messages = [
            {"role": "system", "content": system_msg},
            {"role": "user",   "content": prompt},
        ]

        last_error = None
        for attempt in range(3):
            resp = self._call_llm(messages, temperature=0.3)
            if not resp:
                break
            messages.append({"role": "assistant", "content": resp})

            code = self._extract_code(resp)
            if code:
                try:
                    model_dict = self._execute_code(code)
                    activities = self._extract_activities(model_dict)
                    workflow = {
                        "model":      model_dict,
                        "activities": activities,
                        "code":       code,
                        "method":     "ProMoAI (POWL + LLM) - local",
                    }
                    print("  ✓ POWL 模型生成成功（本地实现）")
                    return workflow, code
                except Exception as exc:
                    last_error = str(exc)
                    print(f"  ⚠ 代码执行失败 (attempt {attempt + 1}): {last_error}")
                    if attempt < 2:
                        err_prompt = create_error_handling_prompt(last_error)
                        messages.append({"role": "user", "content": err_prompt})

        print("  ⚠ 使用模板回退")
        return self._generate_template(user_request), ""

    @staticmethod
    def _extract_code(response: str) -> str:
        matches = re.findall(r"```python(.*?)```", response, re.DOTALL)
        return matches[-1].strip() if matches else ""

    @staticmethod
    def _execute_code(code: str) -> Dict:

        lines = code.split("\n")
        processed = []
        for line in lines:
            stripped = line.strip()
            if stripped.startswith("from promoai") or stripped.startswith("import promoai"):
                continue
            if stripped.startswith("from ") and "ModelGenerator" in stripped:
                continue
            if stripped.startswith("import ") and "ModelGenerator" in stripped:
                continue
            processed.append(line)

        gen = ModelGenerator()
        local_vars  = {"ModelGenerator": ModelGenerator, "gen": gen}
        global_vars = {"ModelGenerator": ModelGenerator, "__builtins__": __builtins__}
        exec("\n".join(processed), global_vars, local_vars)

        if "final_model" in local_vars:
            return local_vars["final_model"]
        raise ValueError("'final_model' not found in generated code")

    def _extract_activities(self, model: Any, _seen: Optional[set] = None) -> List[Dict]:
        if _seen is None:
            _seen = set()
        result = []
        if not isinstance(model, dict):
            return result

        mtype = model.get("type", "")
        if mtype == "activity":
            aid = model.get("id", "")
            if aid not in _seen:
                _seen.add(aid)
                result.append({
                    "id":    aid,
                    "label": model.get("label", ""),
                    "type":  "activity",
                })
        elif mtype in ("partial_order", "decision_graph"):
            for node in model.get("nodes", []):
                result.extend(self._extract_activities(node, _seen))
        elif mtype in ("skip", "self_loop"):
            result.extend(self._extract_activities(model.get("submodel", {}), _seen))
        return result

    def _generate_template(self, user_request: str) -> Dict:
        gen = ModelGenerator()
        acts = []
        for sent in user_request.split("."):
            sent = sent.strip()
            if len(sent) > 10:
                acts.append(gen.activity(" ".join(sent.split()[:6])))
        if not acts:
            acts = [gen.activity("Process task")]

        if len(acts) == 1:
            raw_model = acts[0]
        else:
            deps = [(acts[i], acts[i + 1]) for i in range(len(acts) - 1)]
            raw_model = gen.partial_order(dependencies=deps)

        return {
            "model":      raw_model,
            "activities": [{"id": a["id"], "label": a["label"], "type": "activity"} for a in acts],
            "code":       None,
            "method":     "ProMoAI (Template Fallback)",
        }

    def get_tasks(self, workflow: Dict) -> List[Dict]:

        activities = workflow.get("activities", [])
        tasks = []
        for i, act in enumerate(activities):
            tasks.append({
                "id":   act.get("id",    f"activity_{i + 1}"),
                "name": act.get("label", act.get("name", f"Task {i + 1}")),
                "type": "activity",
                "index": i,
            })
        return tasks

    def get_gateways(self, workflow: Dict) -> List[Dict]:

        raw_model = workflow.get("model", workflow)
        gateways  = []
        self._extract_gateways_recursive(raw_model, gateways)
        return gateways

    def _extract_gateways_recursive(self, model: Dict, gateways: List):
        if not isinstance(model, dict):
            return
        mtype = model.get("type", "")
        if mtype == "partial_order":
            nodes = model.get("nodes", [])
            edges = model.get("edges", [])
            if len(nodes) > 1 and len(edges) < len(nodes) - 1:
                gateways.append({"id": f"pg{len(gateways)+1}", "type": "parallel", "name": "Parallel split"})
        elif mtype == "decision_graph":
            gateways.append({"id": f"eg{len(gateways)+1}", "type": "exclusive", "name": "Decision point"})
        for node in model.get("nodes", []):
            self._extract_gateways_recursive(node, gateways)
        if "submodel" in model:
            self._extract_gateways_recursive(model["submodel"], gateways)


class ProMoAINCFSystem:


    MIN_VOCAB_COVERAGE = 0.20

    def __init__(self, data_path: str = None, embedding_path: str = None,
                 model_path: str = None, use_bridge: bool = True):
        print("\n" + "=" * 60)
        print("初始化 ProMoAI + NCF")
        print("=" * 60)
        print("  阶段1: ProMoAI (POWL + Few-shot Learning)")
        print("  阶段2: NCF (Embedding → MeanPool → MLP)")

        self.data_path      = Path(data_path)      if data_path      else SCRIPT_DIR / "data"
        self.embedding_path = Path(embedding_path) if embedding_path else SCRIPT_DIR / "embedding"

        self.vocab       : Dict[str, int] = {}
        self.max_doc_len : int            = 100

        print("\n[1/4] 初始化 ProMoAI 生成器...")
        self.promoai = ProMoAIGenerator()
        print("  ✓ ProMoAI (POWL) 初始化完成")

        print("\n[2/4] 加载 API 数据...")
        self.api_names = self._load_api_names()
        print(f"  ✓ API 数量: {len(self.api_names)}")

        print("\n[3/4] 初始化 NCF 模型...")
        self.device    = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.ncf_model = self._init_ncf_model(model_path)

        print("\n[4/4] 初始化语义桥接...")
        self.use_bridge = use_bridge
        self.bridge = SemanticBridge(api_key=self.promoai.api_key) if use_bridge else None
        print(f"  {'✓ 语义桥接就绪（BPMN 任务名 → Mashup 风格描述）' if use_bridge else '- 语义桥接已禁用，直接使用原始任务名'}")

        self._build_keyword_index()

        print("\n" + "=" * 60)
        print("系统初始化完成!")
        print(f"  NCF 模式: {'神经网络推理（语义桥接 + 覆盖率兜底）' if (self.ncf_trained and self.vocab) else '关键词匹配（回退）'}")
        print("=" * 60)

    def _load_api_names(self) -> List[str]:
        api_file = self.data_path / "api_name.json"
        if api_file.exists():
            with open(api_file, "r", encoding="utf-8") as f:
                return json.load(f)
        return []

    def _init_ncf_model(self, model_path: str = None) -> Optional[nn.Module]:

        if not self.api_names:
            print("  ⚠ 无 API 数据，NCF 模型未初始化")
            self.ncf_trained = False
            return None

        config_path   = MODEL_ROOT / "checkpoints" / "ncf_improved_config.json"
        improved_path = MODEL_ROOT / "checkpoints" / "ncf_improved.pth"

        if config_path.exists() and improved_path.exists():
            try:
                with open(config_path, "r", encoding="utf-8") as f:
                    cfg = json.load(f)

                self.vocab       = cfg.get("vocab", {})
                self.max_doc_len = cfg.get("max_doc_len", 100)

                if cfg.get("api_names"):
                    self.api_names = cfg["api_names"]

                vocab_size = cfg.get("vocab_size", len(self.vocab) or 10000)
                embed_dim  = cfg.get("embed_dim",  128)
                num_api    = cfg.get("num_api",    len(self.api_names))

                model = _build_ncf_model(vocab_size, embed_dim, num_api)
                state_dict = torch.load(improved_path, map_location=self.device, weights_only=False)
                model.load_state_dict(state_dict)
                model.to(self.device)
                model.eval()

                print(f"  ✓ NCF 已从 ncf_improved.pth 加载（词汇表: {len(self.vocab)} 词）")
                self.ncf_trained = True
                return model

            except Exception as exc:
                print(f"  ⚠ 加载 ncf_improved.pth 失败: {exc}")

        fallback_path = Path(model_path) if model_path else MODEL_ROOT / "checkpoints" / "ncf_best.pth"

        if fallback_path.exists():
            try:
                checkpoint = torch.load(fallback_path, map_location=self.device, weights_only=False)

                if "embedding.weight" in checkpoint:
                    vocab_size = checkpoint["embedding.weight"].shape[0]
                    embed_dim  = checkpoint["embedding.weight"].shape[1]
                else:
                    vocab_size, embed_dim = 10000, 128

                num_api = (checkpoint["mlp.6.weight"].shape[0]
                           if "mlp.6.weight" in checkpoint else len(self.api_names))

                print(f"  从 checkpoint 推断参数: vocab={vocab_size}, embed={embed_dim}, num_api={num_api}")

                model = _build_ncf_model(vocab_size, embed_dim, num_api)
                model.load_state_dict(checkpoint)
                model.to(self.device)
                model.eval()

                print("  ✓ NCF 已从 ncf_best.pth 加载")
                print("  ⚠ 注意: 词汇表未加载，NCF 推理将回退到关键词匹配")
                self.ncf_trained = True
                return model

            except Exception as exc:
                print(f"  ⚠ 加载 ncf_best.pth 失败: {exc}")

        print(f"  ⚠ 未找到模型文件，使用关键词匹配")
        self.ncf_trained = False
        return None

    def _build_keyword_index(self):
        self.api_keywords: Dict[str, List[int]] = {}
        for i, name in enumerate(self.api_names):
            for word in name.lower().replace("-", " ").replace("_", " ").split():
                if len(word) > 2:
                    self.api_keywords.setdefault(word, []).append(i)

    def _text_to_indices(self, text: str) -> torch.Tensor:

        words   = text.lower().split()
        indices = [self.vocab.get(w, 1) for w in words[: self.max_doc_len]]
        while len(indices) < self.max_doc_len:
            indices.append(0)
        return torch.LongTensor([indices]).to(self.device)

    def _calc_vocab_coverage(self, text: str) -> float:
        words = text.lower().split()
        if not words:
            return 0.0
        known = sum(1 for w in words if w in self.vocab)
        return known / len(words)

    def recommend_api(self, task_text: str, top_k: int = 5) -> List[Dict]:

        if not self.api_names:
            return [{"api_name": "manual-task", "score": 0.5, "source": "fallback"}]

        bridged_text = task_text
        if self.use_bridge and self.bridge is not None:
            bridged_text = self.bridge.bridge(task_text)

        coverage = self._calc_vocab_coverage(bridged_text) if self.vocab else 0.0

        use_ncf = (
            self.ncf_model is not None
            and self.ncf_trained
            and bool(self.vocab)
            and coverage >= self.MIN_VOCAB_COVERAGE
        )

        if use_ncf:
            try:
                input_tensor = self._text_to_indices(bridged_text)
                self.ncf_model.eval()
                with torch.no_grad():
                    logits = self.ncf_model(input_tensor)
                    probs  = torch.sigmoid(logits).cpu().numpy()[0]
                top_indices = np.argsort(probs)[::-1][:top_k]
                return [
                    {
                        "api_name":       self.api_names[idx],
                        "score":          float(probs[idx]),
                        "source":         "ncf",
                        "bridged_text":   bridged_text if self.use_bridge else None,
                        "vocab_coverage": coverage,
                    }
                    for idx in top_indices
                ]
            except Exception as exc:
                print(f"  ⚠ NCF 推理失败: {exc}，回退到关键词匹配")
        elif self.ncf_model is not None and self.ncf_trained and self.vocab:
            print(f"  ⚠ 词汇覆盖率过低 ({coverage:.0%} < {self.MIN_VOCAB_COVERAGE:.0%})，"
                  f"NCF 输入超出训练分布，回退到关键词匹配")

        scores      = self._keyword_match_score(task_text)
        top_indices = np.argsort(scores)[::-1][:top_k]
        return [
            {
                "api_name":       self.api_names[idx],
                "score":          float(scores[idx]),
                "source":         "keyword_fallback",
                "bridged_text":   bridged_text if self.use_bridge else None,
                "vocab_coverage": coverage,
            }
            for idx in top_indices
        ]

    def _keyword_match_score(self, task_text: str) -> np.ndarray:

        scores      = np.zeros(len(self.api_names), dtype=np.float32)
        task_lower  = task_text.lower()

        domain_mapping = {
            "ship":      ["shipping", "logistics", "delivery", "fedex", "ups", "post"],
            "pay":       ["payment", "stripe", "paypal", "checkout"],
            "send":      ["email", "sms", "notification", "twilio", "message"],
            "verify":    ["verification", "auth", "identity", "validate"],
            "search":    ["search", "find", "google", "query"],
            "check":     ["check", "verify", "validate", "inspect"],
            "select":    ["select", "choose", "pick", "compare"],
            "label":     ["label", "print", "barcode"],
            "package":   ["package", "parcel", "box", "wrap"],
            "insurance": ["insurance", "policy", "coverage"],
            "offer":     ["offer", "quote", "bid", "price"],
            "order":     ["order", "purchase", "buy"],
        }

        task_keywords: set = set()
        for word in task_lower.split():
            word = word.strip(".,!?;:")
            task_keywords.add(word)
            if word in domain_mapping:
                task_keywords.update(domain_mapping[word])

        for kw in task_keywords:
            for idx in self.api_keywords.get(kw, []):
                scores[idx] += 1.0

        for i, name in enumerate(self.api_names):
            name_lower = name.lower()
            for kw in task_keywords:
                if len(kw) > 3 and kw in name_lower:
                    scores[i] += 0.5

        if scores.max() > 0:
            scores /= scores.max()
        return scores

    def run(self, user_request: str, scenario_name: str) -> UnifiedOutput:

        print(f"\n{'='*60}")
        print(f"ProMoAI_NCF 处理场景: {scenario_name}")
        print(f"{'='*60}")

        start_time = time.time()

        print("\n[Stage 1] ProMoAI - POWL 工作流生成")
        print("-" * 50)
        workflow, generated_code = self.promoai.generate(user_request)

        tasks_raw    = self.promoai.get_tasks(workflow)
        gateways_raw = self.promoai.get_gateways(workflow)

        print(f"  ✓ 任务数: {len(tasks_raw)}")
        print(f"  ✓ 网关数: {len(gateways_raw)}")
        for task in tasks_raw[:5]:
            print(f"    [{task.get('id','?')}] {task.get('name','?')[:45]}")

        print("\n[Stage 2] NCF - API 推荐")
        print("-" * 50)

        ncf_used_count      = 0
        fallback_used_count = 0

        api_bindings: Dict[str, Any] = {}
        for task in tasks_raw:
            task_id   = task.get("id", "")
            task_name = task.get("name", "")

            recommendations = self.recommend_api(task_name, top_k=5)

            if recommendations:
                top_api = recommendations[0]
                source  = top_api.get("source", "unknown")
                if source == "ncf":
                    ncf_used_count += 1
                elif source == "keyword_fallback":
                    fallback_used_count += 1

                api_bindings[task_id] = {
                    "task_name":        task_name,
                    "api_name":         top_api["api_name"],
                    "confidence":       top_api["score"],
                    "source":           source,
                    "bridged_text":     top_api.get("bridged_text"),
                    "vocab_coverage":   top_api.get("vocab_coverage"),
                    "top5_recommendations": [
                        {"rank": r + 1, "api_name": rec["api_name"], "score": rec["score"]}
                        for r, rec in enumerate(recommendations)
                    ],
                }
                cov_str = (f"{top_api['vocab_coverage']:.0%}"
                           if top_api.get("vocab_coverage") is not None else "n/a")
                print(f"  [{task_id}] {task_name[:40]}  (来源: {source}, 词汇覆盖: {cov_str})")
                for r, rec in enumerate(recommendations):
                    print(f"      Top{r+1}: {rec['api_name']} ({rec['score']:.3f})")

        print(f"\n  Stage 2 汇总: NCF神经网络={ncf_used_count}, 关键词回退={fallback_used_count}")

        execution_time = time.time() - start_time
        dependencies   = self._extract_dependencies(workflow)

        return UnifiedOutput(
            method="ProMoAI_NCF",
            scenario_name=scenario_name,
            user_request=user_request,
            tasks=tasks_raw,
            dependencies=dependencies,
            gateways=gateways_raw,
            api_bindings=api_bindings,
            roles=[],
            execution_time=execution_time,
            extra_info={
                "workflow_generator":   "ProMoAI (POWL + Few-shot)",
                "api_recommender":      "NCF (Embed->MeanPool->MLP) + SemanticBridge + keyword fallback",
                "ncf_trained":          getattr(self, "ncf_trained", False),
                "ncf_uses_nn":          bool(self.ncf_trained and self.vocab),
                "semantic_bridge_used": self.use_bridge,
                "min_vocab_coverage":   self.MIN_VOCAB_COVERAGE,
                "tasks_via_ncf":        ncf_used_count,
                "tasks_via_fallback":   fallback_used_count,
                "generated_code":       (generated_code[:500] if generated_code else ""),
            },
        )

    def _extract_dependencies(self, workflow: Dict) -> List[Dict]:
        raw_model    = workflow.get("model", workflow)
        dependencies = []
        self._extract_deps_recursive(raw_model, dependencies)
        return dependencies

    def _extract_deps_recursive(self, model: Dict, deps: List):
        if not isinstance(model, dict):
            return
        for edge in model.get("edges", []):
            from_node = edge.get("from", {})
            to_node   = edge.get("to",   {})
            if isinstance(from_node, dict) and isinstance(to_node, dict):
                from_id = from_node.get("id", "")
                to_id   = to_node.get("id",   "")
                if from_id and to_id:
                    deps.append({"from": from_id, "to": to_id})
        for node in model.get("nodes", []):
            self._extract_deps_recursive(node, deps)
        if "submodel" in model:
            self._extract_deps_recursive(model["submodel"], deps)


def main():

    print("\n")
    print("=" * 60)
    print("  ProMoAI_NCF 评估运行脚本 (修复版 v7)")
    print("  POWL 工作流生成 + 语义桥接 + NCF 协同过滤推荐")
    print("=" * 60)

    data_path      = SCRIPT_DIR / "data"
    embedding_path = SCRIPT_DIR / "embedding"

    if not data_path.exists():
        data_path = MODEL_ROOT / "data"
    if not embedding_path.exists():
        embedding_path = MODEL_ROOT / "embedding"

    USE_SEMANTIC_BRIDGE = os.getenv("NCF_USE_SEMANTIC_BRIDGE", "1") != "0"

    system = ProMoAINCFSystem(
        data_path=str(data_path),
        embedding_path=str(embedding_path),
        use_bridge=USE_SEMANTIC_BRIDGE,
    )

    print("\n" + "=" * 60)
    print("开始评估测试场景")
    print("=" * 60)

    results = []
    for i, scenario in enumerate(BPMN_TEST_SCENARIOS):
        print(f"\n>>> 场景 [{i+1}/{len(BPMN_TEST_SCENARIOS)}]: {scenario.name}")
        try:
            result = system.run(scenario.requirement, scenario.name)
            results.append(result)
            print(f"\n结果摘要:")
            print(f"  - 任务数: {len(result.tasks)}")
            print(f"  - 依赖数: {len(result.dependencies)}")
            print(f"  - 网关数: {len(result.gateways)}")
            print(f"  - API绑定数: {len(result.api_bindings)}")
            print(f"  - 执行时间: {result.execution_time:.2f}s")
        except KeyboardInterrupt:
            print(f"\n  ⚠ 用户中断，跳过场景 {scenario.name}")
            print(f"    (再次按 Ctrl+C 退出整个程序)")
            try:
                time.sleep(2)
            except KeyboardInterrupt:
                print("\n程序被用户终止")
                break
            continue
        except Exception as exc:
            print(f"  ✗ 场景 {scenario.name} 处理失败: {exc}")
            traceback.print_exc()
            continue

    output_dir = EVAL_ROOT / "results"
    save_results(results, str(output_dir), "promoai_ncf")

    print("\n" + "=" * 60)
    print("ProMoAI_NCF 评估完成!")
    print("=" * 60)


if __name__ == "__main__":
    main()
