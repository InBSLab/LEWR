import os
import sys
import re
import csv
import json
import time
import math
import statistics
import traceback
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List, Any, Optional

import numpy as np
import torch


SCRIPT_DIR   = Path(__file__).parent.absolute()
PROJECT_ROOT = SCRIPT_DIR.parent.parent
EVAL_ROOT    = SCRIPT_DIR.parent

N_REPEATS = 10
SCENARIOS_TO_RUN: Optional[List[str]] = None
USE_SEMANTIC_BRIDGE = os.getenv("NCF_USE_SEMANTIC_BRIDGE", "1") != "0"
RESULT_VARIANT = "repaired"
USE_IMPROVED_RECOMMENDER = True
ENGLISH_DIR_OVERRIDE: Optional[Path] = None


OUTPUT_DIR    = SCRIPT_DIR / "robustness_results"
OUTPUT_PREFIX = "promoai_ncf_robustness"


W_CF, W_KW, W_NCF = 0.40, 0.35, 0.25


sys.path.insert(0, str(EVAL_ROOT / "common"))
sys.path.insert(0, str(SCRIPT_DIR))

_main_mod = None
for _name in ("promoai_ncf_run_for_evaluation_v10",
              "promoai_ncf_run_for_evaluation_v11",
              "promoai_ncf_run_for_evaluation_fixed_8",
              "promoai_ncf_run_for_evaluation_fixed_7"):
    try:
        _main_mod = __import__(_name)
        print(f"  已导入主运行脚本: {_name}")
        break
    except ImportError:
        continue
if _main_mod is None:
    raise ImportError("找不到主运行脚本 promoai_ncf_run_for_evaluation_v10.py，"
                      "请与本脚本放在同一目录。")

MODEL_ROOT = _main_mod.MODEL_ROOT
BaseSystem = _main_mod.ProMoAINCFSystem
from scenarios import BPMN_TEST_SCENARIOS  # noqa: E402



_STOP = set("""a an the and or of to in on for with by from at as is are be this that it its
into onto per via then than so if not no yes any all each both either whether which who whom
will would should shall can could may might must do does did done have has had
""".split())


def _stem(w: str) -> str:
    for suf in ("ing", "ed", "es", "s"):
        if len(w) > len(suf) + 3 and w.endswith(suf):
            return w[: -len(suf)]
    return w


def _tokens(text: str) -> List[str]:
    ws = re.findall(r"[a-z0-9]+", str(text).lower())
    return [_stem(w) for w in ws if w not in _STOP and len(w) > 1]


class ImprovedProMoAINCFSystem(BaseSystem):


    CTX_WEIGHT = 0.30
    EXPAND_WEIGHT = 0.70
    KNN_K = 30
    DIVERSITY_DECAY = 0.92

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._ctx_terms: Dict[str, float] = {}
        self._usage: Counter = Counter()
        self._build_improved_indices()


    def _build_improved_indices(self):
        print("\n[改进推荐器] 构建索引 ...")
        n_api = len(self.api_names)
        self._api_idx = {n: i for i, n in enumerate(self.api_names)}


        self._api_tok: List[List[str]] = [_tokens(re.sub(r"[-_.]", " ", n)) for n in self.api_names]
        df = Counter(t for toks in self._api_tok for t in set(toks))
        self._api_idf = {t: math.log((n_api + 1) / (c + 0.5)) for t, c in df.items()}


        descs = self._load_mashup_descriptions()
        used = []
        used_file = Path(self.data_path) / "mashup_used_api.json"
        if used_file.exists():
            try:
                used = json.load(open(used_file, "r", encoding="utf-8"))
            except Exception as exc:
                print(f"  ⚠ 读取 mashup_used_api.json 失败: {exc}")
        self._cf_ready = bool(descs) and len(used) == len(descs)
        self._desc_tok: List[set] = []
        self._inv: Dict[str, List[int]] = defaultdict(list)
        self._used: List[List[int]] = []
        self._api_pop = np.zeros(n_api, dtype=np.float32)
        if self._cf_ready:
            for i, d in enumerate(descs):
                words = d if isinstance(d, list) else str(d).split()
                toks = set(_tokens(" ".join(words)))
                self._desc_tok.append(toks)
                for t in toks:
                    self._inv[t].append(i)
                idxs = [self._api_idx[a] for a in used[i] if a in self._api_idx]
                self._used.append(idxs)
                for j in idxs:
                    self._api_pop[j] += 1
            N = len(descs)
            self._word_idf = {t: math.log((N + 1) / (len(v) + 0.5)) for t, v in self._inv.items()}
            print(f"  ✓ CF 语料 {N} 条，已建立倒排索引")
        else:
            print("  ⚠ 缺少 mashup_used_api.json 或与描述数量不一致，CF 通道关闭")


        self._ncf_prior = np.zeros(n_api, dtype=np.float32)
        if self.ncf_model is not None and getattr(self, "ncf_trained", False) and self.vocab and descs:
            try:
                rng = np.random.RandomState(0)
                pick = rng.choice(len(descs), size=min(300, len(descs)), replace=False)
                outs = []
                self.ncf_model.eval()
                with torch.no_grad():
                    for k in range(0, len(pick), 64):
                        batch = []
                        for i in pick[k:k + 64]:
                            d = descs[i]
                            txt = " ".join(d) if isinstance(d, list) else str(d)
                            batch.append(self._text_to_indices(txt))
                        x = torch.cat(batch, dim=0)
                        outs.append(torch.sigmoid(self.ncf_model(x)).cpu().numpy())
                self._ncf_prior = np.concatenate(outs, axis=0).mean(axis=0).astype(np.float32)
                print(f"  ✓ NCF 去偏置先验就绪（最大先验 {self._ncf_prior.max():.3f}）")
            except Exception as exc:
                print(f"  ⚠ NCF 先验估计失败，跳过去偏置: {exc}")


    def run(self, user_request: str, scenario_name: str):
        self._usage = Counter()
        counts = Counter(_tokens(user_request))
        self._ctx_terms = {t: self.CTX_WEIGHT for t, c in counts.items() if len(t) > 3}
        return super().run(user_request, scenario_name)


    def _query_terms(self, task_text: str) -> Dict[str, float]:
        q: Dict[str, float] = dict(self._ctx_terms)
        base = _tokens(task_text)
        for t in base:
            q[t] = 1.0
        if self.bridge is not None:
            try:
                expanded = self.bridge._keyword_expand(task_text)
            except Exception:
                expanded = set()
            for e in expanded:
                for t in _tokens(re.sub(r"[-_]", " ", e)):
                    q[t] = max(q.get(t, 0.0), self.EXPAND_WEIGHT)
        return q


    def _kw_scores(self, q: Dict[str, float]) -> np.ndarray:
        s = np.zeros(len(self.api_names), dtype=np.float32)
        for i, toks in enumerate(self._api_tok):
            for at in toks:
                idf = self._api_idf.get(at, 1.0)
                if at in q:
                    s[i] += q[at] * idf
                else:
                    for qt, w in q.items():
                        if len(qt) >= 4 and len(at) >= 4 and (qt in at or at in qt):
                            s[i] += 0.5 * w * idf
                            break
        return s / s.max() if s.max() > 0 else s

    def _cf_scores(self, q: Dict[str, float]) -> np.ndarray:
        s = np.zeros(len(self.api_names), dtype=np.float32)
        if not self._cf_ready:
            return s
        cand: Dict[int, float] = defaultdict(float)
        for t, w in q.items():
            idf = self._word_idf.get(t)
            if idf is None:
                continue
            for m in self._inv[t]:
                cand[m] += w * idf
        if not cand:
            return s
        scored = [(m, v / math.sqrt(len(self._desc_tok[m]) + 1.0)) for m, v in cand.items()]
        scored.sort(key=lambda x: x[1], reverse=True)
        top = scored[: self.KNN_K]
        for m, v in top:
            for j in self._used[m]:
                s[j] += v * v
        s = s / np.sqrt(self._api_pop + 5.0)       # 反流行度校正
        return s / s.max() if s.max() > 0 else s

    def _ncf_scores_debiased(self, bridged_text: str):
        raw = np.zeros(len(self.api_names), dtype=np.float32)
        if not (self.ncf_model is not None and getattr(self, "ncf_trained", False) and self.vocab):
            return raw, raw
        try:
            self.ncf_model.eval()
            with torch.no_grad():
                raw = torch.sigmoid(self.ncf_model(self._text_to_indices(bridged_text))).cpu().numpy()[0]
        except Exception as exc:
            print(f"  ⚠ NCF 推理失败: {exc}")
            return raw, raw
        deb = np.clip(raw - self._ncf_prior, 0.0, None)
        return raw, (deb / deb.max() if deb.max() > 0 else deb)


    def recommend_api(self, task_text: str, top_k: int = 5) -> List[Dict]:
        if not USE_IMPROVED_RECOMMENDER:
            return super().recommend_api(task_text, top_k)
        if not self.api_names:
            return [{"api_name": "manual-task", "score": 0.5, "source": "fallback"}]

        q = self._query_terms(task_text)

        bridged_text, retrieved = task_text, []
        if self.use_bridge and self.bridge is not None:
            r = self.bridge.retrieve(task_text)
            bridged_text, retrieved = r["bridged_text"], r["retrieved_mashups"]

        kw = self._kw_scores(q)
        cf = self._cf_scores(q)
        ncf_raw, ncf_deb = self._ncf_scores_debiased(bridged_text)


        w = {"cf": W_CF if cf.max() > 0 else 0.0,
             "kw": W_KW if kw.max() > 0 else 0.0,
             "ncf": W_NCF if ncf_deb.max() > 0 else 0.0}
        tot = sum(w.values())
        if tot == 0:
            combined = np.zeros(len(self.api_names), dtype=np.float32)
        else:
            combined = (w["cf"] * cf + w["kw"] * kw + w["ncf"] * ncf_deb) / tot

        penal = np.array([self.DIVERSITY_DECAY ** self._usage.get(self.api_names[i], 0)
                          for i in range(len(self.api_names))], dtype=np.float32)
        combined = combined * penal

        top = np.argsort(combined)[::-1][:top_k]
        self._usage[self.api_names[top[0]]] += 1
        return [{
            "api_name": self.api_names[i],
            "score": float(combined[i]),
            "ncf_score": float(ncf_raw[i]),
            "keyword_score": float(kw[i]),
            "cf_score": float(cf[i]),
            "source": "ncf+keyword_fused",     # 与主脚本统计字段保持兼容
            "bridged_text": bridged_text if self.use_bridge else None,
            "retrieved_mashups": retrieved,
        } for i in top]



def _stats(values: List[Optional[float]]) -> Dict[str, Optional[float]]:
    v = [x for x in values if x is not None]
    if not v:
        return {"mean": None, "std": None, "var": None}
    if len(v) == 1:
        return {"mean": float(v[0]), "std": 0.0, "var": 0.0}
    return {"mean": statistics.mean(v), "std": statistics.stdev(v), "var": statistics.variance(v)}



METRICS = [
    ("overall_score", "overall_score"),
    ("ged_quality", "ged_quality"),
    ("api_binding_score", "api_binding"),
    ("structural_validity", "structural_validity"),
    ("task_count", "task_count"),
    ("gateway_count", "gateway_count"),
    ("dependency_count", "dependency_count"),
    ("api_binding_count", "api_binding_count"),
    ("vocab_coverage_mean", "vocab_coverage"),
    ("mean_top1_confidence", "top1_confidence"),
    ("ged_raw_average", "ged_raw_average"),
    ("elapsed_sec", "elapsed_sec"),
]


def summarize(scenario: str, records: List[Dict[str, Any]]) -> Dict[str, Any]:
    ok = [r for r in records if r.get("success")]
    out: Dict[str, Any] = {"scenario": scenario, "n_runs": len(records),
                           "n_success": len(ok), "n_failed": len(records) - len(ok),
                           "n_scored": sum(1 for r in ok if "overall_score" in r)}
    for key, name in METRICS:
        st = _stats([r.get(key) for r in ok])
        for k in ("mean", "std", "var"):
            out[f"{name}_{k}"] = None if st[k] is None else round(st[k], 6)
    return out


def summarize_overall(all_records: Dict[str, List[Dict[str, Any]]]) -> Dict[str, Any]:

    by_run: Dict[int, List[Dict[str, Any]]] = defaultdict(list)
    for recs in all_records.values():
        for r in recs:
            if r.get("success"):
                by_run[r["run_index"]].append(r)
    out: Dict[str, Any] = {"scenario": "ALL (跨场景, 先按run平均)",
                           "n_runs": len(by_run), "n_success": len(by_run),
                           "n_failed": 0, "n_scored": 0}
    for key, name in METRICS:
        per_run = []
        for idx in sorted(by_run):
            vals = [r.get(key) for r in by_run[idx] if r.get(key) is not None]
            per_run.append(statistics.mean(vals) if vals else None)
        st = _stats(per_run)
        for k in ("mean", "std", "var"):
            out[f"{name}_{k}"] = None if st[k] is None else round(st[k], 6)
    out["n_scored"] = sum(1 for idx in by_run if any("overall_score" in r for r in by_run[idx]))
    return out


def write_csv(path: Path, rows: List[Dict[str, Any]], fields: Optional[List[str]] = None):
    if fields is None:
        fields = []
        for r in rows:
            for k in r:
                if k not in fields:
                    fields.append(k)
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k) for k in fields})


def print_summary(s: Dict[str, Any]):
    f = lambda n: f"mean={s.get(n + '_mean')} std={s.get(n + '_std')} var={s.get(n + '_var')}"
    print(f"  成功 {s['n_success']}/{s['n_runs']}  已打分 {s['n_scored']}")
    for name in ("overall_score", "ged_quality", "api_binding", "structural_validity"):
        if s.get(name + "_mean") is not None:
            print(f"  {name:<20}: {f(name)}")
    print(f"  tasks: {f('task_count')}")
    print(f"  api绑定数: {f('api_binding_count')}")
    print(f"  top1置信度: {f('top1_confidence')}")



def run_repeated_sampling():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    print("=" * 70)
    print("ProMoAI_NCF 重复采样稳定性实验")
    print("=" * 70)
    print(f"重复次数 N={N_REPEATS} | 结果版本={RESULT_VARIANT} | "
          f"改进推荐器={'开' if USE_IMPROVED_RECOMMENDER else '关'}")
    print(f"输出目录: {OUTPUT_DIR}\n")


    scorer_module = scorer_instance = None
    ged_ready = False
    try:
        sys.path.insert(0, str(EVAL_ROOT))
        import evaluate_all_results_GED_v3 as ged_eval
        scorer_module = ged_eval
        if ENGLISH_DIR_OVERRIDE is not None:
            ged_eval.ENGLISH_DIR = ENGLISH_DIR_OVERRIDE
        ged_ready = ged_eval.ENGLISH_DIR.exists()
        if ged_ready:
            scorer_instance = ged_eval.BERTScorer()
            print(f"✓ 评分模块就绪，Ground Truth: {ged_eval.ENGLISH_DIR}")
        else:
            print(f"⚠ Ground Truth 目录不存在: {ged_eval.ENGLISH_DIR}，只统计结构指标")
    except Exception as e:
        print(f"⚠ 评分模块导入失败，只统计结构指标: {e}")

    data_path = SCRIPT_DIR / "data"
    embedding_path = SCRIPT_DIR / "embedding"
    if not data_path.exists():
        data_path = MODEL_ROOT / "data"
    if not embedding_path.exists():
        embedding_path = MODEL_ROOT / "embedding"

    SystemCls = ImprovedProMoAINCFSystem if USE_IMPROVED_RECOMMENDER else BaseSystem
    system = SystemCls(data_path=str(data_path), embedding_path=str(embedding_path),
                       use_bridge=USE_SEMANTIC_BRIDGE)

    scenarios = BPMN_TEST_SCENARIOS
    if SCENARIOS_TO_RUN:
        scenarios = [s for s in scenarios if s.name in SCENARIOS_TO_RUN]
    print(f"\n将测试 {len(scenarios)} 个场景 × {N_REPEATS} 次\n")

    all_records: Dict[str, List[Dict[str, Any]]] = {}
    all_summaries: List[Dict[str, Any]] = []

    for scenario in scenarios:
        print("=" * 70)
        print(f"场景: {scenario.name}")
        print("=" * 70)
        records: List[Dict[str, Any]] = []

        for run_idx in range(1, N_REPEATS + 1):
            print(f"\n--- {scenario.name} | run {run_idx}/{N_REPEATS} ---")
            t0 = time.time()
            rec: Dict[str, Any] = {"scenario": scenario.name, "run_index": run_idx,
                                   "result_variant": RESULT_VARIANT,
                                   "improved_recommender": USE_IMPROVED_RECOMMENDER,
                                   "success": False, "error": None}
            try:
                outcome = system.run(scenario.requirement, scenario.name)
                result = outcome[RESULT_VARIANT] if isinstance(outcome, dict) else outcome
                elapsed = time.time() - t0
                api_b = getattr(result, "api_bindings", {}) or {}
                extra = getattr(result, "extra_info", {}) or {}
                cov = [b.get("vocab_coverage") for b in api_b.values() if b.get("vocab_coverage") is not None]
                conf = [b.get("confidence") for b in api_b.values() if b.get("confidence") is not None]
                rec.update({
                    "success": True,
                    "elapsed_sec": round(elapsed, 2),
                    "task_count": len(result.tasks),
                    "gateway_count": len(result.gateways),
                    "dependency_count": len(result.dependencies),
                    "api_binding_count": len(api_b),
                    "vocab_coverage_mean": round(statistics.mean(cov), 4) if cov else None,
                    "mean_top1_confidence": round(statistics.mean(conf), 4) if conf else None,
                    "generation_source": extra.get("generation_source"),
                    "top1_apis": {tid: b.get("api_name") for tid, b in api_b.items()},
                })
                print(f"  ✓ {elapsed:.1f}s | tasks={rec['task_count']} gw={rec['gateway_count']} "
                      f"api={rec['api_binding_count']}")

                if ged_ready and scorer_module is not None:
                    try:
                        normed = scorer_module.normalize_result(result.to_dict())
                        gt_key = scorer_module.SCENARIO_NAME_MAPPING.get(scenario.name, scenario.name)
                        gt = scorer_module.load_ground_truth(gt_key)
                        if gt is not None:
                            ann = scorer_module.load_api_annotations(gt_key)
                            ev = scorer_module.evaluate_single(normed, gt, scorer_instance, ann)
                            pm = ev["primary_metrics"]
                            gd = ev.get("ged_distances", {})
                            rec.update({
                                "overall_score": ev["overall_score"],
                                "ged_quality": pm["ged_quality"],
                                "api_binding_score": pm["api_binding"],
                                "structural_validity": pm["structural_validity"],
                                "ged_raw_average": gd.get("average"),
                            })
                            print(f"  ✓ Overall={ev['overall_score']:.3f} GQ={pm['ged_quality']:.3f} "
                                  f"AB={pm['api_binding']:.3f} SV={pm['structural_validity']:.3f}")
                        else:
                            print(f"  ⚠ 找不到 {gt_key} 的 ground truth，跳过打分")
                    except Exception as err:
                        print(f"  ⚠ 打分失败: {err}")
                        rec["score_error"] = str(err)
            except KeyboardInterrupt:
                rec.update({"error": "KeyboardInterrupt", "elapsed_sec": round(time.time() - t0, 2)})
                print("  ⚠ 用户中断本次运行")
            except Exception as e:
                rec.update({"error": str(e), "elapsed_sec": round(time.time() - t0, 2)})
                print(f"  ✗ 失败: {e}")
                traceback.print_exc()

            records.append(rec)
            with open(OUTPUT_DIR / f"{OUTPUT_PREFIX}_raw_{scenario.name}.json", "w", encoding="utf-8") as f:
                json.dump(records, f, indent=2, ensure_ascii=False)

        all_records[scenario.name] = records
        s = summarize(scenario.name, records)
        all_summaries.append(s)
        print(f"\n[{scenario.name} 汇总]")
        print_summary(s)

    overall = summarize_overall(all_records)
    all_summaries.append(overall)
    print("\n" + "=" * 70)
    print("跨场景整体（N 次运行的均值/方差）")
    print("=" * 70)
    print_summary(overall)

    flat = [r for recs in all_records.values() for r in recs]
    # CSV 里不放嵌套 dict
    csv_rows = [{k: v for k, v in r.items() if k != "top1_apis"} for r in flat]
    write_csv(OUTPUT_DIR / f"{OUTPUT_PREFIX}_per_run.csv", csv_rows)

    with open(OUTPUT_DIR / f"{OUTPUT_PREFIX}_summary.json", "w", encoding="utf-8") as f:
        json.dump(all_summaries, f, indent=2, ensure_ascii=False)
    write_csv(OUTPUT_DIR / f"{OUTPUT_PREFIX}_summary.csv", all_summaries)

    print(f"\n全部完成，结果在: {OUTPUT_DIR}")


if __name__ == "__main__":
    run_repeated_sampling()
