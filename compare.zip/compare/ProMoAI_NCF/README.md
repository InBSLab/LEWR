# ProMoAI-NCF

An end-to-end pipeline that turns a natural-language process description into a
**POWL workflow** and then recommends a Web API for each activity in that
workflow using **Neural Collaborative Filtering (NCF)**.

The system combines two ideas:

1. **ProMoAI** – an LLM generates Python code (against a small `ModelGenerator`
   DSL) that builds a POWL (Partially Ordered Workflow Language) model of the
   process. Prompting uses role instructions, a POWL knowledge base, negative
   prompting, and few-shot examples, with an error-handling / self-correction
   loop. Based on ProMoAI (Kourani et al., 2024).
2. **NCF** – a lightweight recommender (`Embedding → Mean-Pooling → MLP`) trained
   on the ProgrammableWeb Mashup dataset that predicts which APIs fit a given
   textual description.

Because the NCF vocabulary is built from *Mashup application descriptions*
(Web-API vocabulary) while BPMN/POWL activity names use *business-process*
vocabulary, a **Semantic Bridge** first rewrites each activity name into a
Mashup-style description via the LLM. A vocabulary-coverage check then decides,
per task, whether to trust the neural recommendation or fall back to keyword
matching — coverage is written into the output so every recommendation is
auditable (`source = "ncf"` vs `"keyword_fallback"`).

## Pipeline

```
natural-language description
        │
        ▼
  ProMoAI (LLM + POWL DSL)  ──►  POWL model + activities
        │
        ▼
  Semantic Bridge (LLM)     ──►  Mashup-style text per activity
        │
        ▼
  vocab-coverage gate
        │
   ┌────┴─────────────┐
   ▼                  ▼
 NCF (neural)   keyword fallback
        │
        ▼
   API bindings per activity
```

## Project structure

```
ProMoAI_NCF_System/
├── ncf/                       # NCF recommender
│   ├── __init__.py
│   └── model.py               # NCF model, config, early stopping, metrics
├── promoai/                   # ProMoAI workflow generator
│   ├── __init__.py
│   ├── generator.py           # ModelGenerator DSL + LLM generate/refine loop
│   └── prompts.py             # role / POWL knowledge / few-shot prompts
├── tools/                     # data loading
│   ├── __init__.py
│   └── dataset.py             # ProgrammableWeb Mashup dataset + loaders
├── config.py                  # paths, hyperparameters, API settings
├── train_ncf_improved.py      # train NCF (keeps APIs used >= 5 times)
├── diagnose_ncf.py            # vocab-coverage / API-domain diagnostics
├── main.py                    # ProMoAI + NCF (integrated run)
├── run_evaluation.py          # batch evaluation over BPMN test scenarios
├── requirements.txt
├── .env.example
└── .gitignore
```

## Requirements

- Python 3.9+
- See `requirements.txt` (`torch`, `numpy`, `requests`)

```bash
pip install -r requirements.txt
```

## Configuration

The workflow generator and semantic bridge call an LLM through a DeepSeek-compatible
`/chat/completions` endpoint. The API key is read from the `DEEPSEEK_API_KEY`
environment variable — set it before running:

```bash
export DEEPSEEK_API_KEY="your-api-key-here"      # macOS / Linux
# setx DEEPSEEK_API_KEY "your-api-key-here"      # Windows
```

See `.env.example`. **No key is hard-coded in the source.**

## Data and model files (not included)

These are required to run shipped with the code:

**Dataset** — place the ProgrammableWeb Mashup JSON files under `data/`:
`api_name.json`, `mashup_name.json`, `mashup_description.json`,
`mashup_used_api.json`, `mashup_category.json`, `category_list.json`.
`python config.py` checks for them.

**Trained NCF checkpoint** — under `checkpoints/`:
- `ncf_improved.pth` + `ncf_improved_config.json` (preferred; the config carries
  the vocabulary and API list), or
- `ncf_best.pth` (fallback; note the vocabulary is not restored in this path, so
  recommendation degrades to keyword matching).

Produce the preferred checkpoint with `python train_ncf_improved.py`.

**Optional RoBERTa features** — `embedding/mashup_features_roberta.npy` and
`embedding/api_features_roberta.npy` enable the dataset's RoBERTa mode.

## Usage

Train the recommender:

```bash
python train_ncf_improved.py
```

Check vocabulary coverage / domain overlap:

```bash
python diagnose_ncf.py
```

Run the integrated system:

```bash
python main.py                     # basic integrated run
```

Toggle the semantic bridge in the evaluation runner via an environment variable
(set to `0` to feed raw activity names to NCF, e.g. for an ablation):

```bash
NCF_USE_SEMANTIC_BRIDGE=1 python run_evaluation.py
```


