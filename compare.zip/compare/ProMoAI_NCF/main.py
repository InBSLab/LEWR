import os
import sys
import json
import time
import requests
import numpy as np
import torch
import torch.nn as nn
from pathlib import Path
from typing import Dict, List, Tuple

PROJECT_ROOT = Path(__file__).parent.absolute()
sys.path.insert(0, str(PROJECT_ROOT))


DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "")

USE_SEMANTIC_BRIDGE = True

TEST_REQUEST = """
If goods shall be shipped, the secretary clarifies who will do the shipping.
If you have large amounts, special shipping will be necessary. In these cases
the secretary invites three logistic companies to make offers and she selects
one of them. In case of small amounts, normal post shipment is used.
Therefore a package label is written by the secretary and a parcel insurance
taken by the logistics department head if necessary. In the meantime the goods
can be already packaged by the warehousemen. If everything is ready, the
packaged goods are prepared for being picked up by the logistic company.
"""


class NCF(nn.Module):


    def __init__(self, vocab_size, embed_dim, num_api, dropout=0.2):
        super(NCF, self).__init__()

        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)

        self.mlp = nn.Sequential(
            nn.Linear(embed_dim, 256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(128, num_api)
        )

    def forward(self, x):
        embed = self.embedding(x)
        embed = embed.mean(dim=1)
        return self.mlp(embed)


class SemanticBridge:


    def __init__(self, api_key: str = None):
        self.api_key = api_key

    def bridge(self, task_description: str) -> str:

        if not self.api_key:
            return task_description

        prompt = f"""Convert this task into a web application description (mashup style).

Task: "{task_description}"

Requirements:
1. Describe what the application does functionally
2. Use common web/software terminology
3. Do NOT mention any specific API names (like fedex, google, etc.)
4. Write 15-25 words

Example:
Task: "write package label"
Output: "web application creates shipping labels with address information barcode generation tracking number assignment delivery service integration"

Task: "take parcel insurance"
Output: "application provides insurance coverage for packages calculates rates based on value handles claims processing delivery protection"

Now convert (output only the description, no quotes):
Task: "{task_description}"
Output:"""

        try:
            response = requests.post(
                "https://api.deepseek.com/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": "deepseek-chat",
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": 2500,
                    "temperature": 0.3
                },
                timeout=30
            )
            result = response.json()
            bridged = result['choices'][0]['message']['content'].strip().lower()
            bridged = ''.join(c if c.isalnum() or c.isspace() else ' ' for c in bridged)
            bridged = ' '.join(bridged.split())
            return bridged
        except Exception as e:
            print(f"      [桥接失败] {e}")
            return task_description


class NCFRecommender:


    def __init__(self, model: NCF, vocab: Dict[str, int], api_names: List[str],
                 max_doc_len: int, device: str):
        self.model = model
        self.vocab = vocab
        self.api_names = api_names
        self.max_doc_len = max_doc_len
        self.device = device

    def _text_to_indices(self, text: str) -> List[int]:

        words = text.lower().split()
        indices = [self.vocab.get(w, 1) for w in words[:self.max_doc_len]]
        while len(indices) < self.max_doc_len:
            indices.append(0)
        return indices

    def _calc_vocab_coverage(self, text: str) -> float:

        words = text.lower().split()
        if not words:
            return 0.0
        known = sum(1 for w in words if w in self.vocab)
        return known / len(words)

    def recommend(self, text: str, top_k: int = 5) -> List[Dict]:

        coverage = self._calc_vocab_coverage(text)

        indices = self._text_to_indices(text)
        input_tensor = torch.LongTensor([indices]).to(self.device)

        self.model.eval()
        with torch.no_grad():
            logits = self.model(input_tensor)
            probs = torch.sigmoid(logits).cpu().numpy()[0]

        top_indices = np.argsort(probs)[::-1][:top_k]

        results = []
        for idx in top_indices:
            results.append({
                'api_name': self.api_names[idx],
                'score': float(probs[idx]),
                'vocab_coverage': coverage
            })

        return results


class ProMoAI_NCF_Fair:


    def __init__(self, api_key: str = None, use_bridge: bool = True):
        print("=" * 60)
        print("ProMoAI + NCF 公平对比版本")
        print("=" * 60)
        print("设计: 完整保留ProMoAI和NCF的原始能力")
        print("      不添加任何额外领域知识")
        print("=" * 60)

        self.api_key = api_key or DEEPSEEK_API_KEY
        self.use_bridge = use_bridge
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'

        print("\n[1] 加载NCF模型...")
        config_path = PROJECT_ROOT / "checkpoints" / "ncf_improved_config.json"
        model_path = PROJECT_ROOT / "checkpoints" / "ncf_improved.pth"

        if not config_path.exists() or not model_path.exists():
            raise FileNotFoundError(
                f"NCF模型文件不存在！请先运行 train_ncf_improved.py"
            )

        with open(config_path, 'r', encoding='utf-8') as f:
            self.config = json.load(f)

        self.ncf_model = NCF(
            vocab_size=self.config['vocab_size'],
            embed_dim=self.config['embed_dim'],
            num_api=self.config['num_api']
        )
        self.ncf_model.load_state_dict(
            torch.load(model_path, map_location=self.device, weights_only=True)
        )
        self.ncf_model.to(self.device)
        self.ncf_model.eval()

        print(f"  ✓ NCF模型加载成功")
        print(f"    - APIs: {self.config['num_api']}")
        print(f"    - Vocab: {self.config['vocab_size']}")
        print(f"    - 结构: Embedding({self.config['embed_dim']}) → MeanPooling → MLP")

        print("\n[2] 创建NCF推荐器...")
        self.recommender = NCFRecommender(
            model=self.ncf_model,
            vocab=self.config['vocab'],
            api_names=self.config['api_names'],
            max_doc_len=self.config['max_doc_len'],
            device=self.device
        )
        print(f"  ✓ NCF推荐器就绪（纯协同过滤，无额外知识）")

        print("\n[3] 语义桥接...")
        if self.use_bridge:
            self.bridge = SemanticBridge(api_key=self.api_key)
            print(f"  ✓ 语义桥接就绪（仅风格转换，不引入领域知识）")
        else:
            self.bridge = None
            print(f"  - 语义桥接已禁用")

        print("\n[4] 初始化ProMoAI...")
        try:
            from promoai import ProMoAIGenerator
            self.promoai = ProMoAIGenerator(api_key=self.api_key)
            print(f"  ✓ ProMoAI就绪 (POWL + Few-shot Learning)")
        except ImportError:
            print(f"  ⚠️ ProMoAI未找到，使用简化版工作流解析")
            self.promoai = None

        print("\n" + "=" * 60)
        print("系统初始化完成!")
        print(f"  - ProMoAI: {'✓' if self.promoai else '简化版'}")
        print(f"  - NCF: ✓ (纯协同过滤)")
        print(f"  - 语义桥接: {'✓' if self.use_bridge else '✗'}")
        print(f"  - 额外领域知识: ✗ (公平对比)")
        print("=" * 60)

    def process(self, user_request: str) -> Dict:

        result = {
            "user_request": user_request,
            "method": f"ProMoAI (POWL) + NCF (Collaborative Filtering)",
            "use_bridge": self.use_bridge,
            "tasks": [],
            "api_bindings": {},
            "statistics": {}
        }

        print("\n" + "=" * 60)
        print("[Step 1] ProMoAI 工作流生成 (POWL + Few-shot)")
        print("=" * 60)

        start_time = time.time()

        result["promoai_used"] = False
        result["promoai_error"] = None

        if self.promoai:
            try:
                workflow, generated_code = self.promoai.generate(user_request)
                result["workflow"] = workflow
                tasks = self.promoai.get_tasks(workflow)
                result["promoai_used"] = True
                print(f"  ✓ 生成工作流，耗时 {time.time() - start_time:.2f}s")
            except Exception as e:
                print(f"  ⚠️ ProMoAI生成失败，本次结果将标记为 fallback（非ProMoAI）: {e}")
                result["promoai_error"] = str(e)
                tasks = self._simple_parse(user_request)
        else:
            result["promoai_error"] = "ProMoAIGenerator 未成功初始化（import失败）"
            tasks = self._simple_parse(user_request)

        result["method"] = (
            "ProMoAI (POWL) + NCF (Collaborative Filtering)"
            if result["promoai_used"]
            else "Fallback keyword-parse (NOT ProMoAI) + NCF (Collaborative Filtering)"
        )
        result["tasks"] = tasks

        print("\n" + "=" * 60)
        print("[Step 2] 提取活动节点")
        print("=" * 60)

        print(f"  ✓ 提取到 {len(tasks)} 个活动:")
        for task in tasks:
            print(f"    - [{task['id']}] {task['name']}")

        print("\n" + "=" * 60)
        print("[Step 3] NCF API推荐 (纯协同过滤)")
        print("=" * 60)

        if self.use_bridge:
            print("  [语义桥接已启用 - 仅风格转换]")
        else:
            print("  [语义桥接已禁用 - 直接使用原始描述]")

        api_bindings = {}
        used_apis = set()

        for task in tasks:
            task_id = task['id']
            task_name = task['name']

            print(f"\n  [{task_id}] {task_name}")

            if self.use_bridge and self.bridge:
                input_text = self.bridge.bridge(task_name)
                print(f"      桥接: {input_text[:55]}...")
            else:
                input_text = task_name

            recommendations = self.recommender.recommend(input_text, top_k=5)

            best_api = recommendations[0]
            used_apis.add(best_api['api_name'])

            api_bindings[task_id] = {
                'task_name': task_name,
                'input_text': input_text if self.use_bridge else None,
                'api_name': best_api['api_name'],
                'ncf_score': best_api['score'],
                'vocab_coverage': best_api['vocab_coverage'],
                'candidates': recommendations
            }

            print(f"      词汇覆盖: {best_api['vocab_coverage']:.0%}")
            print(f"      → {best_api['api_name']} (NCF分数: {best_api['score']:.4f})")
            print(f"      候选: {[r['api_name'] for r in recommendations[1:4]]}")

        result["api_bindings"] = api_bindings

        result["statistics"] = {
            "num_tasks": len(tasks),
            "num_unique_apis": len(used_apis),
            "api_diversity": f"{len(used_apis)}/{len(tasks)}",
            "unique_apis": sorted(list(used_apis)),
            "promoai_used": result["promoai_used"],
        }

        print(f"\n  📊 API多样性: {result['statistics']['api_diversity']}")
        print(f"  📊 使用的API: {result['statistics']['unique_apis']}")

        return result

    def _simple_parse(self, text: str) -> List[Dict]:

        tasks = []
        keywords = ['clarify', 'invite', 'select', 'write', 'take', 'package', 'prepare',
                   'ship', 'send', 'create', 'get', 'search', 'book', 'store', 'upload']

        sentences = text.replace('\n', ' ').split('.')
        task_id = 1

        for sentence in sentences:
            sentence = sentence.strip()
            if len(sentence) > 10:
                for keyword in keywords:
                    if keyword in sentence.lower():
                        words = sentence.lower().split()
                        if keyword in words:
                            idx = words.index(keyword)
                            phrase = ' '.join(words[max(0, idx):min(len(words), idx+5)])
                            tasks.append({'id': f'activity_{task_id}', 'name': phrase})
                            task_id += 1
                            break

        return tasks if tasks else [{'id': 'activity_1', 'name': text[:50]}]

    def print_result(self, result: Dict):

        print("\n" + "=" * 60)
        print("结果汇总")
        print("=" * 60)

        print(f"\n方法: {result['method']}")
        print(f"是否真正使用ProMoAI: {'是' if result.get('promoai_used') else '否（fallback，不应计入ProMoAI baseline统计）'}")
        if result.get("promoai_error"):
            print(f"ProMoAI失败原因: {result['promoai_error']}")
        print(f"语义桥接: {'是' if result['use_bridge'] else '否'}")

        print(f"\n活动节点 ({len(result['tasks'])} 个):")
        for task in result['tasks']:
            print(f"  - [{task['id']}] {task['name']}")

        print(f"\nAPI绑定:")
        for task_id, binding in result['api_bindings'].items():
            print(f"  [{task_id}] {binding['task_name'][:40]}...")
            print(f"      → {binding['api_name']} (NCF: {binding['ncf_score']:.4f}, 词汇覆盖: {binding['vocab_coverage']:.0%})")

        print(f"\n统计:")
        for key, value in result['statistics'].items():
            print(f"  - {key}: {value}")

    def save_result(self, result: Dict, output_path: str = None):

        if output_path is None:
            output_path = PROJECT_ROOT / "output_promoai_ncf_fair.json"

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, ensure_ascii=False, default=str)

        print(f"\n✓ 结果已保存: {output_path}")


def main():


    print("\n" + "=" * 60)
    print("对比实验配置")
    print("=" * 60)
    print(f"语义桥接: {'开启' if USE_SEMANTIC_BRIDGE else '关闭'}")
    print(f"额外领域知识: 无 (保证公平)")

    try:
        system = ProMoAI_NCF_Fair(
            api_key=DEEPSEEK_API_KEY,
            use_bridge=USE_SEMANTIC_BRIDGE
        )
    except FileNotFoundError as e:
        print(f"\n❌ 错误: {e}")
        return

    print("\n" + "=" * 60)
    print("用户请求")
    print("=" * 60)
    print(TEST_REQUEST.strip())

    result = system.process(TEST_REQUEST)

    system.print_result(result)

    system.save_result(result)

    print("\n" + "=" * 60)
    print("✓ 处理完成!")
    print("=" * 60)


if __name__ == '__main__':
    main()
