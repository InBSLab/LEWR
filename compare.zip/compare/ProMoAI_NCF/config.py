import os
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.absolute()

DATA_PATH = PROJECT_ROOT / "data"

EMBEDDING_PATH = PROJECT_ROOT / "embedding"

CHECKPOINT_PATH = PROJECT_ROOT / "checkpoints"

LOG_PATH = PROJECT_ROOT / "logs"

DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "")

DEEPSEEK_BASE_URL = "https://api.deepseek.com/v1"

DEEPSEEK_MODEL_NAME = "deepseek-chat"

NCF_CONFIG = {
    'embed_dim': 128,
    'max_doc_len': 100,
    'dropout': 0.2,
    'lr': 1e-3,
    'batch_size': 128,
    'epochs': 100,
    'early_stopping_patience': 7,
}

PROMOAI_CONFIG = {
    'max_retries': 3,
    'temperature': 0.3,
    'max_tokens': 4000,
}

DEFAULT_TEST_REQUEST = """
If goods shall be shipped, the secretary clarifies who will do the shipping.
If you have large amounts, special shipping will be necessary. In these cases
the secretary invites three logistic companies to make offers and she selects
one of them. In case of small amounts, normal post shipment is used.
Therefore a package label is written by the secretary and a parcel insurance
taken by the logistics department head if necessary. In the meantime the goods
can be already packaged by the warehousemen. If everything is ready, the
packaged goods are prepared for being picked up by the logistic company.
"""


def check_data_directory():

    required_files = [
        'api_name.json',
        'mashup_name.json',
        'mashup_description.json',
        'mashup_used_api.json',
        'mashup_category.json',
        'category_list.json'
    ]

    missing_files = []
    for file in required_files:
        if not (DATA_PATH / file).exists():
            missing_files.append(file)

    if missing_files:
        print("⚠️ Missing data files:")
        for file in missing_files:
            print(f"   - {file}")
        print(f"\nPlease copy data/ directory from AutoFlow_MTFM_Complete1.zip to {DATA_PATH}")
        return False

    return True


def ensure_directories():

    CHECKPOINT_PATH.mkdir(exist_ok=True)
    LOG_PATH.mkdir(exist_ok=True)
    EMBEDDING_PATH.mkdir(exist_ok=True)


if __name__ == '__main__':
    print("Configuration check...")
    ensure_directories()

    if check_data_directory():
        print("✓ All data files present")

    print(f"\nProject root: {PROJECT_ROOT}")
    print(f"Data path: {DATA_PATH}")
    print(f"Checkpoint path: {CHECKPOINT_PATH}")
